# Cypher Tool

GitHub araçlarını **tek linkle** kuran, eksiklerini tamamlayan ve hepsini tek bir uygulamadan çalıştıran Linux uygulaması. İçinde çoklu API destekli yapay zekâ ajanları da var.

## Kurulum

```bash
curl -fsSL https://raw.githubusercontent.com/Monq12/Cypher-Tool/main/kur.sh | bash
```
ya da zip'ten: `python3 -m zipfile -e cyphertool.zip . && bash cyphertool/kur.sh`

Kurulum betiği şunları yapar:
- Eksikse `python3` ve `git` paketlerini kurar.
- Uygulamayı `~/.local/share/cyphertool` klasörüne kopyalar.
- Menüye ve masaüstüne **Cypher Tool** kısayolunu ekler.
- `cyphertool` ve `ct` komutlarını oluşturur.
- Günlük güncelleme kontrolünü açar (systemd --user).

**Tek satırla kurulum (herhangi bir Linux'ta):**
```bash
curl -fsSL https://raw.githubusercontent.com/Monq12/Cypher-Tool/main/kur.sh | bash
```

## Kullanım

| Ne | Nasıl |
|---|---|
| Uygulamayı aç | Menü veya masaüstündeki **Cypher Tool**, ya da `cyphertool` |
| Terminalden kur | `ct https://github.com/sahip/proje` |
| Toplu kur | `ct link1 link2 link3` (uygulamada: Kur → her satıra bir link) |
| Listele / çalıştır | `cyphertool liste` · `cyphertool calistir <ad>` |
| Güncellemeler | `cyphertool kontrol` · `cyphertool guncelle` |
| Taşı | `cyphertool disa-aktar --tam` → diğer bilgisayarda `cyphertool ice-aktar dosya.tar.gz` |

## Özellikler

- **Link at, kurulsun.** GitHub reposu, kısa yazım (`sahip/proje`), rar/zip/7z/tar arşivi, AppImage veya yerel dosya kabul edilir.
  - README dosyaları okunur. Arşivlerin içindekiler de dahildir.
  - Kurulum planı çıkarılır ve **önce sana gösterilir**. İstersen düzenleyebilirsin.
- **Eksikleri kendisi tamamlar.**
  - Sistem paketleri dağıtıma göre kurulur (apt, dnf, pacman, zypper, apk).
  - Node.js 22 ve uv/Python **sudo'suz** olarak kendi klasörüne indirilir.
  - Koddaki `import` satırlarından eksik Python kütüphaneleri bulunur.
  - Kurulum hatasında "command not found" veya "No module named" mesajları yakalanır ve düzeltme önerilir.
  - Yapay zekâ bağlıysa hata çıktısı ona sorulur.
- **🩺 Doktor:** Kurulu bir aracı tarar (eksik kütüphane, bozuk .venv, eksik node_modules, kayıp çalıştırılabilir dosya) ve onarır.
- **Uygulama içinden çalıştırma.** Gerçek bir terminal (xterm) kullanılır, bu yüzden TUI araçlar da çalışır. İstersen ayrı terminal penceresinde de açabilirsin. Masaüstü kısayolları **repo logosuyla** oluşturulur.
- **📘 Türkçe rehber.** Her araç için ne işe yaradığı ve nasıl kullanıldığı yazılır. İngilizce veya başka dildeki README'ler Türkçeye çevrilir.
- **📚 Kütüphane:** GitHub tam adı, açıklama, yıldız, dil, lisans ve sürüm bilgileri.
- **🔑 Çoklu API.** OpenAI, Anthropic, Gemini, OpenRouter, Groq, Mistral, Cerebras, GitHub Models, DeepSeek, xAI, Ollama, LM Studio ve özel OpenAI uyumlu servisler desteklenir.
  - Bir API hata verirse sıradakine otomatik geçilir.
  - Anahtarlar kurulan araçlara ortam değişkeni olarak aktarılır.
- **🤖 Ajanlar.**
  - Her ajana ayrı API, model ve kişilik verilebilir.
  - Bir aracı bağlam olarak seçersen ajan o aracın README'sini bilir.
  - Ajanın önerdiği komutlar onayınla tek tıkla çalışır.
  - "Tüm ajanlara sor" seçeneği soruyu hepsine birden gönderir.
- **🆓 Ücretsiz AI.**
  - Ollama ile anahtarsız yerel modeller kurulabilir; donanımına göre öneri yapılır.
  - Anahtarsız uç noktalar canlı test edilir ve çalışanlar otomatik eklenir.
  - Ücretsiz anahtar veren servislerin listesi ve GitHub'daki ücretsiz API listeleri gösterilir.
- **🔄 Güncellemeler.** Her gün kontrol edilir. Her araç için mod ayrı seçilir: Sor, Otomatik veya Kapalı.
- **📦 Dışa/İçe aktar:** İki seçenek var: hafif `.json` (kaynaktan yeniden kurar) ya da tam `.tar.gz` (dosyalar dahil).
- **🔐 Yönetici şifresi.** sudo gerektiğinde uygulamada "şifreni gir" penceresi açılır.
  - Şifre yalnızca o adım için kullanılır, hiçbir yere kaydedilmez.
  - İstersen sistemin kendi parola penceresi (pkexec) de kullanılabilir.

## 🧠 Yapay Zekâ Merkezi ve 🌉 Köprü

- Uygulamadaki **her özellik** (sohbet, ajanlar, Görev Ajanı, hata çözücü, rehberler, kurulum analizi) aynı beyni kullanır.
- **🤖 Otomatik mod:** En hızlı çalışan API seçilir; hata olursa sıradakine geçilir. **📌 Sabit mod:** Seçtiğin API kullanılır.
- Her API için **✓ Kullan / ⏸ Kapat** ve **⭐ Öncelikli** düğmeleri vardır. İstersen her özelliğe ayrı API atayabilirsin.
- **🌉 Köprü:** Cypher Tool bilgisayarında `http://127.0.0.1:11500/v1` adresinde OpenAI uyumlu bir API açar. Arkasında senin bütün çalışan API'lerin vardır. Kurulu araçlar buna otomatik bağlanır (`OPENAI_BASE_URL`); başka programlar da adresi ve anahtarı kopyalayıp kullanabilir. Model adı: `otomatik`.
- **🖼️ Fotoğraf:** Sohbette ve Görev Ajanı'nda 📎 ile, `Ctrl+V` ile ya da sürükle-bırak ile fotoğraf gönderilebilir. Fotoğraf olunca görsel anlayan bir modele otomatik geçilir.

## 🎯 Görev Ajanı

Ne istediğini düz Türkçe yaz: *"İndirilenler'deki videoları mp3'e çevir"*, *"PDF birleştiren bir araç bul, kur ve dene"*, *"Terminalde hava durumunu gösteren bir araç yaz"*.

Ajan şu sırayla çalışır:
1. Önce kurulu araçlarına bakar.
2. Uygun araç yoksa GitHub'da arar, adayları karşılaştırır, en iyisini **kurar**, **dener** ve görevi o araçla **yapar**.
3. Uygun araç hiç yoksa kendi kodunu yazıp yeni bir araç **geliştirir**, test eder ve Cypher Tool'a ekler.

Ajan seninle konuşarak çalışır:
- Belirsiz bir yerde soru sorar.
- Bir aracı tanıyınca "Bu araçla şunları yapabilirim…" diye seçenekler sunar.
- Senin talimatına göre devam eder.

Beyni senin eklediğin API'lerden biridir; hangisini kullanacağını sen seçersin. İstersen Ajanlar sekmesindeki bir ajanın kişiliğini de ona giydirebilirsin.

**Ona öğretmek için:**
- **📜 Talimatlar:** Her görevde en yüksek öncelikle uyacağı kalıcı kurallar.
- **Sohbette öğretmek:** "bunu hatırla: …" ya da "bundan sonra hep …" dersen kalıcı tercih olarak kaydeder.
- **🧠 Hafıza:** Öğrendiği notları gör, ekle veya sil. Her oturum sonunda kendisi de ders çıkarıp buraya yazar.
- **Öğrenilmiş tarifler:** Başarıyla kurduğu araçların tarifleri saklanır; aynı araç bir dahaki sefere analiz edilmeden kurulur.

Varsayılan olarak her komut ve kurulum planı senin onayınla çalışır. "Komutları sormadan çalıştır" seçeneği açıksa planlar otomatik onaylanır; şifre ve sorular yine sorulur.
Terminalden de kullanabilirsin: `ct gorev "istediğin iş"`

## 🆕 Bu sürümde yeni

### 1.3.4 — internette gezinme, kapsamlı sınama ile sağlamlaştırıldı
- **🌐 + 💻 aynı anda:** 🌐 sekmesi açıkken ekran bölünür — üstte tarayıcı, altta konsol (ayırıcıyı sürükle). ⬒ ile tarayıcıyı büyüt, ✕ ile gizle; konsol sekmesi değiştirince tarayıcı açık kalır.
- **Arama motoru seçimi:** Google (varsayılan), Bing, DuckDuckGo, Startpage ya da kendi adresin.
- **Çerez izni sonrası aramaya döner:** Google'ın "devam etmeden önce" sayfasından sonra arama kaybolmaz.
- **Açılır pencereleri kapatır:** bülten / reklam pencereleri sayfanın üstünü kapatıyorsa yapay zekâ bunu görür, tıklamadan önce ✕/Kapat/Esc ile kendisi kapatır.
- **Web bileşenleri ve iç çerçeveler:** gölge DOM'daki ve iframe içindeki düğme/kutular da görülür, tıklanır, yazılır.
- **Sabit öğe numaraları:** aynı sayfada bir öğenin numarası değişmez (menü kapanınca yanlış yere tıklama olmaz).
- **Reklamları ayırt eder:** sponsorlu sonuçlar "REKLAM" diye işaretlenir, yapay zekâ organik sonuçları seçer.
- **Sayfa içeriğinin oturmasını bekler** (sonradan yüklenen içerik, "Yükleniyor…"), **gerçek fare tekerleğiyle kaydırır** (sonsuz kaydırma), kaydırınca ekrandaki kısmı okur.
- **Formlar:** seçim kutusu adı ve seçenekleri, işaret/radyo durumu (☑/☐) görünür. "Sepete ekle" serbest; "Satın al / Öde" sorulur; "Gönder/Paylaş" yalnızca mesaj/e-posta/gönderi yazılmışsa sorulur.
- **Uygulama içi görünümde** üzerine gelince açılan menüler çalışır (fare hareketi sayfaya iletilir).
- Düzeltmeler: sitenin kendi açtığı yeni sekmeler de 🌐 sekmesi olur; aynı sekmenin iki kez görünmesi, konsol açılış yazısının iki kez çıkması, adres çubuğundan gidince geri dönme hataları giderildi.

### 1.3.3
- **Arama kutuları daha sağlam:** düğmeye basınca açılan arama pencerelerine (GitHub, YouTube ve birçok modern site) doğru yazar; arka planda kalan sekmelerde de yazı kaybolmaz.
- **Açılamayan sayfayı anlar:** site yoksa, internet yoksa ya da sertifika hatası varsa yapay zekâ bunu fark eder, hata sayfasını okumaya çalışmaz, başka kaynağa geçer (sertifika hatalı sayfaya girmez).

### 1.3.2
- **🧩 İlk kurulumda her şey kurulur:** `kur.sh` temiz bir Linux'ta uygulamanın tüm özellikleri için gerekenleri kurar: Python venv/pip, derleyici, curl/wget/unzip/7z, git-lfs, bildirimler, masaüstü kontrolü (xdotool, wmctrl, scrot, Pillow) ve uygulama içi tarayıcı için **Google Chrome** (yoksa Chromium). Sadece eksikler kurulur; biri kurulamazsa kurulum durmaz, Sistem sekmesinden tekrar denenebilir.
- **🧩 Doğrulama çıkınca bekler:** robot doğrulaması gelince sesli uyarı + bildirim, ilgili 🌐 sekmesi açılır; sen "Ben robot değilim"e basınca yapay zekâ **kendiliğinden** devam eder (sohbete yazman gerekmez).
- **🔌 Hesaplar (Ayarlar):** **WordPress** (yazı/sayfa/yorum/eklenti — uygulama parolasıyla), **Meta reklamları** (kampanya, reklam seti, rapor — Marketing API v26) ve **Google Ads** (kampanya raporları, durdur/başlat, bütçe — API v26, "🔑 Google ile bağlan"). Okuma serbest; **para harcatan, yayınlayan, silen her işlem sağ altta sorulur** (tam otomatikte bile); yeni içerik taslak, yeni reklamlar duraklatılmış oluşturulur. Hesap bağlamadan da olur: uygulama içi tarayıcıda giriş yaparsın, yapay zekâ oradan yönetir.

### 1.3.1 — gezinme sağlamlaştırması
- **🍪 Çerez / izin pencereleri kendiliğinden kapanır** (varsayılan "Tümünü reddet"; Google/YouTube AB izin sayfası dahil). Ayarlar → Otomatik işler'den "kabul et" ya da "dokunma" seçilebilir.
- **Normal Chrome gibi görünür:** görünmez tarayıcı kendini "HeadlessChrome" olarak tanıtmaz, dil Türkçe — siteler daha az "robot musun?" sorar.
- **🧩 Doğrulama (CAPTCHA) çıkarsa** sağ altta kart çıkar; sen 🌐 sekmesinde çözersin, yapay zekâ bekleyip devam eder (doğrulamayı kendisi çözmeye çalışmaz).
- **Yeni sekmede açılan bağlantılar** aynı 🌐 sekmesinde açılır; **uyarı pencereleri (alert)** sayfayı dondurmaz; **indirilen dosyalar** İndirilenler klasörüne gider.
- **− / + yakınlaştırma:** dar panelde siteler masaüstü görünümüyle sığar (varsayılan dar panelde %80).
- Uygulama yeniden açılınca **açık 🌐 sekmeleri geri gelir.**

### 1.3.0
- **🌐 Tarayıcı uygulamanın içinde:** Google ve siteler artık ayrı pencerede değil, Konsol'daki 🌐 sekmesinde açılır (adres çubuğu, geri/ileri, tıkla, kaydır, yaz, Türkçe karakter, yapıştır). Yapay zekâ arama yaparken orada canlı izlersin; sohbet paneli yanında açık kalır.
- **🤖 Yapay zekâ tarayıcıda kendisi yapar:** yazar, arar, tıklar, sayfalara girer; nereye basacağından emin değilse ekran görüntüsü alıp (numaralı kutularla) görsel modelle bakar. Sadece ödeme / gönderme / silme gibi geri alınamaz adımlarda sağ alttaki kartla sorar; şifre ve kart alanlarına asla yazmaz.
- **🖥 Masaüstü kontrolü:** yapay zekâ masaüstündeki uygulamaları açıp kullanabilir (koordinat ızgaralı ekran görüntüsü + fare/klavye, xdotool). Çalışırken sağ altta "⏹ Durdur" kartı görünür. (X11/Xorg oturumu gerekir; Wayland'de giriş ekranından "Ubuntu on Xorg" seç.)
- **📚 Öğrenen hafıza:** araştırdıklarını (web sayfaları, YouTube videolarının altyazı özetleri) bilgi hafızasına yazar, benzer görevde önce bunları hatırlar. Sohbet ⚙ menüsünde "📚 Öğrendiklerim".
- **📺 YouTube'dan öğrenme:** "YouTube'da X anlatan video bul ve özetle" dersen videonun altyazısını okuyup Türkçe özet ve öğrenilenleri çıkarır.
- **🎓 Önce öğren, sonra kullan:** bir aracı ya da uygulamayı ilk kez kullanmadan önce README'yi, web kaynaklarını ve gerekirse bir videoyu inceleyip öğrenir; sonra sana ne işe yaradığını anlatır.

### 1.2.9
- **⏸ Aktif / pasif araçlar:** Konsol listesinde ☑ ile araç seç → "✔ Sadece bunlar aktif" / "⏸ Pasif yap". Pasif araçlar kendiliğinden hiçbir şey başlatmaz (izleme, otomatik onarım, güncelleme yok), çalışıyorsa durdurulur, listede aşağıda "Pasif araçlar" bölümünde durur.
- **🧩 Hangi araç hangi konsolda:** her araç kendi sekmesinde açılır (varsayılan). İstersen seçtiğin araçları "🧩 Tek konsolda topla" ile bir grup konsolunda birleştir: konsolun üstünde her biri için ▶ düğmesi olur, yapay zekâ o sekmede önce bu araçları kullanır. Aracın ⚙ menüsünden de ayarlanır.
- **📖 Araca tıkla → yapay zekâ anlatsın:** listeden bir araca tıklayınca araç kendi konsolunda açılır, yapay zekâ önce ne işe yaradığını, neler yaptığını ve nasıl kullanıldığını anlatır, öneriler verir. Ayrı iş için ＋ ile yeni konsol aç.
- **🔔 Büyük pencereler yerine sağ altta küçük bildirim:** onarım, onay ve şifre istekleri yarı saydam bir kartta çıkar (✔ Onayla / ✖ / 🔍 Ayrıntı / ✕ kapat). Onarım arka planda sürer, bitince kart kendiliğinden kapanır.
- **🤖 Tam otomatik onarım:** yapay zekâ bağlıyken onarım onay sormadan çalışır. Önce hata mesajının önerdiği komut denenir (ör. "Run `… setup`"), sonra kurulu tüm API'ler ve modeller sırayla dener; takılan model sıradakine devreder. Tehlikeli komutlar engellenir, başarısız onarım aynı araç için 20 dakika tekrar başlamaz.
- **💻 Yerel ağır kurulumlar sorulur:** Ollama, yerel model indirme, llama.cpp gibi bilgisayarı yoran işlerde önce sana sorar. "🚫 Hayır, bir daha sorma" dersen bir daha sorulmaz, yapılmaz.
- **🔐 Şifre isteyen uygulamalar:** bir uygulama (sudo vb.) şifre isterse sağ altta hangi uygulamanın istediğini gösteren kart çıkar; şifre doğrudan o uygulamaya gider, hiçbir yere kaydedilmez.
- **⚙️ Ayarlar → Otomatik işler:** neyin kendiliğinden çalışacağı tek yerde (tıklayınca yapay zekâ, açılan programları izleme, API yarıştırma, tam otomatik onarım, hata çıkınca onarım, yerel kurulum izni, konsol yerleşimi).

- **💻 Yeni Konsol sayfası (tek ekran):**
  - Solda sade bir liste: en üstte Google Chrome, sonra Cypher ile kurduğun araçlar, sonra diskte bulunan GitHub depoların. Linux'un kendi programları listede görünmez; yapay zekâ onları yine kullanabilir.
  - Ortada her zaman açık konsol, sağda sohbet paneli. Konsolun hemen altında ince bir mesaj kutusu var; yapay zekâya oradan yazarsın.
  - Sayfa aşağı kaymaz. Pencereyi büyütünce konsol ve sohbet büyür, liste sabit kalır.
  - Aradaki çizgileri fareyle sürükleyerek genişlikleri ayarlayabilirsin; çift tıklayınca sıfırlanır.
  - Görev kayıtları artık ayrı pencerede açılır, konsol hep yerinde kalır. Uygulama içinde çalışan araçlar konsolun yanında sekme olarak görünür.
- **📋 "Hangi araçlarım var?":** Yapay zekâya sorduğunda tüm araçlarını (Cypher ile kurulanlar + diskteki GitHub depoları) kategorilere ayırıp her birinin ne işe yaradığını ve öne çıkan özelliklerini özetler. Açıklaması eksik olanları README'sini okuyarak öğrenir, çalışmayanları ⚠ ile belirtir. Tek bir aracı sorarsan ayrıntılı anlatır. Konsoldaki listenin üstündeki **📋** düğmesi bunu tek tıkla sorar.
- **🏁 Araç yarışması:** "GitHub'da şu özellikte araç bul, dene, en iyisini kur" de ya da konsoldaki listenin üstündeki **🏁** düğmesine bas. Adımlar:
  1. Kurulu tüm API'ler aynı anda GitHub arama sorguları ve bildikleri depoları önerir; adaylar toplanır.
  2. Yıldız, son güncelleme, arşiv durumu ve lisansa göre ön elemeden geçerler.
  3. Tüm API'ler README'leri okuyup isteğine en uygunlara oy verir.
  4. En öndeki adaylar (varsayılan 3) kurulur. Kurulum öncesi güvenlik taramasında tehlikeli bulgusu çıkan aday elenir.
  5. Her aday, senin istediğin özellikle güvenli bir testten geçer; test sadece yerel ve zararsız girdiler kullanır. Çıktıyı API'ler 0–10 arası puanlar.
  6. Sonuç tablo halinde gelir. Kazanan kurulu kalır; kaybedenleri kaldırmak için sana sorulur ya da istersen sormadan kaldırılır.
- **🧠 Her araç için en iyi yapay zekâ:** Konsolda bir aracı ilk açtığında kurulu tüm API'lere o araca özel aynı küçük görev verilir: aracın gerçek seçenekleriyle doğru komut yazmak. Geçerli cevap, belgeye uygunluk ve hız puanlanır, en iyisi o araç için seçilir. Sonra her oturumda hangi API'nin işi bitirdiği ve kaç hata yaptığı kaydedilir; sıralama kullandıkça gerçek sonuçlara göre değişir. API seçimi varsayılan olarak **🤖 Otomatik**; ⚙ menüsünden bir API'yi sabitlersen o kullanılır. Aracın ⚙ ayarlarında puan tablosu ve **🔄 Yeniden yarıştır** düğmesi var; ⓘ kartında "🧠 En iyi beyin" yazar.
- **🔍 Görünüm ve okunabilirlik (Ayarlar):** Uygulamanın ölçeği (yazılar, düğmeler, boşluklar birlikte) %80–%200 arasında ayarlanır. Hazır düğmeler (Otomatik, %90 … %175) ve bir sürgü var; "Otomatik" ekran büyüklüğüne göre okunaklı bir değer seçer. Kısayollar: **Ctrl + +** büyüt, **Ctrl + -** küçült, **Ctrl + 0** otomatik. Konsol yazı boyutu ayrıca ayarlanır; **Yüksek kontrast** soluk yazıları belirginleştirir. Ayarlar bilgisayarda hatırlanır ve sadece uygulamanın görünümünü değiştirir, işletim sisteminin ekran ayarlarına dokunmaz.
- **🛠 Ajanla onar (yenilendi):** Düğmeye basınca onarım konsolda, gözünün önünde ve **sormadan** başlar; yönetici şifresi yine sorulur, tehlikeli komutlar yine elenir. Önce hata tüm API'lere birden sorulur. Olmazsa yapay zekâ internette araştırır: GitHub konuları, Stack Overflow ve resmi belgeleri okuyup çözümü öğrenir. Hazır çözüm yoksa eksik dosyayı ya da kodu kendisi yazar, uyumsuz kodu düzeltir; son çare olarak aynı işi yapan küçük bir araç üretir. Başaramazsa iş sıradaki API'ye geçer.
- **🧠🧠 Çok beyinli onarım:** Bir kurulum ya da araç hata verince önce bilgi bankasındaki çözüm denenir. Olmazsa hata **kurulu tüm API'lere aynı anda** sorulur; öneriler (kaç API aynı çözümde birleşti, güvenleri, bu araçtaki geçmiş başarıları) puanlanıp en iyisinden başlayarak denenir. O da tutmazsa onarım ajanı en iyi API ile çalışır; başaramazsa önceki denemelerin özetiyle **sıradaki API'ye devreder**, araç çalışana kadar (en fazla 5 API). Bulunan çözüm bilgi bankasına kaydedilir; aynı hata bir dahakine anında çözülür.
- **ⓘ Bilgi kartları:** Araçlarım sayfasındaki her kartta ve konsoldaki listede küçük bir **i** düğmesi var. Fareyle üzerine gelince aracın ne işe yaradığı, öne çıkan özellikleri, kategorisi ve durumu görünür; tıklayınca Türkçe rehberi açılır. Açıklaması eksik araçlar için Araçlarım sayfasındaki **🧠 Açıklamaları tamamla** düğmesine basınca yapay zekâ hepsini tek tek inceleyip doldurur.
- **🛠 Açılamazsa otomatik onarım:** Bir araç ya da uygulama açılamazsa (çalıştırma komutu yok, kurulum hatalı, uygulama açılmıyor) yapay zekâ hemen konsolda onarmaya başlar, sonra aracı çalıştırır.
- **✨ Araç geliştirme:** Araç kartındaki **✨ Geliştir** düğmesi (konsoldaki araç listesinde ve depo bilgi penceresinde de var). Dört seçenek sunar:
  - **💡 Bana yeni özellikler öner:** Yapay zekâ aracı, kodunu ve GitHub'daki kullanıcı isteklerini (issues) inceler. "İstersen şunları ekleyebilirim" diye somut önerilerle sana sorar ve seçtiğini ekler.
  - **🩺 Çalışmayan özellikleri bul ve onar:** README'deki özellikleri tek tek dener. Bozuk olanların nedenini kodda bulur, internette araştırır, düzeltir ve yeniden dener.
  - **✍️ İstediğim özelliği ekle:** Ne istediğini yazarsın. Kodu okur, gerekirse resmi belgelerden ve örneklerden öğrenir, özelliği ekler, test eder ve README'ye yazar.
  - **🐞 Şu çalışmıyor:** Sorunu yazarsın. Yeniden üretir, kök nedenini bulur ve düzeltir.
  - Her iş bitince **"Şu özellikleri de ekleyebilirim"** diye yeni öneriler sunar. Otomatik onarım da artık gerekirse aracın kodunu düzeltebilir.
- **🛡️ Geliştirmeler güvenli ve geri alınabilir:**
  - Tüm değişiklikler aracın klasöründe **`cypher-gelistirme`** adlı ayrı bir git dalında tutulur; orijinal hal korunur.
  - Her çalışan adım ayrı kaydedilir. **🕘 Geliştirme geçmişi**'nden tek tek **↩ geri al**abilir ya da tek tıkla **orijinal sürüme dönüp** sonra geri gelebilirsin.
  - Kod değişiklikleri (Sormadan çalıştır kapalıyken) önce renkli fark gösterimiyle onayına gelir.
  - Araç güncellenince orijinalin yeni sürümü alınır ve **senin geliştirmelerin onun üstüne yeniden uygulanır**. Çakışma olursa hiçbir şey değişmez ve sana söylenir.
  - Hiçbir şey GitHub'a gönderilmez.
- **🔎 Araştırmayı Chrome'da göster:** Açıkken yapay zekânın internet aramaları **Google'da, ekranda görebileceğin bir Chrome penceresinde** yapılır ("🔎 Araştırma" penceresi). Okuduğu sayfalar da aynı pencerede açılır; ne aradığını ve neyi okuduğunu canlı izlersin.
  - Anahtar Görev Ajanı, Konsol yapay zekâsı ve ✨ Geliştir penceresinde var; varsayılan olarak açık.
  - Google ilk kullanımda çerez onayı isterse yapay zekâ "Tümünü kabul et"e tıklamak için sana sorar.
  - Google robot kontrolü isterse pencerede kendin çözebilirsin; o sırada arama yedek motorla devam eder.
- **🗂️ Çoklu konsol sekmeleri:** Konsolun üstündeki **＋ Yeni sekme** ile istediğin kadar konsol aç. Her sekmenin kendi yapay zekâ sohbeti vardır; bir sekmede araç çalışırken diğerinde yapay zekâ başka iş yapabilir. Sekme adını değiştirmek için çift tıkla. Sekmedeki 🤖 ve renkli nokta, orada yapay zekânın çalıştığını (mor) ya da cevabını beklediğini (sarı) gösterir.
- **📜 Tarifler (oturumu kaydet → tekrar oynat):** Yapay zekâ bir işi başarıyla yaptıktan sonra **💾 Tarif kaydet** ile adımlarını (komutlar, konsola yazılanlar, kurulumlar, tarayıcı adımları) kaydet. **📜 Tarifler**'den:
  - **▶ Aynen:** Kaydedilen adımlar sırayla tekrar çalışır (önce listeyi onaylarsın). Bir adım takılırsa yapay zekâ kaldığı yerden devralabilir.
  - **🤖 Uyarla:** Yapay zekâ tarifi rehber alıp bugünkü duruma ve yazdığın değişikliğe göre yapar (ör. "bu sefer ~/Belgeler klasörü için").
- **⚡ Komut geçmişinden kısayol:** Konsolda aynı komutu sık yazarsan (varsayılan 3+ kez) "Kısayol yapayım mı?" diye sorar. Kısayollar konsolun üstünde düğme olur; istersen **kısa ad (alias)** da verirsin, konsolda onu yazman yeter. Şifre/anahtar içeren komutlar önerilmez; yapay zekânın çalıştırdığı komutlar geçmişe yazılmaz.
- **🐙 Depo bilgisi, güven puanı ve karşılaştırma (GitHub sekmesi):** Her deponun yanındaki **ℹ** düğmesi: yerel durum (dal, son commit, kaydedilmemiş değişiklik), uzakta yeni commit var mı, GitHub bilgileri (yıldız, son güncelleme, arşiv, lisans), kurulum öncesi taramayla aynı **güvenlik taraması** ve bunlardan hesaplanan **0–100 güven puanı**. İstersen bulguları yapay zekâya da inceletebilirsin. **⬆ Güncelle** `git pull --ff-only` yapar (kaydedilmemiş değişikliklerin varsa önce `git stash` ile korunur). **🔍 Güncellemeleri kontrol et** hepsini birden tarar; **⚖️ Karşılaştır** ile depoları seçip yan yana tablo ve yapay zekâ önerisi alırsın.
- **➕ Cypher'a ekle:** Diskte zaten kurulu bir depoyu yerinden oynatmadan Cypher Tool'a ekler: araç kartı, güncelleme takibi, Türkçe rehber ve kısayol. (Kaldırırsan sadece kaydı silinir, klasörüne dokunulmaz.)
- **🧭 Görsel tarayıcı kontrolü (çoklu pencere):** Yapay zekâ kendi kontrol ettiği tarayıcıda (Chrome/Chromium/Brave/Edge) **aynı anda birden fazla pencere** açar, hepsini birlikte okur, sayfalarda **tıklar, yazar, listeden seçer, kaydırır**, ekran görüntüsüne bakar.
  - **Her tıklama ve yazma önce sana sorulur**, "Sormadan çalıştır" açık olsa bile. Onay penceresinde işlem yapılacak yer kırmızı çerçeveyle gösterilir.
  - Şifre, kart numarası ve doğrulama kodu alanlarına yapay zekâ **asla yazmaz**; onları pencerede kendin girersin.
  - Bu tarayıcının kendi profili vardır (`~/CypherTool/tarayici/profil`); giriş yaptığın siteler orada hatırlanır, kendi Chrome'una dokunulmaz.
  - Açık pencereler konsol sayfasının solundaki **🌐 Tarayıcılar** listesinde görünür (📸 ile anlık görüntü, ✖ ile kapat, ＋ ile elle aç). Ekran yoksa görünmez modda çalışır.
- **💻 Konsol + 🤖 Konsol Yapay Zekâsı (Görevler & Konsol sayfası):** Sayfa açılınca gerçek bir Bash konsolu açılır. Altındaki sohbet kutusuna ne istediğini yaz; yapay zekâ komutları **bu konsolda** çalıştırır (canlı görürsün), etkileşimli programlara yazar (`type_keys`), ekranı okur (`read_screen`), Google'da arar ve siteleri tarayıcıda açar (`open_browser`). Yapay zekâ konsolun o anki klasöründe çalışır. "Sormadan çalıştır" kapalıyken her komut ve tarayıcı açma önce onayına gelir. **$ Komut** düğmesi kutudaki metni yapay zekâya sormadan doğrudan konsola yazar.
- **🧰 Araçlar listesi (konsolun solunda):** Dört sekme var: *Cypher* (Cypher Tool ile kurduklarım), *🐙 GitHub* (bilgisayarda `git clone` ile zaten kurulu depolar: ev klasörü, `/opt`, `/usr/local/src`, `/srv` taranır), *Programlar* (PATH'teki komutlar) ve *Uygulamalar*. Bir araca tıklayınca konsolda açılır, yapay zekâ README'yi okuyup o araçla neler yapabileceğini anlatır ve kullanır. **▶** ise yapay zekâsız, sadece çalıştırır. Taranacak ek klasörleri `~/.config/cyphertool/config.json` içine `"repo_dirs": ["~/baska/klasor"]` olarak ekleyebilirsin.
- **🛡️ Kurulum öncesi güvenlik taraması:** Depo kurulmadan önce zararlı kalıplara (ters kabuk, madenci, gizlenmiş kod, şifre dosyalarına erişim vb.) karşı taranır; tehlikeli bulgu varsa kurulum planında en üstte kırmızı uyarı çıkar.
- **📘 Yapay zekâ ayrıntılı Türkçe belge yazar:** Yeni kurulan her araç için README ve aracın kendi `--help` çıktısı okunur; *Ne işe yarar, Özellikleri, Nasıl çalışır, Komutlar, Örnekler, Görev Ajanı'na örnek istekler* bölümleriyle Rehber oluşturulur. Görev Ajanı aracı "tanır" ve sonra kendisi kullanabilir.
- **🤖 "Yapay zekâ kendisi kursun" seçeneği** (Kur sayfası): plan onaylatılmadan kurulur, hata çıkarsa kendisi çözer (yönetici şifresi yine sorulur).
- **🎯 Görev Ajanı daha akıllı:** GitHub'da en az 3 adayı karşılaştırıp en güncel ve çalışanı seçer, çalışmayanı (onayınla) kaldırır; hata alınca hemen internette çözüm arar; bilgisayarın ayar pencerelerini açabilir (ses, ağ, ekran…); tarayıcıyı açıp Google'da arama yapabilir; JavaScript'li sayfaları gerçek tarayıcıyla okuyabilir.

## Hazır katalog (test edilmiş tarifler)

deep-research (drsh), Flint Agent, clai (pentoshi007), clai (baalimago), gptme, OpenSquilla, ARIA, Aider, Local Deep Research, Open WebUI.

## Güvenlik

- Hiçbir komut onayın olmadan çalışmaz. Riskli komutlar (`curl | sh`, `rm -rf /` vb.) ayrıca işaretlenir.
- Arayüz sadece `127.0.0.1` adresinde çalışır ve her istek oturuma özel rastgele bir anahtarla korunur.
- Release dosyalarının SHA256 sağlaması mümkün olduğunda doğrulanır.
- API anahtarları `~/.config/cyphertool/` altında yalnızca senin okuyabileceğin dosyalarda (izin 600) tutulur.

## Klasörler

- `~/CypherTool/tools/`: kurulan araçlar
- `~/CypherTool/runtimes/`: sudo'suz Node.js, uv ve Python
- `~/CypherTool/exports/`: dışa aktarımlar
- `~/.config/cyphertool/`: ayarlar, API'ler, araç kayıtları

Gereksinimler: Linux, Python 3.9+, git. Arayüz için Chromium, Chrome, Brave veya Firefox önerilir; uygulama penceresi gibi açılır.
Windows'ta WSL2 (Ubuntu) içinde çalışır.
