# Cypher Tool

GitHub araçlarını **tek linkle** kuran, eksiklerini tamamlayan ve hepsini tek bir uygulamadan çalıştıran Linux uygulaması. İçinde çoklu API destekli yapay zekâ ajanları da var.

## Kurulum

```bash
curl -fsSL https://raw.githubusercontent.com/Monq12/Cypher-Tool/main/kur.sh | bash
```
ya da zip'ten: `python3 -m zipfile -e cyphertool.zip . && bash cyphertool/kur.sh`

Kurulum betiği şunları yapar:
- Eksikse `python3` ve `git` paketlerini kurar.
- Uygulamayı `~/.local/share/cyphertool` klasörüne kopyalar.
- Menüye ve masaüstüne **Cypher Tool** kısayolunu ekler.
- `cyphertool` ve `ct` komutlarını oluşturur.
- Günlük güncelleme kontrolünü açar (systemd --user).

**Tek satırla kurulum (herhangi bir Linux'ta):**
```bash
curl -fsSL https://raw.githubusercontent.com/Monq12/Cypher-Tool/main/kur.sh | bash
```

## Kullanım

| Ne | Nasıl |
|---|---|
| Uygulamayı aç | Menü veya masaüstündeki **Cypher Tool**, ya da `cyphertool` |
| Terminalden kur | `ct https://github.com/sahip/proje` |
| Toplu kur | `ct link1 link2 link3` (uygulamada: Kur → her satıra bir link) |
| Listele / çalıştır | `cyphertool liste` · `cyphertool calistir <ad>` |
| Güncellemeler | `cyphertool kontrol` · `cyphertool guncelle` |
| Taşı | `cyphertool disa-aktar --tam` → diğer bilgisayarda `cyphertool ice-aktar dosya.tar.gz` |

## Özellikler

- **Link at, kurulsun.** GitHub reposu, kısa yazım (`sahip/proje`), rar/zip/7z/tar arşivi, AppImage veya yerel dosya kabul edilir.
  - README dosyaları okunur. Arşivlerin içindekiler de dahildir.
  - Kurulum planı çıkarılır ve **önce sana gösterilir**. İstersen düzenleyebilirsin.
- **Eksikleri kendisi tamamlar.**
  - Sistem paketleri dağıtıma göre kurulur (apt, dnf, pacman, zypper, apk).
  - Node.js 22 ve uv/Python **sudo'suz** olarak kendi klasörüne indirilir.
  - Koddaki `import` satırlarından eksik Python kütüphaneleri bulunur.
  - Kurulum hatasında "command not found" veya "No module named" mesajları yakalanır ve düzeltme önerilir.
  - Yapay zekâ bağlıysa hata çıktısı ona sorulur.
- **🩺 Doktor:** Kurulu bir aracı tarar (eksik kütüphane, bozuk .venv, eksik node_modules, kayıp çalıştırılabilir dosya) ve onarır.
- **Uygulama içinden çalıştırma.** Gerçek bir terminal (xterm) kullanılır, bu yüzden TUI araçlar da çalışır. İstersen ayrı terminal penceresinde de açabilirsin. Masaüstü kısayolları **repo logosuyla** oluşturulur.
- **📘 Türkçe rehber.** Her araç için ne işe yaradığı ve nasıl kullanıldığı yazılır. İngilizce veya başka dildeki README'ler Türkçeye çevrilir.
- **📚 Kütüphane:** GitHub tam adı, açıklama, yıldız, dil, lisans ve sürüm bilgileri.
- **🔑 Çoklu API.** OpenAI, Anthropic, Gemini, OpenRouter, Groq, Mistral, Cerebras, DeepSeek, xAI, Ollama, LM Studio ve özel OpenAI uyumlu servisler desteklenir.
  - Bir API hata verirse sıradakine otomatik geçilir.
  - Anahtarlar kurulan araçlara ortam değişkeni olarak aktarılır.
- **🤖 Ajanlar.**
  - Her ajana ayrı API, model ve kişilik verilebilir.
  - Bir aracı bağlam olarak seçersen ajan o aracın README'sini bilir.
  - Ajanın önerdiği komutlar onayınla tek tıkla çalışır.
  - "Tüm ajanlara sor" seçeneği soruyu hepsine birden gönderir.
- **🆓 Ücretsiz AI.**
  - Ollama ile anahtarsız yerel modeller kurulabilir; donanımına göre öneri yapılır.
  - Anahtarsız uç noktalar canlı test edilir ve çalışanlar otomatik eklenir.
  - Ücretsiz anahtar veren servislerin listesi ve GitHub'daki ücretsiz API listeleri gösterilir.
- **🔄 Güncellemeler.** Her gün kontrol edilir. Her araç için mod ayrı seçilir: Sor, Otomatik veya Kapalı.
- **📦 Dışa/İçe aktar:** İki seçenek var: hafif `.json` (kaynaktan yeniden kurar) ya da tam `.tar.gz` (dosyalar dahil).
- **🔐 Yönetici şifresi.** sudo gerektiğinde uygulamada "şifreni gir" penceresi açılır.
  - Şifre yalnızca o adım için kullanılır, hiçbir yere kaydedilmez.
  - İstersen sistemin kendi parola penceresi (pkexec) de kullanılabilir.

## 🧠 Yapay Zekâ Merkezi ve 🌉 Köprü

- Uygulamadaki **her özellik** (sohbet, ajanlar, Görev Ajanı, hata çözücü, rehberler, kurulum analizi) aynı beyni kullanır.
- **🤖 Otomatik mod:** En hızlı çalışan API seçilir; hata olursa sıradakine geçilir. **📌 Sabit mod:** Seçtiğin API kullanılır.
- Her API için **✓ Kullan / ⏸ Kapat** ve **⭐ Öncelikli** düğmeleri vardır. İstersen her özelliğe ayrı API atayabilirsin.
- **🌉 Köprü:** Cypher Tool bilgisayarında `http://127.0.0.1:11500/v1` adresinde OpenAI uyumlu bir API açar. Arkasında senin bütün çalışan API'lerin vardır. Kurulu araçlar buna otomatik bağlanır (`OPENAI_BASE_URL`); başka programlar da adresi ve anahtarı kopyalayıp kullanabilir. Model adı: `otomatik`.
- **🖼️ Fotoğraf:** Sohbette ve Görev Ajanı'nda 📎 ile, `Ctrl+V` ile ya da sürükle-bırak ile fotoğraf gönderilebilir. Fotoğraf olunca görsel anlayan bir modele otomatik geçilir.

## 🎯 Görev Ajanı

Ne istediğini düz Türkçe yaz: *"İndirilenler'deki videoları mp3'e çevir"*, *"PDF birleştiren bir araç bul, kur ve dene"*, *"Terminalde hava durumunu gösteren bir araç yaz"*.

Ajan şu sırayla çalışır:
1. Önce kurulu araçlarına bakar.
2. Uygun araç yoksa GitHub'da arar, adayları karşılaştırır, en iyisini **kurar**, **dener** ve görevi o araçla **yapar**.
3. Uygun araç hiç yoksa kendi kodunu yazıp yeni bir araç **geliştirir**, test eder ve Cypher Tool'a ekler.

Ajan seninle konuşarak çalışır:
- Belirsiz bir yerde soru sorar.
- Bir aracı tanıyınca "Bu araçla şunları yapabilirim…" diye seçenekler sunar.
- Senin talimatına göre devam eder.

Beyni senin eklediğin API'lerden biridir; hangisini kullanacağını sen seçersin. İstersen Ajanlar sekmesindeki bir ajanın kişiliğini de ona giydirebilirsin.

**Ona öğretmek için:**
- **📜 Talimatlar:** Her görevde en yüksek öncelikle uyacağı kalıcı kurallar.
- **Sohbette öğretmek:** "bunu hatırla: …" ya da "bundan sonra hep …" dersen kalıcı tercih olarak kaydeder.
- **🧠 Hafıza:** Öğrendiği notları gör, ekle veya sil. Her oturum sonunda kendisi de ders çıkarıp buraya yazar.
- **Öğrenilmiş tarifler:** Başarıyla kurduğu araçların tarifleri saklanır; aynı araç bir dahaki sefere analiz edilmeden kurulur.

Varsayılan olarak her komut ve kurulum planı senin onayınla çalışır. "Komutları sormadan çalıştır" seçeneği açıksa planlar otomatik onaylanır; şifre ve sorular yine sorulur.
Terminalden de kullanabilirsin: `ct gorev "istediğin iş"`

## 🆕 Bu sürümde yeni

### 1.49.0 — 🧠 En iyi IP aracını öner → tek tuşla kur & otomatik ayarla + 10 sn'de bir denetim
- **🧠 En iyisini öner:** AI + beyin GitHub'daki IP/Tor/proxy araçlarını puanlar (yıldız·güncellik·orijinal·lisans) ve **en iyi + en güncel + en sorunsuz** olanı önerir; neden onu seçtiğini de yazar.
- **⬇ Bunu kur ve tüm IP/proxy'yi ayarla:** Tek tuş. Ajan aracı kurar, IP aracı olarak işaretler, **başlatır, proxy'yi bağlar ve anonim modu açar** — bütün IP/proxy ayarını otomatik yapar. Takılırsa AI + 🧠 beyin devreye girip onarır.
- **Her 10 saniyede bir denetim:** Panelin üstünde canlı bir durum satırı — her şey yolundaysa **"✅ Anonimsin — her şey yolunda"**, sorun varsa ne olduğunu yazar (**sızıntı / çıkış IP yok / proxy kapalı**) ve **AI + beyin otomatik çözmeye** başlar (taşmaması için en çok 90 sn'de bir).

### 1.48.0 — 🌍 IP paneli: başlığı "IP görüntüle", kurulu araçları otomatik bulma, çalışan başlat düğmesi
- Sol üstteki rozet artık IP adresini yazmıyor; sadece **"🌍 IP görüntüle"** diyor. IP'ler panelin içinde açılınca görünür.
- **Kurulu IP/Tor/proxy araçları otomatik bulunuyor:** uygulama yüklü araçları tarayıp IP aracı olanları kendiliğinden işaretler ve panelde listeler (🟢 bağlı · 🟡 çalışıyor · ⚪ kapalı), varsayılan proxy adresini de atar.
- **▶ Başlat & bağla** düğmesi artık gerçekten çalışıyor: aracı başlatır, proxy portu açılınca çıkış IP'sini ona bağlar. Açılmazsa **AI + 🧠 beyin** devreye girip başlatmayı/onarmayı dener.
- Onarım/arama artık net biçimde **sadece IP araçları** için: "🧠 AI/Beyin ile çöz (başlat · onar · değiştir)" düğmesi test eder, başlatır, onarır; olmazsa GitHub'dan en güncel IP aracını bulur.

### 1.47.0 — 💬 Karşı tarafa dürüst bilgi (bağlam) alanı
- Ajanı uygulamaya bağlarken artık bir **"Bağlam / doğru bilgiler"** alanı var. Karşı taraf (ör. müşteri) çekince belirtir ya da bir şeyi sorgularsa, ajan senin oraya yazdığın **gerçek** bilgileri açık ve kibar biçimde anlatır (ör. "ilk testleri kendi laboratuvarımızda/sistemlerimizde yapıyoruz, önce görebilirsiniz").
- Sınır nettir: Ajan **yalnızca senin verdiğin, gerçek olan** bilgileri söyler; gerçek olmayan bir kimlik/gerekçe/hikâye **uydurmaz**, kimseyi yanıltmaz. Karşı taraf yine de istemiyorsa **zorlamaz, baskı yapmaz**, kararına saygı gösterir ve durumu sana bildirir.

### 1.46.0 — 🛠 Araç yoksa/çalışmıyorsa GitHub'dan kur; uygulamayı kendi onar
- Uygulamadan gelen cevaba göre uygun **kurulu araç yoksa ya da çalışmıyorsa**, ajan GitHub'dan bu işi yapan **en güncel + en çok çalışan + en sorunsuz** aracı bulup kurar ve işi onunla yapar; olmazsa sıradaki en iyi alternatifi dener.
- **Yerel uygulamanın kendisinde hata/çökme/eksik bağımlılık/bozuk ayar** varsa, AI + 🧠 beyin logu okuyup nedenini bulur ve **onarır** (eksik paket, ayar, bozuk kod), sonra yeniden dener; onaramazsa güncel bir alternatife geçer.
- ⛔ Sınır korunur: Ajan yalnızca **işlevsel hataları** onarır. Bir yazılımın lisansını, deneme/özellik kısıtlamasını, kopya korumasını ya da DRM'ini kaldırma/aşma **yapılmaz** — böyle bir istek gelirse ajan yapmaz ve bunu söyler.

### 1.45.0 — 💬 Ajan uygulamayla karşılıklı konuşsun (kendisi yazar, kendisi sorar)
- Uygulamaya bağlı ajan artık uygulamayla **iki yönlü diyalog** kurar: gerektiğinde giriş/sohbet alanına **kendisi yazar**, **kendisi soru sorar**, uygulama cevap verir, ajan o cevabı okuyup yeni bir şey yazar/sorar — iş bitene kadar böyle sürer.
- Uygulama ajana bir şey sorarsa/bir değer beklerse cevabını **ajan verir**. Her adımı sana sormaz; yalnızca geri alınamaz işlemlerde (ödeme/gönderme/silme/hesap) ve şifre/kart/kod alanlarında durup sana danışır.

### 1.44.0 — 🔁 Uygulamadan gelen cevabı analiz et → tool aç → işlemi yap (döngü)
- Uygulamaya bağlı ajan artık net bir döngüyle çalışır: **1)** uygulamanın verdiği cevabı/çıktıyı okur, **2)** AI + 🧠 beyin birlikte **analiz eder**, **3)** analize göre **gereken aracı açıp çalıştırır** (en uygun kurulu araç; yoksa GitHub'dan en günceli kurulur), **4)** aracın çıktısını alıp gerekiyorsa uygulamaya **geri yazar**, **5)** uygulamanın yeni cevabını tekrar okur — iş bitene kadar sürer.
- Kısacası: *uygulamadan gelen cevabı analiz et → ona göre tool aç → işlemi yap → sonucu uygulamaya işle → tekrar oku.*

### 1.43.0 — 🔌 Uygulamaya bağlı ajan kurulu araçları da çalıştırsın
- Bir ajan yerel uygulamaya bağlıyken artık **Cypher Tool'a kurulu araçları ve sistem komutlarını da çalıştırabilir** — web arayüzüyle sınırlı değil. İkisini birlikte kullanır: örn. bir aracı çalıştırıp çıktısını alır, sonra o çıktıyı web uygulamasına yazar; ya da uygulamadan aldığı veriyi bir araçla işler.
- Ajana kurulu araçların listesi de verilir, hangi aracı ne için kullanacağını bilir; gerekirse yenisini de kurar.
- "Bu uygulamada kal" kuralı artık yalnızca **başka web sitelerine gezinmeyi** sınırlar; kurulu araçları çalıştırmayı, dosya okuyup yazmayı engellemez.

### 1.42.0 — 🔌 Ajanı yerel uygulamana bağla (okusun, yazsın, kullansın)
- Bilgisayarında çalışan yerel bir web uygulamasını (127.0.0.1…) artık bir **ajana kullandırabilirsin**. Uygulama penceresinin başlığındaki **🤖** düğmesi ya da aracın detayındaki **🤖 Ajana kullandır** ile bir görev yaz: ajan uygulamayı **🌐 sekmesinde** açar, ekranı okur, gerekeni yazıp tıklar ve **uygulamanın yanıtına göre devam eder** (bir şey yazdıysa okur, karşılık verir).
- Ajan sadece o uygulamada kalır (istersen "başka site açmasın" kapatılabilir). Yapay zekâ (ve 🧠 beyin) senin yerine uygulamanın içinde çalışır; sen her adımı canlı izlersin ve istediğin an araya yazabilirsin (aynı göreve devam eder).
- Çalışırken ara mesaj yazabilir, takılırsa "atla / başka yol" diyebilirsin; takım moduyla da birleşir (birden çok ajan aynı uygulamayı farklı yollarla deneyip sonucu sana onaylatabilir).
- Not: Web arayüzünü tıklayıp yazmak için bir yapay zekâ gerekir (🆓 Ücretsiz AI'dan anahtarsız bir model eklenebilir); beyin tek başına arayüzü kullanamaz ama izleyip öğrenir.

### 1.41.0 — 👥 Takım: onayınla bitir (diğer ajanlar dursun)
- Bir ajan işi bitirdiğinde **sana sorar**: "İstediğin sonuç bu mu?" **İşlemi tamamla** dersen o ajan kazanan olur ve **diğer tüm ajanlar anında durur** (çalışan komutları/kurulumları kesilir). **Vazgeç** dersen diğerleri denemeye devam eder.
- Yani ötekiler **sen onaylayana kadar** durmaz — otomatik değil, kararı sen verirsin. Birden çok ajan bitmişse her biri ayrı ayrı sorar; hangisini onaylarsan o kazanır, gerisi durur.
- Koordinatör raporu artık onayladığın ajanı 🏆, durdurulanları ⏹ ile gösterir.
- (Web/yerleşik tarayıcıdaki tıklama hedefi sorunu daha önce düzeltilmişti — tıklama artık CSS yakınlaştırmadan etkilenmeden doğru yere gidiyor; bu sürümde de geçerli.)

### 1.40.0 — 👥 Takım: çok ajan, her biri FARKLI araçla aynı işi dener
- Sohbette ya da konsolda **"5 farklı ajan ile şunu dene: …"** (ya da "3 ajanla … dene", "çoklu ajan modu: …") yazdığında **o kadar ajan** aynı anda devreye girer. Her ajan **kendi konsolunu** açar ve işi **farklı bir araçla** dener.
- **Çakışma yok:** Ajanlar ortak bir panodan haberleşir — **kimse aynı aracı kullanmaz**; her ajanın hangi aracı denediği koordinatör konsolunda ve kendi konsolunda yazar.
- **Önce sistemdeki araçlar** denenir (puanlı eşleştirmeyle en uygun komut seçilir). Bir araç olmazsa o ajan bir kez bilinen-hata düzeltmesi dener, yine olmazsa GitHub yoluna geçer.
- **GitHub:** Sistemdekiler yetmezse her ajan GitHub'da **en güncel + en etkili + en işe yarar** aracı bulur (yıldız·güncellik·orijinal/fork değil puanlamasıyla), başka ajanın almadığını seçip kurar ve dener. Gerekirse başka araç da indirip kurar.
- Sonunda koordinatör **karşılaştırmalı rapor** verir: hangi ajan neyle başardı/olmadı, hangi yollar işe yaradı. Her ajanın konsolundan adımları tek tek izleyebilirsin.
- (Not: Bu, var olan "otomatik geçiş" özelliğinden farklı — o, bir yapay zekâ takılınca sıradaki yapay zekâya geçer; bu ise **aynı anda birden çok ajan, farklı araçlarla**.)

### 1.39.0 — 🛡 Anonim Mod: tek düğme, tüm PC trafiği gerçek IP'yi gizler
- IP paneline **🛡 Anonim Mod** düğmesi eklendi. Açtığında bilgisayardan internete çıkan **her şey** — Google Chrome, bilgisayarın kendi terminali/konsolu, açtığın araçlar ve uygulamanın kendisi — proxy/Tor üzerinden çıkar; **gerçek (yerel) IP'n hiçbir uygulamadan görünmez.** (Sistem vekil ayarı + yeni terminaller/oturumlar için ortam değişkenleri + masaüstü proxy'si uygulanır; kapatınca hepsi geri alınır.)
- **%100 doğrulama:** Panel gerçek IP'nin gizli olduğunu sürekli kontrol eder. Proxysiz (doğrudan) çıkış IP'yi de ölçüp proxy çıkışıyla karşılaştırır — **sızıntı varsa (gerçek IP hâlâ görünüyorsa) ❗ ile uyarır.** "🧪 Anonim mi? (test)" ile tam sızıntı testi yapılır: ✅ %100 ANONİM ya da ❌ SIZINTI.
- **Hangi uygulama hangi IP'den çıkıyor:** Panelde çalışan araç/uygulamalar listelenir, her birinin **karşıya görünen çıkış IP'si** ve gerçek IP'sinin gizli olup olmadığı (🛡/⚠) gösterilir. Anonim moddan önce açılmış bir araç gerçek IP kullanıyorsa "yeniden başlat" uyarısı verilir.
- Kapsam göstergesi: *Uygulama·AI·yerleşik tarayıcı* / *açılan araçlar* / *Chrome·terminal·diğer uygulamalar* — her biri için ayrı ✅/○.
- Yapay zeka ve beyin anonimlik durumunu bilir (gerçek IP gizli mi, sistem geneli açık mı); "anonim ol / hepsini gizle" dediğinde Anonim Modu açmayı önerir.

### 1.38.0 — 🩹 IP aracı çalışmıyorsa onar; olmazsa güncel alternatif dene
- IP paneline **🩹 Çalışmıyorsa onar / değiştir** düğmesi eklendi. Sırayla: proxy/IP testi → araç çökmüşse **yeniden başlat** → düzelmezse **AI/beyin ile onar** → yine olmazsa senin onayınla **GitHub'dan en güncel BAŞKA bir Tor/IP aracı** bulup kurup dener.
- **Otomatik tespit:** Bağlı IP aracı bir süre yanıt vermezse (çıkış IP alınamıyorsa) uygulama bunu fark eder ve "IP aracın yanıt vermiyor — 🩹 Onar/Değiştir" bildirimi gönderir.

### 1.37.1 — 🔄 Değişen çıkış IP geçmişi (Tor araçları için)
- IP panelinde artık **değişen çıkış IP'lerinin geçmişi** görünür. Bir Tor/proxy aracı (ör. Tornet) kurup bağladığında, araç IP'yi döndürdükçe panelde yeni IP'ler listelenir — en üstteki yeşil, şu anki. "✨ En iyi IP aracını indir" tam da bu tür güncel Tor araçlarını GitHub'dan bulup kurar.

### 1.37.0 — 🌍 Açılır IP paneli (sol üst) + ✨ en iyi IP aracını indir
- Sol üstteki IP rozetine tıklayınca **aşağı doğru açılır** panel: 🏠 yerel (sabit) IP, 🌍 çıkış IP (uygulama/siteler bunu görür), 🔀 proxy ve **hangi araç üzerinden değiştiği** (bağlı IP aracının adı). Tekrar tıklayınca kapanır.
- **🧪 Test** ve **⚙ Panel** düğmeleri panelin içinde.
- **✨ En iyi IP aracını indir:** Tek tıkla GitHub'dan en iyi + en güncel + güvenli (puanlı) IP değiştirici/proxy/VPN/Tor aracını otomatik bulup kurar.

### 1.36.1 — 🌍 Sol üstte her zaman görünen IP rozeti
- Sol menüde **Cypher Tool** logosunun hemen altına, her sayfada görünen bir IP rozeti eklendi: 🌍 çıkış IP (+ proxy açıksa 🔀) ve 🏠 yerel IP. 8 sn'de bir güncellenir; tıklayınca Sistem'deki tam IP paneli (proxy, test) açılır.

### 1.36.0 — ✨ En iyi aracı bul & kur + 🔄 güncelleme kontrolü
- **✨ Bul ve kur:** Konsoldaki araç alanına "ne lazım?" yaz (ör. "pdf birleştir") → Cypher GitHub'da **en iyi + en güncel + güvenli** (puanlı) aracı bulur, adayları gösterir ve **en iyisini kurup araçlarına ekler**. "sormadan otomatik kur" kutusunu işaretlersen plan sormadan kurar.
- **🔄 Güncelleme kontrolü:** Kurulu araçlarda güncelleme var mı diye **zaten günlük otomatik** bakılıyordu (bulunca bildirim gelir, "otomatik" işaretli araçlar kendini günceller). Artık bir de **"🔄 Güncellemeleri kontrol et"** düğmesiyle istediğin an elle kontrol edersin.

### 1.35.0 — 🛡 Web sekmesi de proxy'den geçer + 🧪 Proxy/IP testi
- **Yerleşik tarayıcı proxy'den geçer:** Proxy ayarlıyken yerleşik tarayıcıda açtığın web sekmeleri de proxy üzerinden gider; girdiğin siteler **gerçek IP'ni görmez** (socks5'te DNS de proxy'den çözülür). Proxy değişince tarayıcı otomatik yenilenir.
- **Araçlar/ajan proxy'den geçer:** Proxy ayarlıyken HTTP_PROXY/HTTPS_PROXY/ALL_PROXY ortam değişkenleri ayarlanır; uygulamadan çalışan araçların internet trafiği de proxy'den gider.
- **🧪 Proxy/IP testi:** IP panelindeki düğme — doğrudan IP ile proxy üzerinden IP'yi karşılaştırır, proxy portu erişilebilir mi bakar ve **gerçek IP sızıyor mu** kontrol eder; sorunsuz çalışıp çalışmadığını ✅/⚠️/❌ ile söyler.

### 1.34.1 — 🌐 IP/proxy aracı kurunca "IP paneline bağlayayım mı?" diye sorar
- Bir **proxy/VPN/Tor/IP** aracı kurduğunda ajan/kurulum sana **sorar**: "IP paneline bağlayıp çıkış IP'ni bunun üzerinden göstereyim mi?" Onaylarsan (ve adresini — bilinen araçlarda hazır gelir) uygular; çıkış IP'n o araç üzerinden görünür, tüm araçlar da onu kullanır.
- Çıkış IP etiketi netleştirildi: **"Çıkış IP (girdiğin siteler bunu görür)"** — proxy açıkken siteler proxy'nin IP'sini görür.

### 1.34.0 — 🌐 IP paneli (yerel + çıkış IP) + proxy
- **Sistem sayfasının üstünde IP paneli:** 🏠 Yerel (sabit) IP ve 🌍 Çıkış (internetteki) IP tek bakışta görünür; çıkış IP **5-10 sn'de bir otomatik** kontrol edilir.
- **🔀 Proxy:** Bir proxy (socks5:// veya http://) girip Uygula dersen çıkış IP'n ondan görünür; tüm araçlar ve ajan da o proxy'yi kullanır. Kaldır ile kapatırsın. Kurduğun bir VPN/proxy/Tor aracı IP'yi değiştirirse panel otomatik yeni IP'yi gösterir.
- **Beyin/AI bunu bilir:** Ajan senin yerel ve çıkış IP'ni ve proxy durumunu bilir; "IP'mi değiştir/gizle" dediğinde proxy'yi ayarlayıp doğrular ya da kurulu VPN/Tor aracını başlatır.

### 1.33.3 — "görev yok" bildirim spam'i düzeltildi
- Ajan/sohbet ekranında kendiliğinden tekrar tekrar çıkan **"⚠ görev yok"** bildirimi giderildi. Sebep: yoklama (poll), tamamlanıp temizlenmiş bir işi çağırınca her 1,2 sn'de hata toast'ı çıkıyordu. Artık yoklama sessiz; iş yoksa ekran sakince boşa döner, bildirim çıkmaz.

### 1.33.2 — 🖱 Yerleşik tarayıcıda fare doğru yere tıklıyor
- Konsoldaki yerleşik tarayıcıda (ekran-görüntülü) fareyle tıklayınca başka yere basıyordu. Sebep: uygulama ölçeği (zoom) açıkken tıklama koordinatı kayıyordu. Tıklama/gezinme/tekerlek artık ölçekten bağımsız, **doğru hedefe** gidiyor.

### 1.33.1 — Yalnız konuştuğun konsola bakar
- "Neden olmadı?" dediğinde artık **yalnızca şu an baktığın/konuştuğun konsol sekmesinin** son çıktısına bakar; yanda açık başka bir konsol sekmesine karışmaz.

### 1.33.0 — ❓ "Neden olmadı?" deyince en son olaya bakar
- Konsolda bir şey çalışıp olmayınca **"neden olmadı / çalışmadı / düzelt / sorun ne"** gibi kısa bir şey yazarsan, yapay zekâ artık **"hangi konu?" diye sormaz**; en son konsol çıktısını kendisi okur, hatayı/sebebi bulur ve gerekirse düzeltmeyi önerir ya da dener. (Normal istekler — "hava durumu", "google aç" — etkilenmez.)

### 1.32.1 — Konsol eski görünümüne döndürüldü
- 1.32.0'daki "🛠 Araçlar / 🤖 Yapay zekâ" konsol modu geri alındı; konsol eskisi gibi (terminal + sohbet yan yana, AI kutusu altta).

### 1.32.0 — 🛠 Konsol sadeleşti: Araçlar / Yapay zekâ ayrı mod
- Konsolun üstüne **🛠 Araçlar | 🤖 Yapay zekâ** anahtarı geldi. **Varsayılan: Araçlar** — konsol yalnız araç terminali için, AI sohbet paneli ve kutusu gizli (ekran sade, kalabalık değil).
- **🤖 Yapay zekâ**'ya basınca sohbet açılır; işin bitince yine Araçlar'a dönersin. Araçlar modundayken AI bir şey üretirse 🤖 düğmesinde küçük yeşil nokta yanar; AI sana bir soru sorarsa otomatik AI moduna geçer (cevap verebilesin).
- Doğrudan kurulumlar (GitHub kutusu / kur düğmesi) zaten konsolda değil Görevler'de akıyor — konsolu meşgul etmez.

### 1.31.0 — 🔀 En iyi aracı dene, olmazsa "ötekini deneyeyim mi?" diye sor
- Sohbette/konsolda bir iş istediğinde beyin **önce en uygun kurulu aracı** dener (zaten böyleydi). Artık o araç yapamazsa **sıradaki araca geçmeden önce sana sorar** ("X ile olmadı, Y deneyeyim mi?"). Onay verirsen sıradakini dener, vermezsen durur.
- Ayarlar'da **"Bir araç olmazsa sıradaki araca geçmeden önce sor"** anahtarı (varsayılan açık). Kapatırsan eskisi gibi sırayla kendisi dener.

### 1.30.0 — 🔑 API isteyen araçlara otomatik anahtar + 🧠 Reversing öz-geliştirme
- **🔑 API'yi araçlara otomatik ekleme:** Bir araç yapay zekâ API anahtarı istiyorsa (README/.env/kaynak taranır), Cypher kurulumda **önce ücretsiz** kayıtlı sağlayıcından uygun olanı aracın `.env` dosyasına yazar (OpenAI-uyumlu anahtar + base_url + model). **Ücretsiz yoksa sana sorar**, eklediğin ücretli API'lerden seçtirir. Araç belirli bir sağlayıcı istiyorsa (DeepSeek vb.) onu kullanır. Araç detayı → ⚙ Yönet → **🔑 Yapay zekâ API'si**'nden bağlı sağlayıcıyı görür, dilediğinle (DeepSeek/OpenAI/…) değiştirirsin; en uygunu önerilir.
- **🧠 Reversing'i geliştir:** Güvenlik/Tersine Mühendislik sayfasında yeni düğme — GitHub'daki güncel reversing araçlarını **orijinal + güncel + güvenli puanıyla** bulur, güçlü analiz araçlarından (capa, FLOSS, rizin, radare2, DIE…) eksik olanları kurup **test eder** ve kullanımını beyne öğretir; ayrıca AI'ya "hangi güncel analiz aracı eksik?" diye sorup önerilerini not alır. (Yalnız yasal analiz; koruma/DRM kırma kapsam dışı.)

### 1.29.1 — ⬇ Konsol otomatik aşağı kayıyor
- Konsolda işlem çalışırken yeni çıktı gelince ekran artık **kendiliğinden en alta iner** (en alttayken). Yukarı kaydırıp bir şey okuyorsan seni aşağı çekmez — okumanı bozmaz.

### 1.29.0 — 🩺 Tanı paneli + ⏸ arka plan ana şalteri (+ geri alma zaten var)
- **🩺 Tanı:** Ayarlar'da "Her şeyi kontrol et" — sistem, Python/Node/git/Ollama, disk/bellek, araçlar (sorunlu/eksik olanları sayar), API'ler, sudo ve arka plan motoru; sorun varsa ✅/⚠️/❌ ile gösterir.
- **⏸ Arka plan ana şalteri:** Ayarlar'da iki seçenek — "Arka plan yapay zekâ motorunu duraklat" (meraklı beyin + kendini geliştirme döngüleri hiç çalışmaz; beyin yine senin isteklerinde çalışır) ve "Sadece ben kullanırken çalışsın" (5 dk boştaysa durur). İşlemci/pil korunur.
- **↩ Geri alma:** Zaten vardı — Uygulamayı Geliştir → Yedekler → "↩ Bu hâle geri dön" ile her appdev değişikliğinden önceki hâle dönersin.

### 1.28.2 — 🛠 Kendiliğinden düzeltme yok: önce sorar, neyi neden düzelteceğini gösterir
- Araç kurulumu başarısız olunca ya da bir araç çalışırken hata verince, uygulama **artık kendiliğinden onarıma başlamaz**. Önce sana sorar (otomatik modda bile), **ne bozuk + ne yapacağını** gösterir; sen onaylarsan başlar, onaylamazsan hiçbir şey yapmaz.
- Uygulamanın kendi kodu (Uygulamayı Geliştir) zaten yalnız sen "✅ Uygula"ya basınca değişir — kendiliğinden değişmez.

### 1.28.1 — 🖥 Yerel pencere düzeltmeleri (kendiliğinden açılma + kapatma + sürükleme)
- **Kendiliğinden açılma kaldırıldı:** Bir araç 127.0.0.1'de arayüz açınca pencere artık kendiliğinden açılmaz; sadece haber verilir, sen konsoldaki **🖥 Arayüzü aç** düğmesiyle açarsın.
- **Kapatma düzeldi:** ✕ ve Esc artık pencereyi gerçekten kapatıyor (bir CSS çakışması pencereyi gizlenemez yapıyordu; aynı yüzden açılışta boş pencere görünebiliyordu — giderildi).
- **Sürükle/boyutlandır düzeldi:** Başlıktan sağa-sola taşıma ve köşeden boyutlandırma artık sorunsuz.

### 1.28.0 — 🛡 GitHub'da en orijinal + güncel + güvenli aracı seç
- GitHub araç aramasında adaylar artık **güvenlik + güncellik + orijinallik puanıyla** sıralanıyor: çok yıldız, yakın zamanda güncellenmiş, lisanslı, kurum hesabı ve **adı birebir eşleşen** depo üste çıkar; **fork/mirror/kopya, arşivli ve "deprecated/taşınmış"** olanlar elenir.
- En iyi aday **best** olarak işaretlenir; beyin/ajan onu (orijinal/resmi olanı) tercih eder, emin değilse puanlarıyla sana gösterip seçtirir.

### 1.27.0 — 🧰 Araç detay paneli + GitHub kutusu + 🎨 arka plan efektleri
- **ℹ Araç detayı:** Konsoldaki bir aracın "i" düğmesi artık detaylı panel açıyor: **Ne işe yarar** (özet + yetenekler + **README**), **📁 Dosyalar** (içindeki tüm dosyaları gez, tıkla → içeriğini tam gör), **⚙ Yönet** (▶ çalıştır · 🖥 arayüzü aç · ⭐ favori · 🔄 güncelle · 📂 klasör · **🗑 tamamen kaldır**).
- **⬇️ GitHub kutusu:** Araç listesinin üstüne link yapıştırıp Enter ile doğrudan kurulum.
- **🗑 Tamamen kaldır:** Aracı dosyalarıyla birlikte siler.
- **Kolay kapatma:** Açık panel/pencereyi **Esc** ya da **dışına tıklayarak** kapat.
- **🎨 Arka plan efektleri (10 adet):** Görünüm ayarlarından seç — Matrix 0/1 yağmuru, ikili yağmur, yıldız alanı, ağ/takımyıldız, kod şeritleri, dalgalar, synthwave ızgara, tarama+glitch, devre yolları, plazma küreleri. **Şeffaf ve geride**, yoğunluğu ayarlanır, **varsayılan kapalı** — istemezsen hiç açılmaz.

### 1.26.0 — 🖥 Yerel web arayüzlerini uygulama içinde aç
- **Otomatik tespit:** Bir araç 127.0.0.1 / localhost üzerinden bir web arayüzü açtığında (ör. `http://127.0.0.1:5000`), Cypher bunu çıktısından **kendisi yakalar** ve Chrome yerine **uygulamanın kendi penceresinde** açar.
- **Şık canlı pencere:** Gerçek, etkileşimli iframe — **⛶ tam ekran**, **⧉ ayrı işletim sistemi penceresi**, **↗ yeni sekme**, **⟳ yenile**, adres çubuğu; başlıktan **sürükle**, köşeden **boyutlandır**. Kendi arayüzümüz ve yerel LLM API portları (11434/1234/…) tespit dışı tutulur.
- Konsol başlığında ayrıca **🖥 Arayüzü aç** düğmesi (iş bir arayüz açtıysa).

### 1.25.0 — 🧠 Beyin yöneticisi + çalışırken yazabilme + takılmayı önleme
- **🧠 Beyin yöneticisi:** Beyin sayfasında artık öğrenilen her şeyi (soru-cevap, iş tarifleri, çözülmüş hatalar, **bilgi notları**, sorular) **ara**, **✏️ düzenle**, **🗑 sil** ve türün tamamını **🧹 temizle**. Yanlış öğrendiğini elle düzeltebilir/silebilirsin.
- **🧑 Çalışırken ek mesaj (aynı işe devam):** Ajan ya da konsol yapay zekâsı çalışırken alt kutuya yazdığın mesaj artık **yeni iş açmaz**; mevcut göreve eklenip aynı konudan devam eder.
- **⏭ Takılınca atla + alternatif:** Her soruda "⏭ Bu adımı atla / gerekmiyor" seçeneği. Oturum açma/giriş/anahtar isteyen adımlarda beyin önce **giriş gerekmeyen başka yol** dener; alternatif sunar; tek yol oysa bunu **açıkça söyler** — artık takılıp beklemez.
- **⏱ Neden bekliyor + süre:** Ajan durumunda ne beklediği (sorunun kısa metni) ve geçen süre görünür.

### 1.24.1 — 🔄 Taşıma artık eksiksiz (API + hesap + model + araç kodları) + 📋 konsol kopyala
- **Eksiksiz taşıma:** Seçmeli taşımada “🧠 Beyni ve ayarları da aktar” artık öğrenilen her şeyi (soru-cevap, bilgi hafızası, çözülmüş hatalar, sohbetler, tarifler, promptlar) + **API anahtarlarını, hesapları ve tokenleri** (yedekte varsa) + eğitilmiş yerel modeli aktarır. Seçili araçlar yedekteki kodlarından geri konur; kod yoksa kaynağından kurulur. Tarama ekranı yedekte anahtar/kod/model olup olmadığını önceden söyler.

### 1.24.0 — 🔄 Başka makineye seçmeli taşıma + 📋 konsol kopyala düzeltmesi
- **🔄 Başka makineye taşı (seçmeli):** Dışa/İçe Aktar sayfasında bir yedek dosyası seç → içindeki araçları **ne işe yaradıklarıyla** ve **en çok kullandıklarından sıralı** listeler. İstediklerini işaretle, **🧠 Beyni ve ayarları da aktar** kutusuyla birlikte **Seçilenleri kur**'a bas; SEC araçları doğrudan, GitHub araçları kaynaklarından otomatik kurulur. API anahtarların yeni makineye aktarılırken korunur.
- **📋 Konsol kopyala:** Konsol başlığına **📋 Kopyala** düğmesi eklendi — fareyle bir yer seçtiysen onu, seçmediysen tüm çıktıyı panoya alır. **Ctrl/Cmd+Shift+C** her zaman, **Ctrl+C** ise seçim varken kopyalar.
- **🔧 Seçim kayması düzeltildi:** Uygulama ölçeği (zoom) açıkken konsolda fareyle seçtiğin yer başka yere düşüyordu; terminal artık net %100'de render edilip seçim/kopyalama doğru çalışıyor (yazı boyutu aynı kalır).

### 1.23.0 — 🧒 "Bunu açıkla" + tıklanabilir sıradaki adım butonları
- **🧒 Bunu açıkla:** Analiz kartının altındaki butona basınca yapay zekâ o sonucu çocuğa anlatır gibi sade açıklar (ne oldu, ne anlama geliyor, sıradaki adım).
- **Tıklanabilir sıradaki adımlar:** Komut yazmana gerek yok — kartın altındaki butonlarla tek tık: **🔬 Derinlemesine incele**, **🧩 Ne yapıyor (capa)**, **🔁 Decompile**, **🕵 Gizli metinler (FLOSS)**. Basınca gerekli araç (yoksa) kurulur ve konsolda canlı çalışır.
- Böylece basitleştirme setinin tamamı hazır: sade sonuç kartı, basit mod, açıkla, tıklanabilir adımlar, sürekli kendini geliştirme.

### 1.22.0 — 🧾 Sade sonuç kartı + 🔰 Basit mod + 🔄 sürekli kendini geliştirme
- **Sade sonuç kartı:** Analiz bitince uzun çıktıyı okumana gerek yok — tek kart: 🟢/🟡/🔴 risk, dosya ne, neyle korunuyor (açıldı mı), ve "sırada ne yapabilirsin" 3-4 madde.
- **🔰 Basit mod** (sol üstte anahtar): teknik detaylar ve ileri menüler (API'ler, Sistem, Dışa/İçe Aktar, Uygulamayı Geliştir, Hata Çözümleri, araç kartlarındaki ileri butonlar, yalıtım çubuğu) gizlenir; sadece ana butonlar ve sade sonuçlar kalır.
- **🔄 Sürekli kendini geliştirme:** Beyin arka planda kurulu araçların kullanımını öğrenir ve GitHub'da güncel reversing araçlarını keşfedip hafızasına not eder (otomatik kurmaz — sürpriz indirme yok; tek tıkla sen kurarsın). Beyin ayarlarından kapatılabilir.

### 1.21.0 — 🔎 İnceleme haritası: "şu bölgeye bak → çünkü…"
- AI tespiti artık bir **🔎 İnceleme Haritası** da veriyor: bu dosyayı anlamak için **hangi noktalara bakman gerektiğini ve neden** — giriş noktası, yüksek entropili/şüpheli bölümler, dikkat çeken import'lar, TLS callback, overlay. Her madde "şu bölgeye bak → çünkü …" biçiminde, öğrenmen için. (Yalnız inceleme/anlama; değiştirme/yama talimatı yok.)

### 1.20.0 — 🤖 AI destekli tespit + çocuğa anlatır gibi kopyala-yapıştır rehber
- **AI tespiti:** ct-protector + Detect It Easy + capa sinyallerini birleştirip korumayı/paketleyiciyi **güven yüzdesiyle** adlandırır — imza bilinenlerden değilse "özel/bilinmeyen koruma, şu belirtilerle" diye tarif eder. Anti-debug/anti-VM teknikleri, derleyici ve dosyanın olası amacı da çıkar. (`tespit.txt`)
- **Çok basit rehber:** Manuel rehber artık hiç bilmeyen birine, çocuğa anlatır gibi — her adımda **tek komut (kopyala-yapıştır)**, "👉 ne göreceksin" ve "🔎 nereye bakacaksın/müdahale", hangi aracı neden kullandığın, sonda sıralı komut listesi. (`REHBER_manuel_analiz.md`)
- Tek analizde: AI tespiti + (basitse) açılmış orijinal + metinler + decompile + öğretici açıklama + kopyala-yapıştır rehber + rapor.

### 1.19.0 — 🛡 Reversing: manuel rehber, araç keşfi, yeni araçlar, sağlamlık
- **Sana özel manuel rehber:** Analiz sonunda, o dosyayı KENDİN adım adım nasıl analiz edersin (komutlu) bir rehber (`REHBER_manuel_analiz.md`) üretilip teslim edilir — öğrenmen için.
- **Güncel araç keşfi:** "Güncel reversing araçlarını bul" dersen GitHub'da araştırır, güçlü analiz araçlarını (capa, FLOSS, rizin, radare2, DIE, pev, pwntools…) kurup **test eder** ve kullanımlarını beyne öğretir.
- **Yeni araçlar eklendi:** capa (yetenek çıkarımı), FLOSS (gizli metin çözme), rizin, pwntools, jadx (APK).
- **Sağlamlık:** Analiz akışı boş/metin/bozuk/rastgele dosyalarda bile çökmeden sonuna kadar çalışır (test edildi); UPX açma başarısı artık doğrulamayla belirlenir.
- **Sınır (değişmedi):** Basit paketleyiciler otomatik açılır; ticari/özel güçlü korumalar tespit edilip açıklanır ama otomatik kırılmaz.

### 1.18.0 — 🛡 Reversing kısmı güçlendirildi (exe/dll analizi, decompile, öğretici açıklama, kurulum onarımı)
- **exe/dll atınca "hata" düzeltildi:** Artık bir exe/dll/elf/arşiv dosyasını sohbete eklediğinde (metin yazmasan bile) doğrudan canlı analiz başlar.
- **Daha derin analiz:** radare2 otomatik kurulur; fonksiyon haritası, içe aktarılan API'ler, giriş kodunun **disassembly + sözde-decompile (pdc)** çıkarılır ve dosya olarak teslim edilir.
- **Öğretici açıklama:** Analiz sonunda yapay zekâ bulguları sade Türkçeyle anlatır — dosya ne, **koruma ne yapar** (anti-debug/anti-VM/sanallaştırma), kod adım adım ne anlama gelir, güvenli sıradaki adım. Açıklama beyne de kaydedilir (öğrenir).
- **Kurulum onarımı:** Araçlar kurulurken takılırsa artık pes etmiyor — apt güncelle + `universe` deposu + tekrar, olmazsa pip/pipx, o da olmazsa **ücretsiz AI'ya nasıl kurulacağını sorup** dener.
- **Sınır:** Basit paketleyiciler (UPX/ASPack/PEtite/MEW/MPRESS…) otomatik açılıp orijinal sana verilir; ticari korumalar (Themida/VMProtect/Enigma) **tespit edilip açıklanır ama otomatik kırılmaz** — yalnızca ne olduğu, nereye müdahale ettiği ve nasıl çalıştığı gösterilir.

### 1.17.0 — ⭐ Araçlara favori ekleme (hızlı erişim)
- Konsol kenar çubuğundaki "Aktif araçlarım" listesinde her aracın yanına **☆/⭐ favori** düğmesi eklendi.
- Favori yaptıkların **listenin en üstüne** sabitlenir — işine yarayanlara hızlı erişirsin. GitHub depoların için de çalışır.

### 1.16.4 — 🔐 Şifreyi bir kez gir, uygulama tüm yönetici işlerini kendisi yapsın
- **"sudo: a password is required" hatası düzeltildi.** Önceki sürümde uygulama bazen şifreyi beslemeden sudo'yu deniyordu (zaman-damgası/tty kaynaklı). Artık **hatırlanan şifre varsa her yönetici komutu onunla çalıştırılır** — güvenilir, tekrar sormaz.
- **Yönetici oturumu:** Şifreyi bir kez girince (varsayılan: oturum boyunca hatırlanır) uygulama arka planda yetkiyi diri tutar ve sonraki tüm sudo işlerini **kendisi** halleder; tekrar tekrar şifre sormaz.
- Şifre yalnız bellekte tutulur (diske/log'a/AI'ya gitmez, uygulama kapanınca unutulur). Hatırlamayı Ayarlar'dan kapatabilirsin.

### 1.16.3 — 🔐 Konsolda takılı kalan "sudo password" istemi düzeltildi
- Konsolda ham `... sudo password:` istemi çıkıp takılmıyor artık: uygulama bu istemi (farklı yazımlarıyla birlikte) algılayıp **şifre kartını/penceresini** gösteriyor (hatırlanan şifre varsa otomatik dolduruyor).
- Güvenlik/analiz adımlarında sudo gerektiren komutlar da artık doğrudan konsola değil, **şifre penceresine** yönlendiriliyor.

### 1.16.2 — 🐛 Yer tutucu doldurma iyileştirildi (dosya yolu çözümü de korunur)
- Değer verince önce bağlamdan akıllı doldurma (dosya yolunu bulma, çıktı adı türetme) denenir; olmazsa verdiğin değer doğrudan yazılır. Böylece hem "kullanıcı adı" gibi değerler tekrar sorulmaz hem de "dosya" verince dosyan Masaüstü/İndirilenler'de bulunur.
- Baştan sona benzer "cevabı tüketmeyip tekrar sorma" durumları tarandı; bulunan tek nokta buydu ve giderildi.

### 1.16.1 — 🐛 Yer tutucu değerini verince aynı soruyu tekrar sorma düzeltildi
- `<kullanici_adi>` gibi bir yer tutucuya öneriye basınca ya da değer yazınca, beyin değeri doğrudan komuta yazıp **çalıştırıyor** — artık aynı soruyu tekrar tekrar sormuyor.

### 1.16.0 — 🔘 "Sadece beyin" artık seçmeli: AI'ya sorsun / hiç sormasın
- "Sadece beyin" modunda yeni anahtar: **"🧠 Takılınca ücretsiz AI'ya sorsun ve öğrensin."**
  - **Açık (varsayılan):** beyin işi kendi yapar, yalnız takıldığında ücretsiz AI'lara danışıp öğrenir.
  - **Kapalı:** **tam çevrimdışı** — beyin hiçbir dış yapay zekâya sormaz; sadece kendi bildiğini ve (varsa) kendi yerel modelini kullanır.
- Ücretli-yedek seçeneği yalnız "AI'ya sorsun" açıkken geçerli.

### 1.15.0 — 💳 Ücretsizler çözemezse (istersen) ücretli AI'lara son çare olarak sor
- Beyin sayfasında (Sadece beyin modunda) yeni bir seçenek: **"Ücretsizler çözemezse, gerekirse ücretli AI'lara da sor (son çare)."**
- Açarsan: beyin önce hep ücretsizleri dener; onlar çözemezse/cevap veremezse **son çare** olarak ücretli API'lerine düşer. Kapalıyken (varsayılan) **hiç ücretli çağrılmaz** — paran senin kontrolünde.
- Ücretli yedek açıkken bile ücretsizler her zaman önce denenir; ücretli yalnız gerektiğinde ve en sonda kullanılır.

### 1.14.0 — 🧠 Beyin bilinmeyen aracı kullanmadan önce "her şeyini" öğrenir
- **Yeni/bilinmeyen bir araçla karşılaşınca beyin, o aracı KULLANMADAN önce** ücretsiz yapay zekâya sorar: ne işe yarar, nasıl kullanılır (örnek komutlar), ne gerekir ve **sık karşılaşılan hatalar + çözümleri**.
- Öğrendiklerini kalıcı yazar: yetenek kartı + sık hatalar beyne **ders** olarak kaydedilir; bir dahakine sormadan kullanır.
- Aynı aracı tekrar tekrar sormaz (AI ile bir kez öğrenince işaretlenir). Çalışırken hata alırsa yine kaynak kodu okuyup AI'dan çözüm alıp öğrenir (1.11.0 akışı).

### 1.13.0 — 🧠 Konsol ajan menüsüne "Beyin" seçeneği
- **Konsoldaki "🤖 Ajan" menüsüne "🧠 Beyin" eklendi.** Seçince o iş **beyin modunda** çalışır: beyin kendi yürütür, sadece **takıldığı yerde** ücretsiz yapay zekâlardan yardım alır, çözümü **öğrenip beyne kaydeder** — bir dahakine kendisi yapar, tekrar sormaz.
- Bu seçim sadece o konsol işini etkiler; üstteki genel mod ayarını değiştirmez.
- Hatırlatma: Beyin öğrendiklerini (soru-cevaplar, araç tarifleri, çözülen hatalar, AI'dan öğrenilen düzeltmeler) zaten kalıcı olarak kaydeder; boşa eğitim gitmez.

### 1.12.0 — ⚡ Prompt kütüphanesi: her model için kayıtlı promptlar + GitHub'dan içe aktarma
- **Yeni "⚡ Prompt'lar" bölümü:** Prompt kaydet, düzenle, sil. Her prompt bir modele atanabilir (ayrı gruplar) ya da "herhangi" kalır.
- **Hangi modele göndereceğini seç:** Her prompt'un yanındaki menüden modeli seç → **▶ Çalıştır** ile tek tıkta o modele gönder. "🧠 Beyin"i de seçebilirsin (ücretsiz/yerel).
- **Sohbetten ekleme:** Sohbete `şunu prompt olarak kaydet: …` (istersen `başlık: … içerik: …`) yazınca beyin/yapay zekâ direkt kütüphaneye ekler.
- **GitHub'dan içe aktarma:** Bir repo ya da dosya linki ver (`owner/repo` veya `.json/.csv/.md/.txt` ham dosya) → uygulama indirir, içindeki promptları çıkarıp ekler. (awesome-chatgpt-prompts gibi CSV/JSON listelerini otomatik tanır; aynı prompt tekrar eklenmez.)

### 1.11.0 — 🔐 Yönetici şifresi doğru sorulur + 🧠 beyin kaynak kodu okuyup takılınca ücretsiz AI'dan öğrenir
- **Şifre artık doğru yerde istenir:** Bir komut "Permission denied / are you root / izin yok" gibi bir hata verirse, uygulama artık sana açık uçlu "hangi seçimi istersin?" diye sormaz — **aynı komutu otomatik `sudo` ile tekrar dener ve kendi güvenli şifre penceresini açar.** Yapay zekâya "yöneticine danış / sudo ayarla" gibi şeyler yazdırmıyoruz.
- **Beyin kaynak kodu okur:** Bir araç README/--help ile çözülmezse ya da hata verirse, beyin aracın **açık kaynak kodunu okur**.
- **Takılınca ücretsiz AI'dan canlı öğrenir:** Kural tabanlı düzeltme ve araştırma yetmezse beyin, kaynak kodu + README + hatayı **ücretsiz yapay zekâya** verir, tek bir çözüm (komut ya da kod düzeltmesi) alır, uygular ve dener. İşe yararsa **beyne kalıcı ders olarak yazar** (bir dahakine kendisi yapar). Yıkıcı komutlar (rm -rf, dd, mkfs) reddedilir; düzenleme aracın klasörü dışına çıkamaz.

### 1.10.0 — 🧠 "Sadece beyin" modunda ÜCRETSİZ yapay zekâları kendisi kullanır + hepsinden öğrenir
- **Sadece beyin modu artık çevrimdışı+ücretsiz:** Beyni seçince, kurulu/ayarlı yapay zekâların içinden **yalnız ücretsiz olanları** (anahtarsız/yerel API'ler, OpenRouter'ın ücretsiz modelleri, havuzdaki ücretsiz API'ler, Ollama) **kendisi bulup** kullanır. **Ücretli API hiç çağrılmaz.**
- **Ücretli istediğinde 🤖'ya bas:** Üstteki moddan "🤖 Sadece yapay zekâ" ya da "🤖+🧠 İkisi birlikte"ye geçince ücretli API'lerin de devreye girer.
- **Beyin kartında görünür:** "Sadece beyin" seçiliyken hangi ücretsiz yapay zekâları kullanacağını listeler.
- **Her yapay zekâdan öğrenir:** Yapay zekâ açıkken (ücretli ya da ücretsiz) sorduğun sorular ve aldığın cevaplar beyne kaydedilir; beyin bir dahakine kendisi cevaplayabilir. (Beynin kendi yerel modeli hariç — onu tekrar öğrenmez.)
- Takıldığında beyin, ücretsiz yapay zekâlardan yardım isteyip öğrendiğini hafızasına yazar.

### 1.9.0 — 💡 Her soruda tıklanabilir öneriler (takılıp kalma yok)
- **Beyin/ajan ne zaman bir şey sorsa, altında öneri düğmeleri çıkar** — birine basınca kendisi devam eder; açık uçlu "ne yazayım?" ekranında artık beklemek zorunda değilsin.
- **Öneriler akıllı:** Komutta `<kullanıcı adı>`, `<dosya>`, `<url>`, `<ip>` gibi bir yer tutucu varsa; cümlendeki değerler, Masaüstü/İndirilenler'deki **son dosyalar**, daha önce kullandığın adres/kullanıcı adları ve (ağ işlerinde) `127.0.0.1` gibi gerçek adaylar önerilir. Anahtar/parola **asla** önerilmez.
- **Uygulamanın kendi seçenekleri de öneri olur:** Soru içinde `(mp3/wav/flac)` ya da `[küçük|orta|büyük]` gibi seçenekler geçiyorsa bunlar düğme olur.
- **Evet/Hayır soruları** için `✅ Evet` / `✋ Hayır` düğmeleri gelir.
- Her soruda **✏️ Kendim yazayım** düğmesi vardır: basınca yazı kutusuna odaklanır, istediğini yazarsın.

### 1.8.3 — Dosya analizinde "hata" düzeltmesi + net sebep
- **Eklediğin dosyanın yolu doğrudan alınır:** Analiz için dosya yolu artık metinden tahmin edilmiyor; sohbete eklediğin dosyanın gerçek yolu doğrudan kullanılıyor (yanlış ad/yol — ör. "3.3" — sorunu bu yüzden çıkıyordu).
- **Bulunamazsa akıllı arama:** Yol tutmazsa dosya adı Yüklenenler, Masaüstü, İndirilenler klasörlerinde aranır.
- **Artık kuru "hata" yok:** Analiz başarısız olursa **gerçek sebebi** (ör. "dosya bulunamadı: /yol/…", "dosya türü desteklenmiyor") sohbette ve konsolda yazılır; ne yapman gerektiğini söyler.

### 1.8.2 — 📦 Arşiv (zip/rar/7z) at → kendisi açıp içindekileri analiz etsin
- **Arşiv ver, kendisi açsın:** Sohbete bir zip/rar/7z (ya da tar/gz/iso) dosyası/yolu verince Cypher Tool arşivi **kendisi açar**, içindeki **exe/dll/ELF gibi çalıştırılabilir dosyaları bulur** ve her birini tek tek **canlı analiz eder** (tür → paketleyici → paket açma → içerik). Niyet kelimesi yazmana gerek yok — dosyayı vermen yeter.
- **Şifreli arşiv:** şifre sorar, yazınca açar.
- **Birleşik rapor:** her dosyanın sonucu tek raporda; açılan içerik ve tüm çıktılar Masaüstü'ndeki güvenlik klasöründe. İlk 10 çalıştırılabilir dosya analiz edilir.
- Güvenlik kartındaki "🔬 Canlı incele" alanı da artık arşiv yolu kabul eder.

### 1.8.1 — Görev kontrolleri: cevap/durdur düğmeleri + "Tümünü durdur"
- **Bekleyen görevi doğrudan cevapla/durdur:** "Şu an çalışanlar" listesinde bir görev cevap beklerken (ör. "devam mı?") seçenek düğmeleri (Devam et / Bitir …) ve bir ✖ durdurma düğmesi yan yana görünür — artık görev sayfasına gitmeye gerek yok.
- **🔐 Şifre bekleyen görev:** gerçekten şifre bekleyen görevde "🔐 Şifre gir" düğmesi çıkar ve şifre penceresini açar (yalnızca gerçekten şifre gerektiğinde yazar; rapor metnindeki "şifre" kelimesi artık yanıltmaz).
- **⛔ Tümünü durdur:** "Şu an çalışanlar" başlığında ve Görevler sayfasında tek tıkla bütün çalışan görevleri (istenirse araç/konsol süreçlerini de) durduran düğme.

### 1.8.0 — 🛡 Koruma Analizcisi, canlı exe/dll analizi (beyin+yapay zekâ), eksik aracı kendi kurma, onaylı özellik ekleme
- **🛡 Koruma Analizcisi (ct-protector) — uygulamanın kendi yardımcı aracı:** bir exe/dll/sys dosyasının paketleyicisini/korumasını (UPX, Themida, VMProtect, Enigma, ASPack, MPRESS…) hızlıca tespit eder ve **nereye müdahale ettiğini** gösterir: giriş noktası hangi bölümde, gizlenen içe aktarımlar, TLS callback'ler, overlay, sürüm/DLL bilgisi ve **anti-analiz göstergeleri** (hata ayıklayıcı/sanal makine tespiti). Çalıştırmaz, korumayı KALDIRMAZ — yalnızca inceler. Beyne öğretilir; hızlı pusula olarak kullanır.
- **🔬 Canlı dosya analizi (geliştirildi):** bir exe/dll ver — beyin **konsolda canlı** yürütür, sen izlersin: ct-protector + Detect It Easy ile koruma tespiti → **UPX gibi basit paketleri açar** → içerik/disassembly. **Güçlü korumalar (Themida/VMProtect/Enigma) otomatik açılmaz** — tespit edilir, nereye dokunduğu gösterilir ve dürüstçe "elle, yalıtılmış sanal makinede analiz gerekir" denir. Koruma raporu dahil tüm çıktılar Masaüstü'ne konup sana verilir.
- **🔧 Eksik aracı kendi bulup kurar:** analiz sırasında gereken bir araç kurulu değilse beyin (gerekirse yapay zekâ yardımıyla) onu bulur, kurar ve uygulamaya ekler; konsolda canlı görürsün; ne gerektiğini hafızasına yazar.
- **🤝 Takılınca yapay zekâ — yalnızca araç/konsol açıkken:** beyin çözemediği adımda yapay zekâya sorar; yapay zekâ konsoldaki her şeyi görür ve çözümü/komutu söyler. İkisi birlikte çalışır.
- **🧬 Yazdığın özelliği uygulamaya ekleme (onaylı):** sohbette "uygulamaya şu özelliği ekle: …" yaz — yapay zekâ(lar) özelliği **uygulamanın bir kopyasında** geliştirir, önizleme verir; **sen 'Uygula' (onay) düğmesine basmadan uygulamana hiçbir şey değişmez**, beğenmezsen geri alınır. (Uygulamayı Geliştir'deki bu akış artık sohbetten de başlatılabilir.)
- **Ek araçlar:** pev (PE araç takımı: readpe/pesec/pescan), ExifTool (üstveri).
- **Sınır:** Cypher Tool lisans/koruma kaldırma (crack) yapmaz; amaç kendi ya da analiz iznin olan dosyaları anlamaktır.

### 1.7.0 — 🛡 Güvenlik / tersine mühendislik: canlı dosya analizi, araç paketi, canlı dersler
- **🛡 Güvenlik araç paketi (Beyin sayfası → Güvenlik):** tek tıkla kurulur — UPX, radare2, binwalk, YARA, GDB, binutils (objdump/strings/nm), ltrace/strace, foremost, edb-debugger, Detect It Easy, unipacker; büyükler için onayla: Ghidra, Cutter, Wine + x64dbg. Kurulanlar beyne tanıtılır.
- **🔬 Canlı dosya analizi:** bir exe/dll/ELF ver (sohbette "bu dosyayı incele" + dosya, ya da Güvenlik kartındaki alan). Beyin **konsolda canlı** yürütür, sen izlersin: tür tespiti → paketleyici tespiti (UPX/Themida/VMProtect…) → **paketi açma (unpack)** → içerik (metinler, imports, disassembly). **Orijinali bozmaz** (kopya üstünde çalışır), **kendi içinde test eder** (açılan dosya geçerli mi, metinler arttı mı), biter bitmez **sonuç dosyalarını Masaüstü'ne koyup sana verir**.
- **🤝 Takılınca yapay zekâ devreye girer — yalnızca araç/konsol açıkken:** beyin bir adımı çözemezse yapay zekâya sorar; yapay zekâ **konsolda olan biteni görür** ve bir sonraki komutu/çözümü söyler. Araç kapalıyken yapay zekâ karışmaz.
- **🛡 Canlı dersler:** her araç için "▶ canlı" — aracı örnek dosyada adım adım çalıştırıp **ne yaptığını ve neden yaptığını** yazar; sen canlı izlersin, beyin öğrenir.
- **🧪 Kendi test ortamı:** "🧪 Kendini test et" — kurulu araçları zararsız örnek dosyalarda dener, çalıştığından emin olur; çalışmayanı yapay zekâyla düzeltir; yapay zekâ test ortamını geliştirir (yeni örnekler/kontroller önerir, beyne kaydedilir).
- **🎓 Beyne öğret → 🛡 Güvenlik:** tersine mühendislik araçlarının kullanımı ve temelleri beyne öğretilir (en iyi yapay zekâ anlatır). Sohbette "beyne güvenlik araçlarını öğret" de yeter.
- **Önemli:** bu araçlar yalnızca **kendi ya da analiz iznin olan** dosyalar içindir. Şüpheli dosyaları çalıştırarak analiz gerekiyorsa 🔒 yalıtım / sanal makine kullan. Not: Windows dinamik analizinde (x64dbg) Wine altında bazı özellikler kısıtlı olabilir; en sağlıklısı bir Windows sanal makinesidir.

### 1.6.0 — ⚡ Sohbette yaz, beyin (ya da yapay zekâ) işi yapsın
- **Sohbet ekranında iş isteği yaz** ("film.mp4'ü mp3'e dönüştür", "a.pdf ve b.pdf'yi birleştir", "şu videonun sesini indir", "videoyu indir sonra sesini çıkar"): iş isteği olduğu kendiliğinden anlaşılır ve iş **sohbetin içinde** yapılır — adımlar canlı görünür, komutlar onayına sunulur, soruları sohbetten cevaplarsın. Seçici: ⚡ Otomatik · ⚡ Hep işi yapsın · 💬 Sadece cevap.
- **🧠 Beyin yapay zekâsız iş yapar:**
  - İsteği adımlara böler ("… sonra …"), her adım için **hangi araç(lar)ın yapabildiğini** bulur (kurulu araçlar, README örnekleri, bilgisayardaki ffmpeg / pdfunite / ImageMagick / 7z / yt-dlp, sistem komutları) ve kaç araçla yapılacağını söyler.
  - Komuttaki adresi, dosyayı, sayıyı, metni cümlenden doldurur; sadece dosya adı yazarsan Masaüstü/İndirilenler/Videolar'da bulur; çıktı dosyasının adını kendisi verir, girdinin üstüne asla yazmaz; eksik değeri sorar.
  - Çalıştırır ve **gerçekten işe yaradı mı** bakar (beklenen dosya oluştu mu). Olmazsa: bilinen hata çözümü → **kodu düzeltir** (Python 2 print/except, collections.abc, NumPy eski adlar, CRLF, python→python3, izinler, eski paket sürümleri…) → README/GitHub sorunları/internette araştırır → sıradaki araca geçer.
  - Kurulu araçlarda yoksa **GitHub'da arar**, en uygun adayı (yıldız, güncellik) kurar, README'sini okur, dener; olmazsa sıradaki adayı.
  - Kod değişikliği ve komutlar her zaman onayına sunulur; bunu yaparken öğrendiklerini hatırlar.
- Yapay zekâ açıkken de beyin, kurulu araçlarda bu işe uyanları yapay zekâya önerir.

### 1.5.0 — 🧠 Beyin öğreniyor: yapay zekâlardan öğrenir, onlara soru sorar, kendi modelin, tam yedek
- **🧠 Beyin sayfası + çalışma modu düğmesi (sol altta da var):** 🤖+🧠 İkisi birlikte · 🧠 Sadece beyin (bulut yapay zekâlar tamamen kapalı) · 🤖 Sadece yapay zekâ.
- **Yapay zekâlar iş yaparken beyin izler ve öğrenir:** sohbet cevaplarını, Görev Ajanı'nın yaptığı işleri adım adım (araç kullanma, kurma, internette gezinme, hata çözme), çözülen hataları kaydeder. Yapay zekâ kapalıyken benzer bir istek gelince öğrendiği yolla aynısını yapar.
- **Beyin kendisi soru sorar:** yapamadığı işleri ve cevaplayamadığı soruları not eder; yapay zekâ açıkken o işte en iyi yapay zekâya sorup öğrenir. Öğretilmemiş araçları da arada bir kendisi öğrenir.
- **🎓 Beyne öğret:** "kurulu bütün araçları kullanmayı / hataları çözmeyi / kodlamayı / internette gezinmeyi" ya da kendi konun. Her konuyu o işte en iyi yapay zekâ öğretir. Sohbette, konsolda ya da Görev Ajanı'nda **"beyne şunları öğret: …"** yazmak yeter.
- **🦙 Kendi modelin:** Beyne bilgisayarındaki bir model seçebilirsin (Ollama). "Kendi modelimi oluştur" düğmesi beynin bildikleriyle (araçların, kuralların, örnek konuşmalar) **cypher-beyin** modelini oluşturur; Ollama yoksa önce onu kurar. İnce ayar (fine-tune) için eğitim verisi (.jsonl) de alınabilir.
- **💾 Tam sistem yedeği → Masaüstüne .rar:** beyin ve öğrendikleri, bilgi hafızası, ajan hafızası, sohbetler, kurallar, ayarlar, araçlar (isteğe bağlı kodlarıyla), projeler, uygulamanın kendisi. İsteğe bağlı şifre ve API anahtarları. Aynı sayfadan tek tıkla geri yükleme (önce mevcut hâl ayrıca yedeklenir).

### 1.4.0 — 🧠 Yerel beyin (yapay zekâsız çalışır) + "API cevap vermedi" hatası düzeltildi
- **Yapay zekâ cevap vermese de iş durmaz:** OpenRouter "içi boş cevap" verirse sıradaki modele (akıl yürütme ayarı olmadan), sonra OpenRouter'ın kendi seçimine ve ücretsiz modellere geçer; boş dönen model yarım saat kullanılmaz. Bütün API'ler susarsa **yerel beyin devralır** ve işe devam eder.
- **🧠 Yerel beyin — hiç yapay zekâ bağlantın olmasa bile:**
  - Kurduğun, açtığın ve indirdiğin (git clone) araçların README'sini ve `--help` çıktısını okur: ne işe yaradığı, özellikleri, nasıl çalıştığı (terminal / pencere / web), gereken anahtarlar ve eksik programlar → Türkçe rehber + "🚀 Şunları yapabiliriz" listesi (tek tıkla çalıştır; örnek değerli komutlarda önce değeri sorar).
  - Görev Ajanı, konsol ve sohbet yapay zekâsız da çalışır: "X ne işe yarar", "X'i çalıştır", "X çalışmıyor düzelt", GitHub bağlantısı "kur", "ara", "hangi araçlarım var", doğrudan terminal komutu.
  - Hata olunca: bilgi bankası → README'nin sorun giderme kısmı → aracın GitHub sorunları → internet araması; bulduğu çözümü **onayınla** dener, işe yarayanı öğrenir ve bir dahaki sefere kendiliğinden çözer.
  - Araç kartlarında ve indirilen depolarda **🧠 İncele** düğmesi; Ayarlar'da açma/kapama.

### 1.3.9 — Kategoriler, yalıtım, kalıcı sohbet, uygulama içi güncelleme, çok uygulamalı konsol, ajan becerileri
- **🗂 Araç kategorileri:** Kurulu ve yeni kurulan araçlar amacına göre otomatik gruplanır (🌐 Ağ ve internet, 🛡 Güvenlik, 🤖 Yapay zekâ, 🎬 Medya, ⬇ İndirme, 💻 Geliştirme…). Emin olunamayanları yapay zekâ sınıflar; araç ⚙ menüsünden elle değiştirebilirsin (elle seçtiğin değişmez).
- **🔒 Yalıtım (bubblewrap kafesi):** İşaretli araçlar ev klasörünü, SSH anahtarlarını ve sistem ayarlarını (/etc, DNS…) göremez/değiştiremez; kendi klasörüne ve ortak klasöre yazar. **Araçlar sayfasındaki anahtarla hepsi için tek tıkla kapatılır**, araç başına da açılıp kapanır (internet / pencere / izinli klasör seçenekleri). Ubuntu 24.04'teki AppArmor kısıtını kurulum betiği düzeltir; yalıtım çalışmazsa araç yine normal açılır.
- **💬 Kalıcı sohbet geçmişi:** Sohbetler kaydedilir, uygulama kapanınca kaybolmaz. 🕘 Geçmiş penceresinde arama, eski sohbete dönme, silme; 🆕 Yeni ile temiz sohbet.
- **🔄 Uygulama içinden güncelleme:** Yeni Cypher Tool sürümü GitHub'a gelince bildirim + "⬆ güncelle" düğmesi. Önce yedek alınır, yeni sürüm ayrı ortamda denenir (hata verirse kurulmaz), Uygulamayı Geliştir ile yaptığın değişiklikler yeni sürüme taşınır. Beğenmezsen Yedekler'den geri dönersin.
- **🧩 Bir konsolda birden fazla uygulama:** Konsolun üstündeki "➕ Uygulama" ile istediğin kadar araç eklersin. Konsoldaki yapay zekâ işe en uygun olanı seçer; o hata verirse sıradakini dener ve hangisini kullandığını söyler.
- **📜 Benim kurallarım — bütün yapay zekâlar uyar:** API ile bağladığın her yapay zekâ (sohbet, konsol, ajanlar, onarım, istersen kurulu araçların köprüsü de) kendi bildiğini değil senin dediğini yapar; yazdığın kurallar her isteğin başına eklenir.
- **🧩 Ajan becerileri:** Bir ajana GitHub'dan bir uygulama verirsin (kurulu araçlardan seç ya da bağlantı yapıştır — kendisi kurar). "Sadece bunu kullansın" seçeneği; yeni sürümü çıkınca otomatik kurulur; araç bozulursa o ajan kendi bilgisiyle kodu geliştirip düzeltir.

### 1.3.8 — Bütün yapay zekâ API'leri sorunsuz, her işe en iyi model, uygulama kendini geliştirir
- **Bütün API'ler test edildi ve düzeltildi:** OpenAI, OpenRouter, Anthropic, Gemini, Groq, Cerebras, xAI, DeepSeek, Mistral. Sağlayıcı bir modeli kaldırınca (ör. Groq `llama-3.3-70b`, Cerebras `llama3.1-8b`, xAI `grok-3-mini`, OpenAI `gpt-4o-mini`) uygulama **hesabındaki modellerden uygun olanı kendisi seçer**, kaydeder ve çalışmaya devam eder. Hazır şablonlar güncel modellere çekildi; kapanan GitHub Models kaldırıldı.
- **⚡ Hepsini test et + API ekleyince otomatik test:** yeni API eklediğinde bütün bağlantılar (her API, köprü, özellik başına seçimler) kendiliğinden denenir; çalışmayanın nedeni Türkçe yazılır. OpenRouter'da kredi/kalan bakiye de gösterilir.
- **🧭 OpenRouter akıllı model seçimi:** kredi yüklü OpenRouter hesabında her iş için o işte en iyi model seçilir (kod/onarım, görev ajanı, görsel, çeviri, uzun metin, sohbet, kısa işler). Bütçe: Ekonomik / Dengeli / En iyi; istersen işi elle bir modele sabitle. İlk model olmazsa OpenRouter sıradakine kendisi geçer. Kurulu uygulamalar da köprüden **kendi türüne uygun** modeli alır (kod aracı → kod modeli…).
- **🤝 Bütün ajanlar denesin:** Görev Ajanı'nda en iyi yapay zekâ başlar; işi başaramazsa ya da adım sınırına gelirse işi notlarıyla birlikte **sıradaki API/model devralır** — hepsi denenene kadar (Ayarlar → Otomatik işler'den kapatılabilir).
- **🧬 Uygulamayı Geliştir (yeni sayfa):** yapay zekâ Cypher Tool'u inceler ve eksikleri/eklenebilecek özellikleri önerir. Seçtiğin öneri uygulamanın bir **kopyasında** en iyi kod modeliyle geliştirilir, ayrı bir ortamda derlenip açılarak **denenir**, hata varsa düzeltilir. Değişiklikleri görürsün; **"✅ Uygula" demeden asıl uygulama değişmez**. Uygulamadan önce yedek alınır, "↩ Geri al" ile eski hâline dönülür. ZIP olarak indirip GitHub'a yükleyebilirsin.
- **🧩 Ajanlar uygulamaya hâkim:** ajanlar uygulamanın her sayfasını ve ayarını kendisi kullanabilir (durumu okur, API'leri test eder, ayar değiştirir…). Ayar değiştiren/silen işlemler sorulur; anahtar/şifre gösteren ve uygulama kodunu uygulayan işlemler ajanlara kapalıdır.
- **📎 Her dosyayı ekle — sohbet, Görev Ajanı ve konsol:** fotoğraf, **PDF, EXE, DLL**, **RAR / ZIP / 7z / tar**, metin ve kod dosyaları. Uygulama dosyayı çalıştırmadan inceler: exe/dll için mimari, derlenme tarihi, imza, sürüm bilgisi, kullandığı/sunduğu işlevler, yetenekler (internet, kayıt defteri, klavye dinleme…), sıkıştırılmış/gizlenmiş kod uyarısı, içindeki bağlantılar; PDF'in metni; arşivin içeriği (açılır, içindeki exe/dll de incelenir). Yapay zekâ bu bilgiyle açıklar ve gerekirse daha derin inceler.
- **🧬 Geliştirmede bütün ajanlar dener:** istersen her ajan (API/model) özelliği kendi kopyasında ayrı ayrı yapar; hepsi denenir, en iyi kod modeli sonuçları karşılaştırıp **⭐ önerilen** sürümü seçer. Sen istediğini uygularsın.
- **👁 Önizle:** değişikliği uygulamadan önce geliştirilmiş kopya ayrı bir pencerede (senin araçların ve ayarlarınla) **canlı açılır** — arayüz/görünüm değişikliklerini gerçekten görürsün. Asıl uygulama değişmez.
- **🏆 Hangi işte hangi ajan iyi:** API'ler sayfasında her iş türü (kod, görev ajanı, görsel, çeviri, uzun metin, sohbet, kısa işler) için **en iyi 10 ajan** nedenleriyle listelenir: model kalite puanları + senin bilgisayarındaki gerçek sonuçlar (hangi ajan hangi işi başardı, ne kadar sürdü). Kullandıkça öğrenir; “📌 Bu işte kullan” ile seçebilirsin. Bütün ajanlar denerken de bu sıra kullanılır.
- **Kendi aracını yapma ve araç onarma en iyi kod modeliyle:** yeni araç onayın olmadan kurulmaz.
- **🛡 Sistem ayarları koruyucusu — araçlardan sonra her şey eski hâline:** bir araç (IP değiştirici, VPN, Tor, proxy…) çalışmaya başlamadan önceki hâl saklanır: DNS (/etc/resolv.conf), güvenlik duvarı (iptables/nftables), masaüstü vekil ayarı, ortam değişkenleri, /etc/hosts, ağ yolu. Araç kapanınca değiştirdikleri **kendiliğinden geri alınır**; uygulama penceresini kapatınca çalışan araçlar durdurulur ve her şey eski hâline getirilir. Yönetici izni gereken bir geri alma yapılamazsa sağ altta “↩ Eski hâline getir” kartı çıkar; uygulama çökse bile bir sonraki açılışta hatırlar. (Ayarlar → Otomatik işler'den kapatılabilir.)
- **Kurulum betiği:** daha önce `sudo` ile çalıştırılmış eski Cypher Tool'u kapatır ve root'a ait kalmış dosyaların sahipliğini düzeltir (güncelleme artık yarım kalmaz).
- **💳 Bütçe ve harcama (API'ler sekmesi):** bugün / bu ay ne kadar harcandığı, son 30 günün grafiği, API'ye, işe ve modele göre dağılım, işlerin tek tek maliyeti, son çağrılar. OpenRouter gerçek tutarı bildirir; diğer API'ler için model fiyatından hesaplanır. **Günlük, aylık ve iş başına sınır** koyabilirsin: %80'de uyarı gelir; sınır dolunca ücretsiz modellere geçilir (ya da ücretli API'ler durdurulur); iş başına sınırı geçen iş devam etmeden önce sorar. Sol altta bugünkü harcama hep görünür.
- **🤖 Çalışan ajanları seç (konsol ve sohbet):** yazı kutusunun altında o konsolda/sohbette çalışabilecek ajanlar işaretli kutularla listelenir; işaretini kaldırdığın ajan orada çalışmaz, ötekiler devam eder. Her konsolun ayarı ayrıdır. “🔗 Şu an çalışan” satırı hangi ajanın, hangi iş için seçildiğini gösterir. “Tüm ajanlara sor” için de sohbetteki kişiliklerin yanında işaret kutusu var.
- **🔔 Gereksiz çalışan ajan uyarısı:** sürekli hata veren API, bir iş türünde hep başarısız olan ajan, aynı şeyi tekrarlayıp takılan ya da çok uzun süren iş, çok harcayıp işe yaramayan API sağ altta bildirilir; tek tıkla “⏸ Devre dışı bırak” / “⏹ Durdur” ya da “Bir daha söyleme”.
- **🪟 Wayland desteği (deneme):** Ubuntu'nun varsayılan Wayland oturumunda da yapay zekâ ekran görüntüsü alıp fare/klavye kullanabilir. Ayarlar → Otomatik işler → “🪟 Wayland desteğini kur” (ekran görüntüsü aracı + ydotool + fare/klavye izni; onayınla). En güvenilir sonuç için yine “Ubuntu on Xorg” önerilir.
- **⚡💸 Varsayılan: en ucuz ve hızlı.** OpenRouter'da her iş için önce en ucuz ve hızlı iyi modeller (flash/mini/lite) seçilir ve denenir; ağır, yavaş düşünen ve pahalı modeller geriye düşer, cevaplar kısa düşünmeyle hızlı gelir. Bir ajan başaramazsa sıradaki ucuz-hızlı model devralır. API'ler → OpenRouter kartından Dengeli / En iyi'ye geçebilirsin.
- **🤖 Ajanı kendin seç (sohbet ve konsol):** yazı kutusunun üstündeki “🤖 Ajan / Cevaplayan” listesinden istediğin API'yi/modeli seç (OpenRouter'da her işte öne çıkan modeller de listede). Varsayılan **Otomatik**. Yanındaki “🔁 Başaramazsa otomatik geç” açıksa seçtiğin ajan başaramazsa iş sıradakine geçer; kapalıysa sadece seçtiğin çalışır. Seçimin hatırlanır.
- **Devretme düzeltildi:** hiçbir yapay zekâ cevap veremediğinde (internet/DNS kesik, anahtar hatalı…) artık “sıradaki devralıyor” deyip beklemiyor; hangi API'nin neden çalışmadığını sohbete Türkçe yazıyor. DNS kesikse bunu ayrıca söylüyor.
- **🏆 Her konsolda önerilen ajanlar:** bir uygulamanın konsolu açılınca o uygulama için en iyi 3 ajan yazılır; konsol yapay zekâsı 1.'yi kullanır, başaramazsa sıradaki devralır.
- **⚠ Uygulama çalışırken hata verirse:** kapanmasını beklemeden hata yakalanır ve **bütün ajanlar sırayla çözmeye çalışır** (en iyiden başlayarak).
- **🧬 Kendiliğinden geliştirme önerisi:** Cypher Tool'un kendi kodunda bir hata olursa ya da bir uygulama Cypher Tool'da eksik bir özellik yüzünden açılamazsa sağ altta “Geliştirme önerisi” kartı çıkar. Tıklayınca Geliştir sayfasında hazır olur; sen onaylamadan hiçbir şey değişmez.
- **🎓 Ajan eğitimi (Ajanlar & Sohbet → 🎓 Ajanı eğit):** bir ajanı istediğin işte uzmanlaştır — ne iş yapacağını yaz (ya da hazır şablon seç), istersen bağlantı/YouTube videosu/PDF ver; ajan internetten ve YouTube'dan kendisi araştırır, öğrendiklerini **kendi hafızasına** yazar, gerekli araçları bulup kurar ve çalıştığını doğrular, sonunda kendini sınar. “Sadece bu işi yapsın” ve “her hafta yeni bilgileri öğrensin” seçenekleri var. Öğrendiklerini görebilir, istemediğini sildirebilirsin.
- **👍 / 👎 ile öğret:** sohbette ajanın cevabını beğenirsen örnek olarak saklanır; yanlışsa doğrusunu yazarsın, ajan bir daha öyle cevap verir.
- **⚡ İşi yapsın:** sohbette bu seçenek açıkken seçili (eğitilmiş) ajan sadece cevap vermez, işi araçlarıyla kendisi yapar.
- **🏁 GitHub'dan bul ve kur (sohbet ekranında):** bir araç istediğinde bütün yapay zekâ ajanları GitHub'da arar, oylar, en iyi adayları güvenlik taramasından geçirip kurar ve dener; **en iyi ve sorunsuz çalışan** kalır. Sohbette araç isteğine benzeyen bir şey yazınca bu kendiliğinden önerilir.

### 1.3.7 — API'ler sessizce çalışmamazlık etmesin
- **Gemini düzeltildi:** varsayılan model `gemini-2.5-flash` yeni hesaplara kapalı olduğu için yeni Gemini anahtarları hiç cevap vermiyordu. Artık varsayılan `gemini-flash-latest`; model bulunamazsa uygulama **hesabındaki modelleri listeleyip en uygun Flash modelini kendisi seçer** ve kaydeder. Modelin iç "düşünce" metni cevaptan ayıklanır.
- **Hatalar Türkçe açıklanır:** ⚡ Test et başarısız olursa nedeni yazılır (anahtar geçersiz, kredi yok, kota doldu, model hesabında yok, erişim reddedildi…) ve ne yapılacağı söylenir. API listesinde son denemede çalışmayanların yanında ⚠ uyarısı çıkar.
- **Gemini aboneliği uyarısı:** Google AI Pro / Gemini aboneliği API'yi kapsamaz (sadece AI Studio web arayüzünde geçerli); "kredi bitti" hatasında bu açıkça söylenir.
- **Satın aldığın API öncelikli:** kendi anahtarınla eklediğin API "⭐ öncelikli" olur; çalıştığı sürece otomatik seçimde ve araç başına seçimde önce o kullanılır.
- Yeni akıl yürütme modelleri (o1/o3/gpt-5…) "temperature" ayarını reddedince uygulama kendiliğinden ayarsız tekrar dener; boş cevap artık hata sayılır (sessiz kalmaz).

### 1.3.6
- **🖥 Sisteme uygula — araçların etkisi tüm bilgisayarda:** konsolda çalışan bir aracın vekil sunucusu (IP değiştirme, Tor, VPN) normalde sadece o konsoldaki programları etkiler. Artık yerel vekil sunucular **kendiliğinden bulunur** (konsolda "🌐 Tor çalışıyor → 🖥 Tüm sisteme uygula") ve tek tıkla Ubuntu'nun **sistem vekil ayarına (GNOME/KDE)** + yeni açılan terminallere uygulanır. Ortam değişkenleri de eklenebilir. Ayarlar → **Sisteme uygulananlar**: liste, ↩ Geri al, 🌐 IP doğrulama, elle ekleme. Yapay zekâ da kullanabilir ("bunu bilgisayarımın tamamında da uygula"), önce sorar.
- **Güvenlik bekçisi:** araç kapanırsa (vekil sunucu durursa) sistem ayarı ~30 sn içinde **kendiliğinden geri alınır** — uygulama kapalıyken bile; bilgisayarın internetsiz kalmaz.
- **🖥 Sistem terminalinde aç:** bir aracı uygulamanın dışında, sistemin kendi terminalinde başlat (aracın ⚙ menüsü).
- **🔐 Şifreyi bir kez gir:** yönetici (sudo) şifresi bir kez girilince hatırlanır; uygulamanın kurulumları ve konsolda `sudo` soran araçlar artık tekrar sormaz (şifre kendiliğinden girilir). **Güvenlik uyarısı verenler** (sistem dosyası silme, disk biçimlendirme, kullanıcı/şifre/sudoers ayarı vb.) **yine sorar**. Şifre sadece bellekte durur — diske yazılmaz, kayıtlara ve yapay zekâya gitmez, ekrana düşmez; uygulama kapanınca unutulur. Ayarlar → Otomatik işler: "oturum boyunca / 1 saat / her seferinde sor" + 🔒 Şimdi unut.
- Ayarlar'daki uzun açıklamalı anahtarların dağınık görünmesi düzeltildi.

### 1.3.5 — kurulum artık takılmıyor ve ne yaptığını gösteriyor
- **Takılma düzeltildi:** Ubuntu'nun "needrestart / debconf" soruları görünmez pencerede cevap bekleyip kurulumu kilitliyordu; artık tüm paket kurulumları soru sormadan çalışır (kurulum betiğinde, Sistem sekmesinde, araç kurulumlarında ve yapay zekânın yazdığı `apt install` komutlarında).
- **Canlı ilerleme:** her paket tek tek kurulur: `[2/5 %40] xdotool kuruluyor  12s  Unpacking…` — ne yaptığı, kaç saniyedir sürdüğü ve son satır görünür. Bekleme sırasında küçük bir 🦖 kaktüslerin üstünden zıplayarak koşar (sadece animasyon).
- **Takıldığı yeri yazar:** 90 saniye ilerleme olmazsa "Takıldığı yer: …" ve paket yöneticisini kilitleyen işlemi (ör. Ubuntu'nun otomatik güncellemesi) söyler; kilit açılana kadar bekler (15 dk'ya kadar), sonra kendiliğinden devam eder. Tüm ayrıntılar: `~/.cache/cyphertool-kurulum.log`.
- Şifre en başta bir kez sorulur ve kurulum boyunca hatırlanır; kurulamayan paket olursa kurulum durmaz, sonda listelenir.

### 1.3.4 — internette gezinme, kapsamlı sınama ile sağlamlaştırıldı
- **🌐 + 💻 aynı anda:** 🌐 sekmesi açıkken ekran bölünür — üstte tarayıcı, altta konsol (ayırıcıyı sürükle). ⬒ ile tarayıcıyı büyüt, ✕ ile gizle; konsol sekmesi değiştirince tarayıcı açık kalır.
- **Arama motoru seçimi:** Google (varsayılan), Bing, DuckDuckGo, Startpage ya da kendi adresin.
- **Çerez izni sonrası aramaya döner:** Google'ın "devam etmeden önce" sayfasından sonra arama kaybolmaz.
- **Açılır pencereleri kapatır:** bülten / reklam pencereleri sayfanın üstünü kapatıyorsa yapay zekâ bunu görür, tıklamadan önce ✕/Kapat/Esc ile kendisi kapatır.
- **Web bileşenleri ve iç çerçeveler:** gölge DOM'daki ve iframe içindeki düğme/kutular da görülür, tıklanır, yazılır.
- **Sabit öğe numaraları:** aynı sayfada bir öğenin numarası değişmez (menü kapanınca yanlış yere tıklama olmaz).
- **Reklamları ayırt eder:** sponsorlu sonuçlar "REKLAM" diye işaretlenir, yapay zekâ organik sonuçları seçer.
- **Sayfa içeriğinin oturmasını bekler** (sonradan yüklenen içerik, "Yükleniyor…"), **gerçek fare tekerleğiyle kaydırır** (sonsuz kaydırma), kaydırınca ekrandaki kısmı okur.
- **Formlar:** seçim kutusu adı ve seçenekleri, işaret/radyo durumu (☑/☐) görünür. "Sepete ekle" serbest; "Satın al / Öde" sorulur; "Gönder/Paylaş" yalnızca mesaj/e-posta/gönderi yazılmışsa sorulur.
- **Uygulama içi görünümde** üzerine gelince açılan menüler çalışır (fare hareketi sayfaya iletilir).
- Düzeltmeler: sitenin kendi açtığı yeni sekmeler de 🌐 sekmesi olur; aynı sekmenin iki kez görünmesi, konsol açılış yazısının iki kez çıkması, adres çubuğundan gidince geri dönme hataları giderildi.

### 1.3.3
- **Arama kutuları daha sağlam:** düğmeye basınca açılan arama pencerelerine (GitHub, YouTube ve birçok modern site) doğru yazar; arka planda kalan sekmelerde de yazı kaybolmaz.
- **Açılamayan sayfayı anlar:** site yoksa, internet yoksa ya da sertifika hatası varsa yapay zekâ bunu fark eder, hata sayfasını okumaya çalışmaz, başka kaynağa geçer (sertifika hatalı sayfaya girmez).

### 1.3.2
- **🧩 İlk kurulumda her şey kurulur:** `kur.sh` temiz bir Linux'ta uygulamanın tüm özellikleri için gerekenleri kurar: Python venv/pip, derleyici, curl/wget/unzip/7z, git-lfs, bildirimler, masaüstü kontrolü (xdotool, wmctrl, scrot, Pillow) ve uygulama içi tarayıcı için **Google Chrome** (yoksa Chromium). Sadece eksikler kurulur; biri kurulamazsa kurulum durmaz, Sistem sekmesinden tekrar denenebilir.
- **🧩 Doğrulama çıkınca bekler:** robot doğrulaması gelince sesli uyarı + bildirim, ilgili 🌐 sekmesi açılır; sen "Ben robot değilim"e basınca yapay zekâ **kendiliğinden** devam eder (sohbete yazman gerekmez).
- **🔌 Hesaplar (Ayarlar):** **WordPress** (yazı/sayfa/yorum/eklenti — uygulama parolasıyla), **Meta reklamları** (kampanya, reklam seti, rapor — Marketing API v26) ve **Google Ads** (kampanya raporları, durdur/başlat, bütçe — API v26, "🔑 Google ile bağlan"). Okuma serbest; **para harcatan, yayınlayan, silen her işlem sağ altta sorulur** (tam otomatikte bile); yeni içerik taslak, yeni reklamlar duraklatılmış oluşturulur. Hesap bağlamadan da olur: uygulama içi tarayıcıda giriş yaparsın, yapay zekâ oradan yönetir.

### 1.3.1 — gezinme sağlamlaştırması
- **🍪 Çerez / izin pencereleri kendiliğinden kapanır** (varsayılan "Tümünü reddet"; Google/YouTube AB izin sayfası dahil). Ayarlar → Otomatik işler'den "kabul et" ya da "dokunma" seçilebilir.
- **Normal Chrome gibi görünür:** görünmez tarayıcı kendini "HeadlessChrome" olarak tanıtmaz, dil Türkçe — siteler daha az "robot musun?" sorar.
- **🧩 Doğrulama (CAPTCHA) çıkarsa** sağ altta kart çıkar; sen 🌐 sekmesinde çözersin, yapay zekâ bekleyip devam eder (doğrulamayı kendisi çözmeye çalışmaz).
- **Yeni sekmede açılan bağlantılar** aynı 🌐 sekmesinde açılır; **uyarı pencereleri (alert)** sayfayı dondurmaz; **indirilen dosyalar** İndirilenler klasörüne gider.
- **− / + yakınlaştırma:** dar panelde siteler masaüstü görünümüyle sığar (varsayılan dar panelde %80).
- Uygulama yeniden açılınca **açık 🌐 sekmeleri geri gelir.**

### 1.3.0
- **🌐 Tarayıcı uygulamanın içinde:** Google ve siteler artık ayrı pencerede değil, Konsol'daki 🌐 sekmesinde açılır (adres çubuğu, geri/ileri, tıkla, kaydır, yaz, Türkçe karakter, yapıştır). Yapay zekâ arama yaparken orada canlı izlersin; sohbet paneli yanında açık kalır.
- **🤖 Yapay zekâ tarayıcıda kendisi yapar:** yazar, arar, tıklar, sayfalara girer; nereye basacağından emin değilse ekran görüntüsü alıp (numaralı kutularla) görsel modelle bakar. Sadece ödeme / gönderme / silme gibi geri alınamaz adımlarda sağ alttaki kartla sorar; şifre ve kart alanlarına asla yazmaz.
- **🖥 Masaüstü kontrolü:** yapay zekâ masaüstündeki uygulamaları açıp kullanabilir (koordinat ızgaralı ekran görüntüsü + fare/klavye, xdotool). Çalışırken sağ altta "⏹ Durdur" kartı görünür. (X11/Xorg oturumu gerekir; Wayland'de giriş ekranından "Ubuntu on Xorg" seç.)
- **📚 Öğrenen hafıza:** araştırdıklarını (web sayfaları, YouTube videolarının altyazı özetleri) bilgi hafızasına yazar, benzer görevde önce bunları hatırlar. Sohbet ⚙ menüsünde "📚 Öğrendiklerim".
- **📺 YouTube'dan öğrenme:** "YouTube'da X anlatan video bul ve özetle" dersen videonun altyazısını okuyup Türkçe özet ve öğrenilenleri çıkarır.
- **🎓 Önce öğren, sonra kullan:** bir aracı ya da uygulamayı ilk kez kullanmadan önce README'yi, web kaynaklarını ve gerekirse bir videoyu inceleyip öğrenir; sonra sana ne işe yaradığını anlatır.

### 1.2.9
- **⏸ Aktif / pasif araçlar:** Konsol listesinde ☑ ile araç seç → "✔ Sadece bunlar aktif" / "⏸ Pasif yap". Pasif araçlar kendiliğinden hiçbir şey başlatmaz (izleme, otomatik onarım, güncelleme yok), çalışıyorsa durdurulur, listede aşağıda "Pasif araçlar" bölümünde durur.
- **🧩 Hangi araç hangi konsolda:** her araç kendi sekmesinde açılır (varsayılan). İstersen seçtiğin araçları "🧩 Tek konsolda topla" ile bir grup konsolunda birleştir: konsolun üstünde her biri için ▶ düğmesi olur, yapay zekâ o sekmede önce bu araçları kullanır. Aracın ⚙ menüsünden de ayarlanır.
- **📖 Araca tıkla → yapay zekâ anlatsın:** listeden bir araca tıklayınca araç kendi konsolunda açılır, yapay zekâ önce ne işe yaradığını, neler yaptığını ve nasıl kullanıldığını anlatır, öneriler verir. Ayrı iş için ＋ ile yeni konsol aç.
- **🔔 Büyük pencereler yerine sağ altta küçük bildirim:** onarım, onay ve şifre istekleri yarı saydam bir kartta çıkar (✔ Onayla / ✖ / 🔍 Ayrıntı / ✕ kapat). Onarım arka planda sürer, bitince kart kendiliğinden kapanır.
- **🤖 Tam otomatik onarım:** yapay zekâ bağlıyken onarım onay sormadan çalışır. Önce hata mesajının önerdiği komut denenir (ör. "Run `… setup`"), sonra kurulu tüm API'ler ve modeller sırayla dener; takılan model sıradakine devreder. Tehlikeli komutlar engellenir, başarısız onarım aynı araç için 20 dakika tekrar başlamaz.
- **💻 Yerel ağır kurulumlar sorulur:** Ollama, yerel model indirme, llama.cpp gibi bilgisayarı yoran işlerde önce sana sorar. "🚫 Hayır, bir daha sorma" dersen bir daha sorulmaz, yapılmaz.
- **🔐 Şifre isteyen uygulamalar:** bir uygulama (sudo vb.) şifre isterse sağ altta hangi uygulamanın istediğini gösteren kart çıkar; şifre doğrudan o uygulamaya gider, hiçbir yere kaydedilmez.
- **⚙️ Ayarlar → Otomatik işler:** neyin kendiliğinden çalışacağı tek yerde (tıklayınca yapay zekâ, açılan programları izleme, API yarıştırma, tam otomatik onarım, hata çıkınca onarım, yerel kurulum izni, konsol yerleşimi).

- **💻 Yeni Konsol sayfası (tek ekran):**
  - Solda sade bir liste: en üstte Google Chrome, sonra Cypher ile kurduğun araçlar, sonra diskte bulunan GitHub depoların. Linux'un kendi programları listede görünmez; yapay zekâ onları yine kullanabilir.
  - Ortada her zaman açık konsol, sağda sohbet paneli. Konsolun hemen altında ince bir mesaj kutusu var; yapay zekâya oradan yazarsın.
  - Sayfa aşağı kaymaz. Pencereyi büyütünce konsol ve sohbet büyür, liste sabit kalır.
  - Aradaki çizgileri fareyle sürükleyerek genişlikleri ayarlayabilirsin; çift tıklayınca sıfırlanır.
  - Görev kayıtları artık ayrı pencerede açılır, konsol hep yerinde kalır. Uygulama içinde çalışan araçlar konsolun yanında sekme olarak görünür.
- **📋 "Hangi araçlarım var?":** Yapay zekâya sorduğunda tüm araçlarını (Cypher ile kurulanlar + diskteki GitHub depoları) kategorilere ayırıp her birinin ne işe yaradığını ve öne çıkan özelliklerini özetler. Açıklaması eksik olanları README'sini okuyarak öğrenir, çalışmayanları ⚠ ile belirtir. Tek bir aracı sorarsan ayrıntılı anlatır. Konsoldaki listenin üstündeki **📋** düğmesi bunu tek tıkla sorar.
- **🏁 Araç yarışması:** "GitHub'da şu özellikte araç bul, dene, en iyisini kur" de ya da konsoldaki listenin üstündeki **🏁** düğmesine bas. Adımlar:
  1. Kurulu tüm API'ler aynı anda GitHub arama sorguları ve bildikleri depoları önerir; adaylar toplanır.
  2. Yıldız, son güncelleme, arşiv durumu ve lisansa göre ön elemeden geçerler.
  3. Tüm API'ler README'leri okuyup isteğine en uygunlara oy verir.
  4. En öndeki adaylar (varsayılan 3) kurulur. Kurulum öncesi güvenlik taramasında tehlikeli bulgusu çıkan aday elenir.
  5. Her aday, senin istediğin özellikle güvenli bir testten geçer; test sadece yerel ve zararsız girdiler kullanır. Çıktıyı API'ler 0–10 arası puanlar.
  6. Sonuç tablo halinde gelir. Kazanan kurulu kalır; kaybedenleri kaldırmak için sana sorulur ya da istersen sormadan kaldırılır.
- **🧠 Her araç için en iyi yapay zekâ:** Konsolda bir aracı ilk açtığında kurulu tüm API'lere o araca özel aynı küçük görev verilir: aracın gerçek seçenekleriyle doğru komut yazmak. Geçerli cevap, belgeye uygunluk ve hız puanlanır, en iyisi o araç için seçilir. Sonra her oturumda hangi API'nin işi bitirdiği ve kaç hata yaptığı kaydedilir; sıralama kullandıkça gerçek sonuçlara göre değişir. API seçimi varsayılan olarak **🤖 Otomatik**; ⚙ menüsünden bir API'yi sabitlersen o kullanılır. Aracın ⚙ ayarlarında puan tablosu ve **🔄 Yeniden yarıştır** düğmesi var; ⓘ kartında "🧠 En iyi beyin" yazar.
- **🔍 Görünüm ve okunabilirlik (Ayarlar):** Uygulamanın ölçeği (yazılar, düğmeler, boşluklar birlikte) %80–%200 arasında ayarlanır. Hazır düğmeler (Otomatik, %90 … %175) ve bir sürgü var; "Otomatik" ekran büyüklüğüne göre okunaklı bir değer seçer. Kısayollar: **Ctrl + +** büyüt, **Ctrl + -** küçült, **Ctrl + 0** otomatik. Konsol yazı boyutu ayrıca ayarlanır; **Yüksek kontrast** soluk yazıları belirginleştirir. Ayarlar bilgisayarda hatırlanır ve sadece uygulamanın görünümünü değiştirir, işletim sisteminin ekran ayarlarına dokunmaz.
- **🛠 Ajanla onar (yenilendi):** Düğmeye basınca onarım konsolda, gözünün önünde ve **sormadan** başlar; yönetici şifresi yine sorulur, tehlikeli komutlar yine elenir. Önce hata tüm API'lere birden sorulur. Olmazsa yapay zekâ internette araştırır: GitHub konuları, Stack Overflow ve resmi belgeleri okuyup çözümü öğrenir. Hazır çözüm yoksa eksik dosyayı ya da kodu kendisi yazar, uyumsuz kodu düzeltir; son çare olarak aynı işi yapan küçük bir araç üretir. Başaramazsa iş sıradaki API'ye geçer.
- **🧠🧠 Çok beyinli onarım:** Bir kurulum ya da araç hata verince önce bilgi bankasındaki çözüm denenir. Olmazsa hata **kurulu tüm API'lere aynı anda** sorulur; öneriler (kaç API aynı çözümde birleşti, güvenleri, bu araçtaki geçmiş başarıları) puanlanıp en iyisinden başlayarak denenir. O da tutmazsa onarım ajanı en iyi API ile çalışır; başaramazsa önceki denemelerin özetiyle **sıradaki API'ye devreder**, araç çalışana kadar (en fazla 5 API). Bulunan çözüm bilgi bankasına kaydedilir; aynı hata bir dahakine anında çözülür.
- **ⓘ Bilgi kartları:** Araçlarım sayfasındaki her kartta ve konsoldaki listede küçük bir **i** düğmesi var. Fareyle üzerine gelince aracın ne işe yaradığı, öne çıkan özellikleri, kategorisi ve durumu görünür; tıklayınca Türkçe rehberi açılır. Açıklaması eksik araçlar için Araçlarım sayfasındaki **🧠 Açıklamaları tamamla** düğmesine basınca yapay zekâ hepsini tek tek inceleyip doldurur.
- **🛠 Açılamazsa otomatik onarım:** Bir araç ya da uygulama açılamazsa (çalıştırma komutu yok, kurulum hatalı, uygulama açılmıyor) yapay zekâ hemen konsolda onarmaya başlar, sonra aracı çalıştırır.
- **✨ Araç geliştirme:** Araç kartındaki **✨ Geliştir** düğmesi (konsoldaki araç listesinde ve depo bilgi penceresinde de var). Dört seçenek sunar:
  - **💡 Bana yeni özellikler öner:** Yapay zekâ aracı, kodunu ve GitHub'daki kullanıcı isteklerini (issues) inceler. "İstersen şunları ekleyebilirim" diye somut önerilerle sana sorar ve seçtiğini ekler.
  - **🩺 Çalışmayan özellikleri bul ve onar:** README'deki özellikleri tek tek dener. Bozuk olanların nedenini kodda bulur, internette araştırır, düzeltir ve yeniden dener.
  - **✍️ İstediğim özelliği ekle:** Ne istediğini yazarsın. Kodu okur, gerekirse resmi belgelerden ve örneklerden öğrenir, özelliği ekler, test eder ve README'ye yazar.
  - **🐞 Şu çalışmıyor:** Sorunu yazarsın. Yeniden üretir, kök nedenini bulur ve düzeltir.
  - Her iş bitince **"Şu özellikleri de ekleyebilirim"** diye yeni öneriler sunar. Otomatik onarım da artık gerekirse aracın kodunu düzeltebilir.
- **🛡️ Geliştirmeler güvenli ve geri alınabilir:**
  - Tüm değişiklikler aracın klasöründe **`cypher-gelistirme`** adlı ayrı bir git dalında tutulur; orijinal hal korunur.
  - Her çalışan adım ayrı kaydedilir. **🕘 Geliştirme geçmişi**'nden tek tek **↩ geri al**abilir ya da tek tıkla **orijinal sürüme dönüp** sonra geri gelebilirsin.
  - Kod değişiklikleri (Sormadan çalıştır kapalıyken) önce renkli fark gösterimiyle onayına gelir.
  - Araç güncellenince orijinalin yeni sürümü alınır ve **senin geliştirmelerin onun üstüne yeniden uygulanır**. Çakışma olursa hiçbir şey değişmez ve sana söylenir.
  - Hiçbir şey GitHub'a gönderilmez.
- **🔎 Araştırmayı Chrome'da göster:** Açıkken yapay zekânın internet aramaları **Google'da, ekranda görebileceğin bir Chrome penceresinde** yapılır ("🔎 Araştırma" penceresi). Okuduğu sayfalar da aynı pencerede açılır; ne aradığını ve neyi okuduğunu canlı izlersin.
  - Anahtar Görev Ajanı, Konsol yapay zekâsı ve ✨ Geliştir penceresinde var; varsayılan olarak açık.
  - Google ilk kullanımda çerez onayı isterse yapay zekâ "Tümünü kabul et"e tıklamak için sana sorar.
  - Google robot kontrolü isterse pencerede kendin çözebilirsin; o sırada arama yedek motorla devam eder.
- **🗂️ Çoklu konsol sekmeleri:** Konsolun üstündeki **＋ Yeni sekme** ile istediğin kadar konsol aç. Her sekmenin kendi yapay zekâ sohbeti vardır; bir sekmede araç çalışırken diğerinde yapay zekâ başka iş yapabilir. Sekme adını değiştirmek için çift tıkla. Sekmedeki 🤖 ve renkli nokta, orada yapay zekânın çalıştığını (mor) ya da cevabını beklediğini (sarı) gösterir.
- **📜 Tarifler (oturumu kaydet → tekrar oynat):** Yapay zekâ bir işi başarıyla yaptıktan sonra **💾 Tarif kaydet** ile adımlarını (komutlar, konsola yazılanlar, kurulumlar, tarayıcı adımları) kaydet. **📜 Tarifler**'den:
  - **▶ Aynen:** Kaydedilen adımlar sırayla tekrar çalışır (önce listeyi onaylarsın). Bir adım takılırsa yapay zekâ kaldığı yerden devralabilir.
  - **🤖 Uyarla:** Yapay zekâ tarifi rehber alıp bugünkü duruma ve yazdığın değişikliğe göre yapar (ör. "bu sefer ~/Belgeler klasörü için").
- **⚡ Komut geçmişinden kısayol:** Konsolda aynı komutu sık yazarsan (varsayılan 3+ kez) "Kısayol yapayım mı?" diye sorar. Kısayollar konsolun üstünde düğme olur; istersen **kısa ad (alias)** da verirsin, konsolda onu yazman yeter. Şifre/anahtar içeren komutlar önerilmez; yapay zekânın çalıştırdığı komutlar geçmişe yazılmaz.
- **🐙 Depo bilgisi, güven puanı ve karşılaştırma (GitHub sekmesi):** Her deponun yanındaki **ℹ** düğmesi: yerel durum (dal, son commit, kaydedilmemiş değişiklik), uzakta yeni commit var mı, GitHub bilgileri (yıldız, son güncelleme, arşiv, lisans), kurulum öncesi taramayla aynı **güvenlik taraması** ve bunlardan hesaplanan **0–100 güven puanı**. İstersen bulguları yapay zekâya da inceletebilirsin. **⬆ Güncelle** `git pull --ff-only` yapar (kaydedilmemiş değişikliklerin varsa önce `git stash` ile korunur). **🔍 Güncellemeleri kontrol et** hepsini birden tarar; **⚖️ Karşılaştır** ile depoları seçip yan yana tablo ve yapay zekâ önerisi alırsın.
- **➕ Cypher'a ekle:** Diskte zaten kurulu bir depoyu yerinden oynatmadan Cypher Tool'a ekler: araç kartı, güncelleme takibi, Türkçe rehber ve kısayol. (Kaldırırsan sadece kaydı silinir, klasörüne dokunulmaz.)
- **🧭 Görsel tarayıcı kontrolü (çoklu pencere):** Yapay zekâ kendi kontrol ettiği tarayıcıda (Chrome/Chromium/Brave/Edge) **aynı anda birden fazla pencere** açar, hepsini birlikte okur, sayfalarda **tıklar, yazar, listeden seçer, kaydırır**, ekran görüntüsüne bakar.
  - **Her tıklama ve yazma önce sana sorulur**, "Sormadan çalıştır" açık olsa bile. Onay penceresinde işlem yapılacak yer kırmızı çerçeveyle gösterilir.
  - Şifre, kart numarası ve doğrulama kodu alanlarına yapay zekâ **asla yazmaz**; onları pencerede kendin girersin.
  - Bu tarayıcının kendi profili vardır (`~/CypherTool/tarayici/profil`); giriş yaptığın siteler orada hatırlanır, kendi Chrome'una dokunulmaz.
  - Açık pencereler konsol sayfasının solundaki **🌐 Tarayıcılar** listesinde görünür (📸 ile anlık görüntü, ✖ ile kapat, ＋ ile elle aç). Ekran yoksa görünmez modda çalışır.
- **💻 Konsol + 🤖 Konsol Yapay Zekâsı (Görevler & Konsol sayfası):** Sayfa açılınca gerçek bir Bash konsolu açılır. Altındaki sohbet kutusuna ne istediğini yaz; yapay zekâ komutları **bu konsolda** çalıştırır (canlı görürsün), etkileşimli programlara yazar (`type_keys`), ekranı okur (`read_screen`), Google'da arar ve siteleri tarayıcıda açar (`open_browser`). Yapay zekâ konsolun o anki klasöründe çalışır. "Sormadan çalıştır" kapalıyken her komut ve tarayıcı açma önce onayına gelir. **$ Komut** düğmesi kutudaki metni yapay zekâya sormadan doğrudan konsola yazar.
- **🧰 Araçlar listesi (konsolun solunda):** Dört sekme var: *Cypher* (Cypher Tool ile kurduklarım), *🐙 GitHub* (bilgisayarda `git clone` ile zaten kurulu depolar: ev klasörü, `/opt`, `/usr/local/src`, `/srv` taranır), *Programlar* (PATH'teki komutlar) ve *Uygulamalar*. Bir araca tıklayınca konsolda açılır, yapay zekâ README'yi okuyup o araçla neler yapabileceğini anlatır ve kullanır. **▶** ise yapay zekâsız, sadece çalıştırır. Taranacak ek klasörleri `~/.config/cyphertool/config.json` içine `"repo_dirs": ["~/baska/klasor"]` olarak ekleyebilirsin.
- **🛡️ Kurulum öncesi güvenlik taraması:** Depo kurulmadan önce zararlı kalıplara (ters kabuk, madenci, gizlenmiş kod, şifre dosyalarına erişim vb.) karşı taranır; tehlikeli bulgu varsa kurulum planında en üstte kırmızı uyarı çıkar.
- **📘 Yapay zekâ ayrıntılı Türkçe belge yazar:** Yeni kurulan her araç için README ve aracın kendi `--help` çıktısı okunur; *Ne işe yarar, Özellikleri, Nasıl çalışır, Komutlar, Örnekler, Görev Ajanı'na örnek istekler* bölümleriyle Rehber oluşturulur. Görev Ajanı aracı "tanır" ve sonra kendisi kullanabilir.
- **🤖 "Yapay zekâ kendisi kursun" seçeneği** (Kur sayfası): plan onaylatılmadan kurulur, hata çıkarsa kendisi çözer (yönetici şifresi yine sorulur).
- **🎯 Görev Ajanı daha akıllı:** GitHub'da en az 3 adayı karşılaştırıp en güncel ve çalışanı seçer, çalışmayanı (onayınla) kaldırır; hata alınca hemen internette çözüm arar; bilgisayarın ayar pencerelerini açabilir (ses, ağ, ekran…); tarayıcıyı açıp Google'da arama yapabilir; JavaScript'li sayfaları gerçek tarayıcıyla okuyabilir.

## Hazır katalog (test edilmiş tarifler)

deep-research (drsh), Flint Agent, clai (pentoshi007), clai (baalimago), gptme, OpenSquilla, ARIA, Aider, Local Deep Research, Open WebUI.

## Güvenlik

- Hiçbir komut onayın olmadan çalışmaz. Riskli komutlar (`curl | sh`, `rm -rf /` vb.) ayrıca işaretlenir.
- Arayüz sadece `127.0.0.1` adresinde çalışır ve her istek oturuma özel rastgele bir anahtarla korunur.
- Release dosyalarının SHA256 sağlaması mümkün olduğunda doğrulanır.
- API anahtarları `~/.config/cyphertool/` altında yalnızca senin okuyabileceğin dosyalarda (izin 600) tutulur.

## Klasörler

- `~/CypherTool/tools/`: kurulan araçlar
- `~/CypherTool/runtimes/`: sudo'suz Node.js, uv ve Python
- `~/CypherTool/exports/`: dışa aktarımlar
- `~/.config/cyphertool/`: ayarlar, API'ler, araç kayıtları

Gereksinimler: Linux, Python 3.9+, git. Arayüz için Chromium, Chrome, Brave veya Firefox önerilir; uygulama penceresi gibi açılır.
Windows'ta WSL2 (Ubuntu) içinde çalışır.
