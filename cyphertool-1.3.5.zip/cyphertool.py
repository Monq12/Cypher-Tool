#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cypher Tool — GitHub araç kurucu, çalıştırıcı ve çoklu-API ajan paneli (Linux)

Kullanım:
  cyphertool                      Arayüzü aç
  cyphertool kur <link> [<link>]  Terminalden kur (ct <link> de olur)
  cyphertool liste                Kurulu araçları listele
  cyphertool calistir <ad>        Aracı terminalde çalıştır
  cyphertool gorev "<istek>"      Görev Ajanı: araştır, kur, dene, kullan (ct gorev ...)
  cyphertool kontrol              Güncellemeleri kontrol et (günlük zamanlayıcı bunu çağırır)
  cyphertool disa-aktar [--tam]   Tüm araçları dışa aktar
  cyphertool ice-aktar <dosya>    Dışa aktarılmış dosyayı içe aktar
  cyphertool sunucu               Sadece sunucuyu başlat (pencere açmadan)
"""
import os, sys, re, json, time, uuid, shutil, shlex, base64, platform, secrets, signal
import tarfile, zipfile, threading, subprocess, hashlib, tempfile, importlib.util, pty, fcntl
import urllib.request, urllib.error, urllib.parse, socket
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

APP = "Cypher Tool"
VERSION = "1.3.5"
APP_DIR = os.path.dirname(os.path.realpath(__file__))
WEB_DIR = os.path.join(APP_DIR, "web")
CATALOG_FILE = os.path.join(APP_DIR, "catalog.json")
CONF_DIR = os.path.expanduser("~/.config/cyphertool")
CONF_FILE = os.path.join(CONF_DIR, "config.json")
TOOLS_FILE = os.path.join(CONF_DIR, "tools.json")
ENV_FILE = os.path.join(CONF_DIR, "env.sh")
GATEWAY_PORT = 11500
SESSION_FILE = os.path.join(CONF_DIR, "session.json")
DATA = os.path.expanduser("~/CypherTool")
TOOLS_DIR = os.path.join(DATA, "tools")
ICON_DIR = os.path.join(DATA, "icons")
LAUNCH_DIR = os.path.join(DATA, "launchers")
EXPORT_DIR = os.path.join(DATA, "exports")
LOG_DIR = os.path.join(DATA, "logs")
RT = os.path.join(DATA, "runtimes")
RT_BIN = os.path.join(RT, "bin")
UA = {"User-Agent": "CypherTool/" + VERSION}
SKIP_DIRS = {".git", "node_modules", ".venv", "venv", "__pycache__", "target", "dist", "build", ".tox"}

for d in (CONF_DIR, DATA, TOOLS_DIR, ICON_DIR, LAUNCH_DIR, EXPORT_DIR, RT_BIN, os.path.join(DATA, "logs")):
    os.makedirs(d, exist_ok=True)

# ───────────────────────────── yardımcılar ─────────────────────────────
_lock = threading.RLock()

def jload(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return json.loads(json.dumps(default))

def jsave(path, obj, private=False):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    if private:
        os.chmod(tmp, 0o600)
    os.replace(tmp, path)

TR_MAP = str.maketrans("çğıöşüÇĞİÖŞÜâîû", "cgiosuCGIOSUaiu")

def slugify(s):
    s = s.strip().translate(TR_MAP)
    s = re.sub(r"[^A-Za-z0-9._-]+", "-", s).strip("-.").lower()
    return s or "arac"

def unique_dir(base, name):
    p = os.path.join(base, name); i = 2
    while os.path.exists(p):
        p = os.path.join(base, f"{name}-{i}"); i += 1
    return p

def q(s):
    return shlex.quote(str(s))

def now():
    return time.strftime("%Y-%m-%d %H:%M")

def is_root():
    return os.geteuid() == 0

def arch_vars():
    m = platform.machine().lower()
    go = {"x86_64": "amd64", "amd64": "amd64", "aarch64": "arm64", "arm64": "arm64"}.get(m, "arm" if m.startswith("armv7") else "386" if re.match(r"i\d86", m) else m)
    x64 = {"amd64": "x64", "arm64": "arm64"}.get(go, go)
    raw = {"amd64": "x86_64", "arm64": "aarch64"}.get(go, m)
    return {"arch_go": go, "arch_x64": x64, "arch": raw}

def os_info():
    info = {"name": platform.system()}
    try:
        for line in open("/etc/os-release"):
            k, _, v = line.strip().partition("=")
            info[k] = v.strip('"')
    except Exception:
        pass
    return info

def detect_pm():
    for pm in ("apt-get", "dnf", "pacman", "zypper", "apk"):
        if shutil.which(pm):
            return pm
    return None

def mem_gb():
    try:
        for line in open("/proc/meminfo"):
            if line.startswith("MemTotal"):
                return round(int(line.split()[1]) / 1024 / 1024, 1)
    except Exception:
        pass
    return 0

def gpu_info():
    if shutil.which("nvidia-smi"):
        try:
            out = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
                                 capture_output=True, text=True, timeout=5).stdout.strip().splitlines()
            if out:
                name, mem = out[0].rsplit(",", 1)
                return {"name": name.strip(), "vram_gb": round(int(mem) / 1024, 1)}
        except Exception:
            pass
    return {"name": "", "vram_gb": 0}

def base_env():
    env = dict(os.environ)
    env["PATH"] = os.pathsep.join([RT_BIN, os.path.join(RT, "node", "bin"), os.path.expanduser("~/.local/bin"), env.get("PATH", "")])
    env["DEBIAN_FRONTEND"] = "noninteractive"
    env["PYTHONUNBUFFERED"] = "1"
    env["UV_PYTHON_INSTALL_DIR"] = os.path.join(RT, "python")
    env.update(provider_env())
    return env

ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(\x07|\x1b\\)|\x1b[()][A-Za-z0-9]|\x1b[=>78]")

def clean_term(t):
    t = ANSI_RE.sub("", t).replace("\r\n", "\n")
    return re.sub(r"[^\n]*\r(?!\n)", "", t)

def http_get(url, timeout=30, headers=None, raw=False):
    req = urllib.request.Request(url, headers={**UA, **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read()
        return data if raw else data.decode("utf-8", "replace")

def http_json(url, body=None, headers=None, timeout=120, method=None):
    data = json.dumps(body).encode() if body is not None else None
    h = {**UA, "Content-Type": "application/json", **(headers or {})}
    req = urllib.request.Request(url, data=data, headers=h, method=method or ("POST" if data else "GET"))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            txt = r.read().decode("utf-8", "replace")
            return json.loads(txt) if txt.strip() else {}
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}: {e.read().decode('utf-8', 'replace')[:400]}")

def download(url, dest, log=None, headers=None):
    req = urllib.request.Request(url, headers={**UA, **(headers or {})})
    os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    with urllib.request.urlopen(req, timeout=60) as r, open(dest + ".part", "wb") as f:
        total = int(r.headers.get("Content-Length") or 0); got = 0; last = 0
        while True:
            chunk = r.read(1 << 16)
            if not chunk:
                break
            f.write(chunk); got += len(chunk)
            if log and got - last > 8 << 20:
                last = got
                log(f"   … {got >> 20} MB" + (f" / {total >> 20} MB" if total else ""))
        final_url = r.geturl()
    os.replace(dest + ".part", dest)
    return final_url

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()

# ───────────────────────────── yapılandırma ─────────────────────────────
PROVIDER_PRESETS = [
    {"preset": "OpenAI", "type": "openai", "base_url": "https://api.openai.com/v1", "model": "gpt-4o-mini", "env": "OPENAI_API_KEY", "signup": "https://platform.openai.com/api-keys"},
    {"preset": "Anthropic (Claude)", "type": "anthropic", "base_url": "https://api.anthropic.com/v1", "model": "claude-sonnet-5-5", "env": "ANTHROPIC_API_KEY", "signup": "https://console.anthropic.com/"},
    {"preset": "Google Gemini", "type": "gemini", "base_url": "https://generativelanguage.googleapis.com/v1beta", "model": "gemini-2.5-flash", "env": "GEMINI_API_KEY", "signup": "https://aistudio.google.com/apikey", "free": True},
    {"preset": "OpenRouter", "type": "openai", "base_url": "https://openrouter.ai/api/v1", "model": "openrouter/free", "env": "OPENROUTER_API_KEY", "signup": "https://openrouter.ai/keys", "free": True},
    {"preset": "Groq", "type": "openai", "base_url": "https://api.groq.com/openai/v1", "model": "llama-3.3-70b-versatile", "env": "GROQ_API_KEY", "signup": "https://console.groq.com/keys", "free": True},
    {"preset": "Mistral", "type": "openai", "base_url": "https://api.mistral.ai/v1", "model": "mistral-small-latest", "env": "MISTRAL_API_KEY", "signup": "https://console.mistral.ai/api-keys", "free": True},
    {"preset": "Cerebras", "type": "openai", "base_url": "https://api.cerebras.ai/v1", "model": "llama3.1-8b", "env": "CEREBRAS_API_KEY", "signup": "https://cloud.cerebras.ai/", "free": True},
    {"preset": "GitHub Models", "type": "openai", "base_url": "https://models.github.ai/inference", "model": "openai/gpt-4o-mini", "env": "GITHUB_TOKEN", "signup": "https://github.com/settings/tokens", "free": True},
    {"preset": "DeepSeek", "type": "openai", "base_url": "https://api.deepseek.com/v1", "model": "deepseek-chat", "env": "DEEPSEEK_API_KEY", "signup": "https://platform.deepseek.com/"},
    {"preset": "xAI (Grok)", "type": "openai", "base_url": "https://api.x.ai/v1", "model": "grok-3-mini", "env": "XAI_API_KEY", "signup": "https://console.x.ai/"},
    {"preset": "Ollama (yerel, anahtarsız)", "type": "openai", "base_url": "http://127.0.0.1:11434/v1", "model": "qwen2.5-coder:7b", "env": "", "keyless": True},
    {"preset": "LM Studio (yerel, anahtarsız)", "type": "openai", "base_url": "http://127.0.0.1:1234/v1", "model": "local-model", "env": "", "keyless": True},
    {"preset": "Pollinations (anahtarsız, bulut)", "type": "openai", "base_url": "https://text.pollinations.ai/openai", "model": "openai", "env": "", "keyless": True},
    {"preset": "Özel (OpenAI uyumlu)", "type": "openai", "base_url": "", "model": "", "env": ""},
]

DEFAULT_AGENTS = [
    {"id": "kod", "name": "Kod Ustası", "provider": "", "model": "", "icon": "💻",
     "system": "Sen deneyimli bir yazılım mühendisisin. Temiz, çalışan, test edilmiş kod yazarsın. Kodu tam ve eksiksiz verirsin, kısa açıklama eklersin. Türkçe cevap ver."},
    {"id": "kurulum", "name": "Kurulum Uzmanı", "provider": "", "model": "", "icon": "🛠️",
     "system": "Linux kurulum uzmanısın. Bir aracın kurulumu, bağımlılıkları ve hataları için adım adım, kopyala-yapıştır yapılabilir komutlar verirsin. Komutları ```bash blokları içinde ver. Türkçe cevap ver."},
    {"id": "hata", "name": "Hata Ayıklayıcı", "provider": "", "model": "", "icon": "🐞",
     "system": "Hata çıktılarını analiz edip kök nedeni bulursun ve kesin çözüm önerirsin. Türkçe cevap ver."},
    {"id": "guvenlik", "name": "Güvenlik Denetçisi", "provider": "", "model": "", "icon": "🛡️",
     "system": "Bir aracın kurulum betiklerini ve komutlarını güvenlik açısından incelersin: şüpheli indirmeler, gereksiz root yetkisi, veri sızdırma riskleri. Riskleri net sırala. Türkçe cevap ver."},
    {"id": "arastirma", "name": "Araştırmacı", "provider": "", "model": "", "icon": "🔎",
     "system": "Konuları derinlemesine açıklarsın, farklı görüşleri dengeli verirsin, emin olmadığın yerleri belirtirsin. Türkçe cevap ver."},
]

DEFAULT_CFG = {
    "providers": [], "default_provider": "", "failover": True, "github_token": "",
    "agents": DEFAULT_AGENTS, "use_ai": True, "auto_shortcut": True, "release_assets": True,
    "update_check": True, "update_default_mode": "sor", "last_update_check": 0,
    "ai_mode": "auto", "routing": {}, "gateway": {"enabled": True, "inject": True, "key": ""},
    "auto_agent_repair": True, "repair": {"provider": "", "model": "", "auto_approve": False, "on_run": True}, "agent_rules": "", "agent_defaults": {"workdir": "", "provider": "", "persona": "", "auto": False},
}

def cfg():
    with _lock:
        c = jload(CONF_FILE, DEFAULT_CFG)
        for k, v in DEFAULT_CFG.items():
            c.setdefault(k, json.loads(json.dumps(v)))
        return c

def save_cfg(c):
    with _lock:
        jsave(CONF_FILE, c, private=True)
        write_env_file(c)

def tools():
    with _lock:
        return jload(TOOLS_FILE, {})

def save_tools(t):
    with _lock:
        jsave(TOOLS_FILE, t)

def update_tool(_slug, **kw):
    with _lock:
        t = tools()
        if _slug in t:
            t[_slug].update(kw); save_tools(t)
            return t[_slug]

def provider_env(c=None):
    c = c or cfg(); env = {}
    for p in c.get("providers", []):
        if not p.get("enabled", True):
            continue
        var = p.get("env") or ""
        if var and p.get("api_key"):
            env.setdefault(var, p["api_key"])
            if var == "GEMINI_API_KEY":
                env.setdefault("GOOGLE_API_KEY", p["api_key"])
        if "11434" in p.get("base_url", ""):
            env.setdefault("OLLAMA_HOST", "http://127.0.0.1:11434")
            env.setdefault("OLLAMA_API_BASE", "http://127.0.0.1:11434")
    g = c.get("gateway") or {}
    if g.get("enabled", True) and g.get("key") and any(p.get("enabled", True) for p in c.get("providers", [])):
        gb = f"http://127.0.0.1:{GATEWAY_PORT}/v1"
        env.update({"CYPHER_AI_BASE_URL": gb, "CYPHER_AI_KEY": g["key"], "CYPHER_AI_MODEL": "otomatik"})
        if g.get("inject", True) and "OPENAI_API_KEY" not in env:
            env.update({"OPENAI_BASE_URL": gb, "OPENAI_API_BASE": gb, "OPENAI_API_KEY": g["key"]})
    return env

def write_env_file(c):
    lines = ["# Cypher Tool tarafından oluşturuldu — API anahtarları (sadece senin okuyabileceğin dosya)"]
    for k, v in provider_env(c).items():
        lines.append(f"export {k}={q(v)}")
    with open(ENV_FILE, "w") as f:
        f.write("\n".join(lines) + "\n")
    os.chmod(ENV_FILE, 0o600)

def catalog():
    return jload(CATALOG_FILE, {"tools": []}).get("tools", [])

MEMORY_FILE = os.path.join(CONF_DIR, "ajan_hafiza.json")
USER_CATALOG = os.path.join(CONF_DIR, "ogrenilen_tarifler.json")

def mem_all():
    return jload(MEMORY_FILE, [])

def mem_add(text, kind="ders", tags=None):
    text = (text or "").strip()
    if not text:
        return
    with _lock:
        m = mem_all()
        if any(x["text"].lower() == text.lower() for x in m):
            return
        m.append({"id": uuid.uuid4().hex[:8], "text": text[:600], "kind": kind, "tags": tags or [], "at": now()})
        jsave(MEMORY_FILE, m[-400:])

# ── 📚 Bilgi hafızası: araştırıp öğrendikleri (web sayfası, YouTube videosu özetleri) — sonraki görevlerde hatırlar ──
KNOW_FILE = os.path.join(CONF_DIR, "bilgi_hafizasi.json")

def know_all():
    return jload(KNOW_FILE, [])

def know_add(topic, summary, source="", kind="not"):
    topic = (topic or "").strip()[:160]; summary = (summary or "").strip()[:6000]
    if not summary:
        return None
    with _lock:
        k = [x for x in know_all() if not (source and x.get("source") == source)]   # aynı kaynak yeniden öğrenilirse güncellenir
        e = {"id": uuid.uuid4().hex[:8], "topic": topic or summary[:60], "summary": summary, "source": source, "kind": kind, "at": now()}
        k.append(e); jsave(KNOW_FILE, k[-800:])
    return e

def _kw(t):
    return {w for w in re.findall(r"\w{4,}", (t or "").lower())}

def know_find(query, n=6):
    q = _kw(query)
    if not q:
        return []
    sc = []
    for x in know_all():
        tw = _kw(x.get("topic")); bw = _kw(x.get("summary"))
        v = 3 * len(q & tw) + len(q & bw)
        if v:
            sc.append((v, x))
    return [x for _, x in sorted(sc, key=lambda z: -z[0])[:n]]

def know_context(task, n=5):
    r = know_find(task, n)
    return "\n".join(f"• [{x['topic']}] {x['summary'][:700]}" + (f" (kaynak: {x['source']})" if x.get("source") else "") for x in r)

YT_JS = r"""(async()=>{const pr=window.ytInitialPlayerResponse||{};const vd=pr.videoDetails||{};
let tr=((pr.captions||{}).playerCaptionsTracklistRenderer||{}).captionTracks||[];
const pick=tr.find(t=>t.languageCode==='tr')||tr.find(t=>t.languageCode==='en'&&t.kind!=='asr')||tr.find(t=>t.languageCode==='en')||tr[0];
let text='';if(pick){try{const r=await fetch(pick.baseUrl+'&fmt=json3');const j=await r.json();text=(j.events||[]).map(e=>(e.segs||[]).map(s=>s.utf8).join('')).join(' ').replace(/\s+/g,' ');}catch(e){}
 if(!text){try{const r=await fetch(pick.baseUrl);const x=await r.text();text=[...x.matchAll(/<text[^>]*>([\s\S]*?)<\/text>/g)].map(m=>m[1]).join(' ').replace(/&amp;#39;|&#39;/g,"'").replace(/&amp;quot;|&quot;/g,'"').replace(/&amp;/g,'&').replace(/\s+/g,' ');}catch(e){}}}
return {title:vd.title||document.title,author:vd.author||'',len:+vd.lengthSeconds||0,desc:(vd.shortDescription||'').slice(0,3000),lang:pick?pick.languageCode:'',text:text.slice(0,60000),url:location.href};})()"""

YT_LIST_JS = r"""[...document.querySelectorAll('a#video-title, a#video-title-link, ytd-video-renderer a[href^="/watch"]')].map(a=>({t:(a.title||a.innerText||'').trim(),u:a.href})).filter(x=>x.t&&x.u.includes('/watch')).filter((x,i,a)=>a.findIndex(y=>y.u===x.u)===i).slice(0,8)"""

def youtube_learn(job, url="", query="", question="", con=None):
    """YouTube videosunu (uygulama içi tarayıcıda) açar, altyazısını okur, Türkçe özet + öğrenilenler çıkarır ve bilgi hafızasına yazar."""
    sid = _research_sid(job)
    if not url and query:
        brw_go(sid, "https://www.youtube.com/results?" + urllib.parse.urlencode({"search_query": query}))
        time.sleep(1.5); lst = brw_eval(sid, YT_LIST_JS) or []
        if not lst:
            try: brw_read(sid)
            except Exception: pass
            return "YouTube'da sonuç bulunamadı (çerez/izin sayfası çıktıysa browser_look ile bakıp kabul et, sonra tekrar dene)."
        if not job.ctx.get("yt_pick_all"):
            url = lst[0]["u"]
        others = "\n".join(f"- {x['t']} → {x['u']}" for x in lst[1:6])
    else:
        others = ""
    brw_go(sid, url); brw_captcha_wait(job, sid, con); time.sleep(1.2)
    info = brw_eval(sid, YT_JS, 60) or {}
    if con: console_print(con, f"📺 {info.get('title', '')} — {'altyazı okundu' if info.get('text') else 'altyazı yok, açıklama kullanılıyor'}", "95")
    src = info.get("text") or info.get("desc") or ""
    if not src:
        return f"Videodan metin alınamadı ({url}). browser_look ile sayfaya bakabilirsin."
    txt, p = llm_ask([{"role": "user", "content": f"VİDEO: {info.get('title')} — {info.get('author')} ({info.get('len', 0) // 60} dk)\nADRES: {info.get('url')}\n"
                       + (f"KULLANICININ MERAK ETTİĞİ: {question}\n" if question else "")
                       + ("ALTYAZI" if info.get("text") else "AÇIKLAMA (altyazı yok)") + f":\n{src[:45000]}\n\n"
                       "Türkçe yaz: 1) **Kısa özet** (3-5 cümle) 2) **Öğrenilenler** (madde madde, somut: komutlar, adımlar, sayılar, isimler) "
                       "3) Kullanıcının sorusu varsa **cevabı**. Videoda olmayan şey uydurma."}], "", log=job.log, feature="chat")
    e = know_add(f"📺 {info.get('title', '')}", txt, info.get("url") or url, "video")
    job.ctx.setdefault("learned", []).append(e["id"] if e else "")
    return f"📺 {info.get('title')} ({info.get('author')}) — özet bilgi hafızasına kaydedildi.\n\n{txt}" + (f"\n\nDİĞER VİDEOLAR:\n{others}" if others else "")

def mem_context(task, n=40):
    m = mem_all()
    if not m:
        return ""
    words = {w for w in re.findall(r"\w{4,}", task.lower())}
    rel = [x for x in m if words & set(re.findall(r"\w{4,}", x["text"].lower()))]
    pick = (rel[-20:] + [x for x in m if x["kind"] == "tercih"][-10:] + m[-n:])
    seen, out = set(), []
    for x in pick:
        if x["id"] not in seen:
            seen.add(x["id"]); out.append(f"- [{x['kind']}] {x['text']}")
    return "\n".join(out[-n:])

def save_user_recipe(tool, tested=None):
    """Başarılı kurulumun tarifini saklar; aynı araç bir dahaki sefere analiz edilmeden kurulur."""
    if not tool.get("source", "").startswith("http") or tool.get("catalog_id"):
        return
    with _lock:
        uc = jload(USER_CATALOG, [])
        src = tool["source"].lower().rstrip("/")
        uc = [x for x in uc if x["source"].lower().rstrip("/") != src]
        uc.append({"id": "ogrenilen-" + tool["slug"], "source": tool["source"], "full_name": tool.get("full_name", ""), "name": tool["name"],
                   "category": tool.get("category") or "Öğrenilen tarif", "learned": True, "tested": tested,
                   "install": [{"type": "release", **json.loads(x[9:])} if x.startswith("@release ") else {"type": "shell", "command": x} for x in tool.get("steps", [])],
                   "actions": tool.get("actions", []), "runtimes": tool.get("runtimes", []), "system_packages": tool.get("system_packages", []),
                   "guide_tr": tool.get("guide_tr", ""), "at": now()})
        jsave(USER_CATALOG, uc)

# ───────────────────────────── LLM yönlendirici ─────────────────────────────
def _img_parts(url):
    m = re.match(r"data:(image/[\w.+-]+);base64,(.*)", url or "", re.S)
    return (m.group(1), m.group(2)) if m else ("image/jpeg", "")

def _mm(messages, t):
    """Mesajlardaki 'images' (data URL) alanlarını sağlayıcının biçimine çevirir."""
    out = []
    for x in messages:
        imgs = x.get("images") or []
        if not imgs:
            out.append({"role": x["role"], "content": x.get("content", "")}); continue
        if t == "anthropic":
            parts = [{"type": "image", "source": {"type": "base64", "media_type": _img_parts(u)[0], "data": _img_parts(u)[1]}} for u in imgs]
            parts.append({"type": "text", "text": x.get("content") or "Bu görsel hakkında ne söyleyebilirsin?"})
        elif t == "gemini":
            parts = imgs  # gemini dalında ayrıca işlenir
        else:
            parts = [{"type": "text", "text": x.get("content") or "Bu görsel hakkında ne söyleyebilirsin?"}] + [{"type": "image_url", "image_url": {"url": u}} for u in imgs]
        out.append({"role": x["role"], "content": parts, "_imgs": imgs, "_text": x.get("content", "")})
    return out

def has_images(messages):
    return any(m.get("images") for m in messages or [])

def llm_call(p, messages, system="", model=None, timeout=180):
    t = p.get("type", "openai"); m = model or p.get("model"); key = p.get("api_key", "")
    messages = _mm(messages, t)
    base = (p.get("base_url") or "").rstrip("/")
    if t == "anthropic":
        body = {"model": m, "max_tokens": 4096, "messages": [{"role": x["role"], "content": x["content"]} for x in messages]}
        if system:
            body["system"] = system
        r = http_json(base + "/messages", body, {"x-api-key": key, "anthropic-version": "2023-06-01"}, timeout)
        return "".join(b.get("text", "") for b in r.get("content", []))
    if t == "gemini":
        contents = []
        for x in messages:
            if x.get("_imgs"):
                parts = [{"inline_data": {"mime_type": _img_parts(u)[0], "data": _img_parts(u)[1]}} for u in x["_imgs"]] + [{"text": x.get("_text") or "Bu görseli açıkla."}]
            else:
                parts = [{"text": x["content"]}]
            contents.append({"role": "model" if x["role"] == "assistant" else "user", "parts": parts})
        body = {"contents": contents}
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        r = http_json(f"{base}/models/{m}:generateContent?key={urllib.parse.quote(key)}", body, {}, timeout)
        return "".join(x.get("text", "") for x in r["candidates"][0]["content"]["parts"])
    h = {"Authorization": f"Bearer {key}"} if key else {}
    if "openrouter.ai" in base:
        h.update({"HTTP-Referer": "https://cyphertool.local", "X-Title": APP})
    msgs = ([{"role": "system", "content": system}] if system else []) + [{"role": x["role"], "content": x["content"]} for x in messages]
    r = http_json(base + "/chat/completions", {"model": m, "messages": msgs, "temperature": 0.3}, h, timeout)
    return r["choices"][0]["message"]["content"] or ""

def llm_available():
    return any(p.get("enabled", True) for p in cfg().get("providers", []))

STATS_FILE = os.path.join(CONF_DIR, "ai_istatistik.json")
_STATS = {}

def ai_stats():
    if not _STATS:
        _STATS.update(jload(STATS_FILE, {}))
    return _STATS

def ai_stat(pid, ok, ms):
    st = ai_stats().setdefault(pid, {"ok": 0, "fail": 0, "ms": 0, "last_fail": 0})
    if ok:
        st["ok"] += 1; st["ms"] = int(ms if not st["ms"] else st["ms"] * 0.7 + ms * 0.3)
    else:
        st["fail"] += 1; st["last_fail"] = time.time()
    try:
        jsave(STATS_FILE, ai_stats())
    except Exception:
        pass

FEATURES = {"chat": "💬 Sohbet ve ajanlar", "agent": "🎯 Görev Ajanı", "repair": "🛠 Hata çözücü / onarım",
            "guide": "📘 Türkçe rehber ve çeviri", "analyze": "🔍 Kurulum analizi (README okuma)", "gateway": "🌉 Köprü (araçlar ve diğer programlar)"}

def ordered_providers(provider_id="", feature=""):
    """Kullanılacak API sırası: özelliğe atanmış → varsayılan/otomatik → diğerleri (en hızlı ve sağlam önce)."""
    c = cfg(); provs = [p for p in c.get("providers", []) if p.get("enabled", True)]
    route = (c.get("routing") or {}).get(feature, "") if feature else ""
    first = provider_id or route or (c.get("preferred", "") if c.get("ai_mode", "auto") == "auto" else c.get("default_provider", ""))
    S = ai_stats(); poolms = {x["id"]: x.get("ms", 0) for x in pool()["items"]} if os.path.exists(POOL_FILE) else {}
    def score(p):
        st = S.get(p["id"], {})
        recent_fail = 1 if time.time() - st.get("last_fail", 0) < 600 else 0
        ratio = st.get("fail", 0) / max(1, st.get("ok", 0) + st.get("fail", 0))
        ms = st.get("ms") or poolms.get(p.get("pool_id", ""), 0) or 3000
        return (0 if p["id"] == first else 1, recent_fail, round(ratio, 1), ms)
    provs.sort(key=score)
    return provs if c.get("failover", True) else provs[:1]

def is_vision(p):
    return "🖼️ Görsel anlama" in model_info(p.get("model", ""))["tags"] or p.get("type") in ("anthropic", "gemini")

LIVE = {"chat": {}, "gateway": {"count": 0, "last": "", "at": 0}}

def llm_ask(messages, system="", provider_id="", model="", log=None, feature=""):
    provs = ordered_providers(provider_id, feature)
    if has_images(messages):
        vis = [p for p in provs if is_vision(p)]
        if not vis and log:
            log("⚠ Görsel anlayabilen bir API bulunamadı; yine de deneniyor (Gemini, GPT-4o, Qwen-VL gibi bir model ekle).")
        provs = vis + [p for p in provs if p not in vis]
    if not provs:
        raise RuntimeError("Hiç API eklenmemiş. 'Ücretsiz AI' sekmesinden anahtarsız API'ler ekleyebilir ya da 'API'ler' sekmesinden kendi anahtarını girebilirsin.")
    errs = []
    for i, p in enumerate(provs):
        t0 = time.time()
        try:
            out = llm_call(p, messages, system, model if i == 0 and model else None)
            ai_stat(p["id"], True, (time.time() - t0) * 1000)
            LIVE["last_api"] = {"name": p.get("name"), "model": p.get("model"), "feature": feature or "genel", "at": time.time()}
            return out, p
        except Exception as e:
            ai_stat(p["id"], False, 0)
            errs.append(f"{p.get('name')}: {e}")
            if log:
                log(f"⚠ {p.get('name')} hata verdi, sıradakine geçiliyor… ({str(e)[:120]})")
    raise RuntimeError(("Fotoğrafı okuyabilecek bir API bulunamadı ya da hepsi başarısız. Görsel anlayabilen bir model ekle (ör. Gemini, GPT-4o, Qwen-VL). " if has_images(messages) else "") +
                       "Tüm API'ler başarısız:\n" + "\n".join(errs))

def describe_images(images, question="", log=None):
    """Fotoğrafları görsel anlayan bir modelle ayrıntılı Türkçe metne çevirir (ajan döngüsü metinle çalışabilsin diye)."""
    if not images:
        return ""
    txt, p = llm_ask([{"role": "user", "content": "Bu görsel(ler)i Türkçe olarak çok ayrıntılı tarif et: içindeki tüm yazıları, hata mesajlarını, kodları, arayüz öğelerini ve önemli detayları aynen aktar." +
                       (f" Kullanıcının sorusu: {question}" if question else ""), "images": images[:6]}], "", log=log, feature="chat")
    if log:
        log(f"🖼️ Fotoğraf okundu ({p.get('name')})")
    return txt

def extract_json(text):
    m = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.S)
    s = m.group(1) if m else text[text.find("{"): text.rfind("}") + 1]
    return json.loads(s)

# ───────────────────────────── bağımlılıklar ─────────────────────────────
# anahtar: (apt, dnf, pacman, zypper, apk)
PKG = {
    "python3": ("python3", "python3", "python", "python3", "python3"),
    "venv": ("python3-venv", "python3", "python", "python3", "py3-virtualenv"),
    "pip": ("python3-pip", "python3-pip", "python-pip", "python3-pip", "py3-pip"),
    "git": ("git", "git", "git", "git", "git"),
    "git-lfs": ("git-lfs", "git-lfs", "git-lfs", "git-lfs", "git-lfs"),
    "curl": ("curl", "curl", "curl", "curl", "curl"),
    "wget": ("wget", "wget", "wget", "wget", "wget"),
    "make": ("make", "make", "make", "make", "make"),
    "gcc": ("build-essential", "gcc gcc-c++", "base-devel", "gcc gcc-c++", "build-base"),
    "cmake": ("cmake", "cmake", "cmake", "cmake", "cmake"),
    "pkg-config": ("pkg-config", "pkgconf-pkg-config", "pkgconf", "pkg-config", "pkgconf"),
    "nodejs": ("nodejs", "nodejs", "nodejs", "nodejs", "nodejs"),
    "npm": ("npm", "npm", "npm", "npm", "npm"),
    "cargo": ("cargo", "cargo", "rust", "cargo", "cargo"),
    "go": ("golang-go", "golang", "go", "go", "go"),
    "java": ("default-jdk", "java-latest-openjdk", "jdk-openjdk", "java-21-openjdk", "openjdk21"),
    "maven": ("maven", "maven", "maven", "maven", "maven"),
    "ruby": ("ruby-full", "ruby", "ruby", "ruby", "ruby"),
    "php": ("php-cli", "php-cli", "php", "php", "php"),
    "docker": ("docker.io", "docker", "docker", "docker", "docker"),
    "ffmpeg": ("ffmpeg", "ffmpeg", "ffmpeg", "ffmpeg", "ffmpeg"),
    "unzip": ("unzip", "unzip", "unzip", "unzip", "unzip"),
    "xdotool": ("xdotool wmctrl", "xdotool wmctrl", "xdotool wmctrl", "xdotool wmctrl", "xdotool wmctrl"),
    "scrot": ("scrot", "scrot", "scrot", "scrot", "scrot"),
    "pil": ("python3-pil", "python3-pillow", "python-pillow", "python3-Pillow", "py3-pillow"),
    "chromium": ("chromium-browser", "chromium", "chromium", "chromium", "chromium"),
    "7z": ("p7zip-full", "p7zip p7zip-plugins", "p7zip", "p7zip-full", "p7zip"),
    "unrar": ("unrar-free", "unrar", "unrar", "unrar", "unrar"),
    "bsdtar": ("libarchive-tools", "bsdtar", "libarchive", "bsdtar", "libarchive-tools"),
    "tk": ("python3-tk", "python3-tkinter", "tk", "python3-tk", "py3-tkinter"),
    "xdg-utils": ("xdg-utils", "xdg-utils", "xdg-utils", "xdg-utils", "xdg-utils"),
    "zstd": ("zstd", "zstd", "zstd", "zstd", "zstd"),
    "notify-send": ("libnotify-bin", "libnotify", "libnotify", "libnotify-tools", "libnotify"),
    "emoji": ("fonts-noto-color-emoji", "google-noto-emoji-color-fonts", "noto-fonts-emoji", "noto-coloremoji-fonts", "font-noto-emoji"),
}
PM_IDX = {"apt-get": 0, "dnf": 1, "pacman": 2, "zypper": 3, "apk": 4}
CMD2KEY = {"python3": "python3", "python": "python3", "pip": "pip", "pip3": "pip", "git": "git", "curl": "curl",
           "wget": "wget", "make": "make", "gcc": "gcc", "g++": "gcc", "cc": "gcc", "cmake": "cmake",
           "pkg-config": "pkg-config", "cargo": "cargo", "rustc": "cargo", "go": "go", "java": "java",
           "javac": "java", "mvn": "maven", "ruby": "ruby", "gem": "ruby", "php": "php", "docker": "docker",
           "ffmpeg": "ffmpeg", "unzip": "unzip", "7z": "7z", "unrar": "unrar", "bsdtar": "bsdtar", "zstd": "zstd"}
RUNTIME_CMDS = {"node": "node22", "npm": "node22", "npx": "node22", "uv": "uv", "uvx": "uv"}
NAME_OK = re.compile(r"^[A-Za-z0-9][A-Za-z0-9.+_:@-]*$")

def which(cmd):
    return shutil.which(cmd, path=base_env()["PATH"])

def check_key(k):
    if k == "pil":
        return subprocess.run(["python3", "-c", "import PIL"], capture_output=True).returncode == 0
    if k == "xdotool":
        return bool(shutil.which("xdotool"))
    if k == "chromium":
        return bool(next((x for x in BROWSERS if "firefox" not in x and which(x)), ""))
    if k == "venv":
        return subprocess.run(["python3", "-c", "import venv, ensurepip"], capture_output=True).returncode == 0 if shutil.which("python3") else False
    if k == "tk":
        return subprocess.run(["python3", "-c", "import tkinter"], capture_output=True).returncode == 0
    if k == "gcc":
        return bool(shutil.which("gcc") and shutil.which("make"))
    if k == "7z":
        return bool(shutil.which("7z") or shutil.which("7za"))
    if k == "nodejs":
        return bool(which("node"))
    if k == "notify-send":
        return bool(shutil.which("notify-send"))
    if k == "xdg-utils":
        return bool(shutil.which("xdg-open"))
    if k == "emoji":
        try:
            return "emoji" in subprocess.run(["fc-list"], capture_output=True, text=True, timeout=10).stdout.lower()
        except Exception:
            return True
    cmd = {"java": "java", "maven": "mvn", "ruby": "ruby", "docker": "docker", "go": "go", "cargo": "cargo"}.get(k, k)
    return bool(shutil.which(cmd))

def pkg_installed(pm, name):
    try:
        cmd = {"apt-get": ["dpkg", "-s", name], "dnf": ["rpm", "-q", name], "zypper": ["rpm", "-q", name],
               "pacman": ["pacman", "-Q", name], "apk": ["apk", "info", "-e", name]}[pm]
        return subprocess.run(cmd, capture_output=True).returncode == 0
    except Exception:
        return False

APT_ENV = "env DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a NEEDRESTART_SUSPEND=1 APT_LISTCHANGES_FRONTEND=none"
APT_OPT = "-o DPkg::Lock::Timeout=600 -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold"

APT_CMD_RX = re.compile(r"(?<![\w./-])(sudo\s+(?:-\S+\s+)*)?(apt-get|apt)\s+(?=(?:-\S+\s+)*(install|upgrade|full-upgrade|dist-upgrade|remove|purge|autoremove|reinstall)\b)")

def apt_safe(cmd):
    """Yapay zekânın/adımın 'sudo apt install …' komutunu soru sormayan hale getir (needrestart/debconf görünmez pencerede beklemesin)."""
    if not cmd or "DEBIAN_FRONTEND" in cmd:
        return cmd
    def sub(m):
        pre = cmd[:m.start()]
        if pre.count("'") % 2 or pre.count('"') % 2:   # tırnak içindeki yazıya dokunma
            return m.group(0)
        return (m.group(1) or "") + f"{APT_ENV} apt-get -y {APT_OPT} "
    return APT_CMD_RX.sub(sub, cmd)

def install_line(pm, pkgs):
    s = "" if is_root() else "sudo "
    p = " ".join(pkgs)
    # sudo ortam değişkenlerini sildiği için sessiz mod 'env' ile komutun İÇİNE yazılır (yoksa needrestart/debconf görünmez bir soru sorup bekler)
    return {"apt-get": f"{s}{APT_ENV} apt-get install -y {APT_OPT} {p}", "dnf": f"{s}dnf install -y {p}",
            "pacman": f"{s}pacman -S --needed --noconfirm {p}", "zypper": f"{s}zypper --non-interactive install {p}",
            "apk": f"{s}apk add {p}"}[pm]

def dep_commands(keys, raw_pkgs=()):
    """Eksik anahtarlar için paket yöneticisi komutları üretir."""
    pm = detect_pm()
    missing = [k for k in sorted(set(keys)) if k in PKG and not check_key(k)]
    if not pm:
        return [], missing
    pkgs = []
    for k in missing:
        pkgs += PKG[k][PM_IDX[pm]].split()
    for r in raw_pkgs:
        if NAME_OK.match(r or "") and not pkg_installed(pm, r) and r not in pkgs:
            pkgs.append(r)
    if not pkgs:
        return [], missing
    cmds = []
    if pm == "apt-get":
        cmds.append(("" if is_root() else "sudo ") + f"{APT_ENV} apt-get update -o DPkg::Lock::Timeout=600")
    cmds.append(install_line(pm, pkgs))
    return cmds, missing

# ───────────────────────────── çalışma zamanları (sudo gerektirmez) ─────────────────────────────
def node_version(path="node"):
    try:
        out = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=10, env=base_env()).stdout.strip()
        return tuple(int(x) for x in out.lstrip("v").split(".")[:3])
    except Exception:
        return (0, 0, 0)

def runtime_ok(name):
    if name == "node22":
        n = which("node")
        return bool(n) and node_version(n) >= (22, 12, 0)
    if name == "uv":
        return bool(which("uv"))
    return True

def ensure_runtime(name, log):
    if runtime_ok(name):
        return True
    av = arch_vars()
    if name == "node22":
        log("⬇ Node.js 22 (LTS) indiriliyor → ~/CypherTool/runtimes/node (sudo gerekmez)")
        idx = json.loads(http_get("https://nodejs.org/dist/index.json"))
        v = next(x["version"] for x in idx if x["version"].startswith("v22."))
        fn = f"node-{v}-linux-{av['arch_x64']}.tar.xz"
        tmp = os.path.join(RT, fn)
        download(f"https://nodejs.org/dist/{v}/{fn}", tmp, log)
        sums = http_get(f"https://nodejs.org/dist/{v}/SHASUMS256.txt")
        exp = next((l.split()[0] for l in sums.splitlines() if l.endswith(fn)), "")
        if exp and exp != sha256(tmp):
            raise RuntimeError("Node.js sağlama (SHA256) uyuşmadı")
        log("✔ SHA256 doğrulandı")
        with tarfile.open(tmp) as tf:
            safe_tar_extract(tf, RT)
        os.remove(tmp)
        link = os.path.join(RT, "node")
        if os.path.islink(link) or os.path.exists(link):
            os.remove(link) if os.path.islink(link) else shutil.rmtree(link)
        os.symlink(os.path.join(RT, fn[:-7]), link)
        log(f"✔ Node.js {v} hazır")
        return True
    if name == "uv":
        log("⬇ uv (Python yöneticisi) indiriliyor → ~/CypherTool/runtimes/bin")
        fn = f"uv-{av['arch']}-unknown-linux-gnu.tar.gz"
        tmp = os.path.join(RT, fn)
        download(f"https://github.com/astral-sh/uv/releases/latest/download/{fn}", tmp, log)
        try:
            exp = http_get(f"https://github.com/astral-sh/uv/releases/latest/download/{fn}.sha256").split()[0]
            if exp != sha256(tmp):
                raise RuntimeError("uv sağlaması uyuşmadı")
            log("✔ SHA256 doğrulandı")
        except urllib.error.HTTPError:
            pass
        with tarfile.open(tmp) as tf:
            for m in tf.getmembers():
                b = os.path.basename(m.name)
                if b in ("uv", "uvx") and m.isfile():
                    with tf.extractfile(m) as src, open(os.path.join(RT_BIN, b), "wb") as dst:
                        shutil.copyfileobj(src, dst)
                    os.chmod(os.path.join(RT_BIN, b), 0o755)
        os.remove(tmp)
        log("✔ uv hazır")
        return True
    return False

# ───────────────────────────── arşivler ─────────────────────────────
ARCH_EXT = (".zip", ".rar", ".7z", ".tar.gz", ".tgz", ".tar.xz", ".txz", ".tar.bz2", ".tbz2", ".tar", ".tar.zst")

def is_archive(p):
    return p.lower().endswith(ARCH_EXT)

def safe_tar_extract(tf, out):
    try:
        tf.extractall(out, filter="data")
    except TypeError:
        root = os.path.realpath(out)
        for m in tf.getmembers():
            if not os.path.realpath(os.path.join(out, m.name)).startswith(root):
                raise RuntimeError("Arşivde güvensiz yol: " + m.name)
        tf.extractall(out)

def extractor_available(path):
    low = path.lower()
    if low.endswith((".zip",)) or re.search(r"\.(tar(\.(gz|xz|bz2))?|tgz|txz|tbz2)$", low):
        return True
    if low.endswith(".tar.zst"):
        return bool(shutil.which("zstd") or shutil.which("bsdtar"))
    return any(shutil.which(x) for x in ("7z", "7za", "unrar", "unar", "bsdtar"))

def extract(path, out, log):
    os.makedirs(out, exist_ok=True); low = path.lower()
    log(f"📦 Arşiv açılıyor: {os.path.basename(path)}")
    if low.endswith(".zip"):
        with zipfile.ZipFile(path) as z:
            root = os.path.realpath(out)
            for n in z.namelist():
                if not os.path.realpath(os.path.join(out, n)).startswith(root):
                    raise RuntimeError("Arşivde güvensiz yol: " + n)
            z.extractall(out)
            for info in z.infolist():  # çalıştırılabilir izinlerini koru
                mode = info.external_attr >> 16
                if mode & 0o111:
                    try: os.chmod(os.path.join(out, info.filename), mode & 0o777)
                    except Exception: pass
        return
    if re.search(r"\.(tar(\.(gz|xz|bz2))?|tgz|txz|tbz2)$", low):
        with tarfile.open(path) as tf:
            safe_tar_extract(tf, out)
        return
    tries = [["7z", "x", "-y", f"-o{out}", path], ["7za", "x", "-y", f"-o{out}", path],
             ["unrar", "x", "-o+", path, out + "/"], ["unar", "-f", "-o", out, path], ["bsdtar", "-xf", path, "-C", out]]
    if low.endswith(".tar.zst"):
        tries.insert(0, ["tar", "--zstd", "-xf", path, "-C", out])
    for t in tries:
        if shutil.which(t[0]):
            r = subprocess.run(t, capture_output=True, text=True)
            if r.returncode == 0:
                return
            log(f"   {t[0]} başarısız: {r.stderr[-300:]}")
    raise RuntimeError("Bu arşivi açacak araç yok (7z / unrar / bsdtar).")

def find_archives(root, depth=2):
    res = []
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS]
        if d[len(root):].count(os.sep) >= depth:
            dirs[:] = []
        for f in files:
            p = os.path.join(d, f)
            if is_archive(f) and os.path.getsize(p) < 800 << 20 and "_acik" not in d and "_indirilen" not in d and ".dl-" not in d and "_release" not in d:
                res.append(p)
    return res

# ───────────────────────────── GitHub ─────────────────────────────
GH_RE = re.compile(r"^https?://(?:www\.)?github\.com/([^/\s]+)/([^/\s#?]+?)(?:\.git)?(?:/tree/([^?#\s]+))?/?(?:[?#].*)?$")

def parse_source(s):
    s = s.strip().strip("'\"")
    if os.path.exists(os.path.expanduser(s)):
        return {"kind": "local", "path": os.path.abspath(os.path.expanduser(s)), "name": os.path.basename(s.rstrip("/"))}
    if re.match(r"^[\w.-]+/[\w.-]+$", s):
        s = "https://github.com/" + s
    if s.startswith("git@github.com:"):
        s = "https://github.com/" + s.split(":", 1)[1]
    path = urllib.parse.urlparse(s).path
    if is_archive(path) or path.lower().endswith((".appimage", ".deb")):
        m = GH_RE.match(s.split("/releases/")[0]) if "/releases/" in s else None
        return {"kind": "archive", "url": s, "name": os.path.basename(path),
                "owner": m.group(1) if m else "", "repo": m.group(2) if m else ""}
    m = GH_RE.match(s)
    if m:
        return {"kind": "git", "owner": m.group(1), "repo": m.group(2), "branch": m.group(3) or "",
                "url": f"https://github.com/{m.group(1)}/{m.group(2)}", "name": m.group(2)}
    if re.match(r"^https?://", s):
        return {"kind": "git", "owner": "", "repo": "", "branch": "", "url": s, "name": os.path.basename(path).removesuffix(".git") or "repo"}
    raise ValueError(f"Tanınmayan kaynak: {s}")

def gh_api(path):
    tok = cfg().get("github_token", "")
    h = {"Accept": "application/vnd.github+json"}
    if tok:
        h["Authorization"] = f"Bearer {tok}"
    return http_json("https://api.github.com" + path, headers=h, timeout=30)

def gh_meta(owner, repo):
    try:
        r = gh_api(f"/repos/{owner}/{repo}")
        return {"full_name": r.get("full_name"), "description": r.get("description") or "",
                "stars": r.get("stargazers_count", 0), "language": r.get("language") or "",
                "license": (r.get("license") or {}).get("spdx_id") or "", "topics": r.get("topics", []),
                "homepage": r.get("homepage") or "", "default_branch": r.get("default_branch", ""),
                "html_url": r.get("html_url"), "owner_avatar": (r.get("owner") or {}).get("avatar_url", ""),
                "fork": r.get("fork", False), "parent": ((r.get("parent") or {}).get("full_name") or "")}
    except Exception:
        return {"full_name": f"{owner}/{repo}", "html_url": f"https://github.com/{owner}/{repo}"}

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None

def latest_release_tag(repo):
    """Önce API kotası harcamadan /releases/latest yönlendirmesinden, olmazsa API'den etiket okunur."""
    try:
        op = urllib.request.build_opener(_NoRedirect)
        try:
            r = op.open(urllib.request.Request(f"https://github.com/{repo}/releases/latest", headers=UA), timeout=20)
            loc = r.geturl()
        except urllib.error.HTTPError as e:
            loc = e.headers.get("Location") or ""
        m = re.search(r"/releases/tag/([^/?#]+)", loc)
        if m:
            return urllib.parse.unquote(m.group(1))
    except Exception:
        pass
    try:
        return gh_api(f"/repos/{repo}/releases/latest").get("tag_name", "")
    except Exception:
        return ""

BAD_ASSET = (".exe", ".msi", ".dmg", ".pkg", ".apk", ".sha256", ".sha512", ".sig", ".asc", ".sbom", ".pem", ".txt",
             "windows", "win64", "win32", "-win-", "macos", "darwin", "apple", "freebsd", "android", ".ps1", ".nupkg")

def pick_asset(assets):
    av = arch_vars(); best = None; bs = -99
    other_arch = [a for a in ("arm64", "aarch64", "armv7", "i386", "i686", "386", "x86_64", "amd64", "x64") if a not in (av["arch_go"], av["arch"], av["arch_x64"])]
    for a in assets:
        n = a["name"].lower()
        if any(b in n for b in BAD_ASSET):
            continue
        s = 0
        if "linux" in n: s += 5
        if any(x in n for x in (av["arch_go"], av["arch"], av["arch_x64"])): s += 4
        elif any(x in n for x in other_arch): s -= 8
        if n.endswith(".appimage"): s += 4
        elif n.endswith((".tar.gz", ".tgz", ".tar.xz")): s += 3
        elif n.endswith((".zip", ".rar", ".7z")): s += 2
        elif n.endswith(".deb") and detect_pm() == "apt-get": s += 1
        elif n.endswith(".rpm") and detect_pm() in ("dnf", "zypper"): s += 1
        elif "." not in n.rsplit("/", 1)[-1][-6:] and "linux" in n: s += 2  # çıplak ikili
        else: s -= 3
        if s > bs:
            bs, best = s, a
    return best if bs >= 3 else None

def fetch_icon(slug, root, owner, prefer=""):
    """Önce repodaki logo, yoksa GitHub sahibinin avatarı."""
    for f in os.listdir(ICON_DIR):
        if f.startswith(slug + "."):
            os.remove(os.path.join(ICON_DIR, f))
    cands = []
    if root and os.path.isdir(root):
        for d, dirs, files in os.walk(root):
            dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not x.startswith(".")]
            if d[len(root):].count(os.sep) >= 3:
                dirs[:] = []
            for f in files:
                fl = f.lower()
                if fl.endswith((".png", ".svg")) and re.search(r"(^|[-_.])(logo|icon|app-icon|favicon)", fl) and os.path.getsize(os.path.join(d, f)) > 600:
                    cands.append(os.path.join(d, f))
        cands.sort(key=lambda p: (0 if "logo" in p.lower() else 1, 0 if p.endswith(".png") else 1, len(p)))
    if prefer and root and os.path.isfile(os.path.join(root, prefer)):
        cands.insert(0, os.path.join(root, prefer))
    if cands:
        ext = os.path.splitext(cands[0])[1].lower()
        dst = os.path.join(ICON_DIR, slug + ext)
        shutil.copy(cands[0], dst)
        return os.path.basename(dst)
    if owner:
        try:
            dst = os.path.join(ICON_DIR, slug + ".png")
            download(f"https://github.com/{owner}.png?size=256", dst)
            return os.path.basename(dst)
        except Exception:
            pass
    return ""

# ───────────────────────────── README / analiz ─────────────────────────────
README_RE = re.compile(r"^(readme|install|installation|kurulum|setup|building|usage|quickstart)(\.[\w]+)?$", re.I)

def find_readmes(root):
    out = []
    for d, dirs, files in os.walk(root):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS and not x.startswith("."))
        depth = d[len(root):].count(os.sep)
        if depth >= 3:
            dirs[:] = []
        for f in files:
            if README_RE.match(f):
                out.append((depth, 0 if f.lower().startswith("readme") else 1, os.path.join(d, f)))
    return [p for _, _, p in sorted(out)]

def read_readme(root, limit=14000):
    txt = ""
    for p in find_readmes(root)[:4]:
        try:
            t = open(p, encoding="utf-8", errors="replace").read()
        except Exception:
            continue
        txt += f"\n\n===== {os.path.relpath(p, root)} =====\n" + t
        if len(txt) > limit:
            break
    return txt[:limit]

def file_tree(root, limit=120):
    lines = []
    for d, dirs, files in os.walk(root):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS and not x.startswith("."))
        depth = d[len(root):].count(os.sep)
        if depth >= 2:
            dirs[:] = []
        for f in sorted(files)[:40]:
            lines.append(os.path.relpath(os.path.join(d, f), root))
            if len(lines) >= limit:
                return "\n".join(lines)
    return "\n".join(lines)

def readme_intro(root):
    for p in find_readmes(root)[:1]:
        for para in re.split(r"\n\s*\n", open(p, encoding="utf-8", errors="replace").read()):
            s = para.strip()
            if s and not s.startswith(("#", "<", "[!", "![", "[![", "|", "```", "---")) and len(s) > 40:
                return re.sub(r"\s+", " ", re.sub(r"[*_`]", "", s))[:500]
    return ""

IMPORT_MAP = {"cv2": "opencv-python", "PIL": "pillow", "yaml": "pyyaml", "sklearn": "scikit-learn", "bs4": "beautifulsoup4",
              "Crypto": "pycryptodome", "Cryptodome": "pycryptodomex", "dotenv": "python-dotenv", "serial": "pyserial",
              "usb": "pyusb", "telegram": "python-telegram-bot", "discord": "discord.py", "dateutil": "python-dateutil",
              "jwt": "PyJWT", "magic": "python-magic", "docx": "python-docx", "pptx": "python-pptx", "attr": "attrs",
              "OpenSSL": "pyOpenSSL", "nmap": "python-nmap", "whois": "python-whois", "dns": "dnspython", "socks": "PySocks",
              "skimage": "scikit-image", "fitz": "PyMuPDF", "Xlib": "python-xlib", "pkg_resources": "setuptools",
              "yt_dlp": "yt-dlp", "speech_recognition": "SpeechRecognition", "websocket": "websocket-client",
              "github": "PyGithub", "git": "GitPython", "MySQLdb": "mysqlclient", "psycopg2": "psycopg2-binary",
              "zmq": "pyzmq", "google.generativeai": "google-generativeai", "Levenshtein": "python-Levenshtein",
              "win32api": None, "win32con": None, "winreg": None, "msvcrt": None, "_winapi": None, "gi": None, "google": None}

def scan_py_imports(root, limit=500):
    names, local = set(), set(); n = 0
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not x.startswith(".")]
        for x in dirs:
            local.add(x)
        for f in files:
            if f.endswith(".py"):
                local.add(f[:-3]); n += 1
                if n > limit:
                    break
                try:
                    src = open(os.path.join(d, f), encoding="utf-8", errors="replace").read()
                except Exception:
                    continue
                for m in re.finditer(r"^\s*(?:from\s+([\w.]+)\s+import|import\s+([\w.,\s]+?))\s*(?:#.*)?$", src, re.M):
                    for part in (m.group(1) or m.group(2) or "").split(","):
                        top = part.strip().split(" ")[0].split(".")[0]
                        if top:
                            names.add(top)
    std = set(getattr(sys, "stdlib_module_names", ())) | {"__future__"}
    return sorted(n for n in names if n not in std and n not in local and not n.startswith("_"))

def pip_names(mods):
    out = []
    for m in mods:
        v = IMPORT_MAP.get(m, m)
        if v and v not in out:
            out.append(v)
    return out

DANGER = [(r"rm\s+-rf\s+(/|~|\$HOME)(\s|$)", "Kök/ev dizinini silen komut!"), (r"\bmkfs\b|\bdd\s+if=.*of=/dev/", "Disk biçimlendirme/yazma!"),
          (r"(curl|wget)[^|]*\|\s*(sudo\s+)?(ba)?sh", "İnternetten indirilen betik doğrudan çalıştırılıyor (kaynağa güvendiğinden emin ol)."),
          (r"chmod\s+-R\s+777\s+/", "Tüm sisteme 777 izni!"), (r":\(\)\s*\{", "Fork bombası!"), (r">\s*/dev/sd", "Diske doğrudan yazma!")]

def danger_warnings(cmds):
    w = []
    for c in cmds:
        for rx, msg in DANGER:
            if re.search(rx, c):
                w.append(f"{msg}  →  {c[:120]}")
    return w

CODE_EXT = (".py", ".js", ".mjs", ".ts", ".go", ".rs", ".c", ".cc", ".cpp", ".h", ".sh", ".rb", ".java", ".kt", ".php", ".lua",
            ".pl", ".cs", ".swift", ".zig", ".nim", ".dart", ".ex", ".exs", ".jl", ".r", ".ps1")
BUILD_FILES = ("package.json", "pyproject.toml", "setup.py", "requirements.txt", "Cargo.toml", "go.mod", "Makefile", "makefile",
               "CMakeLists.txt", "meson.build", "pom.xml", "build.gradle", "Gemfile", "composer.json", "Dockerfile", "docker-compose.yml", "compose.yaml")

DOC_NAME_RE = re.compile(r"(^|[-_.])(awesome|list|lists|resources|directory|cheat-?sheet|roadmap|free-?llm|free-?ai|guide|notes|papers|prompts|links)([-_.]|$)", re.I)
EXAMPLE_DIRS = {"scripts", "examples", "example", "code-examples", "samples", "sample", "docs", "doc", "media", "assets", "images", ".github", "test", "tests", "agents", "site", "website"}

def has_entrypoint(root):
    f = lambda p: os.path.exists(os.path.join(root, p))
    if any(f(x) for x in ("main.py", "app.py", "run.py", "cli.py", "__main__.py", "main.go", "Cargo.toml", "go.mod", "setup.py", "Dockerfile", "docker-compose.yml", "compose.yaml")):
        return True
    if f("pyproject.toml") and "[project.scripts]" in open(os.path.join(root, "pyproject.toml"), errors="replace").read():
        return True
    if f("package.json"):
        pkg = jload(os.path.join(root, "package.json"), {})
        if pkg.get("bin") or (pkg.get("scripts") or {}).get("start") or pkg.get("main"):
            return True
    return False

def is_doc_repo(root):
    """Liste/doküman/veri depolarını tanır (örnek ve yardımcı betik klasörleri sayılmaz)."""
    if not os.path.isdir(root):
        return False
    named = bool(DOC_NAME_RE.search(os.path.basename(root.rstrip("/"))))
    if has_entrypoint(root) and not named:
        return False
    if named and not has_entrypoint(root):
        return True
    if any(os.path.exists(os.path.join(root, x)) for x in BUILD_FILES):
        return False
    n = 0
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not x.startswith(".") and x.lower() not in EXAMPLE_DIRS]
        for x in files:
            if x.lower().endswith(CODE_EXT) or x.lower().endswith(".appimage"):
                n += 1
                if n > 2:
                    return False
    return True

def discover_actions(root, name=""):
    """Bir depoda aracın nasıl çalıştırıldığını yapay zekâ olmadan bulur. → (actions, steps_gerekirse)"""
    f = lambda p: os.path.exists(os.path.join(root, p))
    acts, steps = [], []
    venv_py = ".venv/bin/python" if f(".venv/bin/python") else "python3"
    def add(label, cmd, term=True):
        if cmd and not any(a["command"] == cmd for a in acts):
            acts.append({"label": label, "command": cmd, "terminal": term})
    # Node
    if f("package.json"):
        pkg = jload(os.path.join(root, "package.json"), {})
        b = pkg.get("bin")
        if isinstance(b, str):
            add("Başlat", f"node {b}")
        elif isinstance(b, dict):
            for k, v in list(b.items())[:3]:
                add(f"Başlat ({k})" if len(b) > 1 else "Başlat", f"node {v}")
        sc = pkg.get("scripts") or {}
        skip = {"install", "postinstall", "preinstall", "prepare", "prepublishOnly", "lint", "format", "test", "typecheck", "build", "clean", "precommit"}
        order = sorted(sc, key=lambda k: (0 if k in ("start", "dev", "serve", "cli") else 1, k))
        for k in order:
            if k not in skip and not k.startswith(("pre", "post", "lint", "format", "test")):
                add(f"npm {k}", f"npm run {k}")
            if len(acts) >= 8:
                break
        if pkg.get("main") and not acts:
            add("Başlat", f"node {pkg['main']}")
        if not f("node_modules") and (pkg.get("dependencies") or pkg.get("devDependencies")):
            steps.append("npm ci" if f("package-lock.json") else "npm install")
    # Python
    pyproj = open(os.path.join(root, "pyproject.toml"), errors="replace").read() if f("pyproject.toml") else ""
    if "[project.scripts]" in pyproj:
        for m in re.findall(r"^\s*([\w][\w.-]*)\s*=\s*\"[\w.]+:[\w.]+\"", pyproj.split("[project.scripts]", 1)[1].split("\n[", 1)[0], re.M)[:3]:
            add(f"Başlat ({m})", f".venv/bin/{m}")
    cands = []
    for d in ("", "scripts", "src", "bin", "tools", "cli"):
        dd = os.path.join(root, d)
        if not os.path.isdir(dd):
            continue
        for x in sorted(os.listdir(dd)):
            p = os.path.join(dd, x)
            if not os.path.isfile(p):
                continue
            rel = os.path.join(d, x) if d else x
            if x.endswith(".py") and x not in ("setup.py", "conftest.py", "__init__.py") and not x.startswith(("test_", "_")):
                try:
                    src = open(p, encoding="utf-8", errors="replace").read(200000)
                except Exception:
                    continue
                main = "__main__" in src or "argparse" in src or "click" in src or "typer" in src or x in ("main.py", "app.py", "cli.py", "run.py")
                gui = any(k in src for k in ("streamlit", "gradio", "flask", "fastapi", "uvicorn", "tkinter", "PyQt", "PySide"))
                if main or gui:
                    pri = 0 if x in ("main.py", "app.py", "cli.py", "run.py", f"{name}.py") else (1 if not d else 2)
                    if "streamlit" in src:
                        cands.append((pri, f"Web arayüzü ({x})", f"{venv_py} -m streamlit run {rel}"))
                    else:
                        cands.append((pri, f"Çalıştır ({x})", f"{venv_py} {rel}"))
            elif x.endswith((".js", ".mjs")) and d in ("", "bin", "scripts", "cli") and x not in ("eslint.config.js", "vite.config.js", "webpack.config.js", "jest.config.js"):
                cands.append((2 if d == "scripts" else 1, f"Çalıştır ({x})", f"node {rel}"))
            elif x.endswith(".sh") and x not in ("install.sh", "setup.sh", "build.sh", "uninstall.sh"):
                cands.append((1, f"Betik ({x})", f"bash {rel}"))
            elif os.access(p, os.X_OK) and "." not in x and d in ("", "bin") and x.lower() not in ("license", "makefile", "dockerfile"):
                try:
                    head = open(p, "rb").read(4)
                except Exception:
                    head = b""
                if head.startswith((b"\x7fELF", b"#!")):
                    cands.append((0, f"Başlat ({x})", f"./{rel}"))
            elif x.lower().endswith(".appimage"):
                cands.append((0, "Başlat", f"./{rel}"))
    npm_named = {a["command"].split()[-1].replace(":", "-") for a in acts if a["command"].startswith("npm run ")}
    for pri, label, cmd in sorted(cands):
        stem = os.path.splitext(os.path.basename(cmd.split()[-1]))[0]
        if stem in npm_named or len(acts) >= 6:
            continue
        add(label, cmd)
    # Docker
    for dc in ("docker-compose.yml", "docker-compose.yaml", "compose.yaml", "compose.yml"):
        if f(dc):
            add("Docker ile başlat", "docker compose up", True); break
    else:
        if f("Dockerfile") and not acts:
            add("Docker ile derle ve başlat", f"docker build -t {slugify(name or 'arac')} . && docker run --rm -it {slugify(name or 'arac')}", True)
    # derlenmiş çıktılar
    for p in ("target/release", "build", "bin", "dist"):
        dd = os.path.join(root, p)
        if os.path.isdir(dd):
            for x in sorted(os.listdir(dd))[:20]:
                fp = os.path.join(dd, x)
                if os.path.isfile(fp) and os.access(fp, os.X_OK) and open(fp, "rb").read(4) == b"\x7fELF":
                    add(f"Başlat ({x})", f"./{p}/{x}")
    if acts and acts[0]["label"].startswith(("Çalıştır (main", "Çalıştır (app", "Çalıştır (cli", "Başlat")):
        pass
    if acts:
        acts[0] = {**acts[0], "label": "Başlat" if acts[0]["label"].startswith(("Başlat", "Çalıştır")) and len(acts) == 1 else acts[0]["label"]}
    return acts, steps

def heuristic_plan(root, name):
    f = lambda p: os.path.exists(os.path.join(root, p))
    steps, actions, runtimes, warn = [], [], [], []
    slug = slugify(name)
    top = sorted(os.listdir(root)) if os.path.isdir(root) else []
    appimgs = [os.path.relpath(os.path.join(d, x), root) for d, _, fs in os.walk(root) for x in fs if x.lower().endswith(".appimage")]
    if appimgs:
        steps.append(f"chmod +x {q(appimgs[0])}")
        actions.append({"label": "Başlat", "command": "./" + appimgs[0], "terminal": False})
    pyproj = open(os.path.join(root, "pyproject.toml"), encoding="utf-8", errors="replace").read() if f("pyproject.toml") else ""
    has_py = f("requirements.txt") or pyproj or f("setup.py") or any(x.endswith(".py") for x in top)
    if f("package.json"):
        pkg = jload(os.path.join(root, "package.json"), {})
        eng = (pkg.get("engines") or {}).get("node", "")
        mver = re.search(r"(\d+)", eng)
        if not which("node") or (mver and node_version(which("node") or "node")[0] < int(mver.group(1))):
            runtimes.append("node22")
        steps.append("npm ci" if f("package-lock.json") else "npm install")
        sc = pkg.get("scripts") or {}
        if "build" in sc:
            steps.append("npm run build")
        b = pkg.get("bin")
        if isinstance(b, dict) and b:
            actions.append({"label": "Başlat", "command": "node " + list(b.values())[0], "terminal": True})
        elif isinstance(b, str):
            actions.append({"label": "Başlat", "command": "node " + b, "terminal": True})
        for k in ("start", "dev", "serve"):
            if k in sc:
                actions.append({"label": f"npm {k}", "command": f"npm run {k}", "terminal": True}); break
    elif has_py:
        req = re.search(r'requires-python\s*=\s*"[^"]*?(\d+)\.(\d+)', pyproj)
        need = (int(req.group(1)), int(req.group(2))) if req else (3, 8)
        if sys.version_info[:2] < need or not check_key("venv"):
            runtimes.append("uv")
            steps.append("uv venv --python 3.12 .venv")
            pipc = "uv pip install --python .venv/bin/python"
        else:
            steps.append("python3 -m venv .venv")
            steps.append(".venv/bin/python -m pip install --upgrade pip")
            pipc = ".venv/bin/pip install"
        if f("requirements.txt"):
            steps.append(f"{pipc} -r requirements.txt")
        if pyproj or f("setup.py"):
            steps.append(f"{pipc} .")
        else:
            libs = pip_names(scan_py_imports(root))
            if libs:
                steps.append(f"{pipc} " + " ".join(q(l) for l in libs))
        scripts = re.findall(r"^\s*([\w][\w.-]*)\s*=\s*\"[\w.]+:[\w.]+\"", pyproj.split("[project.scripts]", 1)[1].split("\n[", 1)[0], re.M) if "[project.scripts]" in pyproj else []
        if scripts:
            actions.append({"label": "Başlat", "command": f".venv/bin/{scripts[0]}", "terminal": True})
        else:
            for e in ("main.py", "app.py", "run.py", f"{slug}.py", f"{name}.py", "cli.py", "start.py", "__main__.py"):
                if f(e):
                    actions.append({"label": "Başlat", "command": f".venv/bin/python {e}", "terminal": True}); break
            else:
                pys = [x for x in top if x.endswith(".py") and x not in ("setup.py", "requirements.py", "conftest.py")]
                if pys:
                    actions.append({"label": "Başlat", "command": f".venv/bin/python {pys[0]}", "terminal": True})
    elif f("Cargo.toml"):
        steps.append("cargo build --release")
        m = re.search(r'^name\s*=\s*"([^"]+)"', open(os.path.join(root, "Cargo.toml")).read(), re.M)
        actions.append({"label": "Başlat", "command": f"./target/release/{m.group(1) if m else slug}", "terminal": True})
    elif f("go.mod"):
        steps.append(f"go build -o {q(slug)} ./...") if not f("main.go") else steps.append(f"go build -o {q(slug)} .")
        actions.append({"label": "Başlat", "command": f"./{slug}", "terminal": True})
    elif f("CMakeLists.txt"):
        steps += ["cmake -B build -DCMAKE_BUILD_TYPE=Release", "cmake --build build -j\"$(nproc)\""]
        actions.append({"label": "Başlat", "command": f"./build/{name}", "terminal": True})
    elif f("meson.build"):
        steps += ["meson setup build", "ninja -C build"]
    elif f("Makefile") or f("makefile"):
        steps.append("make -j\"$(nproc)\"")
    if not steps:
        for sh in ("install.sh", "setup.sh", "build.sh"):
            if f(sh):
                steps.append(f"bash {sh}"); warn.append(f"Projenin kendi {sh} betiği çalıştırılacak — içeriğini kontrol et."); break
    if not actions:
        for x in top:
            p = os.path.join(root, x)
            if os.path.isfile(p) and os.access(p, os.X_OK) and not x.endswith((".sh", ".py")) or x in ("run.sh", "start.sh"):
                actions.append({"label": "Başlat", "command": f"./{x}", "terminal": True}); break
    return {"name": name, "summary": "", "steps": steps, "actions": actions, "runtimes": runtimes,
            "system_packages": [], "warnings": warn, "optional": []}

ANALYZE_SYS = """Sen bir Linux kurulum uzmanısın. Sana bir GitHub projesinin README'si ve dosya listesi verilecek.
Görevin: projeyi BU KLASÖRDE (proje kök dizini, cwd) kurup çalışır hale getirecek bir plan çıkarmak.
SADECE geçerli JSON döndür, başka metin yazma. Şema:
{
 "name": "kısa okunur ad",
 "summary_tr": "Türkçe 2-4 cümle: ne işe yarar",
 "runtimes": ["node22" ve/veya "uv" — sistemde yoksa/eskiyse Cypher Tool sudo'suz kurar],
 "system_packages": ["dağıtıma uygun paket adları (sadece gerçekten gerekenler)"],
 "steps": ["proje kökünde sırayla çalışacak bash komutları"],
 "actions": [{"label":"Başlat","command":"proje köküne göre çalıştırma komutu","terminal":true}],
 "optional": [{"label":"açıklama","command":"isteğe bağlı komut"}],
 "warnings": ["riskli ya da kullanıcının bilmesi gereken şeyler, Türkçe"]
}
Kurallar:
- Global kurulum YAPMA. Python için proje içinde .venv kullan (python3 -m venv .venv ; .venv/bin/pip install ...), Python sürümü yetmiyorsa runtimes'a "uv" ekle ve "uv venv --python 3.12 .venv" + "uv pip install --python .venv/bin/python ..." kullan.
- npm için yerel "npm install"/"npm ci"; "npm install -g" kullanma; çalıştırmak için "node bin/x.js" veya "npx" tercih et.
- Hazır Linux ikilisi (release) en kolay yolsa şu özel adımı kullanabilirsin: "@release {\\"repo\\":\\"sahip/repo\\",\\"match\\":[\\"linux\\",\\"{arch_go}\\"],\\"save_as\\":\\"bin/ad\\",\\"chmod\\":\\"bin/ad\\"}" (arşivse save_as yerine "extract_to":"bin").
- sudo gerekiyorsa komutun başına sudo koy (paketleri system_packages'a yazman daha iyi).
- curl|sh tarzı betikleri sadece README'nin tek resmi yolu buysa kullan ve warnings'e yaz.
- Etkileşimli (kullanıcı girişi isteyen) kurulum adımlarının başına "@terminal " ekle.
- cd ile proje dışına çıkma. Komutlar tek satır olsun.
- terminal: CLI/TUI araçlar için true, grafik (GUI) uygulamalar ve arka plan servisleri için false.
"""

def analyze(root, name, meta, log, provider_id=""):
    plan = heuristic_plan(root, name)
    plan["summary"] = meta.get("description") or readme_intro(root)
    if not (cfg().get("use_ai", True) and llm_available()):
        log("ℹ Yapay zekâ analizi kapalı/API yok → otomatik algılama kullanıldı.")
        return plan
    log("🤖 README yapay zekâ ile analiz ediliyor…")
    oi = os_info()
    user = (f"Sistem: {oi.get('PRETTY_NAME', 'Linux')} | paket yöneticisi: {detect_pm()} | mimari: {platform.machine()} | "
            f"Python {platform.python_version()} | node: {'.'.join(map(str, node_version(which('node')))) if which('node') else 'yok'}\n"
            f"Proje: {meta.get('full_name', name)} — {meta.get('description', '')}\n"
            f"Otomatik algılamanın önerisi (yanlış olabilir): {json.dumps({k: plan[k] for k in ('steps', 'actions', 'runtimes')}, ensure_ascii=False)}\n\n"
            f"DOSYALAR:\n{file_tree(root)}\n\nREADME:\n{read_readme(root)}")
    try:
        txt, p = llm_ask([{"role": "user", "content": user}], ANALYZE_SYS, provider_id, log=log, feature="analyze")
        j = extract_json(txt)
        steps = []
        for s in j.get("steps", []):
            if isinstance(s, dict) and "release" in s:
                steps.append("@release " + json.dumps(s["release"]))
            elif isinstance(s, str) and s.strip():
                steps.append(s.strip())
        plan.update({"name": j.get("name") or name, "summary": j.get("summary_tr") or plan["summary"], "steps": steps,
                     "actions": [a for a in j.get("actions", []) if isinstance(a, dict) and a.get("command")] or plan["actions"],
                     "runtimes": [r for r in j.get("runtimes", []) if r in ("node22", "uv")],
                     "system_packages": [x for x in j.get("system_packages", []) if isinstance(x, str) and NAME_OK.match(x)],
                     "optional": [o for o in j.get("optional", []) if isinstance(o, dict) and o.get("command")],
                     "warnings": plan["warnings"] + [w for w in j.get("warnings", []) if isinstance(w, str)]})
        log(f"✔ Analiz tamam ({p.get('name')})")
    except Exception as e:
        log(f"⚠ Yapay zekâ analizi başarısız, otomatik algılama kullanılıyor: {str(e)[:200]}")
    return plan

def required_keys(root, plan):
    keys = set(); rts = set(plan.get("runtimes", []))
    f = lambda p: os.path.exists(os.path.join(root, p))
    if f("CMakeLists.txt"): keys |= {"cmake", "gcc"}
    if f("Makefile") or f("makefile"): keys |= {"make"}
    if f("meson.build"): keys |= {"gcc"}
    if f("Cargo.toml"): keys.add("cargo")
    if f("go.mod") and not any(s.startswith("@release") for s in plan.get("steps", [])): keys.add("go")
    if f("pom.xml"): keys |= {"maven", "java"}
    if f("Gemfile"): keys.add("ruby")
    if f(".gitattributes") and "lfs" in open(os.path.join(root, ".gitattributes"), errors="replace").read(): keys.add("git-lfs")
    cmds = list(plan.get("steps", [])) + [a.get("command", "") for a in plan.get("actions", [])]
    for c in cmds:
        if c.startswith("@release"):
            continue
        c = c.removeprefix("@terminal ")
        for seg in re.split(r"&&|\|\||;|\|", c):
            try:
                toks = shlex.split(seg)
            except ValueError:
                toks = seg.split()
            toks = [t for t in toks if t not in ("sudo", "env", "exec", "time") and not re.match(r"^\w+=", t)]
            if not toks:
                continue
            b = os.path.basename(toks[0])
            if toks[0].startswith((".venv/", "./", "bin/")):
                continue
            if b in RUNTIME_CMDS:
                if not runtime_ok(RUNTIME_CMDS[b]):
                    rts.add(RUNTIME_CMDS[b])
            elif b in CMD2KEY:
                keys.add(CMD2KEY[b])
            if b in ("python3", "python") and "venv" in toks:
                keys.add("venv")
    return keys, rts

# ───────────────────────────── komut çalıştırma ─────────────────────────────
SUDO_RE = re.compile(r"(^|&&|\|\||;|\|)\s*sudo\s+(-\w+\s+)*")

def needs_root(cmd):
    return bool(SUDO_RE.search(cmd))

def strip_sudo(cmd):
    return SUDO_RE.sub(lambda m: m.group(1) + " ", cmd).strip()

def find_terminal():
    for t, a in (("x-terminal-emulator", ["-e"]), ("gnome-terminal", ["--"]), ("konsole", ["-e"]), ("xfce4-terminal", ["-x"]),
                 ("mate-terminal", ["-x"]), ("tilix", ["-e"]), ("kitty", []), ("alacritty", ["-e"]), ("wezterm", ["start", "--"]),
                 ("foot", []), ("lxterminal", ["-e"]), ("xterm", ["-e"])):
        if shutil.which(t):
            return [t] + a
    return None

def open_in_terminal(script):
    t = find_terminal()
    if not t:
        return False
    subprocess.Popen(t + [script], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return True

def run_shell(job, cmd, cwd, interactive=False, secret=None, show=None):
    job.log(f"$ {show or cmd}")
    tail = []
    p = subprocess.Popen(["bash", "-lc", cmd], cwd=cwd, env=base_env(), text=True, errors="replace",
                         stdin=subprocess.PIPE if secret is not None else (None if interactive else subprocess.DEVNULL),
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
    if secret is not None:
        try:
            p.stdin.write(secret + "\n"); p.stdin.flush(); p.stdin.close()
        except Exception:
            pass
        secret = None
    job.proc = p
    for line in p.stdout:
        line = clean_term(line.rstrip("\n"))
        job.log("  " + line)
        tail.append(line); tail = tail[-60:]
        if job.cancelled:
            try: os.killpg(p.pid, signal.SIGTERM)
            except Exception: pass
    rc = p.wait(); job.proc = None
    if rc != 0:
        job.log(f"✖ Komut başarısız (çıkış kodu {rc})")
    return rc, tail

def run_in_terminal_wait(job, cmd, cwd, why):
    fd, path = tempfile.mkstemp(prefix="ct-", suffix=".sh", dir=LAUNCH_DIR)
    done = path + ".done"
    with os.fdopen(fd, "w") as f:
        f.write(f"#!/usr/bin/env bash\nexport PATH={q(base_env()['PATH'])}\ncd {q(cwd)}\necho '▶ Cypher Tool: {why}'\necho '$ {cmd.replace(chr(39), '')}'\n"
                f"{cmd}\nrc=$?\necho $rc > {q(done)}\necho; [ $rc -eq 0 ] && echo '✔ Bitti.' || echo \"✖ Hata (kod $rc)\"\nread -rp 'Kapatmak için Enter…' _\n")
    os.chmod(path, 0o700)
    if job.cli:
        rc = subprocess.call(["bash", path]); os.remove(path); return rc, []
    if not open_in_terminal(path):
        r = job.ask("manual", {"command": cmd, "cwd": cwd, "why": why})
        return (0 if r and r.get("ok") else 1), []
    job.log(f"🖥 Terminal penceresi açıldı: {why} — orada tamamla.")
    while not os.path.exists(done) and not job.cancelled:
        time.sleep(1)
    rc = int(open(done).read().strip() or 1) if os.path.exists(done) else 1
    for x in (path, done):
        try: os.remove(x)
        except Exception: pass
    return rc, []

def sudo_check(pw):
    """Şifreyi doğrular. (True, '') | (False, sebep)"""
    r = subprocess.run(["sudo", "-S", "-k", "-p", "", "-v"], input=pw + "\n", text=True, capture_output=True, timeout=30)
    if r.returncode == 0:
        return True, ""
    err = r.stderr.lower()
    if "sudoers" in err or "not allowed" in err or "izin" in err:
        return False, "nosudo"
    return False, "wrong"

def run_privileged(job, script, cwd):
    if job.cli:
        return run_shell(job, "sudo bash -c " + q(script), cwd, interactive=True)
    inner = f"cd {q(cwd)} && export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a NEEDRESTART_SUSPEND=1 APT_LISTCHANGES_FRONTEND=none && {script}"
    if subprocess.run(["sudo", "-n", "true"], capture_output=True).returncode == 0:
        return run_shell(job, "sudo -n bash -c " + q(inner), cwd, show="sudo " + script)
    has_pk = bool(shutil.which("pkexec") and (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")))
    if not shutil.which("sudo"):
        if has_pk:
            return run_shell(job, f"pkexec bash -c {q(inner)}", cwd, show="pkexec " + script)
        return run_in_terminal_wait(job, "su -c " + q(script), cwd, "yönetici izni gereken adım")
    notify(APP, "🔐 Yönetici şifresi gerekiyor — Cypher Tool penceresine bak")
    job.log("🔐 Yönetici (sudo) şifresi isteniyor…")
    retry = ""
    for _ in range(3):
        r = job.ask("password", {"name": job.title, "commands": script, "retry": retry, "pkexec": has_pk, "user": os.environ.get("USER", "")})
        if not r or not r.get("ok"):
            job.log("✖ Yönetici izni verilmedi."); return 1, ["Yönetici izni verilmedi"]
        d = r.get("data") or {}
        if d.get("use_pkexec") and has_pk:
            job.log("🔐 Sistem parola penceresi açılıyor…")
            return run_shell(job, f"pkexec bash -c {q(inner)}", cwd, show="pkexec " + script)
        if d.get("use_terminal"):
            return run_in_terminal_wait(job, "sudo bash -c " + q(script), cwd, "yönetici (sudo) izni gereken adım")
        pw = d.get("password", "")
        ok, why = sudo_check(pw)
        if ok:
            job.log("✔ Şifre kabul edildi")
            res = run_shell(job, "sudo -S -p '' bash -c " + q(inner), cwd, secret=pw, show="sudo " + script)
            pw = None; d.clear()
            return res
        pw = None; d.clear()
        if why == "nosudo":
            job.log("✖ Bu kullanıcının sudo yetkisi yok."); return 1, ["Kullanıcının sudo yetkisi yok"]
        retry = "Şifre yanlış, tekrar dene."
        job.log("⚠ Şifre yanlış")
    job.log("✖ 3 kez yanlış şifre."); return 1, ["Şifre yanlış"]

def release_step(job, spec, cwd):
    av = arch_vars(); fmt = lambda s: s.format(**av)
    repo = spec["repo"]; tag = ""
    if spec.get("asset"):
        name = fmt(spec["asset"])
        url = f"https://github.com/{repo}/releases/latest/download/{name}"
        tag = latest_release_tag(repo)
        assets = None
    else:
        try:
            rel = gh_api(f"/repos/{repo}/releases/latest")
        except Exception as e:
            if not spec.get("fallback_asset"):
                raise
            job.log(f"   GitHub API kullanılamadı ({str(e)[:60]}), yedek dosya adı deneniyor")
            spec = {**spec, "asset": spec["fallback_asset"]}
            return release_step(job, spec, cwd)
        tag = rel.get("tag_name", ""); assets = rel.get("assets", [])
        if spec.get("match_regex"):
            a = next((x for x in assets if re.search(spec["match_regex"], x["name"])), None)
        elif spec.get("match"):
            ms = [fmt(m).lower() for m in spec["match"]]; ex = [e.lower() for e in spec.get("exclude", [])]
            a = next((x for x in assets if all(m in x["name"].lower() for m in ms) and not any(e in x["name"].lower() for e in ex)), None)
        else:
            a = pick_asset(assets)
        if not a:
            raise RuntimeError(f"{repo} sürümünde bu sisteme uygun dosya bulunamadı.")
        name, url = a["name"], a["browser_download_url"]
    job.log(f"⬇ Sürüm dosyası: {repo} {tag} → {name}")
    tmpd = tempfile.mkdtemp(dir=cwd, prefix=".dl-")
    tmp = os.path.join(tmpd, name)
    final = download(url, tmp, job.log)
    m = re.search(r"/download/([^/]+)/", final)
    tag = tag or (urllib.parse.unquote(m.group(1)) if m else "")
    exp = ""
    try:
        if spec.get("checksums"):
            txt = http_get(f"https://github.com/{repo}/releases/download/{tag}/{fmt(spec['checksums'])}") if tag else http_get(f"https://github.com/{repo}/releases/latest/download/{fmt(spec['checksums'])}")
            exp = next((l.split()[0] for l in txt.splitlines() if l.split() and l.split()[-1].lstrip("*") == name), "")
        elif spec.get("checksum_file"):
            exp = http_get(f"https://github.com/{repo}/releases/latest/download/{fmt(spec['checksum_file'])}").split()[0]
        elif assets:
            sa = next((x for x in assets if x["name"] in (name + ".sha256", name + ".sha256sum")), None)
            if sa:
                exp = http_get(sa["browser_download_url"]).split()[0]
    except Exception as e:
        job.log(f"   (sağlama dosyası alınamadı: {str(e)[:100]})")
    if exp:
        if exp.lower() != sha256(tmp):
            shutil.rmtree(tmpd, ignore_errors=True)
            raise RuntimeError("SHA256 sağlaması uyuşmadı — dosya bozuk veya değiştirilmiş, kurulum durduruldu.")
        job.log("   ✔ SHA256 doğrulandı")
    if spec.get("extract_to"):
        out = os.path.join(cwd, spec["extract_to"]); extract(tmp, out, job.log)
    elif spec.get("save_as"):
        dst = os.path.join(cwd, spec["save_as"]); os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.move(tmp, dst)
    else:
        sd = os.path.join(cwd, spec.get("save_dir", "_release")); os.makedirs(sd, exist_ok=True)
        dst = os.path.join(sd, name); shutil.move(tmp, dst)
        if is_archive(name) and spec.get("save_dir") is None:
            extract(dst, os.path.join(sd, re.sub(r"(\.tar)?\.\w+$", "", name)), job.log)
        if name.lower().endswith(".appimage"):
            os.chmod(dst, 0o755)
    shutil.rmtree(tmpd, ignore_errors=True)
    if spec.get("chmod"):
        os.chmod(os.path.join(cwd, spec["chmod"]), 0o755)
    job.ctx["release_tag"] = tag; job.ctx["release_repo"] = repo
    return 0, []

def run_steps(job, steps, cwd):
    """Adımları sırayla çalıştırır. Başarısızsa (False, kalan_adımlar, son_çıktı)."""
    i = 0
    while i < len(steps):
        if job.cancelled:
            return False, steps[i:], ["İptal edildi"]
        c = apt_safe(steps[i].strip())
        if not c or c.startswith("#"):
            i += 1; continue
        try:
            if c.startswith("@release "):
                rc, tail = release_step(job, json.loads(c[9:]), cwd); j = i + 1
            elif c.startswith("@terminal "):
                rc, tail = run_in_terminal_wait(job, c[10:], cwd, "etkileşimli kurulum adımı"); j = i + 1
            elif needs_root(c) and not is_root():
                group = [strip_sudo(c)]; j = i + 1
                while j < len(steps) and needs_root(steps[j]) and not steps[j].startswith("@"):
                    group.append(strip_sudo(steps[j])); j += 1
                rc, tail = run_privileged(job, " && ".join(group), cwd)
            else:
                rc, tail = run_shell(job, strip_sudo(c) if is_root() else c, cwd); j = i + 1
        except Exception as e:
            job.log(f"✖ {e}"); rc, tail, j = 1, [str(e)], i + 1
        if rc != 0:
            return False, steps[i:], tail
        i = j
    return True, [], []

# ───────────────────────────── hata bilgi bankası ─────────────────────────────
KB_FILE = os.path.join(APP_DIR, "hata_bankasi.json")
LEARNED_ERR = os.path.join(CONF_DIR, "ogrenilen_hatalar.json")
_KB = {}

def kb():
    if not _KB:
        _KB.update(jload(KB_FILE, {"packages": {}, "headers": {}, "libs": {}, "commands": {}, "cmake": {}, "errors": []}))
    return _KB

def kb_errors():
    return jload(LEARNED_ERR, []) + kb().get("errors", [])

def kb_pkgs(keys):
    pm = detect_pm()
    if not pm:
        return []
    out = []
    for k in keys:
        v = kb()["packages"].get(k) or (PKG.get(k) and list(PKG[k]))
        if v:
            out += [x for x in v[PM_IDX[pm]].split() if x not in out]
    return out

def kb_install(keys):
    pm = detect_pm(); pk = kb_pkgs(keys)
    if not pm or not pk:
        return None
    pre = (("" if is_root() else "sudo ") + "apt-get update -qq && ") if pm == "apt-get" else ""
    return pre + install_line(pm, pk)

_COND = re.compile(r"\{g1:((?:[^{}]|\{g1\})*)\}")

def kb_text(t, g):
    t = _COND.sub(lambda m: m.group(1).replace("{g1}", g) if g else "", t or "")
    return t.replace("{g1}", g or "")

def kb_render(tpl, g, tool=None):
    """Çözüm şablonunu bu sisteme göre komuta çevirir; çevrilemezse None."""
    sudo = "" if is_root() else "sudo "
    venv = tool and os.path.isdir(os.path.join(tool.get("path", ""), ".venv"))
    pip = ".venv/bin/python -m pip install" if venv else "python3 -m pip install --user --break-system-packages"
    t = tpl
    t = _COND.sub(lambda m: m.group(1).replace("{g1}", g) if g else "", t)
    if "{g1}" in t and not g:
        return None
    t = t.replace("{g1}", g or "").replace("{SUDO}", sudo).replace("{PIP}", pip)
    if "{PIPMOD}" in t:
        top = (g or "").split(".")[0]
        name = IMPORT_MAP.get(top, top)
        if not name or top in getattr(sys, "stdlib_module_names", ()):
            return None
        t = t.replace("{PIPMOD}", f"{pip} {q(name)}")
    m = re.search(r"\{INSTALL:([^}]+)\}", t)
    if m:
        ic = kb_install(m.group(1).split())
        if not ic:
            return None
        t = t.replace(m.group(0), ic)
    for tok, table in (("{HDR}", "headers"), ("{CMAKEPKG}", "cmake")):
        if tok in t:
            key = kb()[table].get(g or "")
            ic = kb_install([key]) if key else None
            if not ic:
                return None
            t = t.replace(tok, ic)
    if "{LIB}" in t or "{LIBDEV}" in t:
        base = re.sub(r"\.so.*$", "", g or ""); base = base if base.startswith("lib") else "lib" + base
        key = kb()["libs"].get(base) or next((v for k2, v in kb()["libs"].items() if base.startswith(k2)), None)
        ic = kb_install([key]) if key else None
        if not ic:
            return None
        t = t.replace("{LIB}", ic).replace("{LIBDEV}", ic)
    if "{CMDPKG}" in t:
        cmd = os.path.basename(g or "")
        if cmd in RUNTIME_CMDS:
            return "@runtime " + RUNTIME_CMDS[cmd]
        key = kb()["commands"].get(cmd) or (CMD2KEY.get(cmd) if CMD2KEY.get(cmd) in PKG else None)
        ic = kb_install([key]) if key else None
        if not ic:
            return None
        t = t.replace("{CMDPKG}", ic)
    return t

def diagnose(text, tool=None, limit=8):
    """Çıktıdaki bilinen hataları bulur → [{id,title,cause,commands,advice,auto,learned}]"""
    res, seen_g = [], set()
    if not text:
        return res
    for e in kb_errors():
        try:
            rx = re.compile(e["re"], re.M)
        except re.error:
            continue
        hits = 0
        for m in rx.finditer(text):
            g = next((x for x in m.groups() if x), "") if m.groups() else ""
            if e["id"] == "cmd-generic" and g in seen_g:
                continue
            key = (e["id"], g)
            if any((r["id"], r["g"]) == key for r in res):
                continue
            cmds, adv = [], []
            for f in e.get("fix", []):
                r = kb_render(f, g, tool)
                if r is None:
                    continue
                (adv if r.startswith("#") else cmds).append(r.lstrip("# ").strip() if r.startswith("#") else r)
            if not cmds and not adv:
                continue
            title = kb_text(e["title"], g)
            res.append({"id": e["id"], "g": g, "cat": e.get("cat", ""), "title": title, "cause": kb_text(e.get("cause", ""), g),
                        "commands": cmds, "advice": adv, "auto": e.get("auto", True), "learned": bool(e.get("learned")), "line": m.group(0)[:200]})
            seen_g.add(g); hits += 1
            if hits >= 4:
                break
        if len(res) >= limit:
            break
    return res

def learn_error(signature, title, commands, cause=""):
    """Yeni çözülen bir hatayı bilgi bankasına ekler (kendi kendine öğrenme)."""
    sig = (signature or "").strip()
    if len(sig) < 12 or not commands:
        return None
    sig = re.sub(r"/[\w./-]{12,}", "", sig)[:120].strip()
    rx = re.escape(sig)
    rx = re.sub(r"\\ ", r"\\s+", rx)
    with _lock:
        L = jload(LEARNED_ERR, [])
        if any(x["re"] == rx for x in L):
            return None
        e = {"id": "ogr-" + uuid.uuid4().hex[:6], "cat": "Öğrenilen", "re": rx, "title": title[:120], "cause": cause or "Cypher Tool bu hatayı daha önce çözdü.",
             "fix": [c for c in commands if isinstance(c, str)][:8], "auto": True, "learned": True, "at": now()}
        L.append(e); jsave(LEARNED_ERR, L[-500:])
    return e

def error_signature(text):
    lines = [l.strip() for l in (text or "").splitlines() if re.search(r"error|Error|ERROR|failed|Failed|not found|denied|cannot|Cannot", l)]
    return lines[-1] if lines else ""

def quick_fixes(text, tool=None):
    """Hata çıktısından çözüm adımları üretir (bilgi bankası tabanlı)."""
    fixes = []
    for d in diagnose(text, tool):
        why = f"{d['title']} — {d['cause']}" + (f" (öneri: {'; '.join(d['advice'])})" if d["advice"] else "")
        added = False
        for c in d["commands"]:
            if c.startswith("@runtime "):
                fixes.append({"why": why, "runtime": c.split()[1]}); added = True
            elif d["auto"]:
                fixes.append({"why": why, "command": c}); added = True
        if not added:
            fixes.append({"why": why, "command": "", "advice": True})
    return fixes

# ───────────────────────────── görevler (jobs) ─────────────────────────────
JOBS = {}

class Job:
    def __init__(self, title, kind, cli=False):
        self.id = uuid.uuid4().hex[:10]; self.title = title; self.kind = kind; self.cli = cli
        self.status = "bekliyor"; self.lines = []; self.pending = None; self.response = None
        self.event = threading.Event(); self.cancelled = False; self.proc = None; self.ctx = {}
        self.created = time.time(); self.slug = ""; self.auto = False; self.icon = ""
        self.logpath = os.path.join(LOG_DIR, time.strftime("%Y%m%d-%H%M%S") + f"-{kind}-{self.id}.log"); self._lf = None
        JOBS[self.id] = self

    def log(self, s):
        try:
            if self._lf is None:
                self._lf = open(self.logpath, "a", encoding="utf-8")
                self._lf.write(f"# {APP} {VERSION} — {self.title} — {now()}\n")
            self._lf.write(str(s) + "\n"); self._lf.flush()
        except Exception:
            pass
        mp = self.ctx.get("mirror")
        if mp:
            console_print(PROCS.get(mp), str(s), "35")
        for line in str(s).split("\n"):
            self.lines.append(line)
            if self.cli:
                print(line, flush=True)
        if len(self.lines) > 8000:
            del self.lines[:2000]

    def set(self, status):
        self.status = status
        self.log(f"── {status} ──") if self.cli else None

    def ask(self, kind, payload):
        if self.auto and kind in ("plan", "confirm", "fix") and not (isinstance(payload, dict) and (payload.get("heavy") or payload.get("must"))):
            return {"ok": True, "data": payload}
        if self.cli:
            return cli_ask(kind, payload)
        self.pending = {"kind": kind, "payload": payload}; self.event.clear()
        prev = self.status; self.status = "onay bekliyor"
        while not self.event.wait(1):
            if self.cancelled:
                break
        self.pending = None; self.status = prev
        r = self.response; self.response = None
        return r  # şifre yanıtı yalnızca çağırana gider, saklanmaz

    def respond(self, ok, data=None):
        self.response = {"ok": ok, "data": data}; self.event.set()

    def summary(self):
        return {"id": self.id, "title": self.title, "kind": self.kind, "status": self.status, "slug": self.slug, "logfile": os.path.basename(self.logpath), "api": self.ctx.get("api", ""),
                "icon": self.icon, "pending": self.pending, "created": self.created, "nlines": len(self.lines), "console": self.ctx.get("console", ""), "watch": self.ctx.get("watch", ""),
                "repair": bool(getattr(self, "repair", False) or re.search(r"onar|düzelt", self.title + str(self.ctx.get("title", "")), re.I)),
                "last": next((str(x)[:160] for x in reversed(self.lines[-12:]) if str(x).strip() and not str(x).startswith("──")), "")}

def link_log(job):
    if job.slug and job.slug in tools():
        t = tools()[job.slug]
        logs = [x for x in t.get("logs", []) if x.get("file") != os.path.basename(job.logpath)]
        logs.append({"file": os.path.basename(job.logpath), "kind": job.kind, "title": job.title, "status": job.status, "at": now()})
        update_tool(job.slug, logs=logs[-25:])

def start_job(title, kind, fn, *args, cli=False, auto=False):
    job = Job(title, kind, cli=cli); job.auto = auto
    job.repair = kind == "repair" or getattr(fn, "__name__", "") in ("repair_flow", "escalating_repair_flow", "commands_flow", "system_fix_flow")
    def runner():
        try:
            job.status = "çalışıyor"; fn(job, *args)
            if job.status not in ("hata", "iptal"):
                job.status = "tamamlandı"
        except Exception as e:
            import traceback
            job.log(f"✖ Hata: {e}"); job.log(traceback.format_exc()[-1500:]); job.status = "hata"
        finally:
            job.log(f"── bitti: {job.status} ──")
            try: link_log(job)
            except Exception: pass
    if cli:
        runner()
    else:
        threading.Thread(target=runner, daemon=True).start()
    return job

# ───────────────────────────── araç kaydı / kısayol ─────────────────────────────
def desktop_dir():
    try:
        d = subprocess.run(["xdg-user-dir", "DESKTOP"], capture_output=True, text=True).stdout.strip()
        if d and os.path.isdir(d) and d != os.path.expanduser("~"):
            return d
    except Exception:
        pass
    for n in ("Masaüstü", "Desktop"):
        p = os.path.expanduser("~/" + n)
        if os.path.isdir(p):
            return p
    return None

def make_launcher(tool, idx=0):
    a = tool["actions"][idx]
    p = os.path.join(LAUNCH_DIR, f"{tool['slug']}__{idx}.sh")
    with open(p, "w") as f:
        f.write("#!/usr/bin/env bash\n# Cypher Tool başlatıcı\n")
        f.write(f"export PATH={q(RT_BIN)}:{q(os.path.join(RT, 'node', 'bin'))}:\"$HOME/.local/bin:$PATH\"\n")
        f.write(f"export UV_PYTHON_INSTALL_DIR={q(os.path.join(RT, 'python'))}\n")
        if tool.get("inject_keys", True):
            if (cfg().get("gateway") or {}).get("enabled", True):
                f.write(f"(exec 3<>/dev/tcp/127.0.0.1/{GATEWAY_PORT}) 2>/dev/null || {{ nohup {q(os.path.realpath(__file__))} sunucu >/dev/null 2>&1 & sleep 2; }}\n")
            f.write(f"[ -f {q(ENV_FILE)} ] && . {q(ENV_FILE)}\n")
        f.write(f"cd {q(tool['path'])} || exit 1\n")
        f.write(f"{a['command']} \"$@\"\nrc=$?\n")
        if a.get("terminal", True):
            f.write('if [ -t 1 ] && [ "${CT_NOPAUSE:-0}" != 1 ]; then echo; echo "[çıkış kodu $rc]"; read -rp "Kapatmak için Enter…" _; fi\n')
        f.write("exit $rc\n")
    os.chmod(p, 0o755)
    return p

def make_shortcuts(tool, desktop=True):
    if not tool.get("actions"):
        return []
    launcher = make_launcher(tool, 0)
    icon = os.path.join(ICON_DIR, tool["icon"]) if tool.get("icon") else "utilities-terminal"
    entry = (f"[Desktop Entry]\nType=Application\nName={tool['name']}\nComment={(tool.get('summary') or '')[:120].replace(chr(10), ' ')}\n"
             f"Exec=\"{launcher}\"\nPath={tool['path']}\nIcon={icon}\nTerminal={'true' if tool['actions'][0].get('terminal', True) else 'false'}\n"
             f"Categories=Development;Utility;\nStartupWMClass={tool['slug']}\nX-CypherTool={tool['slug']}\n")
    made = []
    apps = os.path.expanduser("~/.local/share/applications"); os.makedirs(apps, exist_ok=True)
    targets = [os.path.join(apps, f"cyphertool-{tool['slug']}.desktop")]
    dd = desktop_dir()
    if desktop and dd:
        targets.append(os.path.join(dd, f"{tool['slug']}.desktop"))
    for t in targets:
        with open(t, "w") as f:
            f.write(entry)
        os.chmod(t, 0o755)
        if shutil.which("gio"):
            subprocess.run(["gio", "set", t, "metadata::trusted", "true"], capture_output=True)
        made.append(t)
    return made

def remove_shortcuts(slug):
    for p in [os.path.expanduser(f"~/.local/share/applications/cyphertool-{slug}.desktop")] + \
             ([os.path.join(desktop_dir(), f"{slug}.desktop")] if desktop_dir() else []):
        try: os.remove(p)
        except Exception: pass
    for f in os.listdir(LAUNCH_DIR):
        if f.startswith(slug + "__"):
            os.remove(os.path.join(LAUNCH_DIR, f))

def notify(title, body):
    if shutil.which("notify-send"):
        subprocess.run(["notify-send", "-a", APP, "-i", os.path.join(WEB_DIR, "logo.svg"), title, body], capture_output=True)

# ───────────────────────────── kurulum akışı ─────────────────────────────
def find_catalog(src):
    s = src.strip().rstrip("/").lower().removesuffix(".git")
    for c in catalog() + jload(USER_CATALOG, []):
        if c["source"].lower() == s or c.get("id") == s:
            return c
    return None

def guide_summary(g):
    m = re.search(r"## Ne işe yarar\?\s*\n(.+?)(\n\s*\n|$)", g or "", re.S)
    return re.sub(r"[*`]", "", m.group(1)).strip() if m else ""

# ───────────────────────────── 🛡️ güvenlik taraması ─────────────────────────────
SEC_RULES = [
    (3, r"(curl|wget)[^\n|]*\|\s*(sudo\s+)?(ba|z)?sh\b", "İnternetten indirilen betik doğrudan çalıştırılıyor"),
    (4, r"base64\s+(-d|--decode)[^\n]*\|\s*(ba)?sh|eval\s*\(\s*(atob|base64|Buffer\.from)|exec\(\s*base64\.b64decode|exec\(\s*(zlib|marshal)\.", "Gizlenmiş (şifrelenmiş) kod çalıştırılıyor"),
    (5, r"\b(xmrig|minerd|cpuminer|stratum\+tcp|cryptonight|nicehash)\b", "Kripto para madencisi izi"),
    (5, r"(nc|ncat|netcat)\s+(-e|-c)\s|bash\s+-i\s*>&\s*/dev/tcp|/dev/tcp/\d+\.\d+\.\d+\.\d+/\d+|socket\.connect\(\(.{0,40}\)\).{0,200}(subprocess|pty\.spawn|/bin/(ba)?sh)", "Uzaktan kontrol (ters kabuk / reverse shell) izi"),
    (4, r"(\.ssh/(id_rsa|id_ed25519|authorized_keys))|(\.config/google-chrome/.{0,30}(Login Data|Cookies))|(\.mozilla/firefox/.{0,40}(logins\.json|cookies\.sqlite))|wallet\.dat|\.electrum", "Şifre/anahtar/çerez dosyalarına erişim"),
    (3, r"(crontab\s+-|/etc/cron\.|>>\s*~?/?\.?(bashrc|profile|zshrc)|systemctl\s+enable|/etc/systemd/system/|\.config/autostart)", "Kalıcılık (açılışta çalışma / cron / bashrc değişikliği)"),
    (2, r"(>|>>|tee|write|open\().{0,20}/etc/(sudoers|shadow)\b|chmod\s+u\+s|chmod\s+[4-7][0-7]{3}\s+/(usr|bin)", "Sistem yetki dosyalarına yazma"),
    (3, r"rm\s+-rf\s+(/|~|\$HOME)(\s|$)|mkfs\.|dd\s+if=.{0,40}of=/dev/sd", "Yıkıcı komut (silme/biçimlendirme)"),
    (2, r"(discord(app)?\.com/api/webhooks|api\.telegram\.org/bot|pastebin\.com/raw|transfer\.sh|ngrok\.io)", "Veri gönderebilecek dış servis adresi"),
    (2, r"\b(keylogger|GetAsyncKeyState|SetWindowsHookEx)\b", "Klavye dinleme (keylogger) izi"),
]
SEC_EXT = (".sh", ".py", ".js", ".mjs", ".cjs", ".ts", ".rb", ".pl", ".php", ".ps1", ".bat", ".json", ".toml", ".cfg", ".yml", ".yaml", "Makefile", "Dockerfile")

SEC_SKIP = {"vendor", "vendors", "third_party", "thirdparty", "node_modules", "test", "tests", "__tests__", "spec", "docs", "doc", "examples",
            "example", "samples", "fixtures", "snippets", "skills", "site", "website", "dist", "build", "assets", "static", "media"}

def security_scan(root, ai=True, log=None):
    """Depoyu kurulumdan önce zararlı kalıplara karşı tarar. → {level: ok|warn|danger, score, findings, ai}"""
    findings, nfiles, kinds = [], 0, {}
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if not x.startswith(".") and x.lower() not in SEC_SKIP and x not in SKIP_DIRS]
        for fn in files:
            p = os.path.join(d, fn); rel = os.path.relpath(p, root)
            if not (fn.endswith(SEC_EXT) or fn in ("Makefile", "Dockerfile") or (os.access(p, os.X_OK) and os.path.getsize(p) < 200_000)):
                continue
            if re.search(r"(^|[._-])(test|spec|min)([._-]|$)", fn.lower()):
                continue
            try:
                if os.path.getsize(p) > 1_500_000:
                    continue
                txt = open(p, encoding="utf-8", errors="replace").read()
            except Exception:
                continue
            nfiles += 1
            dockerish = "docker" in rel.lower() or fn == "Dockerfile"
            for w, rx, why in SEC_RULES:
                m = re.search(rx, txt, re.I)
                if not m:
                    continue
                if dockerish and why.startswith(("Kalıcılık", "İnternetten")):
                    w = 1  # konteyner içi kurulum betiklerinde olağan
                ln = txt[:m.start()].count("\n") + 1
                findings.append({"file": rel, "line": ln, "why": why, "weight": w, "snippet": txt[max(0, m.start() - 60): m.end() + 60].replace("\n", " ")[:220]})
                kinds[why] = max(kinds.get(why, 0), w)
            if fn.endswith((".js", ".mjs", ".cjs")) and max((len(l) for l in txt.splitlines()[:200]), default=0) > 5000:
                findings.append({"file": rel, "line": 1, "why": "Çok uzun tek satırlık (gizlenmiş olabilecek) kod", "weight": 2, "snippet": ""}); kinds["obf"] = 2
            if fn == "package.json":
                sc = (jload(p, {}).get("scripts") or {})
                for k in ("preinstall", "install", "postinstall"):
                    if sc.get(k) and re.search(r"curl|wget|node -e|sh -c|powershell", sc[k]):
                        findings.append({"file": rel, "line": 1, "why": f"npm '{k}' betiği kurulumda komut çalıştırıyor", "weight": 3, "snippet": sc[k][:200]}); kinds["npmhook"] = 3
            if fn == "setup.py" and re.search(r"urlopen|requests\.get|os\.system\(", txt):
                findings.append({"file": rel, "line": 1, "why": "setup.py kurulum sırasında ağ/komut kullanıyor", "weight": 2, "snippet": ""}); kinds["setup"] = 2
    score = sum(kinds.values())
    findings.sort(key=lambda f: -f["weight"])
    level = "danger" if any(f["weight"] >= 5 for f in findings) else ("warn" if score >= 4 else "ok")
    res = {"level": level, "score": score, "files": nfiles, "findings": findings[:25], "ai": ""}
    if ai and findings and llm_available():
        try:
            if log: log("🛡️ Bulgular yapay zekâya inceletiliyor…")
            txt, _ = llm_ask([{"role": "user", "content": "Aşağıda bir GitHub deposunun otomatik güvenlik taramasında çıkan bulgular var. Bunların gerçek bir tehdit mi yoksa normal/meşru kullanım mı (ör. kurulum betiği, belge, test) olduğunu değerlendir. "
                               "Türkçe, kısa yaz: 1 cümle genel karar ('Güvenli görünüyor' / 'Dikkatli ol' / 'Kurma'), sonra en fazla 4 madde. Sonuna tek satır 'KARAR: ok|warn|danger' yaz.\n\n" +
                               json.dumps(findings[:15], ensure_ascii=False)}], "Sen bir yazılım güvenliği uzmanısın. Abartma, ama gerçek riskleri kaçırma.", log=log, feature="repair")
            m = re.search(r"KARAR:\s*(ok|warn|danger)", txt)
            res["ai"] = re.sub(r"KARAR:.*", "", txt).strip()
            if m:
                res["ai_level"] = m.group(1)
                order = {"ok": 0, "warn": 1, "danger": 2}
                if res["level"] == "danger" and m.group(1) == "ok" and not any(f["weight"] >= 5 for f in findings):
                    res["level"] = "warn"
                elif order[m.group(1)] > order[res["level"]]:
                    res["level"] = m.group(1)
        except Exception as e:
            res["ai"] = f"(yapay zekâ incelemesi yapılamadı: {str(e)[:80]})"
    return res

def recipe_to_plan(rec):
    steps = []
    for st in rec.get("install", []):
        steps.append("@release " + json.dumps({k: v for k, v in st.items() if k != "type"}) if st["type"] == "release" else st["command"])
    return {"name": rec["name"], "summary": "", "steps": steps, "actions": rec.get("actions", []), "runtimes": rec.get("runtimes", []),
            "system_packages": rec.get("system_packages", []), "warnings": ([rec["note"]] if rec.get("note") else []),
            "optional": rec.get("optional_install", []), "guide_tr": rec.get("guide_tr", ""), "category": rec.get("category", ""),
            "icon_repo_path": rec.get("icon_repo_path", "")}

def fetch_source(job, src, opts):
    if opts.get("no_clone"):
        dest = unique_dir(TOOLS_DIR, slugify(src.get("repo") or src["name"])); os.makedirs(dest)
        job.log("ℹ Bu araç paket olarak kurulur; kaynak deposu indirilmez (büyük depo).")
        return dest
    if src["kind"] == "local" and os.path.isdir(src["path"]):
        dest = unique_dir(TOOLS_DIR, slugify(src["name"]))
        job.log(f"📁 Yerel klasör kopyalanıyor: {src['path']}")
        shutil.copytree(src["path"], dest, symlinks=True, ignore=shutil.ignore_patterns(".venv", "node_modules"))
        return dest
    base = src.get("repo") or re.sub(r"(\.tar)?\.(zip|rar|7z|gz|tgz|xz|txz|bz2|tbz2|zst|tar|appimage|deb)$", "", src["name"], flags=re.I)
    dest = unique_dir(TOOLS_DIR, slugify(base))
    if src["kind"] in ("archive", "local"):
        os.makedirs(dest)
        fn = os.path.join(dest, "_indirilen", src["name"])
        if src["kind"] == "local":
            os.makedirs(os.path.dirname(fn)); shutil.copy(src["path"], fn)
        else:
            job.log(f"⬇ İndiriliyor: {src['url']}"); download(src["url"], fn, job.log)
        if is_archive(fn):
            ensure_extractor(job, fn); extract(fn, dest, job.log)
            items = [x for x in os.listdir(dest) if x != "_indirilen"]
            if len(items) == 1 and os.path.isdir(os.path.join(dest, items[0])):  # tek üst klasörü düzleştir
                inner = os.path.join(dest, items[0])
                for x in os.listdir(inner):
                    shutil.move(os.path.join(inner, x), os.path.join(dest, x))
                os.rmdir(inner)
        elif fn.lower().endswith(".appimage"):
            os.chmod(fn, 0o755)
        return dest
    if not which("git"):
        r = job.ask("plan", {"name": "git", "summary": "Depoyu indirmek için git gerekli.", "steps": dep_commands(["git"])[0],
                             "actions": [], "deps_only": True, "warnings": []})
        if r and r.get("ok"):
            run_steps(job, (r.get("data") or {}).get("steps") or dep_commands(["git"])[0], DATA)
    if which("git"):
        cmd = ["git", "clone", "--depth", "1", "--recurse-submodules", "--shallow-submodules"]
        if src.get("branch"):
            cmd += ["-b", src["branch"]]
        job.log(f"⬇ git clone {src['url']}")
        env = base_env(); env["GIT_TERMINAL_PROMPT"] = "0"; env["GIT_LFS_SKIP_SMUDGE"] = "1"
        r = subprocess.run(cmd + [src["url"] + ".git" if "github.com" in src["url"] else src["url"], dest], capture_output=True, text=True, env=env)
        if r.returncode != 0:
            shutil.rmtree(dest, ignore_errors=True)
            raise RuntimeError("Depo indirilemedi (gizli/silinmiş olabilir): " + r.stderr.strip()[-300:])
    else:
        job.log("⬇ git yok → zip olarak indiriliyor (güncelleme için git önerilir)")
        os.makedirs(dest); z = os.path.join(dest, "_src.zip")
        download(f"https://codeload.github.com/{src['owner']}/{src['repo']}/zip/{src.get('branch') or 'HEAD'}", z, job.log)
        tmp = dest + "_tmp"; extract(z, tmp, job.log); os.remove(z)
        inner = os.path.join(tmp, os.listdir(tmp)[0])
        for x in os.listdir(inner):
            shutil.move(os.path.join(inner, x), dest)
        shutil.rmtree(tmp, ignore_errors=True)
    return dest

def ensure_extractor(job, path):
    if extractor_available(path):
        return
    cmds, _ = dep_commands(["7z"] if not path.lower().endswith(".tar.zst") else ["zstd"])
    r = job.ask("plan", {"name": "Arşiv açıcı", "summary": f"{os.path.basename(path)} dosyasını açmak için 7-Zip gerekli.",
                         "steps": cmds, "actions": [], "deps_only": True, "warnings": []})
    if r and r.get("ok"):
        run_steps(job, (r.get("data") or {}).get("steps") or cmds, DATA)

def install_flow(job, source, opts, preset=None):
    opts = opts or {}
    rec = preset or find_catalog(source)
    if rec and rec.get("unavailable"):
        raise RuntimeError(rec.get("note", "Bu depo erişilemiyor."))
    src = parse_source(rec["source"] if rec else source)
    job.title = f"Kurulum: {src.get('owner') + '/' if src.get('owner') else ''}{src.get('repo') or src['name']}"
    job.set("indiriliyor")
    meta = gh_meta(src["owner"], src["repo"]) if src.get("owner") else {"full_name": src["name"], "html_url": src.get("url", "")}
    root = fetch_source(job, src, {**opts, "no_clone": (rec or {}).get("clone") is False})
    slug = os.path.basename(root); job.slug = slug
    # repodaki arşivleri (rar/zip/7z) aç
    for a in find_archives(root):
        try:
            ensure_extractor(job, a)
            extract(a, os.path.splitext(a)[0] + "_acik", job.log)
        except Exception as e:
            job.log(f"⚠ {os.path.basename(a)} açılamadı: {e}")
    icon = fetch_icon(slug, root, src.get("owner", ""), (rec or {}).get("icon_repo_path", ""))
    job.icon = icon
    # plan
    job.set("analiz ediliyor")
    if rec:
        plan = recipe_to_plan(rec); plan["summary"] = guide_summary(rec.get("guide_tr")) or meta.get("description", "")
        job.log("🧠 Daha önce öğrenilmiş tarif kullanılıyor (analiz atlandı)." if rec.get("learned") else "📗 Hazır katalog tarifi kullanılıyor (test edilmiş kurulum).")
    else:
        plan = analyze(root, src.get("repo") or src["name"], meta, job.log, opts.get("provider", ""))
        if not plan["steps"] and not plan["actions"] and cfg().get("release_assets", True) and src.get("owner"):
            try:
                rel = gh_api(f"/repos/{src['owner']}/{src['repo']}/releases/latest"); a = pick_asset(rel.get("assets", []))
                if a:
                    job.log(f"ℹ Kaynakta kurulum yöntemi yok; Linux sürüm dosyası bulundu: {a['name']}")
                    spec = {"repo": f"{src['owner']}/{src['repo']}", "match_regex": "^" + re.escape(a["name"]) + "$"}
                    if a["name"].lower().endswith(".appimage"):
                        spec.update({"save_as": "bin/" + a["name"], "chmod": "bin/" + a["name"]})
                        plan["actions"] = [{"label": "Başlat", "command": "./bin/" + a["name"], "terminal": False}]
                    elif is_archive(a["name"]):
                        spec["extract_to"] = "bin"
                    elif a["name"].endswith(".deb"):
                        spec["save_dir"] = "_release"
                        plan["steps"].append(("" if is_root() else "sudo ") + f"{APT_ENV} apt-get install -y {APT_OPT} ./_release/" + a["name"])
                    else:
                        spec.update({"save_as": "bin/" + src["repo"], "chmod": "bin/" + src["repo"]})
                        plan["actions"] = [{"label": "Başlat", "command": "./bin/" + src["repo"], "terminal": True}]
                    plan["steps"].insert(0, "@release " + json.dumps(spec))
            except Exception:
                pass
    if not plan.get("actions"):
        da, _ = discover_actions(root, src.get("repo") or src["name"])
        if da:
            plan["actions"] = da; job.log("🔎 Çalıştırma yolları bulundu: " + ", ".join(a["label"] for a in da))
    if not plan.get("steps") and is_doc_repo(root):
        plan["kind"] = "doc"
        plan["summary"] = (plan.get("summary") or "") + "\n\n📄 Bu depo bir liste/doküman; çalıştırılacak bir program içermiyor. Kütüphanene eklenecek, Türkçe rehberiyle okuyabileceksin."
        job.log("📄 Bu depo bir doküman/liste deposu — çalıştırılacak program yok, okunmak üzere eklenecek.")
    plan = finalize_plan(root, plan)
    plan["full_name"] = meta.get("full_name"); plan["icon"] = icon; plan["slug"] = slug
    if meta.get("fork") and meta.get("parent"):
        plan["warnings"].append(f"Bu depo {meta['parent']} projesinin bir çatalı (fork).")
    if cfg().get("security_scan", True):
        job.log("🛡️ Güvenlik taraması yapılıyor…")
        sec = security_scan(root, log=job.log)
        plan["security"] = sec
        job.log({"ok": "🟢 Güvenlik: şüpheli bir şey bulunmadı", "warn": "🟡 Güvenlik: dikkat edilmesi gereken bulgular var", "danger": "🔴 Güvenlik: TEHLİKELİ bulgular var"}[sec["level"]] +
                f" ({sec['files']} dosya tarandı, {len(sec['findings'])} bulgu)")
        if sec["level"] == "danger":
            plan["warnings"].insert(0, "🔴 GÜVENLİK TARAMASI TEHLİKELİ BULGULAR BULDU — ayrıntıları okumadan kurma!")
            if job.ctx.get("block_danger"):  # araç yarışmasında tehlikeli aday sormadan elenir
                job.log("⛔ Tehlikeli bulgular nedeniyle bu aday elendi; kurulmadı."); shutil.rmtree(root, ignore_errors=True)
                job.ctx["blocked"] = "güvenlik: tehlikeli"; job.status = "iptal"; return
    r = job.ask("plan", plan)
    if not r or not r.get("ok"):
        job.log("İptal edildi; indirilen dosyalar siliniyor."); shutil.rmtree(root, ignore_errors=True)
        try: os.remove(os.path.join(ICON_DIR, icon))
        except Exception: pass
        job.status = "iptal"; return
    plan.update(r.get("data") or {})
    tool = {"slug": slug, "name": plan.get("name") or slug, "path": root, "source": src.get("url") or source,
            "full_name": meta.get("full_name") or slug, "meta": meta, "summary": plan.get("summary", ""),
            "category": plan.get("category", ""), "steps": plan["steps"], "actions": plan.get("actions", []),
            "runtimes": plan.get("runtimes", []), "system_packages": plan.get("system_packages", []),
            "optional": plan.get("optional", []), "icon": icon, "installed_at": now(), "status": "kuruluyor",
            "guide_tr": plan.get("guide_tr", ""), "update_mode": cfg().get("update_default_mode", "sor"),
            "inject_keys": True, "catalog_id": (rec or {}).get("id", ""), "kind": plan.get("kind", "tool"), "security": plan.get("security")}
    with _lock:
        t = tools(); t[slug] = tool; save_tools(t)
    n0 = len(job.lines)
    ok = execute_plan(job, tool, plan)
    tool = tools().get(slug, tool)
    tool["status"] = "kuruldu" if ok else "hata"
    tool["last_error"] = "" if ok else "\n".join(job.lines[n0:][-120:])
    tool["release_tag"] = job.ctx.get("release_tag", tool.get("release_tag", ""))
    tool["commit"] = git_head(root)
    update_tool(slug, **tool)
    if tool.get("actions") and opts.get("shortcut", cfg().get("auto_shortcut", True)):
        made = make_shortcuts(tool); job.log("🔗 Kısayol: " + ", ".join(made))
    if ok:
        save_user_recipe(tools().get(slug, tool))
    if ok and llm_available() and tool.get("kind") != "doc":
        try:
            if not tool.get("guide_tr"):
                job.log("📘 Yapay zekâ aracı inceleyip ayrıntılı Türkçe belge yazıyor (özellikler, nasıl çalışır, komutlar, örnekler)…"); make_guide(slug, job.log)
            else:
                learn_capabilities(slug, tool.get("guide_tr", ""), help_output(tools()[slug]), job.log)
        except Exception as e:
            job.log(f"⚠ Belge/yetenek çıkarılamadı: {str(e)[:150]}")
    elif ok and llm_available() and not tool.get("guide_tr"):
        try:
            job.log("📘 Türkçe rehber hazırlanıyor…"); make_guide(slug, job.log)
        except Exception as e:
            job.log(f"⚠ Rehber oluşturulamadı: {str(e)[:150]}")
    job.status = "tamamlandı" if ok else "hata"
    job.log("✅ Kurulum tamamlandı!" if ok else "❌ Kurulum hatalarla bitti. '🛠 Ajanla onar' ile derin onarım yapılabilir.")
    notify(APP, f"{tool['name']}: " + ("kuruldu ✅" if ok else "kurulum hatası ❌"))
    needs_fix = (not ok) or (tool.get("kind") != "doc" and not tool.get("actions"))
    if needs_fix and not job.ctx.get("no_auto_repair") and job.kind == "install" and cfg().get("auto_agent_repair", True):
        job.log("🛠 Otomatik onarım başlatılıyor (önce hızlı onarım, gerekirse Görev Ajanı)…")
        start_job(f"🛠 Onarım: {tool['name']}", "repair", repair_flow, slug)

def finalize_plan(root, plan):
    keys, rts = required_keys(root, plan)
    plan["runtimes"] = sorted(set(plan.get("runtimes", [])) | rts)
    plan["runtimes_missing"] = [r for r in plan["runtimes"] if not runtime_ok(r)]
    dcmds, missing = dep_commands(keys, plan.get("system_packages", []))
    plan["deps"] = dcmds; plan["deps_missing"] = missing
    plan["warnings"] = list(dict.fromkeys(plan.get("warnings", []) + danger_warnings(plan["steps"] + dcmds)))
    return plan

def git_head(root):
    if os.path.isdir(os.path.join(root, ".git")):
        r = subprocess.run(["git", "-C", root, "rev-parse", "HEAD"], capture_output=True, text=True)
        return r.stdout.strip()
    return ""

def execute_plan(job, tool, plan):
    root = tool["path"]
    job.set("kuruluyor")
    for rt in plan.get("runtimes", []):
        try:
            ensure_runtime(rt, job.log)
        except Exception as e:
            job.log(f"✖ Çalışma ortamı kurulamadı ({rt}): {e}"); return False
    if plan.get("deps"):
        job.log("🧩 Eksik sistem bağımlılıkları kuruluyor: " + ", ".join(plan.get("deps_missing", [])))
        ok, _, _ = run_steps(job, plan["deps"], root)
        if not ok:
            job.log("⚠ Bağımlılık kurulumu başarısız, yine de devam ediliyor…")
    steps = list(plan.get("steps", [])); attempts = 0
    rcfg = repair_cfg()
    def ask_fix(payload):
        if rcfg["auto_approve"]:
            job.log("🤖 Otomatik hata çözücü: düzeltme onay beklemeden uygulanıyor → " + "; ".join(payload.get("steps", [])[:4]))
            return {"ok": True, "data": payload}
        return job.ask("fix", payload)
    while True:
        ok, remaining, tail = run_steps(job, steps, root)
        if ok:
            pl = job.ctx.pop("pending_learn", None)
            if pl and pl[2]:
                e = learn_error(pl[0], pl[1], pl[2])
                if e:
                    job.log(f"🧠 Bu hatanın çözümü bilgi bankasına eklendi: {e['title']}")
            return True
        attempts += 1
        if attempts > 3:
            return False
        if job.ctx.get("pending_learn"):
            job.ctx.pop("pending_learn")  # önceki AI çözümü işe yaramadı
        out = "\n".join(tail)
        fixes = quick_fixes(out, tool)
        fix_cmds = [f["command"] for f in fixes if f.get("command")]
        for f in fixes:
            if f.get("runtime"):
                try: ensure_runtime(f["runtime"], job.log)
                except Exception as e: job.log(f"✖ {e}")
        if fixes and not fix_cmds and not any(f.get("runtime") for f in fixes):
            job.log("📚 Bilinen hata: " + "; ".join(f["why"] for f in fixes))
            fixes = []  # sadece öneri var → yapay zekâya geç
        if fixes:
            job.log("🔧 Eksik tespit edildi: " + "; ".join(f["why"] for f in fixes))
            r = ask_fix({"why": [f["why"] for f in fixes], "steps": fix_cmds + remaining, "failed": remaining[0], "output": out[-3000:]})
            if r and r.get("ok"):
                steps = (r.get("data") or {}).get("steps") or (fix_cmds + remaining); continue
            return False
        if llm_available():
            job.log("🤖 Hata yapay zekâya soruluyor…")
            try:
                txt, _ = llm_ask([{"role": "user", "content":
                    f"Linux: {os_info().get('PRETTY_NAME')} ({detect_pm()}). Proje: {tool['full_name']}. Klasör: proje kökü.\n"
                    f"Başarısız komut: {remaining[0]}\nKalan adımlar: {json.dumps(remaining[1:], ensure_ascii=False)}\n"
                    f"Çıktının sonu:\n{out[-3500:]}\n\nREADME özeti:\n{read_readme(root, 5000)}\n\n"
                    "Sorunu çözüp kurulumu tamamlayacak yeni adım listesini ver. SADECE JSON: {\"explanation_tr\":\"...\",\"steps\":[...]}"}],
                    "Sen Linux kurulum hatası çözme uzmanısın. Global kurulum yerine proje içi .venv/yerel npm kullan.",
                    rcfg["provider"], rcfg["model"], log=job.log, feature="repair")
                j = extract_json(txt)
                r = ask_fix({"why": [j.get("explanation_tr", "AI önerisi")], "steps": j.get("steps", []), "failed": remaining[0], "output": out[-3000:], "ai": True})
                if r and r.get("ok"):
                    steps = (r.get("data") or {}).get("steps") or j.get("steps", [])
                    job.ctx["pending_learn"] = (error_signature(out), j.get("explanation_tr", "Kurulum hatası"), [x for x in steps if x not in remaining])
                    continue
            except Exception as e:
                job.log(f"⚠ AI düzeltmesi alınamadı: {str(e)[:200]}")
        return False

def help_output(t, timeout=20):
    """Aracın kendi yardım çıktısını toplar (belge ve yetenek çıkarımı için)."""
    if not t.get("actions"):
        return ""
    base = t["actions"][0]["command"]; outs = []
    for extra in ("--help", "-h", "help"):
        try:
            env = base_env(); env["CT_NOPAUSE"] = "1"
            r = subprocess.run(["bash", "-lc", f"{base} {extra}"], cwd=t["path"], env=env, capture_output=True, text=True, timeout=timeout, stdin=subprocess.DEVNULL)
            o = clean_term((r.stdout or "") + (r.stderr or ""))
            if len(o) > 80 and re.search(r"usage|kullanım|options|commands|--", o, re.I):
                outs.append(o[:6000]); break
        except Exception:
            continue
    return "\n".join(outs)

def make_guide(slug, log=None):
    t = tools()[slug]
    hlp = help_output(t)
    if log and hlp:
        log("📖 Aracın kendi yardım çıktısı okundu (gerçek komutlar ve seçenekler için)")
    txt, _ = llm_ask([{"role": "user", "content":
        f"Araç: {t['full_name']}\nAçıklama: {t.get('meta', {}).get('description', '')}\n"
        f"Cypher Tool içindeki eylemler (aracın klasöründe çalışır): {json.dumps(t.get('actions', []), ensure_ascii=False)}\n"
        f"Kurulum adımları: {json.dumps(t.get('steps', []), ensure_ascii=False)}\n\n"
        f"ARACIN KENDİ YARDIM ÇIKTISI (--help):\n{hlp or '(alınamadı)'}\n\n"
        f"README (İngilizce veya başka dilde olabilir):\n{read_readme(t['path'], 15000)}"}],
        "README'yi ve yardım çıktısını okuyup TÜRKÇE, sade, ayrıntılı bir kullanım belgesi yaz (Markdown). Başlıklar sırasıyla:\n"
        "'## Ne işe yarar?' (2-4 cümle), '## Özellikleri' (madde madde, tüm önemli özellikler), '## Nasıl çalışır?' (arka planda ne yaptığını basitçe anlat), "
        "'## İlk kullanım' (Cypher Tool'da hangi düğmeye basılacağı, ilk ayar/anahtar gerekiyorsa nasıl), "
        "'## Komutlar ve seçenekler' (yardım çıktısındaki gerçek komut/seçenekleri tablo ya da liste halinde Türkçe açıkla), "
        "'## Örnekler' (```bash blokları; komutları Cypher Tool eylemlerindeki yollarla yaz), "
        "'## Görev Ajanı'na örnek istekler' (kullanıcının ajana yazabileceği 4-6 doğal Türkçe istek), '## İpuçları ve uyarılar'. "
        "Teknik terimleri gerektiğinde parantez içinde İngilizce bırak. Uydurma özellik/seçenek yazma; emin değilsen belirtme.", log=log, feature="guide")
    update_tool(slug, guide_tr=txt.strip())
    try:
        learn_capabilities(slug, txt, hlp, log)
    except Exception as e:
        if log: log(f"(yetenek çıkarımı atlandı: {str(e)[:80]})")
    return txt

def learn_capabilities(slug, guide="", hlp="", log=None):
    """Görev Ajanı'nın aracı sonradan kendisi kullanabilmesi için kısa yetenek kartı çıkarır ve hafızaya yazar."""
    t = tools()[slug]
    txt, _ = llm_ask([{"role": "user", "content": f"Araç: {t['name']} (klasör: {t['path']})\nEylemler: {json.dumps(t.get('actions', []), ensure_ascii=False)}\n"
                       f"Yardım çıktısı:\n{(hlp or '')[:3000]}\n\nBelge:\n{(guide or t.get('guide_tr', ''))[:5000]}\n\n"
                       "Bir yapay zekâ ajanının bu aracı KENDİ BAŞINA, etkileşimsiz kullanabilmesi için kısa yetenek kartı çıkar. SADECE JSON:\n"
                       "{\"ozet\": \"1 cümle Türkçe\", \"yapabilecekleri\": [\"kısa madde\", ...], \"etkilesimsiz_komutlar\": [{\"is\": \"ne yapar\", \"komut\": \"aracın klasörüne göre tam komut\"}], \"gerekenler\": [\"API anahtarı vb.\"]}"}],
                     "Kısa ve doğru ol; yardım çıktısında olmayan seçenek uydurma.", log=log, feature="guide")
    cap = extract_json(txt)
    update_tool(slug, capabilities=cap)
    mem_add(f"Araç '{t['name']}' (slug: {slug}): {cap.get('ozet', '')} Örnek: " +
            "; ".join(f"{c.get('is')}: {c.get('komut')}" for c in (cap.get("etkilesimsiz_komutlar") or [])[:3]), "araç")
    if log:
        log(f"🧠 Görev Ajanı '{t['name']}' aracını tanıdı ({len(cap.get('yapabilecekleri') or [])} yetenek) — artık kendisi kullanabilir")
    return cap

# ───────────────────────────── doktor / güncelleme ─────────────────────────────
def doctor_flow(job, slug):
    t = tools()[slug]; root = t["path"]; job.slug = slug; job.icon = t.get("icon", ""); job.title = f"Doktor: {t['name']}"
    findings, fixes = [], []
    if not os.path.isdir(root):
        raise RuntimeError("Araç klasörü yok — yeniden kurman gerekiyor.")
    plan = {"steps": t.get("steps", []), "actions": t.get("actions", []), "runtimes": t.get("runtimes", []), "system_packages": t.get("system_packages", [])}
    keys, rts = required_keys(root, plan)
    for r in sorted(set(t.get("runtimes", [])) | rts):
        if not runtime_ok(r):
            findings.append(f"Çalışma ortamı eksik: {r}"); fixes.append(f"@runtime {r}")
    dc, miss = dep_commands(keys, t.get("system_packages", []))
    if miss:
        findings.append("Eksik sistem programları: " + ", ".join(miss)); fixes += dc
    vpy = os.path.join(root, ".venv", "bin", "python")
    uses_venv = any(".venv" in s for s in t.get("steps", []) + [a["command"] for a in t.get("actions", [])])
    if uses_venv and not os.path.exists(vpy):
        findings.append("Python sanal ortamı (.venv) yok / bozuk → kurulum adımları yeniden çalıştırılmalı"); fixes += t.get("steps", [])
    elif os.path.exists(vpy):
        mods = scan_py_imports(root)
        if mods:
            code = "import importlib.util,json,sys;print(json.dumps([m for m in sys.argv[1:] if importlib.util.find_spec(m) is None]))"
            r = subprocess.run([vpy, "-c", code, *mods], capture_output=True, text=True, cwd=root)
            try:
                missing = json.loads(r.stdout.strip().splitlines()[-1])
            except Exception:
                missing = []
            missing = [m for m in missing if IMPORT_MAP.get(m, m)]
            if missing:
                findings.append("Kodda kullanılıp kurulu olmayan Python kütüphaneleri: " + ", ".join(missing))
                fixes.append(".venv/bin/python -m pip install " + " ".join(q(p) for p in pip_names(missing)))
        r = subprocess.run([vpy, "-m", "pip", "check"], capture_output=True, text=True, cwd=root)
        if r.returncode != 0 and "No module named pip" not in r.stderr:
            findings.append("pip uyumsuzlukları:\n" + r.stdout.strip()[:800])
    if os.path.exists(os.path.join(root, "package.json")) and not os.path.isdir(os.path.join(root, "node_modules")) \
            and any("npm" in s for s in t.get("steps", [])):
        findings.append("node_modules eksik"); fixes.append("npm install")
    for a in t.get("actions", []):
        first = a["command"].split()[0]
        if first.startswith(("./", ".venv/", "bin/")) and not os.path.exists(os.path.join(root, first)):
            findings.append(f"Çalıştırılabilir dosya yok: {first}")
            if not set(t.get("steps", [])) <= set(fixes):
                fixes += t.get("steps", [])
    errtxt = (t.get("last_error") or "") + "\n" + (t.get("last_run_error") or "")
    for d in diagnose(errtxt, t):
        findings.append(f"Bilinen hata: {d['title']} — {d['cause']}" + (f" Öneri: {'; '.join(d['advice'])}" if d["advice"] else ""))
        fixes += [c for c in d["commands"] if not c.startswith("@runtime ")]
        fixes += ["@runtime " + c.split()[1] for c in d["commands"] if c.startswith("@runtime ")]
    fixes = list(dict.fromkeys(fixes))
    if not findings:
        if t.get("status") == "hata" or (t.get("kind") != "doc" and not t.get("actions")):
            job.log("ℹ Basit kontrollerde eksik bulunmadı ama araç " + ("hata durumunda." if t.get("status") == "hata" else "çalıştırma komutuna sahip değil."))
            if llm_available():
                r = job.ask("confirm", {"message": "Basit Doktor bunu çözemiyor. Görev Ajanı ile DERİN ONARIM başlatılsın mı?\n(README'yi ve hata kaydını okuyup eksikleri kurar, derler, çalıştırma komutunu bulur ve dener.)"})
                if r and r.get("ok"):
                    j = start_agent_repair(slug); job.log(f"🛠 Derin onarım başlatıldı (görev {j.id}) — Görev Ajanı sekmesinden izleyebilirsin.")
            else:
                job.log("Derin onarım için bir yapay zekâ API'si ekle (Ücretsiz AI sekmesi).")
            return
        job.log("✅ Sorun bulunamadı — araç sağlıklı görünüyor."); return
    job.log("🩺 Bulgular:\n  • " + "\n  • ".join(findings))
    r = job.ask("fix", {"why": findings, "steps": fixes, "failed": "", "output": ""})
    if not r or not r.get("ok"):
        job.status = "iptal"; return
    steps = (r.get("data") or {}).get("steps") or fixes
    for s in [s for s in steps if s.startswith("@runtime ")]:
        ensure_runtime(s.split()[1], job.log)
    ok, _, _ = run_steps(job, [s for s in steps if not s.startswith("@runtime ")], root)
    update_tool(slug, status="kuruldu" if ok else "hata")
    job.status = "tamamlandı" if ok else "hata"

def check_update(t):
    """(güncelleme_var, açıklama)"""
    root = t["path"]
    if os.path.isdir(os.path.join(root, ".git")):
        try:
            env = base_env(); env["GIT_TERMINAL_PROMPT"] = "0"
            r = subprocess.run(["git", "-C", root, "ls-remote", "origin", "HEAD"], capture_output=True, text=True, timeout=40, env=env)
            remote = r.stdout.split()[0] if r.stdout.split() else ""
            local = upstream_head(root)
            if remote and local and remote != local:
                return True, f"Yeni commit: {local[:7]} → {remote[:7]}"
        except Exception:
            pass
    repo = t.get("release_repo") or next((json.loads(s[9:]).get("repo") for s in t.get("steps", []) if s.startswith("@release ")), "")
    if repo and t.get("release_tag"):
        tag = latest_release_tag(repo)
        if tag and tag != t["release_tag"]:
            return True, f"Yeni sürüm: {t['release_tag']} → {tag}"
    return False, ""

def check_all_updates(auto_apply=True, cli=False):
    res = []
    for slug, t in tools().items():
        if t.get("update_mode") == "kapali" or t.get("active", True) is False:
            continue
        has, why = check_update(t)
        update_tool(slug, update_available=has, update_info=why, last_check=now())
        if has:
            res.append((slug, why))
            if t.get("update_mode") == "otomatik" and auto_apply:
                start_job(f"Otomatik güncelleme: {t['name']}", "update", update_flow, slug, True, cli=cli, auto=True)
    c = cfg(); c["last_update_check"] = time.time(); save_cfg(c)
    if res:
        notify(APP, "Güncelleme var: " + ", ".join(tools()[s]["name"] for s, _ in res))
    return res

def update_flow(job, slug, auto=False):
    t = tools()[slug]; root = t["path"]; job.slug = slug; job.icon = t.get("icon", ""); job.title = f"Güncelleme: {t['name']}"
    if os.path.isdir(os.path.join(root, ".git")) and dev_branch(root) == DEV_BRANCH:
        job.log("✨ Bu araçta senin geliştirmelerin var → yeni sürüm alınıp geliştirmelerin üstüne yeniden uygulanacak.")
        if not dev_rebase_update(root, job.log):
            job.status = "hata"; return
    elif os.path.isdir(os.path.join(root, ".git")):
        env = base_env(); env["GIT_TERMINAL_PROMPT"] = "0"
        job.log("⬇ git pull")
        shallow = os.path.exists(os.path.join(root, ".git", "shallow"))
        r = subprocess.run(["git", "-C", root, "pull", "--ff-only"] + (["--depth", "1"] if shallow else []), capture_output=True, text=True, env=env)
        job.log(r.stdout + r.stderr)
        if r.returncode != 0:
            job.log("⚠ Hızlı ileri alma başarısız (yerel değişiklik olabilir). Uzak sürüme sıfırlamayı deneyebilirsin.")
            rr = job.ask("confirm", {"message": "Yerel değişiklikler atılıp uzak sürüme eşitlensin mi? (git fetch + reset --hard)"}) if not auto else None
            if rr and rr.get("ok"):
                subprocess.run(["git", "-C", root, "fetch"] + (["--depth", "1"] if shallow else []) + ["origin"], env=env)
                subprocess.run(["git", "-C", root, "reset", "--hard", "FETCH_HEAD"], env=env)
            else:
                job.status = "hata"; return
    plan = finalize_plan(root, {"name": t["name"], "steps": t.get("steps", []), "actions": t.get("actions", []),
                                "runtimes": t.get("runtimes", []), "system_packages": t.get("system_packages", []), "warnings": []})
    plan["summary"] = "Güncelleme sonrası kurulum adımları yeniden çalıştırılacak."
    r = job.ask("plan", plan)
    if not r or not r.get("ok"):
        job.status = "iptal"; return
    plan.update(r.get("data") or {})
    ok = execute_plan(job, t, plan)
    update_tool(slug, status="kuruldu" if ok else "hata", update_available=not ok, update_info="" if ok else t.get("update_info", ""),
                commit=git_head(root), release_tag=job.ctx.get("release_tag") or t.get("release_tag", ""), updated_at=now(),
                steps=plan.get("steps", t.get("steps")), actions=plan.get("actions", t.get("actions")))
    if ok:
        make_shortcuts(tools()[slug], desktop=bool(desktop_dir()) and os.path.exists(os.path.join(desktop_dir() or "/x", f"{slug}.desktop")))
    job.status = "tamamlandı" if ok else "hata"
    notify(APP, f"{t['name']}: güncellendi ✅" if ok else f"{t['name']}: güncelleme hatası ❌")

def update_scheduler():
    while True:
        try:
            c = cfg()
            if c.get("update_check", True) and time.time() - c.get("last_update_check", 0) > 86400:
                check_all_updates()
            if pool()["items"] and time.time() - pool().get("last_test", 0) > 86400:
                start_job("🧪 API havuzu günlük test", "pool", pool_test_flow, [x["id"] for x in pool()["items"] if x["status"] != "needs_key" or x.get("key")], False)
        except Exception:
            pass
        time.sleep(1800)

def optional_flow(job, slug, idx):
    t = tools()[slug]; o = t["optional"][idx]; job.slug = slug; job.icon = t.get("icon", ""); job.title = f"{t['name']}: {o['label']}"
    plan = finalize_plan(t["path"], {"name": o["label"], "steps": [o["command"]], "actions": [], "warnings": [], "summary": o["label"]})
    r = job.ask("plan", plan)
    if not r or not r.get("ok"):
        job.status = "iptal"; return
    plan.update(r.get("data") or {})
    ok, _, _ = run_steps(job, plan.get("deps", []) + plan["steps"], t["path"])
    job.status = "tamamlandı" if ok else "hata"

def commands_flow(job, slug, cmds, title):
    t = tools()[slug] if slug else None; cwd = t["path"] if t else DATA; job.slug = slug or ""; job.title = title
    plan = finalize_plan(cwd, {"name": title, "steps": cmds, "actions": [], "warnings": [], "summary": title})
    r = job.ask("plan", plan)
    if not r or not r.get("ok"):
        job.status = "iptal"; return
    plan.update(r.get("data") or {})
    for rt in plan.get("runtimes", []):
        ensure_runtime(rt, job.log)
    ok, _, _ = run_steps(job, plan.get("deps", []) + plan["steps"], cwd)
    job.status = "tamamlandı" if ok else "hata"

# ───────────────────────────── süreçler (araçları uygulama içinde çalıştırma) ─────────────────────────────
PROCS = {}

class Proc:
    def __init__(self, title, cmd, cwd, slug=""):
        self.id = uuid.uuid4().hex[:10]; self.title = title; self.slug = slug; self.chunks = []; self.rc = None
        self.started = time.time(); self.fixes = []; self.hist = ""; self.hist_base = 0; self.console = False
        import codecs; self.dec = codecs.getincrementaldecoder("utf-8")("replace")
        m, s = pty.openpty()
        try:
            import termios, struct
            fcntl.ioctl(s, termios.TIOCSWINSZ, struct.pack("HHHH", 40, 140, 0, 0))
        except Exception:
            pass
        env = base_env(); env.update({"TERM": "xterm-256color", "CT_NOPAUSE": "1", "COLUMNS": "140", "LINES": "40"})
        self.p = subprocess.Popen(["bash", "-lc", cmd], cwd=cwd, stdin=s, stdout=s, stderr=s, env=env, start_new_session=True, close_fds=True)
        os.close(s); self.m = m
        PROCS[self.id] = self
        threading.Thread(target=self._read, daemon=True).start()

    def _read(self):
        buf = ""
        while True:
            try:
                d = os.read(self.m, 8192)
            except OSError:
                break
            if not d:
                break
            t = self.dec.decode(d); buf += t; buf = buf[-40000:]
            self.chunks.append(t); self._hist_add(t)
            try:  # uygulama şifre soruyor mu? (sudo / su / Password:) → sağ altta bildirim kartı
                tail = clean_term(buf[-400:]).rstrip().split("\n")[-1][-200:]
                self.pw_prompt = tail if PW_PROMPT_RX.search(tail) else ""
            except Exception:
                self.pw_prompt = ""
            if len(self.chunks) > 6000:
                del self.chunks[:1000]
        self.rc = self.p.wait()
        if self.rc not in (0, None):
            try: self.fixes = quick_fixes(clean_term(buf[-20000:]), tools().get(self.slug))
            except Exception: self.fixes = []
        try:
            lp = os.path.join(LOG_DIR, time.strftime("%Y%m%d-%H%M%S") + f"-calistir-{self.slug or 'komut'}-{self.id}.log")
            open(lp, "w", encoding="utf-8").write(f"# {self.title}\n# çıkış kodu: {self.rc}\n" + clean_term(buf))
            if self.slug in tools():
                t = tools()[self.slug]; logs = t.get("logs", [])
                logs.append({"file": os.path.basename(lp), "kind": "çalıştırma", "title": self.title, "status": f"kod {self.rc}", "at": now()})
                upd = {"logs": logs[-25:], "last_run": {"rc": self.rc, "at": now()}}
                if self.rc not in (0, None, -15, 130, 143):
                    upd["last_run_error"] = clean_term(buf[-6000:])
                update_tool(self.slug, **upd)
                txt = clean_term(buf[-6000:])
                if self.rc not in (0, None, -15, 130, 143) and repair_cfg()["on_run"] and tool_active(self.slug) and (self.fixes or re.search(r"Traceback|Error|error:|not found|denied", txt)):
                    rc_ = repair_cfg()
                    cmds = [f["command"] for f in self.fixes if f.get("command")]
                    if cmds and rc_["auto_approve"]:
                        start_job(f"🔧 Otomatik düzeltme: {t['name']}", "commands", commands_flow, self.slug, cmds, "Bilinen hatanın çözümü", auto=True)
                        self.chunks.append("\r\n\x1b[35m[🔧 Bilinen hata — çözüm otomatik uygulanıyor]\x1b[0m\r\n")
                    elif llm_available() and not self.fixes and not repairing(self.slug) and time.time() - REPAIR_FAIL.get(self.slug, 0) > 1200:
                        start_agent_repair(self.slug, "Araç ÇALIŞIRKEN hata verdi; read_tool'daki SON ÇALIŞTIRMA HATASI'na odaklan.")
                        self.chunks.append("\r\n\x1b[35m[🛠 Otomatik hata çözücü başlatıldı — Görev Ajanı sekmesinden izleyebilirsin]\x1b[0m\r\n")
        except Exception:
            pass
        self.chunks.append(f"\r\n\x1b[35m[süreç bitti — çıkış kodu {self.rc}]\x1b[0m\r\n")
        if self.rc not in (0, None):
            t = tools().get(self.slug)
            self.fixes = quick_fixes(clean_term(buf[-20000:]), t)
        try: os.close(self.m)
        except Exception: pass

    def _hist_add(self, t):
        self.hist += t
        if len(self.hist) > 300000:
            cut = len(self.hist) - 200000; self.hist = self.hist[cut:]; self.hist_base += cut

    def resize(self, cols, rows):
        try:
            import termios, struct
            fcntl.ioctl(self.m, termios.TIOCSWINSZ, struct.pack("HHHH", int(rows), int(cols), 0, 0))
        except Exception:
            pass

    def write(self, text):
        try:
            os.write(self.m, text.encode())
        except OSError:
            pass

    def stop(self):
        try:
            os.killpg(self.p.pid, signal.SIGTERM)
            threading.Timer(3, lambda: self.p.poll() is None and os.killpg(self.p.pid, signal.SIGKILL)).start()
        except Exception:
            pass

    def summary(self):
        return {"id": self.id, "title": self.title, "slug": self.slug, "running": self.rc is None, "rc": self.rc,
                "started": self.started, "fixes": self.fixes, "console": self.console, "pw_prompt": self.pw_ask() if self.rc is None else ""}

    def pw_ask(self):
        """Şifre istemi: hangi uygulama, ne için (ön plandaki program) — kart bunu gösterir."""
        pr = getattr(self, "pw_prompt", "")
        if not pr:
            return ""
        app = self.title
        try:
            fg = os.tcgetpgrp(self.m)
            cl = open(f"/proc/{fg}/cmdline", "rb").read().replace(b"\0", b" ").decode(errors="replace").strip()
            if cl: app = cl[:160]
        except Exception:
            pass
        return {"prompt": pr, "app": app}

def run_tool(slug, idx=0, args="", mode="app"):
    t = tools()[slug]
    if not t.get("actions"):
        raise RuntimeError("Bu aracın çalıştırma komutu yok. ⚙️ menüsünden bir eylem ekle.")
    launcher = make_launcher(t, idx)
    a = t["actions"][idx]
    if mode == "terminal":
        cmd_file = launcher
        if args:
            fd, cmd_file = tempfile.mkstemp(prefix=slug + "-", suffix=".sh", dir=LAUNCH_DIR)
            with os.fdopen(fd, "w") as f:
                f.write(f"#!/usr/bin/env bash\nexec {q(launcher)} {args}\n")
            os.chmod(cmd_file, 0o700)
        if not open_in_terminal(cmd_file):
            raise RuntimeError("Terminal uygulaması bulunamadı; 'Uygulama içinde' çalıştır.")
        return None
    if not a.get("terminal", True) and mode == "detached":
        subprocess.Popen([launcher], cwd=t["path"], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return None
    return Proc(f"{t['name']} — {a['label']}", f"{q(launcher)} {args}", t["path"], slug)

# ───────────────────────────── ücretsiz AI bulucu ─────────────────────────────
KEYLESS_CANDIDATES = [
    {"name": "Ollama (bu bilgisayar)", "type": "openai", "base_url": "http://127.0.0.1:11434/v1", "local": True, "env": ""},
    {"name": "LM Studio (bu bilgisayar)", "type": "openai", "base_url": "http://127.0.0.1:1234/v1", "local": True, "env": ""},
    {"name": "llama.cpp sunucusu (bu bilgisayar)", "type": "openai", "base_url": "http://127.0.0.1:8080/v1", "local": True, "env": ""},
    {"name": "Jan (bu bilgisayar)", "type": "openai", "base_url": "http://127.0.0.1:1337/v1", "local": True, "env": ""},
    {"name": "Pollinations (bulut, anahtarsız)", "type": "openai", "base_url": "https://text.pollinations.ai/openai", "model": "openai", "env": ""},
]

OLLAMA_MODELS = [
    {"id": "qwen2.5-coder:7b", "ad": "Qwen2.5 Coder 7B", "tur": "Kodlama", "boyut_gb": 4.7, "ram": 8, "not": "Hafif ve iyi bir kodlama modeli; çoğu bilgisayarda çalışır."},
    {"id": "qwen3-coder:30b", "ad": "Qwen3 Coder 30B (MoE)", "tur": "Kodlama / ajan", "boyut_gb": 19, "ram": 32, "not": "Yerelde en güçlü kodlama seçeneklerinden; 24 GB+ VRAM veya 32 GB+ RAM ister."},
    {"id": "gpt-oss:20b", "ad": "gpt-oss 20B", "tur": "Genel + kod + akıl yürütme", "boyut_gb": 14, "ram": 16, "not": "16 GB RAM ile çalışabilen güçlü genel model."},
    {"id": "qwen3.5:9b", "ad": "Qwen3.5 9B", "tur": "Genel sohbet", "boyut_gb": 6.6, "ram": 12, "not": "Bütçe dostu genel model (ARIA'nın varsayılanı)."},
    {"id": "gemma3:4b", "ad": "Gemma 3 4B", "tur": "Hafif sohbet", "boyut_gb": 3.3, "ram": 6, "not": "Zayıf donanım için; hızlı."},
    {"id": "deepseek-r1:8b", "ad": "DeepSeek-R1 8B", "tur": "Akıl yürütme", "boyut_gb": 5.2, "ram": 10, "not": "Adım adım düşünen akıl yürütme modeli."},
    {"id": "llama3.2:3b", "ad": "Llama 3.2 3B", "tur": "Çok hafif sohbet", "boyut_gb": 2.0, "ram": 4, "not": "En düşük donanım için."},
]

def test_endpoint(c, model=None):
    base = c["base_url"].rstrip("/"); t0 = time.time()
    models = []
    try:
        r = http_json(base + "/models", timeout=6)
        models = [m.get("id") for m in r.get("data", []) if m.get("id")]
    except Exception:
        if c.get("local"):
            return {"ok": False, "error": "çalışmıyor"}
    mdl = model or c.get("model") or (models[0] if models else "")
    if not mdl:
        return {"ok": False, "error": "model yok", "models": models}
    try:
        out = llm_call({"type": "openai", "base_url": base, "model": mdl}, [{"role": "user", "content": "Sadece 'tamam' yaz."}], timeout=40)
        return {"ok": bool(out.strip()), "model": mdl, "models": models, "ms": int((time.time() - t0) * 1000), "sample": out.strip()[:60]}
    except Exception as e:
        return {"ok": False, "error": str(e)[:200], "models": models}

# ───────────────────────────── API havuzu (listelerden çıkar → test et → sınıflandır) ─────────────────────────────
POOL_FILE = os.path.join(CONF_DIR, "api_havuzu.json")
URL_RX = re.compile(r"""https?://[a-zA-Z0-9.-]+\.[a-z]{2,}(?::\d+)?(?:/[\w.~%-]+)*?/(?:v1(?:beta)?|openai(?:/v1)?|api/v1|inference|compatible-mode/v1)(?=[/'"`\s)\]]|$)""")
MODEL_RX = re.compile(r"""["']?model["']?\s*[:=]\s*["']([\w./:@-]{3,80})["']""")
KEYENV_RX = re.compile(r"\b([A-Z][A-Z0-9_]{2,40}_(?:API_KEY|KEY|TOKEN))\b")
NOKEY_RX = re.compile(r"""api_key\s*=\s*["'](?:none|not-needed|no-key|sk-no-key-required|dummy|anything)["']|no (?:api )?key (?:required|needed)|keyless|without (?:an )?api key""", re.I)

MODEL_TAGS = [
    (r"coder|codestral|code|devstral|starcoder|qwen.*coder|deepseek-coder|codegemma", "💻 Kodlama", "kod yazma, hata ayıklama ve kod açıklama"),
    (r"(^|[-/_.])r1([-/_.]|$)|reason|think|qwq|o[134]-|o[134]$|magistral|-r$|gpt-oss", "🧠 Akıl yürütme", "adım adım düşünme, matematik, mantık ve zor problemler"),
    (r"vision|[-_]vl|vl[-_]|-v$|llava|pixtral|gemma-?3|gemini|gpt-4o|4\.1|omni|qwen.*vl|image(?!-gen)", "🖼️ Görsel anlama", "resim/ekran görüntüsü okuyup yorumlama"),
    (r"flux|sdxl|stable-diffusion|dall-?e|imagen|image-gen|playground", "🎨 Görsel üretme", "metinden resim üretme"),
    (r"whisper|transcri|speech-to|asr", "🎙️ Sesten metne", "ses kaydını yazıya dökme"),
    (r"tts|speech|voice|kokoro|orpheus", "🔊 Metinden sese", "yazıyı sesli okuma"),
    (r"embed|bge|e5-|gte-|nomic", "🔗 Embedding", "metinleri vektöre çevirme (arama/RAG)"),
    (r"guard|moderation|safety", "🛡️ Denetim", "zararlı içerik tespiti"),
    (r"translat|mt-|hunyuan-mt|nllb|seamless", "🌐 Çeviri", "diller arası çeviri"),
    (r"rerank", "📊 Sıralama", "arama sonuçlarını alaka sırasına koyma"),
    (r"mini|flash|lite|nano|small|tiny|haiku|instant|(?<![\d.])(?:0\.5|1|1\.5|2|3|4|7|8|9)b\b|lightning|turbo|fast", "⚡ Hızlı/hafif", "hızlı ve ucuz yanıtlar"),
    (r"(?<![\d.])(?:3[2-9]|[4-9]\d|\d{3,4})b\b|large|max|ultra|pro\b|opus|sonnet|plus|-big", "🏆 Güçlü/büyük", "en kaliteli yanıtlar, zor işler"),
    (r"instruct|chat|turbo|gpt|llama|mistral|qwen|glm|kimi|deepseek|gemma|claude|command|hermes|nemotron|grok|minimax|ernie|yi-|gemini|aion|sea-lion|phi", "💬 Sohbet", "genel sohbet, soru-cevap, yazı yazma"),
]

def model_info(mid, meta=None):
    meta = meta or {}
    low = (mid or "").lower()
    tags, uses = [], []
    for rx, tag, use in MODEL_TAGS:
        if re.search(rx, low) and tag not in tags:
            tags.append(tag); uses.append(use)
    mod = str(meta.get("modality") or "").lower()
    if "reason" in mod and "🧠 Akıl yürütme" not in tags:
        tags.insert(0, "🧠 Akıl yürütme"); uses.insert(0, "adım adım düşünme ve zor problemler")
    if any(x in mod for x in ("image", "vision")) and "🖼️ Görsel anlama" not in tags:
        tags.append("🖼️ Görsel anlama"); uses.append("resim okuyup yorumlama")
    if ":free" in low or "free" in low:
        tags.append("🆓 Ücretsiz")
    ctx = meta.get("context") or meta.get("context_length") or ""
    size = re.search(r"(\d{1,4}(?:\.\d)?)b\b", low)
    desc = ("Kullanım: " + ", ".join(dict.fromkeys(uses[:3])) + ".") if uses else "Genel amaçlı model."
    extra = []
    if size: extra.append(f"{size.group(1)} milyar parametre")
    if ctx: extra.append(f"bağlam {ctx}")
    if meta.get("rateLimit"): extra.append(f"limit {meta['rateLimit']}")
    return {"id": mid, "tags": tags[:5] or ["💬 Sohbet"], "desc_tr": desc + (f" ({', '.join(extra)})" if extra else "")}

def pool_summary(it):
    mods = list(dict.fromkeys([it.get("model")] + (it.get("models") or []) + (it.get("model_list") or [])))
    mods = [m for m in mods if m and m != "model-name"][:60]
    meta = it.get("model_meta") or {}
    infos = [model_info(m, meta.get(m)) for m in mods]
    tagcount = {}
    for i in infos:
        for t in i["tags"]:
            if t not in ("⚡ Hızlı/hafif", "🏆 Güçlü/büyük", "🆓 Ücretsiz"):
                tagcount[t] = tagcount.get(t, 0) + 1
    top = [t for t, _ in sorted(tagcount.items(), key=lambda x: -x[1])][:4]
    s = (f"{len(mods)} model: " + ", ".join(t.split(" ", 1)[1].lower() for t in top) + ".") if mods else "Model listesi test sırasında alınacak."
    if it.get("desc_tr") or it.get("desc"):
        s += " " + (it.get("desc_tr") or it["desc"])[:200]
    return s, infos

def pool():
    return jload(POOL_FILE, {"items": [], "last_test": 0})

def save_pool(p):
    with _lock:
        jsave(POOL_FILE, p, private=True)

def pool_id(base, model):
    return hashlib.sha1(f"{base.rstrip('/').lower()}|{model}".encode()).hexdigest()[:10]

def host_name(base):
    h = urllib.parse.urlparse(base).hostname or base
    parts = [x for x in h.split(".") if x not in ("api", "www", "inference", "router", "openai", "llm", "ai", "com", "net", "io", "dev", "co", "cloud", "app", "org", "cn", "xyz")]
    return (parts[0] if parts else h).replace("-", " ").title()

CODE_LANGS = {"python", "bash", "sh", "shell", "js", "javascript", "ts", "typescript", "json", "yaml", "curl", "text", "console", "py", "node"}

KNOWN_HOSTS = [("groq.com", "Groq"), ("cerebras.ai", "Cerebras"), ("nvidia.com", "NVIDIA NIM"), ("mistral.ai", "Mistral"),
               ("generativelanguage.googleapis.com", "Google Gemini"), ("openrouter.ai", "OpenRouter"), ("siliconflow", "SiliconFlow"),
               ("together", "Together AI"), ("deepinfra", "DeepInfra"), ("fireworks.ai", "Fireworks AI"), ("huggingface", "Hugging Face"),
               ("cloudflare", "Cloudflare Workers AI"), ("models.github.ai", "GitHub Models"), ("models.inference.ai.azure", "GitHub Models"),
               ("sambanova", "SambaNova"), ("hyperbolic", "Hyperbolic"), ("novita", "Novita AI"), ("chutes", "Chutes AI"), ("cohere", "Cohere"),
               ("ai21", "AI21 Labs"), ("deepseek", "DeepSeek"), ("x.ai", "xAI Grok"), ("moonshot", "Moonshot (Kimi)"), ("bigmodel", "Zhipu GLM"),
               ("dashscope", "Alibaba Qwen"), ("pollinations", "Pollinations"), ("kilo.ai", "Kilo Gateway"), ("aionlabs", "Aion Labs"),
               ("scaleway", "Scaleway"), ("ovh", "OVHcloud AI"), ("nebius", "Nebius AI"), ("friendli", "Friendli AI"), ("featherless", "Featherless"),
               ("glhf", "GLHF"), ("arliai", "Arli AI"), ("lambda", "Lambda"), ("upstage", "Upstage"), ("perplexity", "Perplexity"), ("anthropic", "Anthropic"),
               ("openai.com", "OpenAI"), ("mancer", "Mancer"), ("inference.net", "Inference.net"), ("llm7", "LLM7"), ("ollama.com", "Ollama Cloud")]

def host_label(base):
    h = (urllib.parse.urlparse(base).hostname or "").lower()
    for k, v in KNOWN_HOSTS:
        if k in h:
            return v
    return host_name(base)

def normalize_base(base):
    """Servislerin OpenAI uyumlu adreslerine çevirir."""
    b = base.rstrip("/")
    h = (urllib.parse.urlparse(b).hostname or "").lower()
    if "generativelanguage.googleapis.com" in h and not b.endswith("/openai"):
        return "https://generativelanguage.googleapis.com/v1beta/openai"
    if "cohere" in h and "compatibility" not in b:
        return "https://api.cohere.ai/compatibility/v1"
    if "anthropic.com" in h:
        return "https://api.anthropic.com/v1"
    return b

def api_url_ok(u):
    if re.search(r"YOUR|ACCOUNT_ID|<|\{", u):
        return False
    pu = urllib.parse.urlparse(u); host = (pu.hostname or "").lower()
    if any(x in host for x in ("github.com", "githubusercontent", "localhost", "example", "huggingface.co/spaces")):
        return False
    return "/v1" in pu.path or host.startswith(("api.", "inference.", "router.", "gateway.", "llm.")) or ".api." in host or "api" in host.split(".")[0]

def extract_apis(root):
    """Bir liste/doküman deposundaki yapay zekâ API'lerini (adres, model, anahtar bilgisi) çıkarır. Servis başına tek kayıt."""
    found = {}
    def put(name, base, models, signup="", key_env="", needs_key=None, desc="", structured=False):
        base = base.rstrip("/").replace("/chat/completions", "")
        if not base.startswith("http") or not api_url_ok(base):
            return
        base = normalize_base(base)
        k = pool_id(base, "")
        models = [m for m in (models or []) if isinstance(m, str) and 2 < len(m) < 90]
        nm = (name or "").strip() if structured else ""
        if not nm or nm.lower() in CODE_LANGS or len(nm) > 40 or nm.startswith(("#", "!", "[")):
            nm = host_label(base)
        e = found.get(k)
        if not e:
            found[k] = {"id": k, "name": nm, "base_url": base, "model": models[0] if models else "", "models": models[:12], "signup": signup,
                        "key_env": key_env, "needs_key_hint": needs_key, "desc": (desc or "")[:200]}
        else:
            for m in models:
                if m not in e["models"] and len(e["models"]) < 12:
                    e["models"].append(m)
            e["model"] = e["model"] or (models[0] if models else "")
            e["signup"] = e["signup"] or signup; e["key_env"] = e["key_env"] or key_env; e["desc"] = e["desc"] or (desc or "")[:200]
            if e["needs_key_hint"] is None:
                e["needs_key_hint"] = needs_key
            if structured and nm and e["name"] == host_label(base):
                e["name"] = nm
    def walk_json(o):
        if isinstance(o, dict):
            base = o.get("baseUrl") or o.get("base_url") or o.get("baseURL") or o.get("api_base") or o.get("endpoint") or o.get("apiBase")
            if isinstance(base, str) and base.startswith("http"):
                ms = o.get("models") or o.get("model") or []
                if isinstance(ms, str):
                    ms = [ms]
                meta = {(m.get("id") or m.get("name")): {k: m.get(k) for k in ("context", "modality", "rateLimit", "maxOutput") if m.get(k)} for m in ms if isinstance(m, dict)}
                ms = [(m.get("id") or m.get("name")) if isinstance(m, dict) else m for m in ms]
                put(o.get("name") or o.get("provider"), base, ms, o.get("url") or o.get("signup") or o.get("website") or "",
                    o.get("envVar") or o.get("env") or "", o.get("requiresKey", o.get("apiKeyRequired")), o.get("description", ""), True)
                kk = pool_id(normalize_base(base.rstrip("/")), "")
                if kk in found and meta:
                    found[kk].setdefault("model_meta", {}).update(meta)
            for v in o.values():
                walk_json(v)
        elif isinstance(o, list):
            for v in o:
                walk_json(v)
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not x.startswith(".")]
        for fn in files:
            p = os.path.join(d, fn)
            if os.path.getsize(p) > 3_000_000:
                continue
            low = fn.lower()
            try:
                if low.endswith(".json"):
                    walk_json(json.load(open(p, encoding="utf-8")))
                    continue
                if not low.endswith((".py", ".js", ".mjs", ".ts", ".sh", ".md", ".yaml", ".yml", ".toml", ".txt")):
                    continue
                txt = open(p, encoding="utf-8", errors="replace").read()
            except Exception:
                continue
            prov = os.path.basename(d) if d != root else ""
            prov = "" if prov.lower() in ("code-examples", "examples", "docs", "scripts", "free-llm-apis", "agents") else prov.replace("-", " ").replace("_", " ").title()
            chunks = re.split(r"\n(?=#{1,4} )", txt) if low.endswith(".md") else [txt]
            for ch in chunks:
                urls = [u for u in dict.fromkeys(URL_RX.findall(ch)) if api_url_ok(u)]
                if not urls or len(urls) > 6:
                    continue
                models = MODEL_RX.findall(ch)
                envm = KEYENV_RX.search(ch)
                needs = False if NOKEY_RX.search(ch) else (True if (envm or re.search(r"YOUR_[A-Z_]*KEY|Authorization: Bearer|api_key", ch)) else None)
                head = ch.strip().splitlines()[0].lstrip("# ").strip() if low.endswith(".md") and ch.strip().startswith("#") else ""
                head = re.sub(r"[^\w .()-]", "", head).strip()
                for u in urls:
                    put("", u, models if len(urls) == 1 else [], "", envm.group(1) if envm else "", needs)
    return list(found.values())

def test_api(item, key=""):
    """→ ('works'|'needs_key'|'fails', ayrıntı, model, ms)"""
    base = item["base_url"].rstrip("/"); t0 = time.time()
    h = {"Authorization": f"Bearer {key}"} if key else {}
    model = item.get("model") or ""
    try:
        r = http_json(base + "/models", headers=h, timeout=12)
        ids = [m.get("id") for m in (r.get("data") or r.get("models") or []) if isinstance(m, dict) and m.get("id")]
        if ids:
            item["model_list"] = ids[:80]
        if not model and ids:
            free = [i for i in ids if ":free" in i or "free" in i.lower()]
            model = (free or ids)[0]
    except RuntimeError as e:
        if re.search(r"HTTP (401|403)", str(e)) and not key:
            return "needs_key", "Anahtar gerekli (401/403)", model, int((time.time() - t0) * 1000)
    except Exception:
        pass
    if not model:
        return "fails", "Model bulunamadı (/models yanıt vermedi)", model, int((time.time() - t0) * 1000)
    tried = [model] + [m for m in (item.get("models") or []) if m != model][:2]
    last = None
    for mdl in tried:
        try:
            out = llm_call({"type": "openai", "base_url": base, "model": mdl, "api_key": key}, [{"role": "user", "content": "Sadece 'tamam' yaz."}], timeout=25)
            if out and out.strip():
                return "works", out.strip()[:60], mdl, int((time.time() - t0) * 1000)
            last = RuntimeError("Boş yanıt")
        except Exception as e:
            last = e
            if not re.search(r"model|404|not.?found|does not exist", str(e), re.I):
                break
    model = tried[0]
    try:
        raise last
    except Exception as e:
        msg = str(e)
        if re.search(r"HTTP (401|403)|api[_ ]?key|unauthori[sz]ed|authentication", msg, re.I) and not key:
            return "needs_key", "Anahtar gerekli", model, int((time.time() - t0) * 1000)
        if re.search(r"HTTP 429|rate", msg, re.I):
            return "fails", "Kota/limit doldu (429) — sonra tekrar denenecek", model, int((time.time() - t0) * 1000)
        if re.search(r"urlopen error|Tunnel connection|Name or service|timed out|Connection (refused|reset)|SSL", msg, re.I):
            return "fails", "Bağlantı kurulamadı (servis kapalı, adres değişmiş ya da ağ/proxy engelli)", model, int((time.time() - t0) * 1000)
        if re.search(r"HTTP 404", msg):
            return "fails", "Adres bulunamadı (404) — servis kapanmış ya da adres değişmiş", model, int((time.time() - t0) * 1000)
        return "fails", re.sub(r"\s+", " ", msg)[:160], model, int((time.time() - t0) * 1000)

def pool_apply(it):
    """Çalışanları API listesine ekler, çalışmayanı kapatır."""
    c = cfg(); prov = next((p for p in c["providers"] if p.get("pool_id") == it["id"]), None)
    if it["status"] == "works":
        if prov:
            prov.update({"model": it["model"]})
            if not prov.get("user_choice"):
                prov["enabled"] = True
        else:
            c["providers"].append({"id": uuid.uuid4().hex[:8], "name": f"{it['name']} (havuz)", "type": "openai", "base_url": it["base_url"],
                                   "model": it["model"], "api_key": it.get("key", ""), "env": it.get("key_env", "") if it.get("key") else "",
                                   "enabled": True, "keyless": not it.get("key"), "pool_id": it["id"]})
            if not c.get("default_provider"):
                c["default_provider"] = c["providers"][-1]["id"]
    elif prov:
        prov["enabled"] = False
    save_cfg(c)

def pool_test_flow(job, ids=None, add_sources=True):
    job.title = "🧪 API havuzu: çıkar ve test et"
    P = pool(); items = {x["id"]: x for x in P["items"]}
    if add_sources:
        srcs = [(s, t) for s, t in tools().items() if t.get("kind") == "doc" or DOC_NAME_RE.search(s)]
        job.log(f"📚 {len(srcs)} liste/doküman deposu taranıyor…")
        for s, t in srcs:
            try:
                ex = extract_apis(t["path"])
            except Exception as e:
                job.log(f"   {t['name']}: okunamadı ({e})"); continue
            new = 0
            for e in ex:
                if e["id"] not in items:
                    e.update({"status": "new", "source": t.get("full_name", s)}); items[e["id"]] = e; new += 1
            job.log(f"   • {t.get('full_name', s)}: {len(ex)} API bulundu ({new} yeni)")
        for k in KEYLESS_CANDIDATES:
            i = pool_id(k["base_url"], k.get("model", ""))
            if i not in items:
                items[i] = {"id": i, "name": k["name"], "base_url": k["base_url"], "model": k.get("model", ""), "signup": "", "key_env": "",
                            "status": "new", "source": "Cypher Tool (yerel/anahtarsız)", "local": k.get("local", False)}
    todo = [x for x in items.values() if (not ids or x["id"] in ids)]
    job.log(f"🧪 {len(todo)} API test ediliyor (paralel)…")
    from concurrent.futures import ThreadPoolExecutor
    def one(it):
        st, info, model, ms = test_api(it, it.get("key", ""))
        it.update({"status": st, "info": info, "model": model or it.get("model", ""), "ms": ms, "tested": now()})
        return it
    done = 0
    with ThreadPoolExecutor(max_workers=10) as ex:
        for it in ex.map(one, todo):
            done += 1
            icon = {"works": "✅", "needs_key": "🔑", "fails": "❌"}[it["status"]]
            job.log(f"  {icon} {it['name']} — {it['base_url']} [{it['model'] or '-'}] {it.get('info', '')[:70]}")
            if job.cancelled:
                break
    P["items"] = list(items.values()); P["last_test"] = time.time()
    need = [x for x in P["items"] if x.get("desc") and not x.get("desc_tr")][:40]
    if need and llm_available():
        try:
            job.log("🌐 Servis açıklamaları Türkçeye çevriliyor…")
            txt, _ = llm_ask([{"role": "user", "content": "Şu servis açıklamalarını kısa ve doğal Türkçeye çevir. SADECE JSON: {\"id\": \"çeviri\", ...}\n" +
                                json.dumps({x["id"]: x["desc"] for x in need}, ensure_ascii=False)}], "Sen bir çevirmensin.", feature="guide")
            tr = extract_json(txt)
            for x in need:
                if isinstance(tr.get(x["id"]), str):
                    x["desc_tr"] = tr[x["id"]][:220]
        except Exception as e:
            job.log(f"   (çeviri atlandı: {str(e)[:80]})")
    save_pool(P)
    for it in P["items"]:
        if it["status"] in ("works", "fails"):
            pool_apply(it)
    cnt = {k: sum(1 for x in P["items"] if x["status"] == k) for k in ("works", "needs_key", "fails")}
    job.ctx["pool"] = cnt
    job.log(f"\n✅ Çalışan: {cnt['works']}   🔑 Anahtar gerekli: {cnt['needs_key']}   ❌ Çalışmayan: {cnt['fails']}")
    job.log("Çalışanlar API listene eklendi; çalışmayanlar kapatıldı.")
    notify(APP, f"API havuzu: {cnt['works']} çalışıyor, {cnt['needs_key']} anahtar istiyor")

def env_name(name):
    n = re.sub(r"[^A-Z0-9]+", "_", (name or "API").translate(TR_MAP).upper()).strip("_")
    return re.sub(r"_(HAVUZ|POOL)$", "", n) or "API"

def api_export(entries, fmt="json", include_keys=True):
    """API'leri başka yerlerde kullanmak için metne dönüştürür."""
    out = []
    E = [{"name": re.sub(r" \(havuz\)$", "", e.get("name", "API")), "base_url": e["base_url"].rstrip("/"), "model": e.get("model", ""),
          "api_key": e.get("api_key") or e.get("key") or "", "type": e.get("type", "openai"), "models": e.get("models") or [],
          "needs": e.get("status") == "needs_key" or ("status" not in e and not e.get("keyless")) or bool(e.get("signup") and not e.get("keyless") and e.get("status") != "works")} for e in entries]
    for e in E:
        k = e["api_key"] if include_keys else ""
        e["shown_key"] = k or ("ANAHTARIN" if (e["api_key"] or e["needs"]) else "")
    if fmt == "json":
        return json.dumps([{"name": e["name"], "base_url": e["base_url"], "model": e["model"], "api_key": e["api_key"] if include_keys else "",
                            "openai_compatible": e["type"] == "openai", "other_models": e["models"][:10]} for e in E], ensure_ascii=False, indent=2)
    for e in E:
        n = env_name(e["name"]); key = e["shown_key"]
        if fmt == "env":
            out.append(f"# {e['name']}\n{n}_BASE_URL={e['base_url']}\n{n}_MODEL={e['model']}" + (f"\n{n}_API_KEY={key}" if key else ""))
        elif fmt == "curl":
            if e["type"] == "anthropic":
                out.append(f"# {e['name']}\ncurl {e['base_url']}/messages -H 'Content-Type: application/json' -H 'x-api-key: {key}' -H 'anthropic-version: 2023-06-01' \\\n  -d '{{\"model\":\"{e['model']}\",\"max_tokens\":512,\"messages\":[{{\"role\":\"user\",\"content\":\"Merhaba\"}}]}}'")
            else:
                auth = f" -H 'Authorization: Bearer {key}'" if key else ""
                out.append(f"# {e['name']}\ncurl {e['base_url']}/chat/completions -H 'Content-Type: application/json'{auth} \\\n  -d '{{\"model\":\"{e['model']}\",\"messages\":[{{\"role\":\"user\",\"content\":\"Merhaba\"}}]}}'")
        elif fmt == "python":
            out.append(f"# {e['name']}  (pip install openai)\nfrom openai import OpenAI\n\nclient = OpenAI(base_url=\"{e['base_url']}\", api_key=\"{key or 'gerekmiyor'}\")\n"
                       f"yanit = client.chat.completions.create(\n    model=\"{e['model']}\",\n    messages=[{{\"role\": \"user\", \"content\": \"Merhaba\"}}],\n)\nprint(yanit.choices[0].message.content)")
        elif fmt == "js":
            auth = f", Authorization: \"Bearer {key}\"" if key else ""
            out.append(f"// {e['name']}\nconst r = await fetch(\"{e['base_url']}/chat/completions\", {{\n  method: \"POST\",\n  headers: {{ \"Content-Type\": \"application/json\"{auth} }},\n"
                       f"  body: JSON.stringify({{ model: \"{e['model']}\", messages: [{{ role: \"user\", content: \"Merhaba\" }}] }}),\n}});\nconsole.log((await r.json()).choices[0].message.content);")
        elif fmt == "plain":
            out.append(f"{e['name']}\n  Adres (base URL): {e['base_url']}\n  Model: {e['model']}\n  Anahtar: {key or '(gerekmiyor)'}" + (f"\n  Diğer modeller: {', '.join(e['models'][:8])}" if e["models"] else ""))
    return "\n\n".join(out)

def free_ai_scan(job, add):
    job.title = "Ücretsiz AI taraması"
    found = []
    job.log("🔎 Anahtarsız uç noktalar canlı test ediliyor…")
    for c in KEYLESS_CANDIDATES:
        r = test_endpoint(c)
        job.log(f"  {'✅' if r['ok'] else '✖'} {c['name']}: " + (f"{r['model']} ({r.get('ms')} ms)" if r["ok"] else r.get("error", "")))
        if r["ok"]:
            found.append({**c, "model": r["model"], "models": r.get("models", [])})
    job.log("🔎 GitHub'da ücretsiz LLM API listeleri aranıyor…")
    gh = []
    for qy in ("free llm api resources", "free ai api list", "awesome free llm"):
        try:
            r = gh_api("/search/repositories?" + urllib.parse.urlencode({"q": qy, "sort": "stars", "per_page": 6}))
            for it in r.get("items", []):
                if it["full_name"] not in [g["full_name"] for g in gh]:
                    gh.append({"full_name": it["full_name"], "url": it["html_url"], "stars": it["stargazers_count"], "description": it.get("description") or ""})
        except Exception as e:
            job.log(f"  GitHub araması başarısız: {str(e)[:120]}"); break
    gh.sort(key=lambda g: -g["stars"])
    job.ctx["github"] = gh[:12]
    if add:
        c = cfg(); existing = {p["base_url"].rstrip("/") for p in c["providers"]}
        for f in found:
            if f["base_url"].rstrip("/") not in existing:
                c["providers"].append({"id": uuid.uuid4().hex[:8], "name": f["name"], "type": "openai", "base_url": f["base_url"],
                                       "model": f["model"], "api_key": "", "env": "", "enabled": True, "keyless": True})
                job.log(f"➕ Eklendi: {f['name']} ({f['model']})")
        if not c.get("default_provider") and c["providers"]:
            c["default_provider"] = c["providers"][0]["id"]
        save_cfg(c)
    job.ctx["found"] = found
    job.log(f"✔ Bitti: {len(found)} çalışan anahtarsız uç nokta, {len(gh)} GitHub listesi.")
    if not found:
        job.log("ℹ Hiç anahtarsız uç nokta çalışmıyor." + ("" if heavy_policy() == "never" else " İstersen Ollama kurup yerel model indirebilirsin (aşağıdan tek tuşla)."))

def ollama_setup_flow(job, model):
    job.title = f"Yerel AI: Ollama + {model}"
    if not which("ollama"):
        r = job.ask("plan", {"name": "Ollama", "summary": "Yerel modelleri API anahtarı olmadan çalıştırmak için Ollama kurulacak (resmi kurulum betiği, yönetici izni ister).",
                             "steps": ["@terminal curl -fsSL https://ollama.com/install.sh | sh"], "actions": [], "deps": [],
                             "warnings": ["Resmi Ollama kurulum betiği internetten indirilip çalıştırılır (ollama.com)."]})
        if not r or not r.get("ok"):
            job.status = "iptal"; return
        ok, _, _ = run_steps(job, (r.get("data") or {}).get("steps") or ["@terminal curl -fsSL https://ollama.com/install.sh | sh"], DATA)
        if not ok or not which("ollama"):
            job.log("✖ Ollama kurulamadı."); job.status = "hata"; return
    try:
        http_get("http://127.0.0.1:11434/api/version", timeout=3)
    except Exception:
        job.log("▶ Ollama sunucusu başlatılıyor…")
        subprocess.Popen(["ollama", "serve"], env=base_env(), start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(3)
    rc, _ = run_shell(job, f"ollama pull {q(model)}", DATA)
    if rc != 0:
        job.status = "hata"; return
    c = cfg()
    p = next((p for p in c["providers"] if "11434" in p.get("base_url", "")), None)
    if p:
        p["model"] = model
    else:
        p = {"id": uuid.uuid4().hex[:8], "name": "Ollama (yerel)", "type": "openai", "base_url": "http://127.0.0.1:11434/v1",
             "model": model, "api_key": "", "env": "", "enabled": True, "keyless": True}
        c["providers"].append(p)
    if not c.get("default_provider"):
        c["default_provider"] = p["id"]
    save_cfg(c)
    job.log(f"✅ Hazır! '{model}' API anahtarsız olarak sağlayıcılara eklendi. Ajanlar sekmesinden sohbet edebilirsin.")

# ───────────────────────────── dışa / içe aktarma ─────────────────────────────
def export_all(full=False, include_keys=False):
    c = cfg(); ts = time.strftime("%Y%m%d-%H%M")
    man = {"app": APP, "version": VERSION, "exported_at": now(), "tools": [], "agents": c.get("agents", []),
           "providers": [{k: v for k, v in p.items() if include_keys or k != "api_key"} for p in c.get("providers", [])],
           "settings": {k: c[k] for k in ("failover", "use_ai", "auto_shortcut", "release_assets", "update_check", "update_default_mode", "auto_agent_repair")},
           "memory": mem_all(), "learned_recipes": jload(USER_CATALOG, []), "agent_rules": c.get("agent_rules", "")}
    for slug, t in tools().items():
        e = {k: v for k, v in t.items() if k != "path"}
        if t.get("icon") and os.path.exists(os.path.join(ICON_DIR, t["icon"])):
            e["icon_b64"] = base64.b64encode(open(os.path.join(ICON_DIR, t["icon"]), "rb").read()).decode()
        man["tools"].append(e)
    if not full:
        p = os.path.join(EXPORT_DIR, f"cyphertool-araclar-{ts}.json")
        jsave(p, man, private=include_keys)
        return p
    p = os.path.join(EXPORT_DIR, f"cyphertool-tam-{ts}.tar.gz")
    ex = {".venv", "node_modules", "__pycache__", "target", ".dl-"}
    def filt(ti):
        parts = ti.name.split("/")
        return None if any(x in ex or x.startswith(".dl-") for x in parts) else ti
    with tarfile.open(p, "w:gz") as tf:
        data = json.dumps(man, ensure_ascii=False, indent=2).encode()
        info = tarfile.TarInfo("manifest.json"); info.size = len(data); info.mtime = time.time()
        import io
        tf.addfile(info, io.BytesIO(data))
        for slug, t in tools().items():
            if os.path.isdir(t["path"]):
                tf.add(t["path"], arcname=f"tools/{slug}", filter=filt)
        reg = {os.path.realpath(t["path"]) for t in tools().values()}
        for d in os.listdir(PROJ_DIR):
            pp = os.path.join(PROJ_DIR, d)
            if os.path.isdir(pp) and os.path.realpath(pp) not in reg:
                tf.add(pp, arcname=f"projects/{d}", filter=filt)
    if include_keys:
        os.chmod(p, 0o600)
    return p

def import_flow(job, path):
    job.title = f"İçe aktarma: {os.path.basename(path)}"
    tmpdir = None
    if path.endswith(".json"):
        man = jload(path, {})
    else:
        tmpdir = tempfile.mkdtemp(prefix="ct-import-")
        with tarfile.open(path) as tf:
            safe_tar_extract(tf, tmpdir)
        man = jload(os.path.join(tmpdir, "manifest.json"), {})
    if man.get("app") != APP:
        raise RuntimeError("Bu dosya bir Cypher Tool dışa aktarımı değil.")
    c = cfg()
    have = {(a.get("id"), a.get("name")) for a in c["agents"]}
    c["agents"] += [a for a in man.get("agents", []) if (a.get("id"), a.get("name")) not in have]
    urls = {p["base_url"] for p in c["providers"]}
    for p in man.get("providers", []):
        if p.get("base_url") not in urls:
            c["providers"].append(p)
    save_cfg(c)
    if man.get("agent_rules") and not c.get("agent_rules"):
        c["agent_rules"] = man["agent_rules"]; save_cfg(c)
    for x in man.get("memory", []):
        mem_add(x.get("text", ""), x.get("kind", "ders"))
    if man.get("learned_recipes"):
        uc = jload(USER_CATALOG, []); have = {x["source"] for x in uc}
        jsave(USER_CATALOG, uc + [x for x in man["learned_recipes"] if x["source"] not in have])
    job.log(f"🧠 {len(man.get('memory', []))} hafıza notu ve {len(man.get('learned_recipes', []))} öğrenilmiş tarif alındı.")
    job.log(f"✔ {len(man.get('agents', []))} ajan ve {len(man.get('providers', []))} API ayarı alındı (anahtarlar dahil değilse API'ler sekmesinden gir).")
    if tmpdir and os.path.isdir(os.path.join(tmpdir, "projects")):
        for d in os.listdir(os.path.join(tmpdir, "projects")):
            dest = unique_dir(PROJ_DIR, d); shutil.move(os.path.join(tmpdir, "projects", d), dest)
            job.log(f"🛠️ Proje alındı: {os.path.basename(dest)}")
    for e in man.get("tools", []):
        name = e.get("name", e.get("slug"))
        if tmpdir and os.path.isdir(os.path.join(tmpdir, "tools", e["slug"])):
            dest = unique_dir(PROJ_DIR if e.get("project") else TOOLS_DIR, e.get("project") or e["slug"]); shutil.move(os.path.join(tmpdir, "tools", e["slug"]), dest)
            if e.get("project"): e["project"] = os.path.basename(dest)
            slug = os.path.basename(dest)
            icon = ""
            if e.get("icon_b64"):
                icon = slug + os.path.splitext(e.get("icon", ".png"))[1]
                open(os.path.join(ICON_DIR, icon), "wb").write(base64.b64decode(e["icon_b64"]))
            t = {k: v for k, v in e.items() if k != "icon_b64"}; t.update({"slug": slug, "path": dest, "icon": icon, "status": "kuruluyor"})
            with _lock:
                tt = tools(); tt[slug] = t; save_tools(tt)
            job.log(f"📁 {name}: dosyalar alındı, ortam yeniden kuruluyor…")
            plan = finalize_plan(dest, {"name": name, "steps": t.get("steps", []), "actions": t.get("actions", []),
                                        "runtimes": t.get("runtimes", []), "system_packages": t.get("system_packages", []), "warnings": []})
            plan["summary"] = "İçe aktarılan aracın ortamı (.venv, node_modules vb.) bu bilgisayarda yeniden kuruluyor."
            r = job.ask("plan", plan)
            ok = bool(r and r.get("ok")) and execute_plan(job, t, {**plan, **((r or {}).get("data") or {})})
            update_tool(slug, status="kuruldu" if ok else "hata")
            make_shortcuts(tools()[slug])
        else:
            job.log(f"⬇ {name}: kaynaktan yeniden kuruluyor…")
            rec = find_catalog(e.get("source", ""))
            preset = rec or {"source": e.get("source"), "name": name, "install": [
                {"type": "release", **json.loads(s[9:])} if s.startswith("@release ") else {"type": "shell", "command": s} for s in e.get("steps", [])],
                "actions": e.get("actions", []), "runtimes": e.get("runtimes", []), "system_packages": e.get("system_packages", []),
                "guide_tr": e.get("guide_tr", ""), "category": e.get("category", "")}
            try:
                sub = Job(job.title, "install"); sub.lines = job.lines; sub.cli = job.cli
                sub.ask = job.ask  # aynı onay kanalı
                install_flow(sub, e.get("source"), {}, preset=preset)
            except Exception as ex:
                job.log(f"✖ {name}: {ex}")
    if tmpdir:
        shutil.rmtree(tmpdir, ignore_errors=True)
    job.log("✅ İçe aktarma bitti.")

# ───────────────────────────── ajan sohbeti ─────────────────────────────
def chat(agent_id, messages, slug=""):
    c = cfg(); ag = next((a for a in c["agents"] if a["id"] == agent_id), c["agents"][0])
    LIVE["chat"][ag["id"]] = {"name": ag["name"], "icon": ag.get("icon", "🤖"), "at": time.time(), "busy": True}
    sysmsg = ag["system"] + f"\n\nKullanıcının sistemi: {os_info().get('PRETTY_NAME', 'Linux')} ({detect_pm()}), {platform.machine()}."
    if slug and slug in tools():
        t = tools()[slug]
        sysmsg += (f"\n\nBağlam — kullanıcının Cypher Tool ile kurduğu araç: {t['full_name']} (klasör: {t['path']}).\n"
                   f"Eylemler: {json.dumps(t.get('actions', []), ensure_ascii=False)}\n"
                   f"Önerdiğin ```bash bloklarındaki komutlar kullanıcı onaylarsa bu araç klasöründe çalıştırılır.\n"
                   f"README:\n{read_readme(t['path'], 7000)}")
    msgs = [{"role": m["role"], "content": m.get("content", ""), **({"images": m["images"]} if m.get("images") else {})} for m in messages[-30:]]
    for m in msgs[:-1]:  # eski mesajlardaki fotoğrafları tekrar gönderme (sadece son mesajdaki)
        m.pop("images", None)
    txt, p = llm_ask(msgs, sysmsg, ag.get("provider", ""), ag.get("model", ""), feature="chat")
    LIVE["chat"][ag["id"]] = {"name": ag["name"], "icon": ag.get("icon", "🤖"), "at": time.time(), "busy": False, "api": f"{p.get('name')} · {p.get('model')}"}
    return {"reply": txt, "provider": p.get("name"), "agent": ag["name"]}

# ───────────────────────────── görev ajanı (araştır → kur → dene → kullan → gerekirse geliştir) ─────────────────────────────
WORK_DIR = os.path.join(DATA, "workspace")
os.makedirs(WORK_DIR, exist_ok=True)

def run_capture(job, cmd, cwd, timeout=180):
    """Komutu zaman aşımıyla çalıştırır, çıktıyı hem kayda hem dönüşe verir."""
    cmd = apt_safe(cmd)
    if needs_root(cmd) and not is_root():
        rc, tail = run_privileged(job, strip_sudo(cmd), cwd)
        return rc, "\n".join(tail)
    job.log(f"$ {cmd}")
    env = base_env(); env["CT_NOPAUSE"] = "1"
    p = subprocess.Popen(["bash", "-lc", cmd], cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, text=True, errors="replace", start_new_session=True)
    out = []
    def rd():
        for line in p.stdout:
            line = clean_term(line.rstrip("\n")); out.append(line); job.log("  " + line)
            if len(out) > 4000:
                del out[:1000]
    th = threading.Thread(target=rd, daemon=True); th.start()
    try:
        rc = p.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        try: os.killpg(p.pid, signal.SIGKILL)
        except Exception: pass
        rc = -9; job.log(f"⏱ Zaman aşımı ({timeout} sn) — süreç durduruldu")
    th.join(3)
    return rc, "\n".join(out)

def gh_search(query, n=8):
    q = query.strip()
    if "fork:" not in q:
        q += " fork:false archived:false"
    r = gh_api("/search/repositories?" + urllib.parse.urlencode({"q": q, "sort": "stars", "order": "desc", "per_page": max(n, 10)}))
    res = []
    for it in r.get("items", [])[:n]:
        res.append({"repo": it["full_name"], "stars": it["stargazers_count"], "description": (it.get("description") or "")[:200],
                    "language": it.get("language") or "", "updated": (it.get("pushed_at") or "")[:10],
                    "license": ((it.get("license") or {}).get("spdx_id") or ""), "url": it["html_url"], "topics": it.get("topics", [])[:6]})
    return res

def gh_readme(repo, limit=7000):
    try:
        tok = cfg().get("github_token", "")
        h = {"Accept": "application/vnd.github.raw"}
        if tok:
            h["Authorization"] = f"Bearer {tok}"
        return http_get(f"https://api.github.com/repos/{repo}/readme", headers=h)[:limit]
    except Exception:
        for br in ("HEAD", "main", "master"):
            for fn in ("README.md", "readme.md", "README.rst", "README"):
                try:
                    return http_get(f"https://raw.githubusercontent.com/{repo}/{br}/{fn}")[:limit]
                except Exception:
                    continue
    return ""

def smoke_test(job, slug, timeout=25):
    """Aracı etkileşimsiz olarak dener (--help / --version). (geçti_mi, özet)"""
    t = tools()[slug]
    if not t.get("actions"):
        return False, "Çalıştırma komutu yok"
    base = t["actions"][0]["command"]
    for extra in ("--help", "--version", "-h", ""):
        rc, out = run_capture(job, f"{base} {extra}".strip(), t["path"], timeout)
        ok = rc == 0 or bool(re.search(r"usage|kullanım|options|--help|version|\bv?\d+\.\d+", out, re.I)) and rc not in (126, 127)
        if ok:
            update_tool(slug, test={"ok": True, "at": now(), "cmd": f"{base} {extra}".strip(), "out": out[-1500:]})
            save_user_recipe(tools()[slug], tested=True)
            return True, f"`{base} {extra}` çalıştı (kod {rc}):\n{out[-1200:]}"
    update_tool(slug, test={"ok": False, "at": now(), "out": out[-1500:]})
    return False, f"Deneme başarısız (kod {rc}):\n{out[-1500:]}"

def resolve_tool(ref):
    """Ajanın verdiği araç adını (slug, ad, repo) kurulu araçla eşleştirir."""
    tl = tools()
    if ref in tl:
        return ref
    r = slugify(ref or "")
    for s, t in tl.items():
        if r and (slugify(s) == r or slugify(t.get("name", "")) == r or slugify(t.get("full_name", "").split("/")[-1]) == r):
            return s
    return None

def html_to_text(html):
    import html as H
    t = re.sub(r"(?is)<(script|style|noscript|svg|head)[^>]*>.*?</\1>", " ", html)
    t = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</li>|</h\d>|</tr>", "\n", t)
    t = re.sub(r"<[^>]+>", " ", t)
    t = H.unescape(t)
    t = re.sub(r"[ \t\r\f\v]+", " ", t)
    return re.sub(r"\n\s*\n+", "\n\n", t).strip()

def web_search(query, n=8):
    """Anahtarsız web araması (DuckDuckGo HTML; olmazsa Wikipedia)."""
    import html as H
    res = []
    try:
        data = urllib.parse.urlencode({"q": query, "kl": "tr-tr"}).encode()
        req = urllib.request.Request("https://html.duckduckgo.com/html/", data=data, headers={**UA, "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) CypherTool"})
        page = urllib.request.urlopen(req, timeout=20).read().decode("utf-8", "replace")
        for m in re.finditer(r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>.*?class="result__snippet"[^>]*>(.*?)</a>', page, re.S):
            href = H.unescape(m.group(1))
            if "uddg=" in href:
                href = urllib.parse.unquote(href.split("uddg=")[1].split("&")[0])
            if "duckduckgo.com/y.js" in href:
                continue
            res.append({"title": html_to_text(m.group(2))[:150], "url": href, "snippet": html_to_text(m.group(3))[:300]})
            if len(res) >= n:
                break
    except Exception as e:
        res_err = str(e)[:120]
    if not res:
        for lang in ("tr", "en"):
            try:
                r = http_json(f"https://{lang}.wikipedia.org/w/api.php?" + urllib.parse.urlencode({"action": "query", "list": "search", "srsearch": query, "format": "json", "srlimit": 5}), timeout=15)
                for it in r.get("query", {}).get("search", []):
                    res.append({"title": it["title"], "url": f"https://{lang}.wikipedia.org/wiki/" + urllib.parse.quote(it["title"].replace(" ", "_")),
                                "snippet": html_to_text(it.get("snippet", ""))})
                if res:
                    break
            except Exception:
                continue
    return res

def fetch_url(url, limit=9000, _nobrowse=False):
    if not re.match(r"^https?://", url or ""):
        raise RuntimeError("Geçersiz adres")
    req = urllib.request.Request(url, headers={**UA, "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) CypherTool", "Accept-Language": "tr,en;q=0.8"})
    with urllib.request.urlopen(req, timeout=25) as r:
        ct = r.headers.get("Content-Type", "")
        raw = r.read(3_000_000)
    if "pdf" in ct:
        tmp = tempfile.mktemp(suffix=".pdf"); open(tmp, "wb").write(raw)
        out = subprocess.run(["pdftotext", "-layout", tmp, "-"], capture_output=True, text=True).stdout if shutil.which("pdftotext") else "(PDF — pdftotext kurulu değil)"
        os.remove(tmp); return out[:limit]
    txt = raw.decode("utf-8", "replace")
    title = re.search(r"(?is)<title[^>]*>(.*?)</title>", txt)
    body = html_to_text(txt) if "<" in txt[:2000] else txt
    if len(body.strip()) < 400 and "<script" in txt and not _nobrowse:
        try:
            return browse(url, limit=limit)
        except Exception:
            pass
    return ((html_to_text(title.group(1)) + "\n\n") if title else "") + body[:limit]

def list_apps(flt=""):
    """Bilgisayarda kurulu grafik uygulamalar (.desktop) ve terminal programları."""
    flt = (flt or "").lower(); apps = []
    dirs = ["/usr/share/applications", "/usr/local/share/applications", os.path.expanduser("~/.local/share/applications"),
            "/var/lib/flatpak/exports/share/applications", os.path.expanduser("~/.local/share/flatpak/exports/share/applications"), "/var/lib/snapd/desktop/applications"]
    seen = set()
    for d in dirs:
        if not os.path.isdir(d):
            continue
        for fn in os.listdir(d):
            if not fn.endswith(".desktop") or fn in seen:
                continue
            seen.add(fn)
            try:
                txt = open(os.path.join(d, fn), encoding="utf-8", errors="replace").read().split("\n[", 1)[0]
            except Exception:
                continue
            if re.search(r"^NoDisplay=true", txt, re.M):
                continue
            g = lambda k: (re.search(rf"^{k}=(.*)$", txt, re.M) or [None, ""])[1].strip()
            name = g("Name[tr]") or g("Name"); com = g("Comment[tr]") or g("Comment"); ex = re.sub(r"\s%\w", "", g("Exec"))
            if not name:
                continue
            if flt and flt not in (name + com + fn + ex).lower():
                continue
            apps.append({"tür": "uygulama", "ad": name, "id": fn[:-8], "komut": ex[:120], "açıklama": com[:120]})
    cli = []
    for d in base_env()["PATH"].split(os.pathsep):
        try:
            for fn in os.listdir(d):
                if (not flt or flt in fn.lower()) and os.access(os.path.join(d, fn), os.X_OK):
                    cli.append(fn)
        except Exception:
            continue
    cli = sorted(set(cli))
    return {"grafik_uygulamalar": apps[:60], "terminal_programları": cli[:120] if flt else f"{len(cli)} program (filtreyle ara: ör. ffmpeg, convert, libreoffice)",
            "toplam_uygulama": len(apps)}

def open_app(app="", file=""):
    env = base_env()
    if file:
        fp = os.path.expanduser(file)
        if app:
            cmd = ["gtk-launch", app, fp] if shutil.which("gtk-launch") else [app, fp]
        else:
            cmd = ["xdg-open", fp]
    elif app:
        cmd = ["gtk-launch", app] if shutil.which("gtk-launch") and not shutil.which(app) else [app]
    else:
        raise RuntimeError("app ya da file gerekli")
    subprocess.Popen(cmd, env=env, start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return "Açıldı: " + " ".join(cmd)

def safe_path(p, roots):
    ap = os.path.realpath(os.path.expanduser(p))
    return ap if any(ap == os.path.realpath(r) or ap.startswith(os.path.realpath(r) + os.sep) for r in roots) else None

AGENT_SYS = """Sen Cypher Tool'un GÖREV AJANISIN. Kullanıcının Linux bilgisayarında, verdiği görevi baştan sona kendin yaparsın:
1) Önce kurulu araçlara (list_tools) ve sistemdeki programlara (list_apps) bak. Uygun araç/program varsa onu kullan (run ile; terminal programlarını doğrudan çağırabilirsin).
   Araştırma istenirse web_search + fetch_url ile birden fazla kaynağı oku, bilgileri karşılaştır, kaynak adreslerini raporda ver.
2) Yoksa GitHub'da ara (search_github — İNGİLİZCE anahtar kelimelerle, gerekirse 2-3 farklı sorgu; ayrıca web_search ile "best ... tool 2026" gibi güncel karşılaştırmalara bak).
   EN İYİSİNİ SEÇ: en az 3 adayı karşılaştır — son güncelleme (son 12 ay içinde olmalı), yıldız sayısı, arşivlenmemiş olması, açık sorunlar, sürüm (release) varlığı, lisans ve Linux desteği. repo_info ile README'yi oku.
   Seçtiğini kur ve DENE; çalışmazsa düzeltmeyi dene, yine olmazsa sıradaki adaya geç. Kullanıcı "en iyisini bul/test et" derse en iyi 2-3 adayı kurup AYNI küçük testle dene, sonuçları tablo halinde karşılaştır, en iyi çalışanı tut, diğerlerini (onayla) uninstall ile kaldır. Kullanıcıya hangi adayları neden elediğini kısaca söyle.
3) En iyisini kur (install). Kurulum planını kullanıcı onaylar.
4) Kurduğun aracı DENE (smoke_test ve/veya run ile --help, örnek kullanım). Hata olursa düzelt (README'ye göre komutları değiştir, eksik paketi kur, gerekirse başka aday dene).
5) Görev bir iş yapmaksa (dosya dönüştürme, indirme, analiz vb.) aracı run ile KULLANARAK işi bitir ve sonucu doğrula (ör. çıktı dosyası var mı, ls ile bak).
6) Uygun araç yoksa ya da çok basit bir işse KENDİ ARACINI GELİŞTİR (create_tool): temiz, çalışan, hata kontrollü kod yaz (tercihen Python stdlib veya küçük bağımlılıklar), README + Türkçe rehber ekle, sonra mutlaka dene.
HATA ALINCA: Bir komut/araç hata verirse önce GÖZLEM'deki bilgi bankası çözümlerine bak; yoksa HEMEN web_search ile hata mesajının ayırt edici kısmını ara (tırnaksız, araç adıyla), en güvenilir 1-2 kaynağı fetch_url ile oku, çözümü uygula, tekrar dene; çözünce learn_error ile kaydet. Pes etmeden önce en az 2 farklı çözüm dene.
YÖNETİCİ ŞİFRESİ: sudo gerektiren komutları normal şekilde (sudo ile) run'a yaz; Cypher Tool kullanıcıdan şifreyi kendi penceresinde ister. Şifreyi asla kendin isteme ya da yazma.
7) Bir işi bitirince finish ile Türkçe rapor ver: ne yaptın, hangi araç, nasıl kullanılır, test sonucu, oluşan dosyalar. finish'ten sonra kullanıcı yeni istek verebilir; sohbet devam eder.

SOHBET KURALLARI (çok önemli):
- Kullanıcıyla Türkçe, samimi ve net konuş. Görev belirsizse ya da birden fazla yol varsa önce say ile ne istediğini sor (seçenekler sun).
- Bir aracı kurup tanıdığında (README'sini okuyup denedikten sonra) say ile kullanıcıya o araçla NELER YAPABİLECEĞİNİ somut maddelerle anlat ("Bu araçla şunları yapabilirim: …") ve options içinde 3-5 tıklanabilir öneri ver; sonra kullanıcının talimatını bekle.
- Kullanıcının talimatını uygula, sonucu göster, sonra yine "başka ne yapayım?" diye seçenek sun.
- Kullanıcı "hangi uygulamalarım / araçlarım var", "neler kurulu", "X ne işe yarıyor", "bana özet geç" gibi bir şey sorarsa: list_tools ile envanteri al ve say ile TÜRKÇE özetle — araçları KATEGORİLERE göre grupla (ör. 🤖 Yapay zekâ ajanları, 🔎 Araştırma, 🛡️ Güvenlik/Keşif, 🧰 Geliştirme…), her araç için tek satır: **ad** — ne işe yarar + 2-3 öne çıkan özelliği. Açıklaması boş ya da belirsiz olanları uydurma: read_tool (Cypher aracı) ya da read_file (disk deposunun README'si) ile öğren. Çalışmayan/komutu olmayanları ⚠ ile belirt. Sonunda options ile "X'i aç", "Y ile ne yapabilirim?", "Çalışmayanları onar" gibi 3-5 öneri sun. Tek bir araç sorulursa o aracı ayrıntılı anlat (ne yapar, özellikleri, nasıl kullanılır, örnek komut).
- Kullanıcı açıkça "kendin karar ver / hepsini yap" demedikçe, büyük ya da geri alınamaz işlerden önce say ile onayını al.
- Kullanıcı "hatırla", "unutma", "bundan sonra hep …", "bir daha … yapma" gibi bir şey derse HEMEN remember (kind: tercih) ile kaydet ve kaydettiğini söyle.
- Kullanıcı yaptığın bir şeyi düzeltirse ("yanlış oldu, şöyle olmalıydı") bunu remember (kind: ders) ile kaydet.

HER YANITIN SADECE TEK BİR JSON NESNESİ olmalı:
{"thought": "kısa Türkçe düşünce", "action": "<eylem>", "args": {...}}

EYLEMLER:
- list_tools {} | {"filter": "kelime", "detail": true}  → kullanıcının TÜM araçları: Cypher ile kurulanlar + diskte git ile indirilmiş GitHub depoları + tarayıcı (ne yaptıkları, özellikleri, durumları)
- tool_hunt {"istek": "kullanıcının istediği araç özelliği (Türkçe)", "aday": 3}  → 🏁 ARAÇ YARIŞMASI: tüm API'ler GitHub'da aday arar ve oylar, en iyi adaylar kurulup isteğe özel test edilir, puanlanır, kazanan kurulu kalır (sonuç tablosu döner). Kullanıcı "şu özellikte araç bul, dene, en iyisini kur", "hangisi daha iyi çalışıyorsa onu kur" derse BUNU kullan.
- search_github {"query": "pdf merge cli"}  → GitHub adayları (GitHub arama sözdizimi kullanabilirsin: language:python, stars:>100)
- repo_info {"repo": "sahip/ad"}  → açıklama + README
- install {"url": "https://github.com/sahip/ad"}  → kurar (eksik bağımlılıkları da), dönüşte araç adı (slug) ve eylemleri gelir
- read_tool {"slug": "..."}  → kurulu aracın README'si ve eylemleri
- smoke_test {"slug": "..."}  → aracı --help/--version ile otomatik dener
- run {"command": "...", "where": "work" | "<slug>" | "/mutlak/klasör", "timeout": 180}  → bash komutu çalıştırır (kullanıcı onaylar). "where": slug ise o aracın klasöründe çalışır (.venv/bin/..., ./bin/... yolları oradan geçerli). Etkileşimli (girdi bekleyen) komut çalıştırma; her zaman etkileşimsiz bayrakları kullan.
- write_file {"path": "çalışma klasörüne göre yol veya mutlak yol", "content": "..."}  → dosya yazar
- create_tool {"name": "...", "description_tr": "...", "files": {"main.py": "..."}, "steps": ["python3 -m venv .venv", ".venv/bin/pip install ..."], "actions": [{"label": "Başlat", "command": ".venv/bin/python main.py", "terminal": true}], "guide_tr": "## Ne işe yarar?\\n..."}  → yeni araç geliştirip Cypher Tool'a ekler
- web_search {"query": "arama sorgusu"}  → anahtarsız web araması (başlık, adres, özet döner). Güncel bilgi, araç önerisi, hata çözümü, araştırma için kullan.
- fetch_url {"url": "https://..."}  → bir web sayfasını/PDF'i metin olarak okur. Araştırmalarda kaynakları gerçekten oku ve raporda ADRESLERİYLE belirt.
- open_browser {"query": "google'da aranacak metin"} veya {"url": "https://..."}  → kullanıcının bilgisayarında GÖRÜNÜR tarayıcıyı (Chrome/Firefox) açar; kullanıcı aramayı/sayfayı ekranda görür. Kullanıcı "google aç", "tarayıcıda göster", "şu siteyi aç" derse kullan.
- browse {"query": "arama"} veya {"url": "https://..."}  → sayfayı GERÇEK (görünmez) tarayıcıyla açıp okur (JavaScript'li sayfalar, Google sonuçları dahil). fetch_url boş/eksik dönerse bunu kullan.
- uninstall {"slug": "..."}  → kurduğun bir aracı kaldırır. En iyisini seçmek için birkaç adayı denediysen, kullanıcı onayıyla çalışmayan/elenen adayları kaldır.
- list_apps {"filter": "isteğe bağlı kelime (ör. video, pdf, ffmpeg)"}  → bu bilgisayarda kurulu grafik uygulamaları ve terminal programlarını listeler. Bir işi yapmadan önce sistemde zaten uygun program var mı bak (ffmpeg, libreoffice, imagemagick, pandoc, gimp, vlc…).
- open_settings {"panel": "ag | wifi | ekran | ses | bluetooth | guc | kullanicilar | klavye | fare | gorunum | yazici | tarih | dil | guncelleme | disk | gorev | guvenlik_duvari | genel"}  → bilgisayarın ilgili AYARLAR penceresini açar (kullanıcı ayarı kendisi görsün diye). Ayarı komutla yapabiliyorsan (nmcli, pactl, xrandr, timedatectl, gsettings, xfconf-query…) run ile kendin yap.
- open_app {"app": "uygulama adı/id ya da komut", "file": "isteğe bağlı açılacak dosya"}  → grafik uygulamayı (ör. firefox, libreoffice, gimp) açar ya da dosyayı varsayılan programıyla açar
- say {"message_tr": "kullanıcıya söyleyeceğin (Markdown olabilir)", "options": ["öneri 1", "öneri 2", "..."]}  → kullanıcıya konuşur/sorar ve CEVABINI BEKLER (cevap GÖZLEM olarak gelir)
- finish {"report_tr": "Markdown Türkçe rapor", "next_options": ["sonraki öneri 1", "..."]}  → işi bitirir, kullanıcıya rapor verir ve yeni isteğini bekler
- set_actions {"slug": "...", "actions": [{"label": "Başlat", "command": "aracın klasörüne göre komut", "terminal": true}], "kind": "tool" | "doc", "steps": ["(isteğe bağlı) gelecekte yeniden kurulum için doğru kurulum adımları"]}  → aracın çalıştırma komutlarını/türünü KALICI kaydeder ve durumunu 'kuruldu' yapar (önce smoke_test/run ile doğrula)
- add_provider {"name": "...", "base_url": "https://.../v1", "model": "...", "type": "openai", "api_key": "", "env": ""}  → bir yapay zekâ API'sini önce CANLI TEST eder, çalışıyorsa Cypher Tool'un API listesine ekler (sadece resmi/ücretsiz servisler; izinsiz proxy'ler değil)
- learn_error {"signature": "hatanın ayırt edici satırı (aynen)", "title": "kısa Türkçe başlık", "commands": ["onu çözen komutlar"], "cause": "neden"}  → BİLMEDİĞİN bir hatayı çözdüğünde MUTLAKA kaydet; bir dahaki sefere otomatik çözülür
- learn {"topic": "konu", "summary": "öğrendiğin bilginin Türkçe özeti (maddeler, komutlar, sayılar)", "source": "adres"}  → BİLGİ HAFIZASINA yazar. Bir şey araştırıp öğrendiğinde (web sayfası, belge, video) mutlaka kaydet; sonraki görevlerde hatırlarsın.
- recall {"query": "konu"}  → bilgi hafızasında daha önce öğrendiklerini arar (araştırmaya başlamadan önce bak).
- youtube {"url": "https://youtube.com/watch?v=..."} | {"query": "youtube'da aranacak", "question": "videoda neyi merak ediyorum"}  → videoyu uygulama içi tarayıcıda açar, ALTYAZISINI okur, Türkçe özet + öğrenilenleri çıkarır ve bilgi hafızasına kaydeder.
- remember {"note": "kısa, genel geçer not", "kind": "ders" | "tercih" | "araç"}  → KALICI HAFIZAYA yazar. Kullan: kullanıcının bir tercihini öğrendiğinde (tercih), işe yarayan bir komut/çözüm bulduğunda ya da bir hatadan ders çıkardığında (ders), bir aracın neyi nasıl yaptığını öğrendiğinde (araç; slug ve örnek komutla). Gereksiz/tek seferlik şeyleri yazma.

HAFIZA: Aşağıda geçmiş oturumlardan öğrendiklerin var. Bunlara uy (özellikle kullanıcı tercihlerine) ve aynı hataları tekrarlama.

KURALLAR: Global kurulum yapma (proje içi .venv / yerel npm). Kullanıcının dosyalarını silme veya üzerine yazma; çıktıları yeni dosyalara yaz. Aynı başarısız şeyi tekrar etme, farklı yol dene. Gizli bilgi (şifre, anahtar) isteme. Gözlemleri dikkatle oku."""

def agent_flow(job, task, opts):
    opts = opts or {}
    shown_task = (opts.get("shown") or task or "") + (f"  🖼️ ({len(opts['images'])} fotoğraf)" if opts.get("images") else "")
    if opts.get("images"):
        try:
            d = describe_images(opts["images"], task, job.log)
            task = (task or "Bu fotoğrafla ilgili yardım et.") + "\n\n[KULLANICININ GÖNDERDİĞİ FOTOĞRAFIN AYRINTILI AÇIKLAMASI]\n" + d
        except Exception as e:
            job.log(f"⚠ Fotoğraf okunamadı: {str(e)[:200]}")
        opts = {k: v for k, v in opts.items() if k != "images"}
    workdir = os.path.expanduser(opts.get("workdir") or WORK_DIR)
    os.makedirs(workdir, exist_ok=True)
    auto = bool(opts.get("auto")); max_steps = int(opts.get("max_steps", 30))
    con = PROCS.get(opts.get("console") or "") if opts.get("console") else None
    unattended = bool(opts.get("unattended")); un_says = 0
    job.ctx["unattended"] = unattended
    if con:
        job.ctx["console"] = con.id
        console_print(con, f"\n🧑 Sen: {(opts.get('shown') or task)[:300]}", "1;36")
    job.auto = auto  # kullanıcı "sormadan çalıştır" dediyse planlar otomatik onaylanır (şifre ve sorular yine sorulur)
    job.title = opts.get("title") or ("🎯 " + task[:70]); job.ctx["task"] = task; job.ctx["steps"] = []
    title = job.title
    if not llm_available():
        urls = re.findall(r"(https?://\S+|git@\S+)", task or "")
        if urls:
            job.log("ℹ Yapay zekâ API'si yok → bulunan linkler doğrudan kuruluyor.")
            for u in urls:
                if con: job.ctx["mirror"] = con.id; console_print(con, f"$ ct kur {u}", "1;95")
                install_flow(job, u.rstrip(".,)"), {}); job.ctx.pop("mirror", None)
            return
        return hunt_fallback(job, task, workdir)
    oi = os_info()
    sysmsg = AGENT_SYS + (f"\n\nSİSTEM: {oi.get('PRETTY_NAME', 'Linux')} | paket yöneticisi: {detect_pm()} | {platform.machine()} | "
                          f"RAM {mem_gb()} GB | Python {platform.python_version()} | node: {'var' if which('node') else 'yok'} | "
                          f"ollama: {'var' if which('ollama') else 'yok'}" + ("  ⛔ KULLANICI YEREL MODEL/OLLAMA/llama.cpp KURULUMUNU YASAKLADI — asla önerme, kurma, indirme." if heavy_policy() == "never" else "  (yerel model/Ollama kurulumu gerekirse sistem kullanıcıya ayrıca sorar)") + f"\nÇALIŞMA KLASÖRÜ (work): {workdir}\nEv dizini: {os.path.expanduser('~')}")
    rules = (cfg().get("agent_rules") or "").strip()
    if rules:
        sysmsg += "\n\nKULLANICININ KALICI TALİMATLARI (EN YÜKSEK ÖNCELİK — her zaman uy):\n" + rules
        job.log("📜 Kalıcı talimatlar yüklendi")
    if con:
        sysmsg += CONSOLE_SYS
    sysmsg += BROWSER_SYS + DESKTOP_SYS + INTEG_SYS
    if unattended:
        sysmsg += "\n\nGÖZETİMSİZ ÇALIŞMA: Bu görev zamanlanmış/otomatik çalışıyor, kullanıcı şu an başında değil. Soru sorma; en makul yolu seç, işi bitir ve finish ile ayrıntılı rapor ver."
    mc = mem_context(task)
    sysmsg += "\n\nHAFIZAN (geçmiş oturumlardan):\n" + (mc or "(henüz boş)")
    kc = know_context(task)
    if kc:
        sysmsg += "\n\nBİLGİ HAFIZAN (daha önce araştırıp öğrendiklerin — bu konuda tekrar aramadan önce bunları kullan):\n" + kc
        job.log(f"📚 Bilgi hafızasından {kc.count(chr(10)) + 1} kayıt hatırlandı")
    persona = next((a for a in cfg()["agents"] if a.get("id") == opts.get("persona")), None)
    if persona:
        sysmsg += f"\n\nEK KİŞİLİK ({persona['name']}): {persona['system']}"
        job.log(f"🎭 Kişilik: {persona['name']}")
    if mc:
        job.log(f"🧠 Hafızadan {mc.count(chr(10)) + 1} not yüklendi")
    msgs = [{"role": "user", "content": f"GÖREV: {task}" if task.strip() else "GÖREV: (kullanıcı henüz bir görev yazmadı — kendini kısaca tanıt ve say ile ne yapmak istediğini sor, örnek seçenekler sun)"}]
    if opts.get("keep_chat") and job.ctx.get("chat"):
        job.ctx["chat"].append({"role": "user", "text": shown_task or "(sıradaki API devraldı)"})
    else:
        job.ctx["chat"] = [{"role": "user", "text": shown_task}] if shown_task.strip() else []
    job.log(f"🎯 Görev: {task}\n📁 Çalışma klasörü: {workdir}\n🤖 Onay modu: {'otomatik (komutlar sorulmadan)' if auto else 'her komutta onay'}")
    droot = os.path.realpath(os.path.expanduser(opts["develop_root"])) if opts.get("develop_root") else ""
    roots = [workdir, TOOLS_DIR] + ([droot] if droot else [])
    visible = bool(opts.get("visible", cfg().get("visible_research", True))) and visible_ok() and (not unattended or opts.get("watched"))
    if droot or opts.get("repair"):
        sysmsg += TOOL_DEV_SYS
    if visible:
        sysmsg += "\n\nGÖRÜNÜR ARAŞTIRMA AÇIK: web_search ve fetch_url, kullanıcının ekranda gördüğü Chrome penceresinde (Google) yapılır; kullanıcı aramalarını ve okuduğun sayfaları canlı izler."
    tkey = opts.get("tool_key") or ""; user_fixed = bool(opts.get("provider")); sess = {}
    def _use_best(key, bench_ok):
        nonlocal tkey
        tkey = key
        if user_fixed or len([p for p in cfg().get("providers", []) if p.get("enabled", True)]) < 2:
            return
        best = tool_ai_best(key)
        if not best and bench_ok:
            job.status = "🧠 API'ler bu araç için yarıştırılıyor"
            job.log("🧠 Bu araç için en uygun yapay zekâyı bulmak üzere kurulu tüm API'ler aynı küçük görevle deneniyor…")
            if con: console_print(con, "🧠 Kurulu API'ler bu araç için yarıştırılıyor…", "95")
            try: best = tool_ai_bench(key, job.log)
            except Exception as e: job.log(f"⚠ Yarıştırma yapılamadı: {str(e)[:150]}")
        if best and best != opts.get("provider"):
            opts["provider"] = best; lb = tool_ai_scores(key).get(best, {})
            job.log(f"🧠 Bu araç için en iyi beyin: {lb.get('name')} · {lb.get('model')} ({lb.get('score')} puan)")
            if con: console_print(con, f"🧠 Bu araç için en iyi beyin: {lb.get('name')} · {lb.get('model')}", "95")
    if tkey:
        _use_best(tkey, auto_cfg()["bench"])
    step = 0; budget = max_steps
    while True:
        step += 1
        if step > budget:
            r = job.ask("question", {"question": f"⏳ {max_steps} adımlık sınıra geldim. Devam edeyim mi, yoksa başka bir şey mi yapayım?", "options": ["Devam et", "Bitir"]})
            ans = (((r or {}).get("data") or {}).get("answer") or "") if r and r.get("ok") else ""
            if not ans or ans.strip().lower() in ("bitir", "dur", "çık", "kapat"):
                break
            job.ctx["chat"].append({"role": "user", "text": ans}); budget = step + max_steps
            msgs.append({"role": "user", "content": "KULLANICI: " + ans}); continue
        if job.cancelled:
            job.status = "iptal"; return
        job.status = f"düşünüyor (adım {step})"
        try:
            txt, prov = llm_ask(msgs[:1] + msgs[-24:], sysmsg, opts.get("provider", ""), opts.get("model", ""), log=job.log,
                                feature="repair" if opts.get("repair") else "agent")
            job.ctx["api"] = f"{prov.get('name')} · {prov.get('model')}"
            cur_pid = prov.get("id", ""); sess.setdefault(cur_pid, {"steps": 0, "errors": 0})["steps"] += 1
        except Exception as e:
            job.log(f"✖ Yapay zekâya ulaşılamadı: {e}"); job.status = "hata"; return
        try:
            d = extract_json(txt); act = d.get("action", ""); args = d.get("args") or {}
        except Exception:
            sess[cur_pid]["errors"] += 1
            msgs += [{"role": "assistant", "content": txt[:2000]}, {"role": "user", "content": "GÖZLEM: Yanıtın geçerli JSON değildi. SADECE tek bir JSON nesnesi döndür."}]
            continue
        job.log(f"\n💭 {d.get('thought', '')}\n▶ {act} {json.dumps(args, ensure_ascii=False)[:300]}")
        stp = {"role": "step", "n": step, "thought": d.get("thought", ""), "action": act, "args": {k: (v if len(str(v)) < 300 else str(v)[:300] + "…") for k, v in args.items()}}
        job.ctx["steps"].append(stp)
        if act not in ("finish", "say", "ask_user"):
            job.ctx["chat"].append(stp)
        job.status = f"{act} (adım {step})"
        obs = ""
        try:
            if act in ("finish", "say", "ask_user"):
                if act == "finish":
                    msg = args.get("report_tr") or d.get("thought", ""); opts_ = args.get("next_options") or []
                    job.ctx["report"] = msg; job.log("\n✅ İŞ TAMAMLANDI\n" + msg)
                    if tkey:  # 🧠 bu araçla işi bitiren API'leri kaydet (kullandıkça öğrenir)
                        for pid_, v_ in sess.items():
                            tool_ai_record(tkey, pid_, True, v_["steps"], v_["errors"])
                        sess.clear()
                    notify(APP, "🎯 Görev Ajanı işi bitirdi — sonraki isteğini bekliyor")
                else:
                    msg = args.get("message_tr") or args.get("question") or d.get("thought", ""); opts_ = args.get("options") or []
                    job.log("\n💬 " + msg)
                job.ctx["chat"].append({"role": "agent", "text": msg, "options": opts_, "final": act == "finish"})
                job.title = title
                if con:
                    console_print(con, "🤖 " + re.sub(r"[*#`]", "", msg)[:1500], "95")
                if unattended:
                    un_says += 1
                    if act == "finish" or un_says > 3:
                        job.status = "tamamlandı"; agent_reflect(job, msgs, sysmsg, opts); return
                    msgs += [{"role": "assistant", "content": json.dumps(d, ensure_ascii=False)}, {"role": "user", "content": "KULLANICI: (başında değil) En makul seçimi kendin yap ve devam et."}]
                    continue
                r = job.ask("question", {"question": msg, "options": opts_, "final": act == "finish"})
                ans = (((r or {}).get("data") or {}).get("answer") or "").strip() if r and r.get("ok") else ""
                imgs = ((r or {}).get("data") or {}).get("images") or []
                shown_ans = ans + (f"  🖼️ ({len(imgs)} fotoğraf)" if imgs else "")
                if imgs:
                    try:
                        ans = (ans or "Bu fotoğrafa bak.") + "\n\n[FOTOĞRAF AÇIKLAMASI]\n" + describe_images(imgs, ans, job.log)
                    except Exception as e:
                        job.log(f"⚠ Fotoğraf okunamadı: {str(e)[:200]}")
                if not ans or ans.lower() in ("bitir", "dur", "çık", "kapat", "teşekkürler", "tesekkurler", "yeter"):
                    agent_reflect(job, msgs, sysmsg, opts)
                    job.status = "tamamlandı"; job.log("👋 Oturum bitti."); return
                job.ctx["chat"].append({"role": "user", "text": shown_ans if imgs else ans}); job.log("🧑 " + (shown_ans if imgs else ans))
                if con: console_print(con, "🧑 Sen: " + (shown_ans if imgs else ans)[:500], "1;36")
                budget = step + max_steps
                msgs += [{"role": "assistant", "content": json.dumps(d, ensure_ascii=False)}, {"role": "user", "content": "KULLANICI: " + ans}]
                continue
            elif act == "web_search" and visible:
                try:
                    obs = visible_search(job, args.get("query", task), con)
                except Exception as e:
                    r = web_search(args.get("query", task)); obs = f"(Chrome açılamadı: {str(e)[:120]} — normal arama)\n" + json.dumps(r, ensure_ascii=False)
                job.log(f"🔎 Chrome'da arandı: {args.get('query', '')}")
            elif act in ("fetch_url", "browse") and visible and args.get("url"):
                try:
                    obs = visible_fetch(job, args.get("url", ""), con)
                except Exception as e:
                    obs = fetch_url(args.get("url", ""))
                job.log(f"📄 Chrome'da okundu: {args.get('url', '')} ({len(obs)} karakter)")
            elif act == "web_search":
                r = web_search(args.get("query", task))
                obs = json.dumps(r, ensure_ascii=False) if r else "Sonuç bulunamadı (ağ engelli olabilir). Farklı kelimelerle dene ya da fetch_url ile bilinen bir siteyi oku."
                job.log(f"🌐 Arama: {args.get('query', '')} → {len(r)} sonuç")
            elif act == "fetch_url":
                obs = fetch_url(args.get("url", ""))
                job.log(f"📄 Okundu: {args.get('url', '')} ({len(obs)} karakter)")
            elif act == "open_browser":
                if not auto:
                    r = job.ask("confirm", {"message": f"Yapay zekâ tarayıcıyı açmak istiyor:\n{args.get('url') or ('Google araması: ' + args.get('query', ''))}"})
                    if not r or not r.get("ok"):
                        obs = "Kullanıcı tarayıcı açmayı onaylamadı."
                if not obs:
                    obs = open_browser(args.get("url", ""), args.get("query", ""), args.get("browser", "")); job.log("🌐 " + obs)
                    if con: console_print(con, "🌐 " + obs, "95")
            elif act == "browse":
                obs = browse(args.get("url", ""), args.get("query", ""))
                job.log(f"🧭 Tarayıcıyla okundu: {args.get('url') or args.get('query')} ({len(obs)} karakter)")
            elif act == "uninstall":
                sl = resolve_tool(args.get("slug", "")) or args.get("slug", "")
                nm = tools()[sl]["name"]
                r = {"ok": True} if auto else job.ask("confirm", {"message": f"Yapay zekâ '{nm}' aracını kaldırmak istiyor (deneme sonucu elendi).\nNeden: {d.get('thought', '')}"})
                if r and r.get("ok"):
                    uninstall_tool(sl); obs = f"Kaldırıldı: {sl}"; job.log("🗑 " + obs)
                else:
                    obs = "Kullanıcı kaldırmayı onaylamadı."
            elif act == "open_settings":
                obs = open_settings(args.get("panel", "genel")); job.log("⚙️ " + obs)
            elif act in ("type_keys", "read_screen"):
                if not con or con.rc is not None:
                    obs = "Konsol modu kapalı; bu eylem sadece Konsol sekmesinden başlatılan oturumlarda çalışır. run kullan."
                else:
                    if act == "type_keys":
                        txt_ = str(args.get("text", "")).replace("\\u0003", "\x03")
                        con.write(txt_ + ("\n" if args.get("enter", True) else "")); job.log(f"⌨ {txt_[:120]!r}")
                        time.sleep(min(30, float(args.get("wait", 3) or 3)))
                    obs = "KONSOL EKRANI (son kısım):\n" + console_screen(con, 3500)
            elif act == "list_apps":
                obs = json.dumps(list_apps(args.get("filter", "")), ensure_ascii=False)[:6000]
            elif act == "open_app":
                if not auto and not desk_on():
                    r = job.ask("confirm", {"message": f"Ajan bir uygulama açmak istiyor:\n{args.get('app', '')} {args.get('file', '')}"})
                    if not r or not r.get("ok"):
                        obs = "Kullanıcı onaylamadı."
                if not obs:
                    obs = open_app(args.get("app", ""), args.get("file", "")); job.log("🖥 " + obs)
            elif act == "learn_error":
                e = learn_error(args.get("signature", ""), args.get("title", "Hata"), args.get("commands", []), args.get("cause", ""))
                obs = "Hata bilgi bankasına eklendi." if e else "Eklenemedi (imza çok kısa, komut yok ya da zaten var)."
                job.log("📚 " + obs)
            elif act == "learn":
                e_ = know_add(args.get("topic", ""), args.get("summary", ""), args.get("source", ""))
                obs = "Bilgi hafızasına kaydedildi." if e_ else "Boş özet, kaydedilmedi."
                job.log("📚 Öğrenildi: " + str(args.get("topic", ""))[:120])
                if con: console_print(con, "📚 Hafızaya kaydedildi: " + str(args.get("topic", ""))[:120], "95")
            elif act == "recall":
                r_ = know_find(args.get("query", task), 8)
                obs = "\n\n".join(f"[{x['topic']}] ({x['at']}{', ' + x['source'] if x.get('source') else ''})\n{x['summary'][:1500]}" for x in r_) or "Bilgi hafızasında bu konuda kayıt yok — araştır ve learn ile kaydet."
            elif act == "youtube":
                try:
                    obs = youtube_learn(job, args.get("url", ""), args.get("query", ""), args.get("question", ""), con)
                except Exception as e_:
                    obs = f"YouTube okunamadı: {str(e_)[:200]}"
                job.log("📺 " + obs[:300])
            elif act == "remember":
                mem_add(args.get("note", ""), args.get("kind", "ders")); obs = "Hafızaya yazıldı."
                job.log("🧠 Hafızaya eklendi: " + args.get("note", "")[:200])
            elif act == "list_tools":
                obs = tools_inventory(args.get("filter", ""), bool(args.get("detail")))
            elif act == "search_github":
                obs = json.dumps(gh_search(args.get("query", task)), ensure_ascii=False)
            elif act == "repo_info":
                repo = args.get("repo", "").replace("https://github.com/", "").strip("/")
                m = gh_meta(*repo.split("/", 1)) if "/" in repo else {}
                obs = json.dumps({k: m.get(k) for k in ("full_name", "description", "stars", "language", "license", "topics")}, ensure_ascii=False) + "\nREADME:\n" + gh_readme(repo)
            elif act == "install":
                url = args.get("url", "")
                before = set(tools())
                if con:
                    job.ctx["mirror"] = con.id; console_print(con, f"$ ct kur {url}", "1;95")
                try:
                    install_flow(job, url, {"shortcut": opts.get("shortcut", True), "provider": opts.get("provider", "")})
                finally:
                    job.ctx.pop("mirror", None)
                job.title = title
                new = [s for s in tools() if s not in before]
                if new:
                    t = tools()[new[0]]
                    obs = json.dumps({"slug": new[0], "durum": t["status"], "eylemler": t.get("actions", []), "klasör": t["path"]}, ensure_ascii=False)
                    job.ctx.setdefault("installed", []).append(new[0])
                else:
                    obs = "Kurulum yapılmadı (kullanıcı iptal etti ya da hata oluştu). Son kayıtlar:\n" + "\n".join(job.lines[-25:])
            elif act == "read_tool":
                t = tools()[resolve_tool(args.get("slug", "")) or args.get("slug", "")]
                obs = json.dumps({"durum": t.get("status"), "tür": t.get("kind", "tool"), "eylemler": t.get("actions"), "klasör": t["path"],
                                  "kurulum": t.get("steps"), "son_test": t.get("test")}, ensure_ascii=False) + \
                      ("\nSON HATA KAYDI:\n" + t["last_error"][-3500:] if t.get("last_error") else "") + \
                      ("\nSON ÇALIŞTIRMA HATASI:\n" + t["last_run_error"][-2500:] if t.get("last_run_error") else "") + \
                      ("\nBİLGİ BANKASI TEŞHİSİ:\n" + "\n".join(f"- {d['title']} → {d['commands'] or d['advice']}" for d in diagnose((t.get("last_error") or "") + "\n" + (t.get("last_run_error") or ""), t)) if (t.get("last_error") or t.get("last_run_error")) else "") + \
                      "\nDOSYALAR:\n" + file_tree(t["path"], 80) + "\nREADME:\n" + read_readme(t["path"], 7000)
            elif act == "set_actions":
                sl = resolve_tool(args.get("slug", "")) or args.get("slug", "")
                t = tools()[sl]; acts = [a for a in (args.get("actions") or []) if isinstance(a, dict) and a.get("command")]
                upd = {"kind": args.get("kind") or t.get("kind", "tool"), "status": "kuruldu", "last_error": ""}
                if acts or upd["kind"] == "doc":
                    upd["actions"] = acts
                if isinstance(args.get("steps"), list) and args["steps"]:
                    upd["steps"] = [x for x in args["steps"] if isinstance(x, str)]
                update_tool(sl, **upd)
                if acts:
                    make_shortcuts(tools()[sl]); save_user_recipe(tools()[sl])
                obs = f"Kaydedildi: {sl} → tür={upd['kind']}, eylemler={[a['command'] for a in acts]}"
                job.log("💾 " + obs)
            elif act == "add_provider":
                cand = {"type": args.get("type", "openai"), "base_url": (args.get("base_url") or "").rstrip("/"), "model": args.get("model", ""), "api_key": args.get("api_key", "")}
                if not cand["base_url"].startswith(("http://", "https://")):
                    obs = "Geçersiz adres."
                else:
                    try:
                        out = llm_call(cand, [{"role": "user", "content": "Sadece 'tamam' yaz."}], timeout=40)
                        okp = bool(out.strip())
                    except Exception as e:
                        okp = False; out = str(e)[:200]
                    if okp:
                        c = cfg()
                        if not any(p.get("base_url", "").rstrip("/") == cand["base_url"] and p.get("model") == cand["model"] for p in c["providers"]):
                            c["providers"].append({"id": uuid.uuid4().hex[:8], "name": args.get("name") or cand["base_url"], **cand,
                                                   "env": args.get("env", ""), "enabled": True, "keyless": not cand["api_key"]})
                            save_cfg(c)
                        obs = f"✅ Çalışıyor ve eklendi: {args.get('name')} ({cand['model']}) — yanıt: {out.strip()[:40]}"
                    else:
                        obs = f"✖ Çalışmadı, eklenmedi: {out}"
                job.log("🔌 " + obs)
            elif act == "smoke_test":
                ok, out = smoke_test(job, resolve_tool(args.get("slug", "")) or args.get("slug", ""))
                obs = ("BAŞARILI: " if ok else "BAŞARISIZ: ") + out
            elif act == "run":
                cmd = args.get("command", "").strip(); where = str(args.get("where", "work") or "work")
                ts = resolve_tool(where)
                if ts:
                    where = ts; cwd = tools()[ts]["path"]
                elif where in ("work", "") :
                    cwd = workdir
                elif os.path.isdir(os.path.expanduser(where)):
                    cwd = os.path.expanduser(where)
                else:
                    raise KeyError(f"'{where}' adında araç ya da klasör yok")
                if not heavy_ok(job, [cmd], d.get("thought", "")):
                    obs = "ENGELLENDİ: " + HEAVY_NO
                    job.log("⏸ " + obs)
                    msgs += [{"role": "assistant", "content": json.dumps(d, ensure_ascii=False)}, {"role": "user", "content": "GÖZLEM: " + obs}]
                    continue
                if auto and danger_warnings([cmd]):
                    obs = "ENGELLENDİ (tehlikeli komut, otomatik modda çalıştırılmaz): " + "; ".join(danger_warnings([cmd])) + " — daha güvenli bir yol bul."
                    job.log("⛔ " + obs)
                    msgs += [{"role": "assistant", "content": json.dumps(d, ensure_ascii=False)}, {"role": "user", "content": "GÖZLEM: " + obs}]
                    continue
                if not auto:
                    plan = finalize_plan(cwd, {"name": "Ajanın komutu", "summary": f"💭 {d.get('thought', '')}\n📁 {cwd}", "steps": [cmd], "actions": [], "warnings": []})
                    r = job.ask("plan", plan)
                    if not r or not r.get("ok"):
                        obs = "Kullanıcı bu komutu ONAYLAMADI. Başka bir yol düşün ya da ask_user ile sor."
                        msgs += [{"role": "assistant", "content": json.dumps(d, ensure_ascii=False)}, {"role": "user", "content": "GÖZLEM: " + obs}]
                        continue
                    data = r.get("data") or {}
                    for c in data.get("deps", []) or []:
                        run_capture(job, c, cwd)
                    cmd = " && ".join(data.get("steps") or [cmd])
                try:
                    con_free = bool(con) and os.tcgetpgrp(con.m) == con.p.pid
                except Exception:
                    con_free = False
                if con and con.rc is None and con_free and not (needs_root(cmd) and not is_root()):
                    rc, out = console_exec(con, apt_safe(cmd), cwd, int(args.get("timeout", 180)), job)
                    job.log(f"$ {cmd}\n" + out[-2000:])
                else:
                    if con: job.ctx["mirror"] = con.id; console_print(con, f"$ {cmd}   " + ("(yönetici izni gerekiyor — Cypher Tool şifre penceresi açılacak)" if needs_root(cmd) and not is_root() else "(konsolda program açık; arka planda çalıştırılıyor)"), "1;95")
                    rc, out = run_capture(job, cmd, cwd, int(args.get("timeout", 180)))
                    job.ctx.pop("mirror", None)
                dg = diagnose(out, tools().get(where)) if rc != 0 else []
                obs = f"çıkış kodu: {rc}\nÇIKTI (son kısım):\n{out[-3500:]}" + \
                      (("\nBİLGİ BANKASINDAKİ BİLİNEN ÇÖZÜMLER:\n" + "\n".join(f"- {d['title']}: {d['cause']} → komutlar: {d['commands']} öneriler: {d['advice']}" for d in dg)) if dg else
                       ("\n(Bu hata bilgi bankasında yok — HEMEN web_search ile hata mesajını ara, çözümü uygula; çözersen learn_error ile kaydet.)" if rc != 0 else ""))
            elif act == "write_file":
                p = args.get("path", "")
                ap = safe_path(p if os.path.isabs(os.path.expanduser(p)) else os.path.join(workdir, p), roots)
                if not ap:
                    obs = f"Bu yola yazma izni yok. Sadece çalışma klasörü ({workdir}) veya araç klasörleri."
                else:
                    content = args.get("content", "")
                    if not auto:
                        r = job.ask("confirm", {"message": f"Ajan bir dosya yazmak istiyor:\n{ap}\n({len(content.splitlines())} satır)\n\n{content[:1500]}"})
                        if not r or not r.get("ok"):
                            obs = "Kullanıcı dosya yazmayı onaylamadı."
                    if not obs:
                        os.makedirs(os.path.dirname(ap), exist_ok=True)
                        in_dev = bool(droot) and (ap == droot or ap.startswith(droot + os.sep))
                        if in_dev:
                            dev_prepare(droot, job.log)
                        if os.path.exists(ap) and not in_dev and not ap.startswith(os.path.realpath(TOOLS_DIR)) and not ap.startswith(os.path.realpath(WORK_DIR)):
                            obs = "Dosya zaten var; kullanıcının dosyasının üzerine yazılmaz. Başka bir ad kullan."
                        else:
                            open(ap, "w", encoding="utf-8").write(content); obs = f"Yazıldı: {ap}"; job.log(f"📝 {ap}")
            elif act == "create_tool":
                obs = agent_create_tool(job, args, opts)
                job.title = title
            elif act == "read_file":
                p_ = os.path.expanduser(args.get("path", ""))
                ap = os.path.realpath(p_ if os.path.isabs(p_) else os.path.join(droot or workdir, p_))
                if not os.path.isfile(ap):
                    obs = f"Dosya yok: {ap}"
                else:
                    ls_ = open(ap, encoding="utf-8", errors="replace").read().split("\n")
                    a_ = max(1, int(args.get("start", 1) or 1)); b_ = min(len(ls_), int(args.get("end", a_ + 249) or a_ + 249), a_ + 399)
                    obs = f"{ap} (toplam {len(ls_)} satır, gösterilen {a_}-{b_}):\n" + "\n".join(f"{i:5}| {ls_[i - 1]}" for i in range(a_, b_ + 1))[:24000]
            elif act == "edit_file":
                p_ = os.path.expanduser(args.get("path", ""))
                ap = safe_path(p_ if os.path.isabs(p_) else os.path.join(droot or workdir, p_), roots)
                old_, new_ = args.get("old", ""), args.get("new", "")
                if not ap:
                    obs = f"Bu dosyayı düzenleme izni yok. Sadece {droot or workdir} altında."
                elif not os.path.isfile(ap):
                    obs = f"Dosya yok: {ap} (yeni dosya için write_file kullan)"
                else:
                    src = open(ap, encoding="utf-8", errors="replace").read(); n_ = src.count(old_) if old_ else 0
                    if n_ != 1:
                        obs = ("'old' metni dosyada bulunamadı — read_file ile güncel hâlini oku ve AYNEN kopyala." if n_ == 0 else
                               f"'old' metni dosyada {n_} yerde geçiyor; tek bir yeri seçmek için daha fazla çevre satırı ekle.")
                    else:
                        import difflib
                        dif = "".join(difflib.unified_diff(src.splitlines(True), src.replace(old_, new_, 1).splitlines(True), os.path.basename(ap), os.path.basename(ap) + " (yeni)", n=2))
                        if not auto:
                            r = job.ask("confirm", {"message": f"✏️ Yapay zekâ kodu değiştirmek istiyor:\n{ap}\n💭 {d.get('thought', '')}\n\n{dif[:3500]}", "diff": True})
                            if not r or not r.get("ok"):
                                obs = "Kullanıcı bu değişikliği ONAYLAMADI. Başka bir yol düşün ya da say ile sor."
                        if not obs:
                            if droot and (ap == droot or ap.startswith(droot + os.sep)):
                                dev_prepare(droot, job.log)
                            open(ap, "w", encoding="utf-8").write(src.replace(old_, new_, 1))
                            job.ctx.setdefault("changed", []).append(ap)
                            obs = f"Düzenlendi: {ap}\n{dif[:1500]}"; job.log(f"✏️ {ap}")
                            if con: console_print(con, f"✏️ kod düzenlendi: {os.path.relpath(ap, droot or workdir)}", "95")
            elif act == "dev_commit":
                obs = dev_commit(droot or workdir, args.get("message", "geliştirme"))
                job.log("💾 " + obs)
                if con: console_print(con, "💾 " + obs, "92")
            elif act == "tool_hunt":
                obs = tool_hunt_run(job, args.get("istek") or args.get("request") or task, {"n": args.get("aday", 3), "auto": auto, "console": con.id if con else ""})
            elif act == "repo_issues":
                fn_ = args.get("repo") or opts.get("full_name") or ""
                obs = repo_issues(fn_)
                job.log(f"🐞 GitHub konuları: {fn_}")
            elif act in ("accounts", "wp", "meta_ads", "google_ads"):
                if con:
                    console_print(con, f"🔌 {act} " + json.dumps({k: v for k, v in args.items() if k not in ('body',)}, ensure_ascii=False)[:200], "95")
                try:
                    obs = integ_action(job, act, args)
                except Exception as e_:
                    obs = f"HATA ({act}): {str(e_)[:600]}"
                job.log("🔌 " + obs[:300])
            elif act.startswith("desktop_"):
                if con:
                    console_print(con, f"🖥 {act.replace('desktop_', 'masaüstü: ')} " + json.dumps({k: v for k, v in args.items() if k != 'text'}, ensure_ascii=False)[:160] + (f" «{str(args.get('text'))[:60]}»" if args.get("text") else ""), "95")
                obs = desktop_action(job, act, args)
            elif act.startswith("browser_"):
                if con:
                    br_ = args.get("urls") or args.get("queries") or args.get("url") or args.get("query") or (f"[{args.get('element')}] {args.get('text', '')}" if args.get("element") is not None else "")
                    console_print(con, f"🧭 {act.replace('browser_', 'tarayıcı: ')} {args.get('session', '')} {br_}"[:300], "95")
                obs = browser_action(job, act, args, auto)
                if job.ctx.get("unattended") and obs.startswith("Kullanıcı"):
                    obs = "Gözetimsiz çalışmada tarayıcıda tıklama/yazma yapılamaz (her adım kullanıcı onayı ister). Sadece okuma (browser_read/browse) kullan."
            else:
                obs = f"Bilinmeyen eylem: {act}. Geçerli eylemlerden birini kullan."
        except KeyError as e:
            obs = f"Bulunamadı: {e}. list_tools ile doğru slug'ı kontrol et."
        except Exception as e:
            obs = f"HATA: {str(e)[:800]}"
        job.log("👁 " + obs[:600].replace("\n", "\n   "))
        stp["obs"] = obs[:700]
        if act not in ("say", "ask_user", "finish"):  # 📜 tarif için tam kayıt
            bad = re.match(r"^(HATA|Bulunamadı|Bilinmeyen|Kullanıcı|Gözetimsiz|Konsol modu kapalı)", obs) or (act == "run" and not obs.startswith("çıkış kodu: 0"))
            if bad and not obs.startswith("Kullanıcı"):
                sess.setdefault(cur_pid, {"steps": 0, "errors": 0})["errors"] += 1
            if not tkey and act in ("run", "read_tool", "smoke_test", "set_actions"):  # oturum ortasında bir araca geçildiyse onun en iyi beynini kullan
                ts_ = resolve_tool(str(args.get("where") or args.get("slug") or ""))
                if ts_:
                    _use_best(ts_, False)
            job.ctx.setdefault("steps_full", []).append({"action": act, "args": {k: v for k, v in args.items() if k != "_desc"}, "thought": d.get("thought", "")[:300], "ok": not bad,
                                                         "cwd": (locals().get("cwd") or "") if act == "run" else "", "desc": args.get("_desc")})
        msgs += [{"role": "assistant", "content": json.dumps(d, ensure_ascii=False)}, {"role": "user", "content": "GÖZLEM: " + obs[:(24000 if act == "list_tools" else 5000)]}]
    job.status = "tamamlandı"

def repair_task(slug):
    t = tools()[slug]
    prob = []
    if t.get("status") == "hata":
        prob.append("kurulum HATA verdi")
    if not t.get("actions"):
        prob.append("çalıştırma komutu (eylem) yok")
    if t.get("test", {}).get("ok") is False:
        prob.append("son deneme başarısız")
    return (f"'{t['name']}' aracını ONAR ve çalışır hale getir (slug: {slug}, repo: {t.get('full_name')}, klasör: {t['path']}). "
            f"Sorun: {', '.join(prob) or 'çalışmıyor'}.\n"
            "ÖNCE: hata mesajı bir komut öneriyorsa (ör. \"Run `xyz setup`\", \"try: pip install ...\") ilk iş onu araç klasöründe (varsa .venv/bin/ ile) çalıştır ve smoke_test ile dene. "
            "Yapman gerekenler: read_tool ile README'yi, kurulum adımlarını ve SON HATA KAYDINI oku; hatanın kök nedenini bul; "
            "eksik sistem paketlerini/çalışma ortamlarını kur, gerekirse derle (cargo/npm/pip/docker vb. — README'deki resmi yolu izle); "
            "aracın gerçek çalıştırma komutunu bul ve set_actions ile kaydet; smoke_test ile doğrula. "
            "Bir yol tutmazsa başka yol dene (ör. hazır release dosyası, Docker, farklı Python sürümü). "
            "Araç bir doküman/liste deposuysa set_actions ile kind='doc' olarak işaretle. "
            "Sorun kodun kendisindeyse (README'deki bir özellik çalışmıyor vb.) read_file/edit_file ile düzelt ve dev_commit ile kaydet; internette araştır, GitHub konularına bak (repo_issues). "
            "ARAŞTIR VE ÜRET: Hata mesajının ayırt edici kısmını web_search ile ara; GitHub issues, Stack Overflow ve resmi belgeleri fetch_url ile OKU, çözümü kaynaklardan öğren ve uygula (okuduğun adresleri raporda yaz). "
            "Hazır bir çözüm yoksa KENDİN ÜRET: eksik dosyayı/modülü/yapılandırmayı/başlatıcı betiği write_file ile yaz, uyumsuz kodu edit_file ile düzelt (yeni Python/Node sürümüne uyarla, kaldırılmış kütüphane yerine güncelini kullan). "
            "Araç hiçbir şekilde çalışmıyorsa son çare olarak aynı işi yapan küçük, çalışan bir sarmalayıcı/araç üret (create_tool) ve kullanıcıya bunu açıkça söyle. "
            "Bitince bana ne yaptığını ve aracı nasıl kullanacağımı say/finish ile anlat; next_options içinde bu araca eklenebilecek 3 yeni özellik öner. Kullanıcıdan bilgi gerekiyorsa sor.")

def repair_cfg():
    r = cfg().get("repair") or {}
    full = bool((cfg().get("auto") or {}).get("full_repair", True)) and llm_available()
    return {"provider": r.get("provider", ""), "model": r.get("model", ""), "auto_approve": bool(r.get("auto_approve")) or full, "on_run": r.get("on_run", True), "full": full}

PW_PROMPT_RX = re.compile(r"(\[sudo\] (password|parola|şifre)[^:]*:|^(Password|Parola|Şifre|Passphrase|Enter password|Enter passphrase)[^:\n]{0,60}:|password for [\w.-]+:|Kimlik doğrulama|Authentication required|Enter PEM pass phrase)\s*$", re.I)

REPAIR_FAIL = {}  # slug -> son başarısız otomatik onarım zamanı (aynı araç için sürekli yeniden başlamasın)

def error_hints(text):
    """Hata mesajının kendisi bir çözüm komutu öneriyorsa (ör. "Run `unsloth studio setup`") onu çıkar."""
    out = []
    for m in re.finditer(r"(?:[Rr]un|[Tt]ry|[Ee]xecute|[Pp]lease run|[Yy]ou (?:can|may|should) run|[Ii]nstall (?:it )?with|[Çç]alıştır(?:ın)?)[:\s]+[`'\"]([^`'\"\n]{3,160})[`'\"]", text or ""):
        c = m.group(1).strip()
        if re.match(r"^(pip3?|python3?|uv|npm|npx|pnpm|yarn|cargo|go|apt(-get)?|sudo|make|cmake|bash|sh|\./|\.venv/|[\w.-]+ (setup|install|init|download|update|build|fetch|configure|login))", c) or re.match(r"^[\w.-]+( [\w.:=/-]+){0,6}$", c):
            if not danger_warnings([c]) and c not in out and not re.search(r"chmod \+x llama-server|<|>|\bYOUR_|\.\.\.", c):
                out.append(c)
    return out[:3]

# ── Yerel ağır kurulumlar (Ollama, model indirme, llama.cpp…): tam otomatikte bile önce kullanıcıya sorulur ──
HEAVY_RX = re.compile(r"\bollama\b|ollama\.com/install|\b(hf|huggingface-cli)\s+download|\.gguf\b|llama[.\-_]?cpp|llama-server|\bvllm\b|\blms\s+get|lm[- ]?studio|\blocalai\b|text-generation-webui|\bgit\s+lfs\s+pull|\bstudio\s+setup\b", re.I)

def heavy_cmds(cmds):
    return [c for c in (cmds or []) if HEAVY_RX.search(str(c or ""))]

def heavy_policy():
    return (cfg().get("auto") or {}).get("heavy", "ask")   # ask · never (bir daha sorma, hiç yapma) · always

def set_heavy_policy(v):
    c = cfg(); a = c.get("auto") or {}; a["heavy"] = v; c["auto"] = a; save_cfg(c)

def heavy_ok(job, cmds, why=""):
    """Yerel model/Ollama gibi bilgisayarı yoran bir kurulumsa önce sor; 'bir daha sorma' denirse kalıcı olarak hiç yapma."""
    h = heavy_cmds(cmds)
    if not h:
        return True
    pol = heavy_policy()
    if pol == "never":
        job.log("⏸ Yerel ağır kurulum atlandı (yerel kurulum istemediğini söylemiştin): " + h[0][:140]); return False
    if pol == "always":
        return True
    r = job.ask("confirm", {"heavy": True, "name": job.title,
                            "message": "Bilgisayarına YEREL yapay zekâ / model kurulumu yapılmak isteniyor (işlemci, RAM ve disk kullanır):\n" + "\n".join(h[:3]) + (f"\n\nNeden: {why[:300]}" if why else "")})
    ch = ((r or {}).get("data") or {}).get("choice") or ("yes" if (r or {}).get("ok") else "no")
    if ch == "never":
        set_heavy_policy("never"); job.log("⏸ Tamam — yerel ağır kurulumlar bir daha sorulmayacak ve yapılmayacak (Ayarlar → Otomatik işler'den değiştirebilirsin)."); return False
    if ch == "always":
        set_heavy_policy("always"); return True
    return ch == "yes"

HEAVY_NO = "Kullanıcı bu YEREL ağır kurulumu (Ollama / yerel model / llama.cpp vb.) istemiyor. Bunu bir daha önerme; bulut API'leriyle ya da hafif başka bir yolla çöz."

def hint_fix(job, slug, err, say=None):
    """1. tur (yapay zekâsız, saniyeler): hata mesajının önerdiği komutu araç klasöründe (venv'i kullanarak) dene."""
    t = tools()[slug]; root = t["path"]; say = say or job.log
    for c in error_hints(err):
        first = c.split()[0]
        for vb in (".venv/bin", "venv/bin", "env/bin"):
            if not shutil.which(first) and os.path.exists(os.path.join(root, vb, first)):
                c = os.path.join(vb, first) + c[len(first):]; break
        if not heavy_ok(job, [c], "Hata mesajı bu komutu öneriyor"):
            continue
        say(f"💡 Hata mesajı bir çözüm öneriyor, önce onu deniyorum: {c}")
        rc, out = run_capture(job, c, root)
        if rc != 0:
            say(f"   ✖ olmadı (çıkış {rc}): {str(out)[-200:]}"); continue
        ok, o2 = tool_healthy(job, slug)
        if ok:
            update_tool(slug, status="kuruldu", last_error="", last_run_error="")
            try: learn_error(error_signature(err), f"{t['name']} hatası", [c], "Hata mesajının kendi önerdiği komut")
            except Exception: pass
            say(f"✅ {t['name']} onarıldı — hata mesajının önerdiği komut işe yaradı: {c}")
            return True
        say("   … komut çalıştı ama araç hâlâ sorunlu, devam ediyorum")
    return False

def repairing(slug):
    return any(j.kind == "agent" and j.slug == slug and j.status not in ("tamamlandı", "hata", "iptal") for j in JOBS.values())

def repair_flow(job, slug):
    t = tools()[slug]; root = t["path"]; job.slug = slug; job.icon = t.get("icon", ""); job.title = f"🛠 Onarım: {t['name']}"
    job.log(f"🛠 {t['name']} onarılıyor — önce yapay zekâsız hızlı onarım…")
    if not os.path.isdir(root):
        job.log("✖ Araç klasörü yok; yeniden kurulmalı."); job.status = "hata"; return
    doc = is_doc_repo(root)
    acts, steps = discover_actions(root, os.path.basename(root))
    if doc:
        job.log("📄 Bu depo bir liste/doküman deposu — asıl kullanımı okumak. '📖 Oku' düğmesi eklendi.")
        if acts:
            job.log("   Ayrıca içindeki betikler için düğmeler bulundu: " + ", ".join(a["label"] for a in acts))
        update_tool(slug, kind="doc", status="kuruldu", actions=acts or t.get("actions", []), last_error="")
        job.status = "tamamlandı"; return
    allacts = (t.get("actions") or []) + acts
    if any(".venv/" in a["command"] for a in allacts) and not os.path.exists(os.path.join(root, ".venv", "bin", "python")):
        hp = heuristic_plan(root, os.path.basename(root))
        steps = [x for x in hp["steps"] if x not in steps] + steps
        for rt in hp.get("runtimes", []):
            ensure_runtime(rt, job.log)
        update_tool(slug, steps=list(dict.fromkeys((t.get("steps") or []) + hp["steps"])))
    if steps:
        job.log("📦 Önce eksik ortam/bağımlılıklar kuruluyor:\n   " + "\n   ".join(steps))
        plan = finalize_plan(root, {"name": t["name"], "steps": steps, "actions": [], "warnings": []})
        if plan.get("deps"):
            run_steps(job, plan["deps"], root)
        run_steps(job, steps, root)
        acts, _ = discover_actions(root, os.path.basename(root))  # ortam kurulduktan sonra yeniden keşfet (.venv python'u kullanılsın)
    existing = t.get("actions") or []
    if not acts and not existing:
        job.log("ℹ Depoda çalıştırılabilir bir giriş noktası bulunamadı.")
    elif acts:
        job.log("🔎 Bulunan çalıştırma yolları:\n   " + "\n   ".join(f"[{a['label']}] {a['command']}" for a in acts))
        update_tool(slug, actions=acts if not existing else existing + [a for a in acts if a["command"] not in [e["command"] for e in existing]], kind="tool")
    t = tools()[slug]
    if t.get("actions"):
        ok, out = smoke_test(job, slug)
        if ok:
            update_tool(slug, status="kuruldu", last_error=""); make_shortcuts(tools()[slug])
            job.log(f"✅ Onarıldı! '{t['actions'][0]['label']}' ile çalıştırabilirsin."); job.status = "tamamlandı"
            notify(APP, f"{t['name']}: onarıldı ✅"); return
        job.log("⚠ Bulunan komut denendi ama hata verdi.")
        dg = diagnose(out, t)
        if dg and any(d["commands"] for d in dg):
            cmds = [c for d in dg for c in d["commands"]]
            job.log("📚 Bilinen hata: " + "; ".join(d["title"] for d in dg))
            r = {"ok": True, "data": {"steps": cmds}} if repair_cfg()["auto_approve"] else job.ask("fix", {"why": [f"{d['title']} — {d['cause']}" for d in dg], "steps": cmds, "failed": "", "output": out[-2000:]})
            if r and r.get("ok"):
                for c in [x for x in (r.get("data") or {}).get("steps") or cmds if x.startswith("@runtime ")]:
                    ensure_runtime(c.split()[1], job.log)
                run_steps(job, [x for x in (r.get("data") or {}).get("steps") or cmds if not x.startswith("@")], root)
                ok, out = smoke_test(job, slug)
                if ok:
                    update_tool(slug, status="kuruldu", last_error=""); job.log("✅ Onarıldı!"); job.status = "tamamlandı"; return
    if llm_available():
        try:
            if multi_fix_round(job, slug, (locals().get("out") or "") if t.get("actions") else ""):
                job.status = "tamamlandı"; return
        except Exception as e:
            job.log(f"⚠ Çok beyinli öneri turu yapılamadı: {str(e)[:150]}")
        job.log("🤖 Öneriler yetmedi → Görev Ajanı derin onarıma başlıyor; başaramazsa sıradaki API devralacak.")
        j = start_agent_repair(slug); job.ctx["agent_job"] = j.id
        job.log(f"   Görev Ajanı sekmesinden izleyebilirsin (görev {j.id}).")
        job.status = "tamamlandı"; return
    job.log("ℹ Daha derin onarım için yapay zekâ gerekiyor: 🧯 Hata Çözümleri → '+ API bağla' (ücretsiz: OpenRouter/Gemini/Groq).")
    job.status = "hata"

# ═════════════════════════════ 🧠🧠 ÇOK BEYİNLİ ONARIM (tüm API'ler dener, biri başarana kadar) ═════════════════════════════
def tool_healthy(job, slug):
    t = tools().get(slug) or {}
    if t.get("kind") == "doc":
        return True, ""
    if not t.get("actions"):
        return False, "çalıştırma komutu (eylem) yok"
    return smoke_test(job, slug)

def _repair_ctx(slug, err=""):
    t = tools()[slug]; oi = os_info()
    return (f"ARAÇ: {t['name']} (repo: {t.get('full_name')}, klasör: {t['path']})\nSİSTEM: {oi.get('PRETTY_NAME', 'Linux')} | paket yöneticisi: {detect_pm()} | "
            f"{platform.machine()} | Python {platform.python_version()} | node: {'var' if which('node') else 'yok'} | root: {'evet' if is_root() else 'hayır'}\n"
            f"KURULUM ADIMLARI: {json.dumps(t.get('steps', []), ensure_ascii=False)[:1200]}\nÇALIŞTIRMA EYLEMLERİ: {json.dumps(t.get('actions', []), ensure_ascii=False)[:600]}\n"
            f"HATA ÇIKTISI (son kısım):\n{(err or t.get('last_error') or t.get('last_run_error') or '')[-3500:]}\n\nREADME (kısa):\n{read_readme(t['path'], 2500)}\n\n"
            f"DOSYALAR:\n{file_tree(t['path'], 50)}")

def multi_fix_round(job, slug, err="", max_try=4, auto=None):
    """1. tur: hata kaydı TÜM API'lere aynı anda sorulur; öneriler puanlanıp en iyisinden başlayarak denenir — biri çalışınca durulur."""
    provs = [p for p in cfg().get("providers", []) if p.get("enabled", True)]
    if not provs:
        return False
    t = tools()[slug]; root = t["path"]
    job.log(f"🧠 Hata kurulu {len(provs)} API'ye aynı anda soruluyor; her biri çözüm önerecek…")
    sysm = ("Sen Linux'ta GitHub araçlarının kurulum hatalarını çözen bir uzmansın. Hatanın KÖK NEDENİNİ bul ve aracın klasöründe sırayla çalıştırılacak düzeltme komutlarını yaz. "
            "Global kurulum yerine proje içi .venv / yerel npm tercih et. Sistem paketi gerekiyorsa sudo ile yaz. Tehlikeli/yıkıcı komut yazma. "
            "Eksik bir dosya/betik/yapılandırma gerekiyorsa onu oluşturan komutu da yazabilirsin (ör. cat > dosya <<'EOF' … EOF). "
            "SADECE JSON: {\"neden\": \"Türkçe kısa açıklama\", \"komutlar\": [\"...\"], \"eylem\": {\"label\": \"Başlat\", \"command\": \"aracı başlatan komut (bilmiyorsan boş)\"}, \"guven\": 0-100}")
    ctx = _repair_ctx(slug, err)
    props = {}
    def one(p):
        t0 = time.time()
        try:
            txt = llm_call(p, [{"role": "user", "content": ctx}], sysm, None, timeout=90)
            d = extract_json(txt); cmds = [str(c).strip() for c in (d.get("komutlar") or []) if str(c).strip()][:12]
            props[p["id"]] = {"p": p, "neden": str(d.get("neden", ""))[:400], "cmds": cmds, "eylem": d.get("eylem") or {}, "guven": int(d.get("guven") or 50), "ms": (time.time() - t0) * 1000}
        except Exception as e:
            job.log(f"   ⚠ {p.get('name')}: öneri alınamadı ({str(e)[:90]})")
    ths = [threading.Thread(target=one, args=(p,), daemon=True) for p in provs[:10]]
    [x.start() for x in ths]; [x.join(100) for x in ths]
    cands = [v for v in props.values() if (v["cmds"] or (v["eylem"] or {}).get("command")) and not danger_warnings(v["cmds"]) and not (heavy_policy() == "never" and heavy_cmds(v["cmds"]))]
    if not cands:
        job.log("   Hiçbir API uygulanabilir bir öneri vermedi."); return False
    sig = lambda v: tuple(v["cmds"][:2])
    votes = {}
    for v in cands:
        votes[sig(v)] = votes.get(sig(v), 0) + 1
    hist = tool_ai_scores(slug)
    for v in cands:  # puan: kaç API aynı çözümde birleşti + kendi güveni + bu araçtaki geçmiş başarısı
        v["score"] = votes[sig(v)] * 30 + v["guven"] * 0.4 + (hist.get(v["p"]["id"], {}).get("score", 50)) * 0.3
    seen = set(); order = []
    for v in sorted(cands, key=lambda v: -v["score"]):
        k = (sig(v), (v["eylem"] or {}).get("command", ""))
        if k not in seen:
            seen.add(k); order.append(v)
    for i, v in enumerate(order[:max_try], 1):
        if job.cancelled:
            return False
        nm = f"{v['p'].get('name')} · {v['p'].get('model')}"
        job.log(f"\n🧠 Öneri {i}/{min(len(order), max_try)} — {nm} (puan {v['score']:.0f}, {votes[sig(v)]} API aynı fikirde)\n   Neden: {v['neden']}\n   Komutlar:\n   " + "\n   ".join(v["cmds"] or ["(komut yok, sadece çalıştırma komutu düzeltmesi)"]))
        if not (repair_cfg()["auto_approve"] if auto is None else auto):
            r = job.ask("fix", {"why": [f"🧠 {nm}: {v['neden']}"], "steps": v["cmds"], "failed": "", "output": (err or t.get("last_error") or "")[-1500:]})
            if not r or not r.get("ok"):
                job.log("   ↷ Bu öneri atlandı."); continue
            v["cmds"] = (r.get("data") or {}).get("steps") or v["cmds"]
        for c in [x for x in v["cmds"] if x.startswith("@runtime ")]:
            ensure_runtime(c.split()[1], job.log)
        if not heavy_ok(job, v["cmds"], v.get("neden", "")):
            continue
        run_steps(job, [x for x in v["cmds"] if not x.startswith("@")], root)
        ev = v["eylem"] or {}
        if ev.get("command") and not tools()[slug].get("actions"):
            update_tool(slug, actions=[{"label": ev.get("label") or "Başlat", "command": ev["command"], "terminal": True}])
        ok, out = tool_healthy(job, slug)
        tool_ai_record(slug, v["p"]["id"], ok, 1, 0 if ok else 1)
        if ok:
            update_tool(slug, status="kuruldu", last_error="")
            try: make_shortcuts(tools()[slug])
            except Exception: pass
            sg = error_signature(err or t.get("last_error") or "")
            if sg and v["cmds"]:
                try: learn_error(sg, f"{t['name']} kurulum hatası", v["cmds"], v["neden"])
                except Exception: pass
            job.log(f"✅ ONARILDI — çözümü bulan: {nm}. Çözüm bilgi bankasına kaydedildi; bir dahakine anında uygulanır.")
            notify(APP, f"{t['name']}: onarıldı ✅ ({v['p'].get('name')})")
            return True
        job.log(f"   ✖ Bu öneri işe yaramadı: {str(out)[-300:]}")
        err = (err or "") + "\n--- denenen öneri sonrası çıktı ---\n" + str(out)[-1500:]
    return False

def escalating_repair_flow(job, slug, extra="", base_opts=None):
    """2. tur: Görev Ajanı en iyi API ile onarır; başaramazsa önceki denemelerin özetiyle SIRADAKİ API'ye devreder — araç çalışana kadar."""
    t = tools()[slug]; job.slug = slug; job.icon = t.get("icon", "")
    d = cfg().get("agent_defaults", {}) or {}; rc = repair_cfg()
    live = [p for p in cfg().get("providers", []) if p.get("enabled", True)]
    hist = tool_ai_scores(slug)
    first = rc["provider"] or (base_opts or {}).get("provider") or ""
    order = sorted(live, key=lambda p: (0 if p["id"] == first else 1, -(hist.get(p["id"], {}).get("score", 50))))
    # her API'nin varsayılan modeli önce, sonra aynı API'deki diğer modeller — "kaç model varsa hepsi denesin"
    tries = [(p, p.get("model", "")) for p in order]
    for p in order:
        for m_ in list(dict.fromkeys(p.get("models") or []))[:3]:
            if m_ and m_ != p.get("model"): tries.append((p, m_))
    tries = tries[:10] if rc["full"] else tries[:5]
    notes = []; bo = base_opts or {}; con = PROCS.get(bo.get("console") or "")
    if con:
        job.ctx["console"] = con.id
    def say(x):
        job.log(x)
        if con: console_print(con, x, "1;33")
    job.ctx.setdefault("chat", []).append({"role": "user", "text": f"🛠 {t['name']} onarılıyor"})
    err0 = (t.get("last_run_error") or "") + "\n" + (t.get("last_error") or "") + "\n" + extra
    try:
        if hint_fix(job, slug, err0, say):
            msg = f"✅ **{t['name']} onarıldı** (hata mesajının önerdiği komutla)."
            job.ctx["chat"].append({"role": "agent", "text": msg, "final": True}); job.ctx["report"] = msg; job.status = "tamamlandı"; return
    except Exception as e:
        job.log(f"⚠ İpucu denemesi yapılamadı: {str(e)[:150]}")
    if not live:
        say("✖ Onarım için yapay zekâ API'si yok. 🆓 Ücretsiz AI sekmesinden anahtarsız bir model ekleyebilirsin."); job.status = "hata"; return
    if rc["full"]:
        say(f"🤖 Tam otomatik onarım: onay sorulmadan {len(live)} API / {len(tries)} model sırayla deneyecek (tehlikeli komutlar engellenir).")
    if bo.get("multi", True) or rc["full"]:
        say(f"🛠 {t['name']} onarılıyor — önce hata kurulu {len(live)} API'ye aynı anda soruluyor…")
        try:
            if multi_fix_round(job, slug, t.get("last_run_error") or t.get("last_error") or "", auto=bool(bo.get("auto")) or rc["auto_approve"]):
                msg = f"✅ **{t['name']} onarıldı** (API'lerin önerilerinden biri işe yaradı)."
                job.ctx["chat"].append({"role": "agent", "text": msg, "final": True}); job.ctx["report"] = msg; say(msg.replace("**", "")); return
        except Exception as e:
            job.log(f"⚠ Öneri turu yapılamadı: {str(e)[:150]}")
        say("🔎 Öneriler yetmedi → yapay zekâ araştırıp kendisi onaracak; başaramazsa sıradaki API devralacak.")
    N = len(tries)
    for i, (p, mdl) in enumerate(tries, 1):
        if job.cancelled:
            return
        mname = mdl or p.get("model")
        say(f"🧠 Onarım denemesi {i}/{N}: {p.get('name')} · {mname}")
        job.log(f"\n══════ 🧠 Onarım denemesi {i}/{N}: {p.get('name')} · {mname} ══════")
        task = repair_task(slug) + (("\n" + extra) if extra else "")
        if notes:
            task += ("\n\nÖNCEKİ DENEMELER BAŞARISIZ OLDU (aynı şeyleri tekrarlama, FARKLI bir yol dene — ör. başka kurulum yöntemi, hazır release, farklı Python/Node sürümü, Docker):\n" + "\n".join(notes))
        o = {"workdir": t["path"], "develop_root": t["path"], "full_name": t.get("full_name", ""), "tool_key": slug, "provider": p["id"], "model": "",
             "persona": d.get("persona", ""), "auto": rc["auto_approve"] or bool(d.get("auto")), "repair": True, "unattended": True, "keep_chat": i > 1,
             "title": f"🛠 {t['name']} — {p.get('name')} onarıyor", **(base_opts or {}),
             "shown": f"🛠 {t['name']} onarılıyor — {i}. deneme: {p.get('name')} · {p.get('model')}" + (" (öncekiler başaramadı)" if notes else "")}
        o["provider"] = p["id"]; o["model"] = mdl if mdl != p.get("model") else ""; o["unattended"] = True; o["watched"] = bool(con)
        o["max_steps"] = 18 if N > 1 else 35   # takılan model çok beklemeden sıradakine devretsin
        if rc["full"]: o["auto"] = True
        agent_flow(job, task, o)
        if job.cancelled:
            return
        ok, out = tool_healthy(job, slug)
        if ok:
            update_tool(slug, status="kuruldu", last_error="")
            try: make_shortcuts(tools()[slug])
            except Exception: pass
            msg = f"✅ **{t['name']} onarıldı** — başaran: {p.get('name')} · {mname} ({i}. deneme)."
            job.log(msg); job.ctx.setdefault("chat", []).append({"role": "agent", "text": msg, "final": True}); job.ctx["report"] = msg
            notify(APP, f"{t['name']}: onarıldı ✅"); job.status = "tamamlandı"
            con = PROCS.get(job.ctx.get("console", ""))
            if con: console_print(con, "✅ " + msg.replace("**", ""), "92")
            return
        tool_ai_record(slug, p["id"], False, 1, 1)
        notes.append(f"- {p.get('name')} · {mname}: {(job.ctx.get('report') or '')[:500]} → SONUÇ: hâlâ çalışmıyor: {str(out)[-300:]}")
        say(f"✖ {p.get('name')} · {mname} başaramadı" + (" — sıradaki model devralıyor…" if i < N else ""))
        job.status = "çalışıyor"
    REPAIR_FAIL[slug] = time.time()
    msg = f"✖ {t['name']} için {N} model denendi ama araç hâlâ çalışmıyor. Kayıtlara bakıp Konsol'da birlikte çözebiliriz."
    job.log(msg); job.ctx.setdefault("chat", []).append({"role": "agent", "text": msg, "final": True}); job.status = "hata"

# ═════════════════════════════ 🏁 ARAÇ YARIŞMASI (tüm API'ler arar → oylar → en iyiler kurulup denenir → kazanan kalır) ═════════════════════════════
def _hunt_say(job, con, text, step=None):
    if step:
        job.ctx.setdefault("chat", []).append({"role": "step", "n": len(job.ctx.get("chat", [])), "thought": "", "action": step, "args": {"note": text[:200]}})
    job.log(text)
    if con: console_print(con, "🏁 " + re.sub(r"[*#`]", "", text)[:400], "95")

def _ask_all(prompt, system, n=10, timeout=90, prefer=""):
    provs = [p for p in cfg().get("providers", []) if p.get("enabled", True)]
    provs = sorted(provs, key=lambda p: 0 if p["id"] == prefer else 1)[:n]; out = {}
    def one(p):
        try:
            out[p["id"]] = (p, extract_json(llm_call(p, [{"role": "user", "content": prompt}], system, None, timeout=timeout)))
        except Exception:
            pass
    ths = [threading.Thread(target=one, args=(p,), daemon=True) for p in provs]
    [t.start() for t in ths]; [t.join(timeout + 10) for t in ths]
    return out

def tool_hunt_run(job, request, opts=None):
    import math
    opts = opts or {}; n_try = max(1, min(5, int(opts.get("n", 3)))); auto = bool(opts.get("auto")); con = PROCS.get(opts.get("console") or "")
    if not llm_available():
        raise RuntimeError("Araç yarışması için en az bir yapay zekâ API'si gerekli.")
    _hunt_say(job, con, f"🏁 Araç yarışması başladı: “{request}”", "search_github")
    # 1) tüm API'ler arama sorgusu + bildikleri depoları önerir
    res = _ask_all(f"Kullanıcı Linux için şu işi yapan bir GitHub aracı istiyor: {request}\n"
                   "GitHub'da aramak için 3 kısa İNGİLİZCE arama sorgusu ve bildiğin en iyi 5 aday depoyu (sahip/ad) ver. SADECE JSON: "
                   "{\"queries\": [\"...\"], \"repos\": [\"owner/name\"]}", "Sen açık kaynak araçları çok iyi bilen bir uzmansın. Var olmayan depo uydurma.")
    queries, named = [], {}
    for pid, (p, d) in res.items():
        queries += [str(q)[:80] for q in (d.get("queries") or [])[:3]]
        for r in (d.get("repos") or [])[:6]:
            r = str(r).strip().removeprefix("https://github.com/").strip("/")
            if re.match(r"^[\w.-]+/[\w.-]+$", r):
                named[r] = named.get(r, 0) + 1
    queries = list(dict.fromkeys(queries))[:9] or [request]
    _hunt_say(job, con, f"🔎 {len(res)} API {len(queries)} arama sorgusu ve {len(named)} aday depo önerdi; GitHub'da aranıyor…")
    cands = {}
    for q_ in queries:
        try:
            for it in gh_search(q_, 6):
                c = cands.setdefault(it["repo"], dict(it, votes=0, found=0)); c["found"] += 1
        except Exception as e:
            job.log(f"⚠ Arama hatası ({q_}): {str(e)[:100]}")
    for r, v in named.items():
        if r not in cands:
            try:
                g = gh_api(f"/repos/{r}")
                if g.get("archived"):
                    continue
                cands[r] = {"repo": g["full_name"], "stars": g.get("stargazers_count", 0), "description": (g.get("description") or "")[:200], "language": g.get("language") or "",
                            "updated": (g.get("pushed_at") or "")[:10], "license": ((g.get("license") or {}).get("spdx_id") or ""), "url": g.get("html_url"), "votes": 0, "found": 0}
            except Exception:
                continue
        if r in cands:
            cands[r]["named"] = v
    if not cands:
        return "GitHub'da uygun aday bulunamadı (ağ ya da GitHub kotası engelli olabilir; Ayarlar'dan GitHub token ekleyebilirsin)."
    def pre(c):
        age = (time.time() - _iso_ts((c.get("updated") or "") + "T00:00:00")) / 86400 if c.get("updated") else 9999
        return (math.log10(c.get("stars", 0) + 1) * 12 + c.get("found", 0) * 6 + c.get("named", 0) * 10 - (15 if age > 730 else 6 if age > 365 else 0) + (3 if c.get("license") else 0))
    top = sorted(cands.values(), key=pre, reverse=True)[:8]
    job.ctx["candidates"] = top
    _hunt_say(job, con, f"📋 {len(cands)} aday bulundu; ön elemeden geçen {len(top)} aday: " + ", ".join(f"{c['repo']} (⭐{c['stars']})" for c in top))
    # 2) tüm API'ler README'lere bakıp oy verir
    brief = ""
    for c in top:
        rd = re.sub(r"\s+", " ", gh_readme(c["repo"], 1500))[:900]
        brief += f"\n### {c['repo']} | ⭐{c['stars']} | son güncelleme {c['updated']} | {c['language']} | lisans {c['license'] or '-'}\n{c['description']}\nREADME: {rd}\n"
    votes = _ask_all(f"Kullanıcının isteği: {request}\nAdaylar:{brief}\n\nİsteğe EN UYGUN, Linux'ta çalışan ve bakımı süren en iyi 3 adayı sırala. SADECE JSON: "
                     "{\"sirala\": [\"owner/name\", \"...\"], \"neden\": \"1-2 cümle Türkçe\"}", "Tarafsız bir değerlendiricisin. Sadece listedeki adaylardan seç.")
    reasons = []
    for pid, (p, d) in votes.items():
        for i, r in enumerate((d.get("sirala") or [])[:3]):
            r = str(r).strip().removeprefix("https://github.com/").strip("/")
            for c in top:
                if c["repo"].lower() == r.lower():
                    c["votes"] += 3 - i
        if d.get("neden"):
            reasons.append(f"{p.get('name')}: {str(d['neden'])[:200]}")
    for c in top:
        c["pre"] = round(pre(c), 1)
    final = sorted(top, key=lambda c: (c["votes"] * 8 + c["pre"]), reverse=True)[:n_try]
    _hunt_say(job, con, f"🗳️ {len(votes)} API oy verdi. Denenecek ilk {len(final)}: " + ", ".join(f"{c['repo']} ({c['votes']} oy)" for c in final), "repo_info")
    # 3) kur ve dene
    installed_before = {(t.get("source") or "").lower().rstrip("/").removesuffix(".git"): s_ for s_, t in tools().items()}
    results = []
    for c in final:
        if job.cancelled:
            break
        url = f"https://github.com/{c['repo']}"; r_ = {"repo": c["repo"], "stars": c["stars"], "updated": c["updated"], "votes": c["votes"], "slug": "", "new": False,
                                                    "install": "-", "test": "-", "judge": None, "score": 0, "note": ""}
        results.append(r_); job.ctx["hunt"] = results
        slug = installed_before.get(url.lower())
        if slug:
            r_.update(slug=slug, install="zaten kurulu")
        else:
            _hunt_say(job, con, f"⬇️ Kuruluyor: {c['repo']}", "install")
            sub = start_job(f"🏁 Kurulum: {c['repo']}", "install", install_flow, url, {"auto": auto}, auto=auto)
            sub.ctx["no_auto_repair"] = True; sub.ctx["block_danger"] = True
            if con: sub.ctx["mirror"] = con.id
            while sub.status not in ("tamamlandı", "hata", "iptal"):
                if job.cancelled:
                    sub.cancelled = True; break
                time.sleep(1.5)
            slug = sub.slug if sub.slug in tools() else ""
            r_.update(slug=slug, new=bool(slug), install={"tamamlandı": "✔", "hata": "✖ hata", "iptal": "✖ " + (sub.ctx.get("blocked") or "iptal")}.get(sub.status, sub.status))
        if not slug or r_["install"].startswith("✖"):
            r_["note"] = "kurulamadı"; continue
        # 4) isteğe özel güvenli test
        t = tools()[slug]; ok, out = tool_healthy(job, slug)
        r_["test"] = "✔ çalışıyor" if ok else "✖ çalışmıyor"
        if not ok:
            r_["note"] = str(out)[-160:]; r_["score"] = 10; continue
        name, root, hlp, readme = tool_ai_ctx(slug)
        best = tool_ai_best(slug)
        gen = _ask_all(f"ARAÇ: {name}\nYARDIM:\n{hlp[:3000]}\nBELGE:\n{readme[:2500]}\n\nKullanıcının istediği özellik: {request}\n"
                       "Bu özelliği GÜVENLİ ve ETKİLEŞİMSİZ biçimde gösteren tek bir test komutu yaz (aracın klasöründe çalışır, 60 sn'den kısa). "
                       "Sadece yerel/zararsız girdiler kullan (örnek dosya oluşturabilirsin, localhost, --help, --dry-run); başkasına ait sistemlere/sitelere istek ATMA. "
                       "SADECE JSON: {\"command\": \"...\", \"beklenen\": \"çıktıda ne görülmeli\"}", "Sen dikkatli bir test mühendisisin.", n=1, prefer=best)
        g = next(iter(gen.values()), (None, {}))[1] if gen else {}
        cmd = str(g.get("command") or "").strip()
        tout = ""
        if cmd and not danger_warnings([cmd]):
            _hunt_say(job, con, f"🧪 {c['repo']} deneniyor: {cmd[:160]}", "smoke_test")
            rc, tout = run_capture(job, f"timeout 60 bash -c {q(cmd)}", t["path"], 75)
            r_["test"] = f"{'✔' if rc == 0 else '✖'} özellik testi (kod {rc})"
        jd = _ask_all(f"Kullanıcının isteği: {request}\nAraç: {c['repo']}\nTest komutu: {cmd or '(yok, sadece --help)'}\nBeklenen: {g.get('beklenen', '')}\nÇIKTI:\n{(tout or out)[-2500:]}\n\n"
                      "Bu araç kullanıcının isteğini ne kadar karşılıyor? 0-10 puan ver. SADECE JSON: {\"puan\": 0-10, \"yorum\": \"1 cümle Türkçe\"}",
                      "Tarafsız ve kanıta dayalı değerlendir; çıktıda görmediğin bir şeyi varsayma.", n=3)
        pts = [max(0, min(10, float(d.get("puan", 0)))) for _, d in jd.values() if isinstance(d, dict)]
        r_["judge"] = round(sum(pts) / len(pts), 1) if pts else None
        r_["note"] = next((str(d.get("yorum", ""))[:160] for _, d in jd.values() if d.get("yorum")), "")
        sec = (t.get("security") or {}).get("level", "ok")
        r_["score"] = round(40 + (r_["judge"] or 5) * 4 + min(15, math.log10(c["stars"] + 1) * 4) + min(10, c["votes"]) - (15 if sec == "warn" else 0), 1)
    ranked = sorted(results, key=lambda r: -r["score"])
    win = ranked[0] if ranked and ranked[0]["score"] > 10 else None
    tbl = "| Aday | ⭐ | Son güncelleme | Oy | Kurulum | Test | Değerlendirme | Puan |\n|---|---|---|---|---|---|---|---|\n" + "\n".join(
        f"| {'🏆 ' if r is win else ''}{r['repo']} | {r['stars']} | {r['updated']} | {r['votes']} | {r['install']} | {r['test']} | {('%s/10' % r['judge']) if r['judge'] is not None else '-'} {r['note']} | **{r['score']}** |"
        for r in ranked)
    rep_ = f"## 🏁 Araç yarışması: {request}\n\n{tbl}\n\n" + (f"**Kazanan: {win['repo']}** — kurulu ve hazır (araç adı: `{win['slug']}`)." if win else "Hiçbir aday çalışır hale gelmedi.")
    if reasons:
        rep_ += "\n\n**API'lerin görüşleri:**\n" + "\n".join(f"- {x}" for x in reasons[:5])
    losers = [r for r in results if r is not win and r.get("new") and r.get("slug")]
    if win and losers:
        rm_ = opts.get("remove")
        if rm_ is None:
            rr = job.ask("confirm", {"message": f"🏆 Kazanan: {win['repo']}\nBu yarışmada kurulan diğer {len(losers)} aday kaldırılsın mı?\n" + "\n".join("• " + r["repo"] for r in losers)})
            rm_ = bool(rr and rr.get("ok"))
        if rm_:
            for r in losers:
                try: uninstall_tool(r["slug"]); r["note"] += " (kaldırıldı)"
                except Exception: pass
            rep_ += f"\n\n🗑 Kaybeden {len(losers)} aday kaldırıldı."
    job.ctx["report"] = rep_; job.ctx["hunt"] = results
    _hunt_say(job, con, "🏆 Kazanan: " + (win["repo"] if win else "yok"))
    return rep_

def tool_hunt_flow(job, request, opts):
    job.title = "🏁 " + request[:60]; job.ctx["task"] = request; job.ctx["chat"] = [{"role": "user", "text": "🏁 " + request}]
    if opts.get("console"): job.ctx["console"] = opts["console"]
    rep_ = tool_hunt_run(job, request, opts)
    win = next((r for r in sorted(job.ctx.get("hunt") or [], key=lambda r: -r["score"]) if r["score"] > 10), None)
    job.ctx["chat"].append({"role": "agent", "text": rep_, "final": True,
                            "options": ([f"{win['slug']} aracını aç ve neler yapabildiğini göster", f"{win['slug']} ile isteğimi yap"] if win else ["Farklı kelimelerle tekrar ara"])})
    notify(APP, "🏁 Araç yarışması bitti" + (f": {win['repo']} kazandı" if win else ""))

def start_agent_repair(slug, extra=""):
    if repairing(slug):
        return next(j for j in JOBS.values() if j.kind == "agent" and j.slug == slug and j.status not in ("tamamlandı", "hata", "iptal"))
    d = cfg().get("agent_defaults", {}) or {}; rc = repair_cfg()
    t = tools()[slug]
    j = start_job(f"🛠 Onarım: {t['name']}", "agent", escalating_repair_flow, slug, extra, {"multi": rc["full"]})
    j.slug = slug; j.icon = t.get("icon", "")
    return j

def agent_reflect(job, msgs, sysmsg, opts):
    """Oturumdan kalıcı dersler çıkarır (kendini geliştirme)."""
    if len(msgs) < 4:
        return
    try:
        txt, _ = llm_ask(msgs[:1] + msgs[-30:] + [{"role": "user", "content":
            "OTURUM BİTTİ. Bu oturumdan gelecekte işine yarayacak en fazla 5 kalıcı ders/tercih/araç bilgisi çıkar "
            "(ör. 'X işi için Y aracı iyi çalışıyor: komut …', 'Kullanıcı çıktıları masaüstüne istiyor', 'Z kurulumunda şu hata şöyle çözüldü'). "
            "Zaten hafızada olanları tekrar etme. SADECE JSON: {\"notes\":[{\"note\":\"...\",\"kind\":\"ders|tercih|araç\"}]}"}],
            sysmsg, opts.get("provider", ""), opts.get("model", ""))
        notes = extract_json(txt).get("notes", [])
        for n in notes[:5]:
            mem_add(n.get("note", ""), n.get("kind", "ders"))
        if notes:
            job.log("🧠 Bu oturumdan öğrenilenler hafızaya yazıldı:\n   • " + "\n   • ".join(n.get("note", "") for n in notes[:5]))
    except Exception as e:
        job.log(f"(ders çıkarma atlandı: {str(e)[:100]})")

def agent_create_tool(job, a, opts):
    name = a.get("name") or "ajan-araci"
    dest = unique_dir(TOOLS_DIR, slugify(name)); os.makedirs(dest)
    slug = os.path.basename(dest)
    files = a.get("files") or {}
    for rel, content in files.items():
        ap = safe_path(os.path.join(dest, rel), [dest])
        if not ap:
            continue
        os.makedirs(os.path.dirname(ap), exist_ok=True)
        open(ap, "w", encoding="utf-8").write(content)
        if content.startswith("#!"):
            os.chmod(ap, 0o755)
    if "README.md" not in files:
        open(os.path.join(dest, "README.md"), "w", encoding="utf-8").write(f"# {name}\n\n{a.get('description_tr', '')}\n\nCypher Tool Görev Ajanı tarafından geliştirildi.\n")
    job.log(f"🛠 Yeni araç geliştirildi: {dest} ({len(files)} dosya)")
    plan = finalize_plan(dest, {"name": name, "summary": a.get("description_tr", "") + "\n\nDosyalar: " + ", ".join(files),
                                "steps": a.get("steps", []), "actions": a.get("actions", []), "warnings": ["Bu aracı yapay zekâ ajanı yazdı; kodu Rehber → Orijinal README / klasörden inceleyebilirsin."]})
    plan["full_name"] = "yerel/" + slug
    r = {"ok": True, "data": None} if opts.get("auto") else job.ask("plan", plan)
    if not r or not r.get("ok"):
        shutil.rmtree(dest, ignore_errors=True); return "Kullanıcı aracı onaylamadı; dosyalar silindi."
    plan.update(r.get("data") or {})
    icon = ""
    try:
        src = os.path.join(WEB_DIR, "logo.svg"); icon = slug + ".svg"; shutil.copy(src, os.path.join(ICON_DIR, icon))
    except Exception:
        pass
    tool = {"slug": slug, "name": plan.get("name") or name, "path": dest, "source": "yerel (Görev Ajanı geliştirdi)", "full_name": "yerel/" + slug,
            "meta": {"description": a.get("description_tr", "")}, "summary": a.get("description_tr", ""), "category": "Ajanın geliştirdiği araç",
            "steps": plan.get("steps", []), "actions": plan.get("actions", []), "runtimes": plan.get("runtimes", []), "system_packages": [],
            "optional": [], "icon": icon, "installed_at": now(), "status": "kuruluyor", "guide_tr": a.get("guide_tr", ""),
            "update_mode": "kapali", "inject_keys": True, "catalog_id": "", "agent_made": True}
    with _lock:
        t = tools(); t[slug] = tool; save_tools(t)
    ok = execute_plan(job, tool, plan) if (plan.get("steps") or plan.get("deps") or plan.get("runtimes")) else True
    update_tool(slug, status="kuruldu" if ok else "hata")
    if ok and tool["actions"]:
        make_shortcuts(tools()[slug], desktop=opts.get("shortcut", True))
    job.ctx.setdefault("installed", []).append(slug)
    return json.dumps({"slug": slug, "klasör": dest, "kurulum": "başarılı" if ok else "HATALI", "eylemler": tool["actions"],
                       "son_kayıtlar": job.lines[-15:] if not ok else []}, ensure_ascii=False)

def hunt_fallback(job, task, workdir):
    """API yokken: GitHub'da ara → en çok yıldızlıyı kur → dene."""
    job.log("ℹ Yapay zekâ API'si yok → basit mod: GitHub'da ara, en popüler adayı kur ve dene.\n"
            "   (Görevi kendisinin yapması ve araç geliştirmesi için Ücretsiz AI sekmesinden bir model ekle.)")
    try:
        cands = gh_search(task, 5)
    except Exception as e:
        job.log(f"✖ GitHub araması başarısız: {e}"); job.status = "hata"; return
    if not cands:
        job.log("✖ Aday bulunamadı. İngilizce anahtar kelimelerle dene (ör. 'pdf merge')."); job.status = "hata"; return
    job.ctx["candidates"] = cands
    r = job.ask("choose", {"candidates": cands, "task": task})
    if not r or not r.get("ok"):
        job.status = "iptal"; return
    repo = ((r.get("data") or {}).get("repo")) or cands[0]["repo"]
    before = set(tools()); title = job.title
    install_flow(job, "https://github.com/" + repo, {})
    job.title = title
    new = [s for s in tools() if s not in before]
    if not new:
        job.status = "hata"; return
    ok, out = smoke_test(job, new[0])
    t = tools()[new[0]]
    job.ctx["report"] = (f"## Sonuç\n**{repo}** kuruldu ({t['status']}).\n\n**Deneme:** {'✅ çalışıyor' if ok else '❌ başarısız'}\n\n```\n{out[-800:]}\n```\n\n"
                         f"Kullanım için **Rehberler** sekmesine bak.")
    job.status = "tamamlandı" if ok else "hata"

# ───────────────────────────── HTTP sunucu ─────────────────────────────
TOKEN = secrets.token_urlsafe(24)
LAST_SEEN = [time.time()]

def public_state():
    c = cfg()
    provs = [{**{k: v for k, v in p.items() if k != "api_key"}, "has_key": bool(p.get("api_key"))} for p in c["providers"]]
    for slug, t in list(tools().items()):
        if not t.get("kind_v2"):
            upd = {"kind_v2": True}
            if not t.get("actions") and is_doc_repo(t.get("path", "")):
                upd["kind"] = "doc"
                if t.get("status") == "hata":
                    upd["status"] = "kuruldu"
                da, _ = discover_actions(t.get("path", ""), slug)
                if da:
                    upd["actions"] = da
            elif "kind" not in t:
                upd["kind"] = "tool"
            update_tool(slug, **upd)
    tl = []; _bai = tool_ai_labels()
    for slug, t in sorted(tools().items(), key=lambda x: x[1].get("installed_at", ""), reverse=True):
        tl.append({k: v for k, v in t.items() if k not in ("guide_tr",)} | {"has_guide": bool(t.get("guide_tr")), "guide_sum": guide_summary(t.get("guide_tr"))[:600], "best_ai": _bai.get(slug, "")})
    installed_src = {t.get("source", "").lower().rstrip("/") for t in tools().values()}
    cat = [{**{k: v for k, v in x.items() if k not in ("guide_tr", "install")}, "summary": guide_summary(x.get("guide_tr")),
            "owner": x["full_name"].split("/")[0], "installed": x["source"].lower() in installed_src} for x in catalog()]
    return {"app": APP, "version": VERSION, "tools": tl, "providers": provs, "default_provider": c.get("default_provider", ""), "preferred": c.get("preferred", ""),
            "agents": c["agents"], "catalog": cat, "presets": PROVIDER_PRESETS,
            "repair": {**repair_cfg(), "on_install": c.get("auto_agent_repair", True)},
            "live": {"chat": [v | {"id": k} for k, v in LIVE["chat"].items() if time.time() - v["at"] < 900],
                     "gateway": {**LIVE["gateway"], "running": bool(GATEWAY_SRV[0])}, "last_api": LIVE.get("last_api")},
            "ai": {"mode": c.get("ai_mode", "auto"), "routing": c.get("routing") or {}, "features": FEATURES,
                   "ranking": [{"id": p["id"], "name": p["name"], "model": p.get("model"), **{k: ai_stats().get(p["id"], {}).get(k, 0) for k in ("ok", "fail", "ms")}}
                               for p in ordered_providers("", "")][:12],
                   "gateway": {"enabled": (c.get("gateway") or {}).get("enabled", True), "inject": (c.get("gateway") or {}).get("inject", True),
                               "autostart": bool((c.get("gateway") or {}).get("autostart")), "running": bool(GATEWAY_SRV[0]),
                               "url": f"http://127.0.0.1:{GATEWAY_PORT}/v1", "port": GATEWAY_PORT}},
            "agent_rules": c.get("agent_rules", ""), "agent_defaults": c.get("agent_defaults", {}), "workdir_default": WORK_DIR,
            "settings": {k: c[k] for k in ("failover", "use_ai", "auto_shortcut", "release_assets", "update_check", "update_default_mode", "auto_agent_repair")} | {"github_token_set": bool(c.get("github_token")), "security_scan": c.get("security_scan", True)},
            "schedules": schedules(), "workflows": workflows(), "app_watch": c.get("app_watch", False), "watch_events": WATCH["events"][-8:], "console": (CONSOLE[0].id if CONSOLE[0] and CONSOLE[0].rc is None else ""), "consoles": consoles_state(), "browsers": brw_state(), "visible_research": c.get("visible_research", True), "visible_ok": visible_ok(),
            "browser_embed": brw_embed(),
            "desktop": ({"job": DESK["job"], "title": DESK["title"]} if DESK["job"] and time.time() - DESK["at"] < 25 and (JOBS.get(DESK["job"]) and JOBS[DESK["job"]].status not in ("tamamlandı", "hata", "iptal")) else None),
            "auto": auto_cfg() | {"browser_auto": brw_auto(), "app_watch": c.get("app_watch", False), "on_run": repair_cfg()["on_run"], "auto_agent_repair": c.get("auto_agent_repair", True)},
            "con_recipes": [{k: v for k, v in r.items() if k != "steps"} | {"n": len(r.get("steps", []))} for r in con_recipes()],
            "phone": {"enabled": bool((c.get("phone") or {}).get("enabled")), "has_password": bool((c.get("phone") or {}).get("hash")), "running": bool(PHONE_SRV[0]),
                      "url": f"http://{lan_ip()}:{(c.get('phone') or {}).get('port', 8766)}"},
            "whisper_local": os.path.exists(os.path.join(WHISPER_ENV, "bin", "python")), "sys_tasks": list(SYS_TASKS), "dev_templates": {k: v["label"] for k, v in DEV_TEMPLATES.items()},
            "jobs": [j.summary() for j in sorted(JOBS.values(), key=lambda j: -j.created)][:60],
            "procs": [p.summary() for p in sorted(PROCS.values(), key=lambda p: -p.started)][:40],
            "system": {"os": os_info().get("PRETTY_NAME", "Linux"), "pm": detect_pm(), "arch": platform.machine(),
                       "ram_gb": mem_gb(), "gpu": gpu_info(), "desktop": desktop_dir() or "", "terminal": (find_terminal() or [""])[0]}}

def error_report(slug=""):
    """Kopyalanıp paylaşılabilecek hata raporu (anahtarlar dahil değil)."""
    oi = os_info()
    L = [f"=== {APP} {VERSION} hata raporu — {now()} ===",
         f"Sistem: {oi.get('PRETTY_NAME', 'Linux')} | paket yön.: {detect_pm()} | mimari: {platform.machine()} | RAM: {mem_gb()} GB | root: {is_root()}",
         f"Python: {platform.python_version()} | node: {'.'.join(map(str, node_version(which('node')))) if which('node') else 'yok'} | uv: {'var' if which('uv') else 'yok'} | git: {'var' if which('git') else 'yok'}",
         "Eksik bileşenler: " + (", ".join(i["label"] for i in system_checks() if not i["ok"] and i["kind"] != "info") or "yok")]
    t = tools().get(slug)
    if t:
        L += ["", f"--- Araç: {t['name']} ({t.get('full_name')}) ---", f"Durum: {t.get('status')} | tür: {t.get('kind', 'tool')} | klasör: {t['path']}",
              "Kurulum adımları:", *["  $ " + x for x in t.get("steps", [])], "Eylemler:", *[f"  [{a['label']}] {a['command']}" for a in t.get("actions", [])]]
        if t.get("test"):
            L.append(f"Son test: {'başarılı' if t['test'].get('ok') else 'başarısız'} ({t['test'].get('at')})")
        err = (t.get("last_error") or "") + "\n" + (t.get("last_run_error") or "")
        dg = diagnose(err, t)
        if dg:
            L += ["", "Bilgi bankası teşhisi:", *[f"  • {d['title']} → {d['commands'] or d['advice']}" for d in dg]]
        if t.get("last_error"):
            L += ["", "--- Son kurulum hatası ---", t["last_error"][-6000:]]
        if t.get("last_run_error"):
            L += ["", "--- Son çalıştırma hatası ---", t["last_run_error"][-4000:]]
        if t.get("logs"):
            f = os.path.join(LOG_DIR, t["logs"][-1]["file"])
            if os.path.isfile(f):
                L += ["", f"--- Son kayıt dosyası ({t['logs'][-1]['file']}) — son 150 satır ---"] + open(f, encoding="utf-8", errors="replace").read().splitlines()[-150:]
    else:
        bad = [j for j in sorted(JOBS.values(), key=lambda j: -j.created) if j.status == "hata"][:3]
        for j in bad:
            L += ["", f"--- Hatalı görev: {j.title} ---"] + j.lines[-80:]
    txt = "\n".join(L)
    for p in cfg().get("providers", []):  # anahtar sızmasın
        if p.get("api_key"):
            txt = txt.replace(p["api_key"], "•••")
    return txt

def system_checks():
    items = []
    for k, label, why in (("git", "git", "Depoları indirmek ve güncellemek için"), ("venv", "Python venv", "Python araçlarını izole kurmak için"),
                          ("7z", "7-Zip", "rar/7z arşivlerini açmak için"), ("unrar", "unrar", "rar arşivleri için (alternatif)"),
                          ("gcc", "Derleyici (gcc/make)", "Kaynaktan derlenen araçlar için"), ("curl", "curl", "Bazı resmi kurulum betikleri için"),
                          ("git-lfs", "git-lfs", "Büyük dosyalı depolar için"), ("notify-send", "Bildirimler", "Güncelleme/kurulum bildirimleri için"),
                          ("xdg-utils", "xdg-utils", "Masaüstü kısayolları ve dosya açma için"),
                          ("emoji", "Emoji yazı tipi", "Arayüzdeki simgelerin kutu yerine düzgün görünmesi için"),
                          ("chromium", "Chrome / Chromium", "Uygulama içi tarayıcı: yapay zekânın internette gezinmesi, araştırma, YouTube'dan öğrenme"),
                          ("xdotool", "xdotool + wmctrl", "Yapay zekânın masaüstündeki uygulamaları fare/klavyeyle kullanması"),
                          ("scrot", "scrot", "Masaüstü ekran görüntüsü (yapay zekâ ekrana bakabilsin)"),
                          ("pil", "Python Pillow", "Ekran görüntüsüne koordinat ızgarası çizmek için")):
        items.append({"key": k, "label": label, "why": why, "ok": check_key(k), "kind": "sys"})
    for r, label, why in (("node22", "Node.js 22+", "Node tabanlı araçlar (sudo'suz yerel kurulum)"), ("uv", "uv (Python yöneticisi)", "Modern Python araçları, istenen Python sürümü")):
        items.append({"key": r, "label": label, "why": why, "ok": runtime_ok(r), "kind": "runtime"})
    items.append({"key": "ollama", "label": "Ollama", "why": "API anahtarsız yerel yapay zekâ modelleri", "ok": bool(which("ollama")), "kind": "ollama"})
    items.append({"key": "pkexec", "label": "pkexec (polkit)", "why": "Grafik parola penceresiyle güvenli yönetici izni", "ok": bool(shutil.which("pkexec")), "kind": "info"})
    return items

def system_fix_flow(job, keys):
    job.title = "Sistem bağımlılıkları"
    rts = [k for k in keys if k in ("node22", "uv")]
    sysk = [k for k in keys if k in PKG]
    cmds, missing = dep_commands(sysk)
    plan = {"name": "Sistem bağımlılıkları", "summary": "Seçilen eksikler kurulacak: " + ", ".join(keys), "steps": cmds, "actions": [],
            "runtimes": rts, "runtimes_missing": rts, "deps": [], "warnings": []}
    r = job.ask("plan", plan)
    if not r or not r.get("ok"):
        c = cfg(); c["system_setup_declined"] = time.time(); save_cfg(c)
        job.status = "iptal"; return
    plan.update(r.get("data") or {})
    for rt in rts:
        ensure_runtime(rt, job.log)
    ok, _, _ = run_steps(job, plan["steps"], DATA)
    job.status = "tamamlandı" if ok else "hata"

ESSENTIAL = ["git", "venv", "7z", "curl", "xdg-utils", "notify-send", "emoji", "unzip"]

def auto_system_setup():
    time.sleep(4)
    try:
        if time.time() - cfg().get("system_setup_declined", 0) < 7 * 86400:
            return
        miss = [k for k in ESSENTIAL if not check_key(k)]
        if miss and detect_pm():
            start_job("🧩 Sistem hazırlığı", "system", system_fix_flow, miss)
    except Exception:
        pass

# ═════════════════════════════ 💻 KONSOL (yapay zekâ yazar, kurar, çözer, kullanır) ═════════════════════════════
CONSOLE = [None]

def console_rc():
    rc = os.path.join(CONF_DIR, "konsol.rc")
    body = f"""[ -f ~/.bashrc ] && . ~/.bashrc
[ -f {q(ENV_FILE)} ] && . {q(ENV_FILE)}
export PATH={q(RT_BIN)}:$HOME/.local/bin:$PATH
alias ct='cyphertool'
PS1='\\[\\e[1;35m\\]cypher\\[\\e[0m\\]:\\[\\e[95m\\]\\w\\[\\e[0m\\]\\$ '
echo -e "\\e[1;35m💻 Cypher Tool Konsolu\\e[0m — komut yaz ya da alttaki kutudan yapay zekâya söyle (link yapıştırırsan kurar)."
"""
    body += f"""export HISTFILE={q(CON_HIST)} HISTSIZE=5000 HISTFILESIZE=20000 HISTCONTROL=ignorespace:ignoredups
shopt -s histappend 2>/dev/null
"""
    for qc in (cfg().get("quick_cmds") or []):
        if qc.get("alias") and re.match(r"^[A-Za-z_][\w-]{0,30}$", qc["alias"]):
            body += f"alias {qc['alias']}={q(qc['command'])}\n"
    body += """__ct_mark(){ local r=$?; history -a 2>/dev/null; printf '\\033]777;ctd;%s;%s\\007' "$r" "$PWD"; return $r; }
PROMPT_COMMAND="__ct_mark${PROMPT_COMMAND:+; $PROMPT_COMMAND}"
"""
    open(rc, "w").write(body)
    return rc

CON_HIST = os.path.join(CONF_DIR, "konsol_gecmisi")
CONSOLES = {}  # 🗂️ çoklu konsol sekmeleri: id → Proc

def console_list():
    return sorted((p for p in CONSOLES.values() if p.rc is None), key=lambda p: p.num)

def console_new(title="", cwd=""):
    used = {p.num for p in console_list()}; n = 1
    while n in used:
        n += 1
    wd = cwd if cwd and os.path.isdir(cwd) else os.path.expanduser("~")
    p = Proc(title or f"💻 Konsol {n}", f"exec bash --rcfile {q(console_rc())} -i", wd, "")
    p.console = True; p.num = n; CONSOLES[p.id] = p
    if not CONSOLE[0] or CONSOLE[0].rc is not None:
        CONSOLE[0] = p
    for _ in range(40):  # ilk istem gelsin (işaret karışmasın)
        if CT_MARK.search(p.hist):
            p.cwd = CT_MARK.findall(p.hist)[-1][1]; break
        time.sleep(0.1)
    return p

def console_get(create=True, cid=""):
    if cid:
        p = CONSOLES.get(cid)
        if p and p.rc is None:
            return p
    p = CONSOLE[0]
    if p and p.rc is None:
        return p
    alive = console_list()
    if alive:
        CONSOLE[0] = alive[0]; return alive[0]
    if not create:
        return None
    return console_new()

def tool_active(slug):
    """Pasif araçlar kendiliğinden hiçbir şey başlatmaz (izleme, otomatik onarım, güncelleme), listede gizlenir; yapay zekâ kullanıcı istemedikçe dokunmaz."""
    t = tools().get(slug) or {}
    return t.get("active", True) is not False

def auto_cfg():
    """⚙️ Otomatik işler (Ayarlar): kullanıcı istemeden başlayan her şeyin anahtarı."""
    a = cfg().get("auto") or {}
    return {"click_ai": a.get("click_ai", True),            # listede araca tıklayınca araç konsolda açılır + yapay zekâ ne işe yaradığını anlatır
            "bench": a.get("bench", True),                  # araç ilk açılınca API'leri yarıştır
            "console_mode": a.get("console_mode", "own"),
            "full_repair": a.get("full_repair", True),
            "heavy": a.get("heavy", "ask"),
            "desktop": a.get("desktop", True),           # yapay zekâ masaüstündeki uygulamaları kullanabilsin
            "learn_first": a.get("learn_first", True),
            "cookies": a.get("cookies", "reject"),
            "search_engine": a.get("search_engine", "google")}       # çerez pencereleri: reject (tümünü reddet) · accept · off   # bir aracı/uygulamayı ilk kez kullanmadan önce araştırıp öğrensin               # yapay zekâ bağlıyken onarım hiç sormadan, tüm model/API'lerle kendisi halleder   # own: her araç kendi sekmesinde · active: açık sekmede · group: araç grubuna göre

def console_for(key, title, cwd, mode=None, group="", cid=""):
    """Aracın açılacağı konsolu seç: kendi sekmesi / grup sekmesi / açık sekme."""
    mode = mode or auto_cfg()["console_mode"]
    if group:
        k = "grp:" + group; title = "🧩 " + group
    elif mode in ("own", "group") and key:
        k = "tool:" + key
    else:
        return console_get(cid=cid)
    for p in console_list():
        if getattr(p, "key", "") == k:
            return p
    p = console_new(title[:30], cwd); p.key = k
    return p

def console_tools(con):
    """Grup konsolundaki araçlar (konsolun üstünde düğme olur, yapay zekâ önce bunları kullanır)."""
    k = getattr(con, "key", "") if con else ""
    if k.startswith("grp:"):
        g = k[4:]
        return [s_ for s_, t in tools().items() if t.get("console_group") == g]
    if k.startswith("tool:") and k[5:] in tools():
        return [k[5:]]
    return []

def console_cwd(con):
    mk = CT_MARK.findall(con.hist[-60000:]) if con else []
    cur = mk[-1][1] if mk else ""
    return cur if cur and os.path.isdir(cur) else os.path.expanduser("~")

def consoles_state():
    out = []
    for p in console_list():
        js = [j for j in JOBS.values() if j.ctx.get("console") == p.id and j.kind == "agent"]
        act = [j for j in js if j.status not in ("tamamlandı", "hata", "iptal")]
        try: fg = os.tcgetpgrp(p.m) != p.p.pid
        except Exception: fg = False
        ct_ = console_tools(p)
        out.append({"id": p.id, "title": p.title, "num": p.num, "cwd": getattr(p, "cwd", ""), "program": fg, "key": getattr(p, "key", ""),
                    "tools": [{"slug": x, "name": tools()[x]["name"], "actions": [a_["label"] for a_ in tools()[x].get("actions", [])][:4]} for x in ct_],
                    "ai": (act[-1].id if act else ""), "ai_wait": bool(act and act[-1].pending), "last_job": (max(js, key=lambda j: j.created).id if js else "")})
    return out

# ⚡ komut geçmişinden kısayol önerisi
TRIVIAL_CMDS = {"ls", "ll", "la", "l", "cd", "pwd", "clear", "exit", "history", "whoami", "date", "top", "htop", "btop", "ct", "cyphertool", "q", "reset"}

def quick_cmds():
    return cfg().get("quick_cmds") or []

def cmd_history(limit=4000):
    try:
        lines = open(CON_HIST, encoding="utf-8", errors="replace").read().splitlines()[-limit:]
    except Exception:
        return []
    return [re.sub(r"\s+", " ", l).strip() for l in lines if l.strip() and not l.startswith("#")]

def cmd_suggestions(minc=3):
    from collections import Counter
    c = Counter(cmd_history())
    have = {x["command"] for x in quick_cmds()}; dismissed = set(cfg().get("quick_dismissed") or [])
    out = []
    for cmd, n in c.most_common(60):
        if n < minc:
            break
        toks = cmd.split()
        if cmd in have or cmd in dismissed or len(cmd) < 8 or (toks[0] in TRIVIAL_CMDS and len(toks) <= 2) or re.search(r"(passw|token|secret|api[_-]?key)\S*=", cmd, re.I):
            continue
        name = " ".join(t for t in toks[:3] if not t.startswith(("-", "/", "~", ".")))[:28] or toks[0]
        alias = re.sub(r"[^a-z0-9_]", "", "".join(w[:3] for w in name.lower().split()))[:12]
        out.append({"command": cmd, "count": n, "name": name, "alias": alias if alias and not which(alias) else ""})
        if len(out) >= 3:
            break
    return out

def console_print(proc, text, color="95"):
    if proc and proc.rc is None:
        t = "\r\n".join(f"\x1b[{color}m{l}\x1b[0m" for l in str(text).split("\n"))
        proc.chunks.append(t + "\r\n"); proc._hist_add(t + "\r\n")

CT_MARK = re.compile(r"\x1b\]777;ctd;(-?\d+);([^\x07]*)\x07")

def console_exec(proc, cmd, cwd, timeout=180, job=None):
    """Komutu kullanıcının gördüğü konsola yazar, bitmesini bekler (görünmez istem işaretiyle), çıktısını döndürür."""
    pos = proc.hist_base + len(proc.hist)
    cmd = cmd.strip()
    mk = CT_MARK.findall(proc.hist[-60000:])  # kullanıcı/araç elle cd yapmış olabilir → gerçek klasörü istem işaretinden al
    if mk:
        proc.cwd = mk[-1][1]
    pre = "" if os.path.realpath(getattr(proc, "cwd", "") or "/nonexistent") == os.path.realpath(cwd) else f"cd {q(cwd)} && "
    line = pre + (("{ " + cmd + "\n}") if "\n" in cmd else cmd)
    proc.write(" " + line + "\n")
    t0 = time.time(); rc = None; seg = ""
    while time.time() - t0 < timeout:
        if job and job.cancelled:
            proc.write("\x03"); break
        seg = proc.hist[max(0, pos - proc.hist_base):]
        m = CT_MARK.search(seg)
        if m:
            rc = int(m.group(1)); proc.cwd = m.group(2); seg = seg[:m.start()]; break
        if proc.rc is not None:
            break
        time.sleep(0.25)
    out = clean_term(CT_MARK.sub("", seg)).replace("\r", "")
    lines = out.split("\n")
    first = line.split("\n")[0][:40]
    while lines and (first and first in lines[0] or lines[0].startswith("> ")):
        lines = lines[1:]
    out = "\n".join(lines).strip()
    if rc is None:
        return -9, out[-6000:] + f"\n[⏱ {timeout} sn içinde bitmedi — program hâlâ çalışıyor olabilir (etkileşimli/sunucu). read_screen ile ekrana bak, type_keys ile yanıt ver ya da Ctrl+C için type_keys {{\"text\": \"\\u0003\", \"enter\": false}} gönder.]"
    return rc, out[-6000:]

def console_screen(proc, n=4000):
    return clean_term(CT_MARK.sub("", proc.hist[-n:])).replace("\r", "") if proc else ""

CONSOLE_SYS = """

KONSOL MODU (şu an aktif): Kullanıcı seninle Cypher Tool'un KONSOLU üzerinden çalışıyor ve yaptığın her şeyi canlı görüyor.
- run komutların bu konsolda çalışır (kullanıcı ekranda görür). Kurulum gereken her şeyi konsolda kur.
- Kullanıcı GitHub/arşiv linkleri verdiyse her birini install ile kur (birden fazla link varsa sırayla). Kurulum hata verirse: hata kaydını oku, bilgi bankasındaki çözümleri uygula, eksik paketi kur, tekrar dene; çözdüğün yeni hatayı learn_error ile kaydet.
- Kurulumdan sonra aracı DENE (smoke_test / run --help) ve kullanıcıya ne yapabildiğini anlat; sonra kullanıcının istediği işi bu araçla YAP.
- Etkileşimli programlarda (soru soran, menülü, sohbet arayüzlü): programı run ile başlat; bitmezse read_screen ile ekrana bak ve type_keys ile yanıt ver.
EK EYLEMLER:
- type_keys {"text": "yazılacak metin", "enter": true, "wait": 3}  → konsoldaki çalışan programa klavyeden yazar (ör. menü seçimi, soruya cevap). Ctrl+C için text "\\u0003", enter false.
- read_screen {}  → konsol ekranının son kısmını okur."""

# ── 🐙 bilgisayarda (Cypher Tool dışında) kurulu GitHub/git araçları
REPO_SCAN = {"at": 0.0, "items": [], "lock": threading.Lock()}
REPO_SKIP = SKIP_DIRS | {"snap", "Trash", "site-packages", "dist-packages", "go", "proc", "sys", "lost+found"}

def _git_remote(gitdir):
    """'.git' klasöründen (ya da worktree/submodule '.git' dosyasından) origin adresini okur."""
    try:
        if os.path.isfile(gitdir):
            m = re.match(r"gitdir:\s*(.+)", open(gitdir, encoding="utf-8", errors="replace").read().strip())
            if not m:
                return ""
            gd = m.group(1).strip()
            gitdir = gd if os.path.isabs(gd) else os.path.normpath(os.path.join(os.path.dirname(gitdir), gd))
            if "/worktrees/" in gitdir:
                gitdir = gitdir.split("/worktrees/")[0]
        txt = open(os.path.join(gitdir, "config"), encoding="utf-8", errors="replace").read()
    except Exception:
        return ""
    urls = re.findall(r'\[remote "([^"]+)"\][^\[]*?url\s*=\s*(\S+)', txt, re.S)
    return next((u for n, u in urls if n == "origin"), urls[0][1] if urls else "")

def _repo_full_name(url):
    m = re.search(r"(?:github\.com|gitlab\.com|codeberg\.org|bitbucket\.org)[:/]+([\w.-]+)/([\w.-]+?)(?:\.git)?/?$", url or "")
    return f"{m.group(1)}/{m.group(2)}" if m else ""

def github_repos(force=False, budget=4.0):
    """Ev dizini, /opt, /usr/local/src, /srv… altındaki git klonlarını bulur (Cypher Tool'un kendi araçları hariç)."""
    with REPO_SCAN["lock"]:
        if not force and REPO_SCAN["at"] and time.time() - REPO_SCAN["at"] < 180:
            return REPO_SCAN["items"]
        home = os.path.expanduser("~")
        managed = {os.path.realpath(t.get("path", "")) for t in tools().values() if t.get("path")}
        skip_roots = {os.path.realpath(x) for x in (DATA, CONF_DIR, os.path.join(home, ".local"), os.path.join(home, ".cache"))}
        roots = [(home, 4), ("/opt", 3), ("/usr/local/src", 3), ("/usr/local/share", 2), ("/srv", 3), ("/usr/share", 1)]
        extra = (cfg().get("repo_dirs") or [])
        roots += [(os.path.expanduser(x), 4) for x in extra if isinstance(x, str)]
        out, seen, t0, visited = [], set(), time.time(), 0
        for root, maxd in roots:
            if not os.path.isdir(root):
                continue
            stack = [(root, 0)]
            while stack:
                if time.time() - t0 > budget or visited > 25000:
                    stack = []; break
                d, depth = stack.pop()
                visited += 1
                rd = os.path.realpath(d)
                if rd in seen or rd in skip_roots:
                    continue
                seen.add(rd)
                gd = os.path.join(d, ".git")
                if os.path.exists(gd):
                    if rd in managed:
                        continue
                    url = _git_remote(gd)
                    if url:
                        fn = _repo_full_name(url)
                        try: mt = os.path.getmtime(gd)
                        except Exception: mt = 0
                        try: desc = readme_intro(d)[:220]
                        except Exception: desc = ""
                        out.append({"kind": "repo", "id": rd, "name": os.path.basename(d), "path": rd, "url": re.sub(r"://[^/@]+@", "://", url),
                                    "full_name": fn, "github": "github.com" in url, "desc": desc, "mtime": mt,
                                    "owner": fn.split("/")[0] if fn else ""})
                    continue  # bir deponun içindeki alt klasörlere inme
                if depth >= maxd:
                    continue
                try:
                    with os.scandir(d) as it:
                        subs = [e.path for e in it if e.is_dir(follow_symlinks=False) and not e.name.startswith(".") and e.name not in REPO_SKIP]
                except Exception:
                    continue
                stack += [(s, depth + 1) for s in sorted(subs, reverse=True)]
        out.sort(key=lambda x: (-x["github"], -x["mtime"]))
        REPO_SCAN["items"] = out[:400]; REPO_SCAN["at"] = time.time()
        return REPO_SCAN["items"]

def caps_all_flow(job, force=False):
    """Açıklaması/özellik kartı eksik araçları yapay zekâya inceletir (ⓘ bilgi kartları dolsun)."""
    job.title = "🧠 Araç açıklamaları tamamlanıyor"
    if not llm_available():
        job.log("✖ Bunun için bir yapay zekâ API'si gerekli (Ücretsiz AI sekmesinden ekleyebilirsin)."); job.status = "hata"; return
    todo = [s_ for s_, t in tools().items() if force or not (t.get("capabilities") or {}).get("yapabilecekleri")]
    job.log(f"{len(todo)} aracın açıklaması eksik.")
    ok = 0
    for i, s_ in enumerate(todo, 1):
        if job.cancelled:
            break
        t = tools()[s_]; job.status = f"{i}/{len(todo)}: {t['name']}"
        try:
            hlp = help_output(t) if t.get("actions") else ""
            guide = t.get("guide_tr") or read_readme(t["path"], 7000)
            cap = learn_capabilities(s_, guide, hlp, None)
            if not t.get("summary") and cap.get("ozet"):
                update_tool(s_, summary=cap["ozet"])
            ok += 1; job.log(f"✔ {t['name']}: {cap.get('ozet', '')[:120]}")
        except Exception as e:
            job.log(f"⚠ {t['name']}: {str(e)[:150]}")
    job.ctx["report"] = f"{ok}/{len(todo)} aracın açıklaması ve özellik kartı hazırlandı."
    job.log("✅ " + job.ctx["report"])

# ═════════════════════════════ 🧠 ARAÇ BAŞINA EN İYİ BEYİN (API'leri yarıştır + kullandıkça öğren) ═════════════════════════════
TOOL_AI_FILE = os.path.join(CONF_DIR, "arac_beyinleri.json")
_TAI_LOCK = threading.Lock()

def tool_ai():
    return jload(TOOL_AI_FILE, {})

def _tai_save(d):
    with _TAI_LOCK:
        jsave(TOOL_AI_FILE, d)

def tool_ai_ctx(key):
    """key: Cypher aracının slug'ı ya da diskteki deponun yolu → (ad, kök klasör, yardım çıktısı, README)"""
    if key in tools():
        t = tools()[key]
        try: hlp = help_output(t) if t.get("actions") else ""
        except Exception: hlp = ""
        return t["name"], t["path"], hlp, (t.get("guide_tr") or read_readme(t["path"], 4000))
    rp = os.path.realpath(os.path.expanduser(key))
    return os.path.basename(rp), rp, "", read_readme(rp, 4000) + "\n\nDOSYALAR:\n" + file_tree(rp, 60)

def _bench_score(txt, ms, hlp, readme, name):
    try:
        d = extract_json(txt)
    except Exception:
        return 0, "geçersiz JSON"
    sc, why = 45, ["geçerli JSON"]
    cmd = str((d.get("args") or {}).get("command", "")) if d.get("action") == "run" else ""
    if not cmd:
        return 20, "komut üretmedi"
    sc += 10
    ref = (hlp + "\n" + readme).lower()
    toks = [t for t in re.findall(r"--?[\w-]+|[a-z][\w.-]{2,}", cmd.lower()) if t not in ("sudo", "the", "and")]
    if toks:
        hit = sum(1 for t in toks if t in ref) / len(toks)
        sc += int(hit * 35); why.append(f"komutun %{int(hit * 100)}'i belgede geçiyor")
    if re.search(r"<[^>]+>|\.\.\.|YOUR_|örnek_", cmd):
        sc -= 8; why.append("yer tutucu var")
    sc += max(0, 10 - int(ms / 2500)); why.append(f"{ms / 1000:.1f} sn")
    return max(0, min(100, sc)), ", ".join(why)

def tool_ai_bench(key, log=None):
    """Kurulu tüm API'lere bu araca özel aynı küçük görevi verir; en iyisini araç için kaydeder."""
    provs = [p for p in cfg().get("providers", []) if p.get("enabled", True)]
    if not provs:
        raise RuntimeError("Hiç API yok.")
    name, root, hlp, readme = tool_ai_ctx(key)
    sysm = ("Sen bir Linux terminal aracı kullanma uzmanısın. Sadece verilen yardım çıktısı ve belgedeki gerçek seçenekleri kullan, uydurma. "
            "SADECE tek bir JSON nesnesi döndür: {\"thought\": \"kısa\", \"action\": \"run\", \"args\": {\"command\": \"tam komut\", \"where\": \"work\"}}")
    user = (f"ARAÇ: {name}\nKLASÖR: {root}\nYARDIM ÇIKTISI:\n{(hlp or '(yok)')[:3500]}\n\nBELGE:\n{readme[:3000]}\n\n"
            "GÖREV: Bu aracın ANA işini yapan, etkileşimsiz ve hemen çalıştırılabilir tek bir örnek komut yaz (aracın klasöründe çalışacak).")
    res = {}
    def one(p):
        t0 = time.time()
        try:
            txt = llm_call(p, [{"role": "user", "content": user}], sysm, None, timeout=70)
            ms = (time.time() - t0) * 1000
            sc, why = _bench_score(txt, ms, hlp, readme, name)
            res[p["id"]] = {"score": sc, "why": why, "ms": int(ms), "ok": True, "name": p.get("name"), "model": p.get("model")}
        except Exception as e:
            res[p["id"]] = {"score": 0, "why": "hata: " + str(e)[:100], "ms": 0, "ok": False, "name": p.get("name"), "model": p.get("model")}
    ths = [threading.Thread(target=one, args=(p,), daemon=True) for p in provs[:12]]
    [t.start() for t in ths]; [t.join(80) for t in ths]
    d = tool_ai(); e = d.setdefault(key, {}); e["bench"] = res; e["bench_at"] = now(); e["name"] = name
    _tai_save(d)
    best = tool_ai_best(key)
    if log:
        for pid, r in sorted(res.items(), key=lambda x: -x[1]["score"]):
            log(f"   {'🏆' if pid == best else '  '} {r['name']} · {r['model']}: {r['score']} puan ({r['why']})")
    return best

def tool_ai_record(key, pid, ok, steps, errors):
    """Gerçek kullanım sonucu: o API bu araçla işi bitirdi mi, kaç hata yaptı."""
    if not key or not pid:
        return
    d = tool_ai(); e = d.setdefault(key, {}); u = e.setdefault("use", {}).setdefault(pid, {"runs": 0, "ok": 0, "steps": 0, "errors": 0})
    u["runs"] += 1; u["ok"] += 1 if ok else 0; u["steps"] += steps; u["errors"] += errors; u["at"] = now()
    _tai_save(d)

def tool_ai_scores(key, d=None, live=None):
    e = (tool_ai() if d is None else d).get(key) or {}; live = live or {p["id"]: p for p in cfg().get("providers", []) if p.get("enabled", True)}
    out = {}
    for pid, p in live.items():
        b = (e.get("bench") or {}).get(pid); u = (e.get("use") or {}).get(pid)
        bs = b["score"] if b else None
        us = None
        if u and u["runs"]:
            us = max(0, min(100, 100 * u["ok"] / u["runs"] - 40 * u["errors"] / max(1, u["steps"])))
        if bs is None and us is None:
            continue
        w = min(0.8, 0.25 * (u["runs"] if u else 0))  # kullandıkça gerçek sonuçların ağırlığı artar
        sc = us if bs is None else (bs if us is None else bs * (1 - w) + us * w)
        out[pid] = {"score": round(sc, 1), "bench": bs, "use": us, "runs": (u or {}).get("runs", 0), "name": p.get("name"), "model": p.get("model"),
                    "why": (b or {}).get("why", "")}
    return out

def tool_ai_best(key):
    sc = tool_ai_scores(key)
    return max(sc, key=lambda k: sc[k]["score"]) if sc else ""

def tool_ai_labels():
    d = tool_ai(); live = {p["id"]: p for p in cfg().get("providers", []) if p.get("enabled", True)}; out = {}
    for k in d:
        sc = tool_ai_scores(k, d, live)
        if sc:
            b = max(sc, key=lambda x: sc[x]["score"]); out[k] = f"{sc[b]['name']} · {sc[b]['model']}"
    return out

def tools_inventory(flt="", detail=False):
    """Kullanıcının araçlarının kısa envanteri (yapay zekâ özetlesin diye): Cypher araçları + diskteki GitHub depoları + tarayıcı."""
    flt = (flt or "").lower(); lines = []
    for s_, t in sorted(tools().items(), key=lambda x: (x[1].get("category") or "~", x[1]["name"].lower())):
        cap = t.get("capabilities") or {}
        ne = cap.get("ozet") or guide_summary(t.get("guide_tr")) or t.get("summary") or (t.get("meta") or {}).get("description") or ""
        yet = cap.get("yapabilecekleri") or []
        row = (f"- [{s_}] {t['name']} | kategori: {t.get('category') or '-'} | repo: {t.get('full_name') or '-'} | durum: {t.get('status')}"
               + (" | ✨geliştirildi" if t.get("developed") else "") + (" | ⚠çalıştırma komutu yok" if not t.get("actions") and t.get("kind") != "doc" else "")
               + (" | ⏸ PASİF (kullanıcı kapattı — kullanıcı açıkça istemedikçe KULLANMA)" if t.get("active", True) is False else "")
               + (f" | 🧩 konsol grubu: {t['console_group']}" if t.get("console_group") else "")
               + f"\n    ne yapar: {re.sub(chr(10), ' ', ne)[:(400 if detail else 170)]}"
               + (f"\n    özellikler: {'; '.join(yet[:(8 if detail else 4)])}" if yet else "")
               + (f"\n    komutlar: {'; '.join(c.get('is', '') + ' → ' + c.get('komut', '') for c in (cap.get('etkilesimsiz_komutlar') or [])[:4])}" if detail and cap.get("etkilesimsiz_komutlar") else ""))
        if not flt or flt in row.lower():
            lines.append(row)
    rp = []
    try:
        for r in github_repos():
            row = f"- [{r['path']}] {r['name']} | repo: {r['full_name'] or r['url']}\n    ne yapar (README): {r['desc'][:(300 if detail else 160)] or '(README açıklaması yok — read_file ile README oku)'}"
            if not flt or flt in row.lower():
                rp.append(row)
    except Exception:
        pass
    b = find_browser()
    out = (f"CYPHER TOOL İLE KURULU ARAÇLAR ({len(lines)}):\n" + ("\n".join(lines) or "(yok)") +
           f"\n\nDİSKTE GİT İLE İNDİRİLMİŞ GITHUB DEPOLARI ({len(rp)}) — Cypher'a eklenmemiş; run 'where' olarak klasör yolunu kullan:\n" + ("\n".join(rp) or "(yok)") +
           f"\n\nTARAYICI: {b or 'yok'}")
    return out + ("\n\n(Ayrıntı için list_tools {\"detail\": true, \"filter\": \"kelime\"} ya da read_tool {\"slug\": \"...\"})" if not detail else "")

def repo_launch_cmd(path):
    """Bir depo için konsolda çalıştırılacak en olası başlatma komutu ('' = sadece klasöre gir)."""
    try:
        acts, _ = discover_actions(path, os.path.basename(path))
    except Exception:
        acts = []
    return (acts[0]["command"] if acts else ""), acts[:6]

def console_agent_task(kind, item):
    if kind == "repo":
        name = os.path.basename(item.rstrip("/"))
        r = next((x for x in REPO_SCAN["items"] if x["path"] == item), {})
        _, acts = repo_launch_cmd(item)
        al = "; ".join(f"{a['label']}: {a['command']}" for a in acts) or "bulunamadı"
        return (f"Kullanıcı Konsol → GitHub araçları listesinden bilgisayarında zaten kurulu olan '{name}' deposunu açtı "
                f"(klasör: {item}, repo: {r.get('full_name') or r.get('url') or '?'}). Bu araç Cypher Tool ile kurulmadı; klasörü olduğu gibi kullan. "
                f"Tahmini çalıştırma komutları: {al}.\n"
                f"1) run ile (where: \"{item}\") 'ls' ve README'yi oku (ör. 'sed -n 1,120p README*'), gerekirse --help çalıştır. "
                "2) Eksik bağımlılık varsa (requirements.txt, package.json…) kullanıcıya sorarak proje içine kur (.venv / yerel npm). "
                "3) say ile bu araçla NELER YAPABİLECEĞİNİ Türkçe, somut maddelerle anlat, 3-5 tıklanabilir öneri ver ve ne istediğini sor. "
                "4) Kullanıcının isteğini bu araçla konsolda yap; etkileşimliyse read_screen/type_keys kullan; hata çıkarsa kendin çöz.")
    if kind == "tool":
        t = tools()[item]
        cap = (t.get("capabilities") or {}).get("ozet", "")
        return (f"Kullanıcı Konsol → Uygulamalar menüsünden '{t['name']}' aracını açtı (slug: {t['slug']}, repo: {t.get('full_name')}). {cap}\n"
                f"Araç bu konsol sekmesinde zaten açıldı. "
                + (f"ÖNCE ÖĞREN (bu aracı ilk kez kullanıyorsun, bilgi hafızanda yok): read_tool ile README'yi oku; web_search ile '{t['name']} {t.get('full_name', '')} nasıl kullanılır' ara ve en iyi 1-2 kaynağı fetch_url ile oku; "
                   f"faydalı olacaksa youtube {{\"query\": \"{t['name']} tutorial\"}} ile bir video özeti çıkar. Öğrendiklerini learn ile '{t['name']} kullanımı' başlığıyla kaydet. "
                   if auto_cfg().get("learn_first", True) and not know_find(t["name"] + " kullanımı", 1) else f"Bilgi hafızanda '{t['name']}' hakkında kayıt varsa onu kullan. ")
                + "SONRA ANLAT: 1) read_tool ile README'sini ve eylemlerini oku (gerekirse read_screen ile konsoldaki çıktıya bak). "
                "2) Hemen say/ask_user ile Türkçe, kısa ve anlaşılır şekilde anlat: **Bu araç ne?** (1-2 cümle), **Ne işe yarar / neler yapar?** (3-6 somut madde), **Nasıl kullanılır?** (en sık 2-3 komut/örnek). "
                "3-5 tıklanabilir öneri ver (ör. 'X'i tara', 'örnek bir rapor çıkar') ve ne yapmak istediğimi sor. Bu aşamada bir şey KURMA, uzun işlem BAŞLATMA. "
                "3) Ben söyleyince isteğimi bu araçla bu konsolda yap; etkileşimliyse read_screen/type_keys kullan; hata çıkarsa kendin çöz.")
    return (f"Kullanıcı bilgisayarındaki '{item}' programını seçti. Önce bu programın ne olduğunu öğren (konsolda '{item} --help' veya 'man {item} | head -80' "
            "çalıştır; grafik bir uygulamaysa list_apps ile bilgisine bak). Kullanıcıya Türkçe olarak ne işe yaradığını ve nasıl kullanıldığını kısaca anlat, "
            "'İstersen ben halledeyim' de, 3-5 örnek iş öner ve ne yapmak istediğini sor. İsterse programı kendin kullanarak işi yap: grafik uygulamaysa open_app ile aç, "
            "desktop_look ile ekrana bakıp desktop_click/desktop_type/desktop_key ile KENDİN kullan. "
            + (f"Bu programı ilk kez kullanıyorsan ÖNCE ÖĞREN: web_search ile '{item} nasıl kullanılır' ara, kaynakları oku, gerekirse youtube ile video özeti çıkar ve learn ile kaydet." if not know_find(str(item) + " kullanımı", 1) else ""))

# ═════════════════════════════ 📜 KONSOL TARİFLERİ (oturumu kaydet → tekrar oynat) ═════════════════════════════
CON_RECIPES = os.path.join(CONF_DIR, "konsol_tarifleri.json")
REPLAY_ACTS = ("run", "type_keys", "open_browser", "install", "write_file", "browser_open", "browser_go", "browser_click", "browser_type",
               "browser_scroll", "browser_back", "browser_close")

def con_recipes():
    return jload(CON_RECIPES, [])

def recipe_from_job(job, name="", pick=None):
    steps = [x for x in job.ctx.get("steps_full", []) if x.get("action") in REPLAY_ACTS]
    if pick is not None:
        allowed = set(int(i) for i in pick)
        steps = [x for i, x in enumerate(steps) if i in allowed]
    else:
        steps = [x for x in steps if x.get("ok")]
    if not steps:
        raise RuntimeError("Bu oturumda tekrar oynatılabilecek başarılı bir adım yok (komut, tarayıcı, kurulum…).")
    return {"id": uuid.uuid4().hex[:8], "name": (name or job.ctx.get("task") or job.title)[:80], "task": (job.ctx.get("task") or "")[:2000],
            "steps": [{k: v for k, v in x.items() if k in ("action", "args", "cwd", "thought", "desc")} for x in steps],
            "created": now(), "runs": 0, "last_run": "", "last_ok": None}

def recipe_save(rec):
    with _lock:
        l = [r for r in con_recipes() if r["id"] != rec["id"]] + [rec]; jsave(CON_RECIPES, l)
    return rec

def step_text(x):
    a = x.get("args") or {}
    if x["action"] == "run":
        return f"$ {a.get('command', '')}" + (f"   (📁 {x.get('cwd')})" if x.get("cwd") else "")
    if x["action"] == "type_keys":
        return f"⌨ {json.dumps(a.get('text', ''), ensure_ascii=False)}" + (" + Enter" if a.get("enter", True) else "")
    if x["action"] in ("open_browser", "browser_open", "browser_go"):
        return f"🌐 {a.get('url') or a.get('urls') or ('Google: ' + str(a.get('query', '')))}"
    if x["action"] == "browser_click":
        return f"🖱 tıkla: {(x.get('desc') or {}).get('text') or a.get('element')}"
    if x["action"] == "browser_type":
        return f"⌨ tarayıcıya yaz: {(x.get('desc') or {}).get('text') or a.get('element')} ← {json.dumps(a.get('text', ''), ensure_ascii=False)}"
    if x["action"] == "install":
        return f"⬇ kur: {a.get('url', '')}"
    if x["action"] == "write_file":
        return f"📝 dosya yaz: {a.get('path', '')}"
    return f"{x['action']} {json.dumps(a, ensure_ascii=False)[:120]}"

def recipe_replay_flow(job, rid, cid="", inp=""):
    """Kaydedilen adımları sırayla konsolda AYNEN yeniden oynatır (önce tüm plan onaya sunulur)."""
    rec = next((r for r in con_recipes() if r["id"] == rid), None)
    if not rec:
        raise KeyError(rid)
    con = console_get(cid=cid); job.ctx["console"] = con.id
    job.title = f"📜 {rec['name']}"; job.ctx["task"] = rec["name"]; job.ctx["chat"] = [{"role": "user", "text": f"📜 Tarifi aynen tekrarla: {rec['name']}"}]
    r = job.ask("confirm", {"message": f"📜 '{rec['name']}' tarifi bu konsolda AYNEN tekrarlanacak ({len(rec['steps'])} adım):\n\n"
                            + "\n".join(f"{i}. {step_text(x)}" for i, x in enumerate(rec["steps"], 1))
                            + "\n\nTarayıcıda tıklama/yazma adımları yine tek tek onayına gelecek. Başlatılsın mı?"})
    if not r or not r.get("ok"):
        job.status = "iptal"; return
    console_print(con, f"\n📜 Tarif tekrarlanıyor: {rec['name']}", "1;35")
    smap = {}; ok = True; fail = ""
    for i, x in enumerate(rec["steps"], 1):
        if job.cancelled:
            job.status = "iptal"; return
        a = dict(x.get("args") or {}); act = x["action"]
        job.status = f"{i}/{len(rec['steps'])}: {act}"
        stp = {"role": "step", "n": i, "thought": x.get("thought", ""), "action": act, "args": {k: str(v)[:200] for k, v in a.items() if not k.startswith("_")}}
        job.ctx["chat"].append(stp)
        try:
            if act == "run":
                cwd = x.get("cwd") or console_cwd(con)
                cmd = a.get("command", "")
                if needs_root(cmd) and not is_root():
                    job.ctx["mirror"] = con.id; rc, out = run_capture(job, cmd, cwd, int(a.get("timeout", 180))); job.ctx.pop("mirror", None)
                else:
                    rc, out = console_exec(con, cmd, cwd, int(a.get("timeout", 180)), job)
                stp["obs"] = f"çıkış kodu {rc}\n{out[-600:]}"
                if rc != 0:
                    ok = False; fail = f"'{cmd}' komutu {rc} koduyla bitti:\n{out[-1500:]}"; break
            elif act == "type_keys":
                txt_ = str(a.get("text", "")).replace("\\u0003", "\x03")
                con.write(txt_ + ("\n" if a.get("enter", True) else "")); time.sleep(min(30, float(a.get("wait", 3) or 3)))
                stp["obs"] = console_screen(con, 600)
            elif act == "open_browser":
                stp["obs"] = open_browser(a.get("url", ""), a.get("query", ""), a.get("browser", ""))
            elif act == "install":
                job.ctx["mirror"] = con.id; install_flow(job, a.get("url", ""), {}); job.ctx.pop("mirror", None); stp["obs"] = "kuruldu"
            elif act == "write_file":
                pth = os.path.expanduser(a.get("path", ""))
                if os.path.exists(pth):
                    stp["obs"] = "dosya zaten var, atlandı"
                else:
                    os.makedirs(os.path.dirname(pth) or ".", exist_ok=True); open(pth, "w", encoding="utf-8").write(a.get("content", "")); stp["obs"] = f"yazıldı: {pth}"
            elif act.startswith("browser_"):
                if a.get("session") in smap:
                    a["session"] = smap[a["session"]]
                if act == "browser_click" or act == "browser_type":
                    s_ = brw_sess(a.get("session"))
                    brw_read(s_["id"])  # öğe numaraları yeniden verilsin
                    n = brw_find(s_["id"], x.get("desc") or {})
                    if not n:
                        ok = False; fail = f"Tarayıcıda '{(x.get('desc') or {}).get('text', '')}' öğesi bulunamadı (sayfa değişmiş olabilir)."; break
                    a["element"] = n
                old = (x.get("args") or {}).get("session")
                obs = browser_action(job, act, a, auto=False)
                if act == "browser_open":
                    m = re.search(r"oturum: (\w+)", obs)
                    if m and old:
                        smap[old] = m.group(1)
                stp["obs"] = obs[:600]
                if obs.startswith(("HATA", "Kullanıcı")):
                    ok = False; fail = obs; break
        except Exception as e:
            ok = False; fail = f"{act}: {e}"; stp["obs"] = "HATA: " + str(e)[:300]; break
    with _lock:
        l = con_recipes()
        for r_ in l:
            if r_["id"] == rid:
                r_["runs"] = r_.get("runs", 0) + 1; r_["last_run"] = now(); r_["last_ok"] = ok
        jsave(CON_RECIPES, l)
    if ok:
        msg = f"✅ **{rec['name']}** tarifi baştan sona tekrarlandı ({len(rec['steps'])} adım)."
        job.ctx["chat"].append({"role": "agent", "text": msg, "final": True}); console_print(con, "📜 " + msg.replace("**", ""), "92"); job.log(msg)
        return
    job.log("✖ " + fail)
    console_print(con, "📜 Tarif bir adımda takıldı: " + fail[:300], "31")
    if llm_available():
        r = job.ask("confirm", {"message": f"Tarif bir adımda takıldı:\n{fail[:800]}\n\nYapay zekâ kaldığı yerden duruma uyum sağlayıp devam etsin mi?"})
        if r and r.get("ok"):
            done = "\n".join(step_text(y) for y in rec["steps"][:i - 1])
            todo = "\n".join(step_text(y) for y in rec["steps"][i - 1:])
            task = (f"Kayıtlı '{rec['name']}' tarifini tekrarlıyordum, bir adımda takıldı. Orijinal görev: {rec['task']}\n"
                    f"TAMAMLANAN ADIMLAR:\n{done or '(yok)'}\nKALAN ADIMLAR:\n{todo}\nHATA:\n{fail[:1500]}\n"
                    "Hatanın nedenini bul, gerekirse adımları bugünkü duruma uyarla ve görevi bitir.")
            j = start_job("Konsol AI", "agent", agent_flow, task, {"console": con.id, "workdir": console_cwd(con), "title": f"📜 {rec['name']} (onarım)",
                                                                   "shown": f"📜 '{rec['name']}' tarifinde takılan yeri düzelt ve bitir"})
            job.ctx["chat"].append({"role": "agent", "text": "🤖 Yapay zekâ devraldı — konsol sohbetinde devam ediyor.", "final": True})
            job.ctx["next_job"] = j.id
            return
    job.ctx["chat"].append({"role": "agent", "text": "✖ Tarif tamamlanamadı:\n```\n" + fail[:1500] + "\n```", "final": True})
    job.status = "hata"

def recipe_ai_task(rec, inp=""):
    return (f"Kayıtlı bir tarifi uygula: '{rec['name']}'.\nOrijinal görev: {rec['task']}\n"
            + (f"BU SEFERKİ İSTEK / DEĞİŞİKLİK: {inp}\n" if inp else "")
            + "Daha önce başarıyla işe yarayan adımlar (sırayla):\n" + "\n".join(f"{i}. {step_text(x)}" for i, x in enumerate(rec["steps"], 1))
            + "\nBu adımları rehber olarak kullan; bugünkü duruma ve yeni isteğe göre uyarla (dosya adları, klasörler, sürümler değişmiş olabilir). Sonucu doğrula ve finish ile rapor ver.")


# ═════════════════════════════ 🐙 DİSKTEKİ DEPOLAR: bilgi, güvenlik puanı, güncelleme, karşılaştırma, Cypher'a ekle ═════════════════════════════
REPO_INFO_FILE = os.path.join(CONF_DIR, "depo_bilgileri.json")

def repo_cache():
    return jload(REPO_INFO_FILE, {})

def _git(path, *a, timeout=40):
    env = base_env(); env["GIT_TERMINAL_PROMPT"] = "0"
    try:
        r = subprocess.run(["git", "-C", path, *a], capture_output=True, text=True, timeout=timeout, env=env)
        return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
    except Exception as e:
        return 1, "", str(e)

def _age_tr(ts):
    if not ts:
        return "bilinmiyor"
    d = (time.time() - ts) / 86400
    return "bugün" if d < 1 else (f"{int(d)} gün önce" if d < 60 else (f"{int(d / 30)} ay önce" if d < 730 else f"{d / 365:.1f} yıl önce"))

def _iso_ts(s):
    try:
        import calendar
        return calendar.timegm(time.strptime((s or "")[:19], "%Y-%m-%dT%H:%M:%S"))
    except Exception:
        return 0

def repo_score(info):
    sc, why = 100, []
    sec = info.get("security") or {}
    if sec:
        if sec.get("level") == "danger":
            sc -= 50; why.append("🛡️ Güvenlik taramasında TEHLİKELİ bulgu var (−50)")
        elif sec.get("level") == "warn":
            sc -= 20; why.append("🛡️ Güvenlik taramasında dikkat edilmesi gereken bulgular var (−20)")
        if sec.get("findings"):
            pen = min(15, int(sec.get("score", 0)) * 2)
            sc -= pen
            if sec.get("level") == "ok" and pen:
                why.append(f"🛡️ {len(sec['findings'])} küçük güvenlik bulgusu (incele) (−{pen})")
    gh = info.get("gh") or {}
    if gh.get("archived"):
        sc -= 25; why.append("📦 Depo arşivlenmiş, artık geliştirilmiyor (−25)")
    pt = gh.get("pushed_ts") or info.get("remote_ts") or info.get("head_ts") or 0
    if pt:
        age = (time.time() - pt) / 86400
        if age > 3 * 365:
            sc -= 20; why.append(f"⏳ Son güncelleme çok eski: {_age_tr(pt)} (−20)")
        elif age > 365:
            sc -= 10; why.append(f"⏳ Son 1 yılda güncellenmemiş: {_age_tr(pt)} (−10)")
    if gh:
        if not gh.get("license"):
            sc -= 5; why.append("📄 Lisans belirtilmemiş (−5)")
        st = gh.get("stars", 0)
        if st < 10:
            sc -= 10; why.append(f"⭐ Çok az yıldız ({st}) — az kişi kullanıyor (−10)")
        elif st >= 1000:
            why.append(f"⭐ Popüler: {st} yıldız")
    if info.get("update"):
        why.append("⬆ Yeni sürüm/commit var — güncellemen önerilir")
    if info.get("dirty"):
        why.append("✏️ Klasörde senin yaptığın kaydedilmemiş değişiklikler var")
    sc = max(0, min(100, sc))
    return sc, ("iyi" if sc >= 80 else "orta" if sc >= 50 else "riskli"), why

def repo_info(path, net=True, scan=True, ai=False, log=None):
    rp = os.path.realpath(os.path.expanduser(path))
    if not os.path.exists(os.path.join(rp, ".git")):
        raise KeyError(path)
    url = _git_remote(os.path.join(rp, ".git")); fn = _repo_full_name(url)
    _, head, _ = _git(rp, "log", "-1", "--format=%H|%ct|%s")
    h, ts, subj = (head.split("|", 2) + ["", "", ""])[:3]
    _, br, _ = _git(rp, "rev-parse", "--abbrev-ref", "HEAD")
    _, st, _ = _git(rp, "status", "--porcelain")
    info = {"path": rp, "name": os.path.basename(rp), "url": re.sub(r"://[^/@]+@", "://", url), "full_name": fn, "github": "github.com" in url,
            "branch": br, "head": h, "head_ts": int(ts or 0), "head_msg": subj[:160], "dirty": bool(st), "shallow": os.path.exists(os.path.join(rp, ".git", "shallow")),
            "checked": now(), "adopted": next((s for s, t in tools().items() if os.path.realpath(t.get("path", "")) == rp), "")}
    old = repo_cache().get(rp, {})
    if net:
        rb = (dev_base(rp)[0] if br == DEV_BRANCH else br) or "HEAD"
        rc, out, err = _git(rp, "ls-remote", "origin", "HEAD" if rb in ("HEAD", "") else rb, timeout=40)
        rh = out.split()[0] if out.split() else ""
        uh = upstream_head(rp) or h
        info["remote_head"] = rh; info["update"] = bool(rh and uh and rh != uh); info["developed"] = dev_branch(rp) == DEV_BRANCH
        info["net_error"] = "" if rc == 0 else (err[-200:] or "uzak depoya ulaşılamadı")
        if fn and info["github"]:
            try:
                o, r_ = fn.split("/", 1); g = gh_api(f"/repos/{o}/{r_}")
                info["gh"] = {"stars": g.get("stargazers_count", 0), "forks": g.get("forks_count", 0), "issues": g.get("open_issues_count", 0),
                              "archived": bool(g.get("archived")), "license": (g.get("license") or {}).get("spdx_id") or "", "language": g.get("language") or "",
                              "description": g.get("description") or "", "pushed_at": g.get("pushed_at", ""), "pushed_ts": _iso_ts(g.get("pushed_at")),
                              "html_url": g.get("html_url", ""), "default_branch": g.get("default_branch", ""), "topics": g.get("topics", [])[:8]}
            except Exception as e:
                info["gh_error"] = str(e)[:160]; info["gh"] = old.get("gh") or {}
    else:
        for k in ("remote_head", "update", "gh"):
            if k in old:
                info[k] = old[k]
        if info.get("remote_head") and info.get("remote_head") != h:
            info["update"] = True
    if scan:
        if log: log(f"🛡️ Güvenlik taraması: {rp}")
        sec = security_scan(rp, ai=ai, log=log)
        info["security"] = {k: sec[k] for k in ("level", "score", "files", "findings", "ai") if k in sec}
        info["security"]["findings"] = info["security"]["findings"][:12]
        info["scanned_head"] = h
    elif old.get("security") and old.get("scanned_head") == h:
        info["security"] = old["security"]; info["scanned_head"] = h
    info["desc"] = (info.get("gh") or {}).get("description") or readme_intro(rp)[:300]
    info["score"], info["grade"], info["why"] = repo_score(info)
    with _lock:
        c = repo_cache(); c[rp] = info; jsave(REPO_INFO_FILE, c)
    return info

def repos_check_flow(job, paths, scan=False):
    job.title = "🐙 Depolar kontrol ediliyor"; res = []
    paths = paths or [r["path"] for r in github_repos()]
    for i, pth in enumerate(paths, 1):
        if job.cancelled:
            break
        job.status = f"{i}/{len(paths)}: {os.path.basename(pth)}"
        try:
            inf = repo_info(pth, net=True, scan=scan, log=job.log)
            res.append(inf)
            job.log(f"{'⬆' if inf.get('update') else '✔'} {inf['name']}: puan {inf['score']} ({inf['grade']})" + (f" · ⭐ {inf['gh'].get('stars')}" if inf.get("gh") else "")
                    + (" · güncelleme var" if inf.get("update") else ""))
        except Exception as e:
            job.log(f"⚠ {pth}: {e}")
    n = sum(1 for x in res if x.get("update"))
    job.ctx["report"] = f"{len(res)} depo kontrol edildi, {n} tanesinde güncelleme var."
    job.log("✅ " + job.ctx["report"])
    if n:
        notify(APP, f"🐙 {n} depoda güncelleme var")

def repo_update_flow(job, path):
    rp = os.path.realpath(os.path.expanduser(path)); job.title = f"⬆ Güncelleme: {os.path.basename(rp)}"
    inf = repo_info(rp, net=True, scan=False)
    if inf.get("dirty"):
        r = job.ask("confirm", {"message": f"'{inf['name']}' klasöründe kaydedilmemiş değişikliklerin var.\nGüncelleme önce bunları 'git stash' ile kenara koyacak (kaybolmaz, 'git stash pop' ile geri alınır). Devam edilsin mi?"})
        if not r or not r.get("ok"):
            job.status = "iptal"; return
        rc, out, err = _git(rp, "stash", "push", "-u", "-m", "cyphertool-guncelleme"); job.log(out + err)
    if dev_branch(rp) == DEV_BRANCH:
        rc = 0 if dev_rebase_update(rp, job.log) else 1
    else:
        rc, out, err = _git(rp, "pull", "--ff-only", timeout=300); job.log("$ git pull --ff-only\n" + out + "\n" + err)
    if rc != 0:
        job.log("✖ Hızlı ileri alma yapılamadı (dal ayrışmış olabilir). Konsolda 'git status' ile bakabilir ya da Konsol AI'dan yardım isteyebilirsin.")
        job.status = "hata"; return
    inf = repo_info(rp, net=False, scan=True, log=job.log)
    for s_, t in tools().items():
        if os.path.realpath(t.get("path", "")) == rp:
            update_tool(s_, commit=git_head(rp), update_available=False, update_info="", updated_at=now())
    job.log(f"✅ Güncellendi. Yeni puan: {inf['score']} ({inf['grade']})")
    if any(os.path.exists(os.path.join(rp, f)) for f in ("requirements.txt", "package.json", "pyproject.toml", "Cargo.toml", "go.mod")):
        job.log("ℹ Bağımlılıklar değişmiş olabilir; araç çalışmazsa kartındaki 🩺 Doktor'u ya da Konsol AI'ı kullan.")

def repo_compare(paths, ai=True):
    infos = []
    for pth in paths[:6]:
        c = repo_cache().get(os.path.realpath(pth))
        infos.append(c if c and c.get("security") else repo_info(pth, net=True, scan=True))
    summary = ""
    if ai and llm_available() and len(infos) > 1:
        brief = [{"ad": i["name"], "repo": i.get("full_name"), "aciklama": i.get("desc", "")[:200], "puan": i["score"], "yildiz": (i.get("gh") or {}).get("stars"),
                  "son_guncelleme": _age_tr((i.get("gh") or {}).get("pushed_ts") or i.get("head_ts")), "arsiv": (i.get("gh") or {}).get("archived"),
                  "lisans": (i.get("gh") or {}).get("license"), "guvenlik": (i.get("security") or {}).get("level"), "guncelleme_var": i.get("update"), "notlar": i.get("why")} for i in infos]
        try:
            summary, _ = llm_ask([{"role": "user", "content": "Bu GitHub araçlarını karşılaştır:\n" + json.dumps(brief, ensure_ascii=False)}],
                                 "Türkçe, kısa ve net yaz (Markdown). Önce 1 cümle sonuç: hangisini önerirsin ve neden. Sonra her araç için 1-2 maddelik artı/eksi. "
                                 "Aynı işi yapmıyorlarsa bunu söyle. Uydurma bilgi ekleme.", feature="chat")
        except Exception as e:
            summary = f"(yapay zekâ özeti alınamadı: {str(e)[:100]})"
    return {"items": infos, "summary": summary}

def adopt_repo(path, shortcut=False):
    rp = os.path.realpath(os.path.expanduser(path))
    if not os.path.exists(os.path.join(rp, ".git")):
        raise KeyError(path)
    for s_, t in tools().items():
        if os.path.realpath(t.get("path", "")) == rp:
            return s_
    url = _git_remote(os.path.join(rp, ".git")); fn = _repo_full_name(url); name = os.path.basename(rp)
    owner, repo = (fn.split("/", 1) if fn else ("", name))
    slug = slugify(repo or name) or "depo"
    while slug in tools():
        slug += "-2"
    meta = gh_meta(owner, repo) if fn and "github.com" in url else {"full_name": fn or name, "html_url": url}
    acts, _ = discover_actions(rp, name)
    try: icon = fetch_icon(slug, rp, owner if "github.com" in url else "")
    except Exception: icon = ""
    tool = {"slug": slug, "name": name, "path": rp, "source": re.sub(r"://[^/@]+@", "://", url) or rp, "full_name": meta.get("full_name") or fn or name, "meta": meta,
            "summary": meta.get("description") or readme_intro(rp)[:300], "category": "Diskten eklendi", "steps": [], "actions": acts,
            "runtimes": [], "system_packages": [], "optional": [], "icon": icon, "installed_at": now(), "status": "kuruldu",
            "guide_tr": "", "update_mode": cfg().get("update_default_mode", "sor"), "inject_keys": True, "catalog_id": "", "kind": "tool",
            "external": True, "commit": git_head(rp)}
    with _lock:
        t = tools(); t[slug] = tool; save_tools(t)
    if acts and shortcut:
        try: make_shortcuts(tools()[slug])
        except Exception: pass
    REPO_SCAN["at"] = 0
    if llm_available():
        def bg():
            try:
                make_guide(slug)
            except Exception:
                pass
        threading.Thread(target=bg, daemon=True).start()
    return slug


# ═════════════════════════════ 🧭 GÖRSEL TARAYICI KONTROLÜ (Chrome DevTools Protokolü — çoklu tarayıcı, her adım onaylı) ═════════════════════════════
BRW_DIR = os.path.join(DATA, "tarayici"); BRW_SHOTS = os.path.join(BRW_DIR, "goruntuler")
os.makedirs(BRW_SHOTS, exist_ok=True)
BRW = {"proc": None, "port": 0, "browser": "", "headless": False, "sessions": {}, "n": 0, "lock": threading.RLock()}

class WS:
    """Sadece standart kütüphaneyle küçük bir WebSocket istemcisi (CDP için yeterli)."""
    def __init__(self, url, timeout=20):
        u = urllib.parse.urlparse(url)
        self.s = socket.create_connection((u.hostname, u.port), timeout=timeout)
        key = base64.b64encode(os.urandom(16)).decode()
        self.s.sendall((f"GET {u.path} HTTP/1.1\r\nHost: {u.hostname}:{u.port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                        f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n").encode())
        resp = b""
        while b"\r\n\r\n" not in resp:
            c = self.s.recv(4096)
            if not c:
                raise ConnectionError("WebSocket el sıkışması başarısız")
            resp += c
        head, rest = resp.split(b"\r\n\r\n", 1)
        if b" 101" not in head.split(b"\r\n")[0]:
            raise ConnectionError("WebSocket reddedildi: " + head.split(b"\r\n")[0].decode(errors="replace"))
        self.buf = bytearray(rest); self.lock = threading.Lock(); self.mid = 0

    def _recv(self, n):
        while len(self.buf) < n:
            c = self.s.recv(1 << 20)
            if not c:
                raise ConnectionError("bağlantı kapandı")
            self.buf += c
        d = bytes(self.buf[:n]); del self.buf[:n]; return d

    def _send(self, op, payload):
        n = len(payload); h = bytearray([0x80 | op])
        if n < 126:
            h.append(0x80 | n)
        elif n < 65536:
            h.append(0x80 | 126); h += n.to_bytes(2, "big")
        else:
            h.append(0x80 | 127); h += n.to_bytes(8, "big")
        m = os.urandom(4); h += m
        mi = int.from_bytes((m * (n // 4 + 1))[:n], "big") if n else 0
        body = (int.from_bytes(payload, "big") ^ mi).to_bytes(n, "big") if n else b""
        self.s.sendall(bytes(h) + body)

    def recv_msg(self):
        parts = []
        while True:
            b1, b2 = self._recv(2); op = b1 & 0x0F; n = b2 & 0x7F
            if n == 126:
                n = int.from_bytes(self._recv(2), "big")
            elif n == 127:
                n = int.from_bytes(self._recv(8), "big")
            data = self._recv(n)
            if op == 8:
                raise ConnectionError("tarayıcı bağlantıyı kapattı")
            if op == 9:
                self._send(10, data); continue
            if op == 10:
                continue
            parts.append(data)
            if b1 & 0x80:
                return b"".join(parts).decode("utf-8", "replace")

    def call(self, method, params=None, timeout=30):
        with self.lock:
            self.mid += 1; mid = self.mid
            self._send(1, json.dumps({"id": mid, "method": method, "params": params or {}}).encode())
            self.s.settimeout(timeout)
            while True:
                m = json.loads(self.recv_msg())
                if m.get("id") == mid:
                    if "error" in m:
                        raise RuntimeError(m["error"].get("message", "CDP hatası"))
                    return m.get("result", {})

    def close(self):
        try: self.s.close()
        except Exception: pass

def _brw_port_ok(port):
    try:
        http_get(f"http://127.0.0.1:{port}/json/version", timeout=2); return True
    except Exception:
        return False

def brw_embed():
    """Uygulama içi tarayıcı (varsayılan): kontrollü Chrome pencere açmadan çalışır, görüntüsü Konsol'daki 🌐 sekmesinde akar."""
    return cfg().get("browser_embed", True) is not False

def brw_frame(sid, q=55):
    s = brw_sess(sid)
    r = s["ws"].call("Page.captureScreenshot", {"format": "jpeg", "quality": int(q)}, 15)
    s["at"] = time.time()
    return base64.b64decode(r["data"])

KEYS = {"Enter": 13, "Backspace": 8, "Tab": 9, "Escape": 27, "Delete": 46, "ArrowLeft": 37, "ArrowUp": 38, "ArrowRight": 39, "ArrowDown": 40,
        "Home": 36, "End": 35, "PageUp": 33, "PageDown": 34}

def brw_input(sid, b):
    """Kullanıcının uygulama içindeki tarayıcı görüntüsünde yaptığı tıklama/kaydırma/yazma (kullanıcının kendisi — onay gerekmez)."""
    s = brw_sess(sid); ws = s["ws"]; t = b.get("t")
    if t == "click":
        x, y = float(b.get("x", 0)), float(b.get("y", 0))
        for ty in ("mouseMoved", "mousePressed", "mouseReleased"):
            ws.call("Input.dispatchMouseEvent", {"type": ty, "x": x, "y": y, "button": "left" if ty != "mouseMoved" else "none", "clickCount": 0 if ty == "mouseMoved" else int(b.get("n", 1))})
    elif t == "move":
        ws.call("Input.dispatchMouseEvent", {"type": "mouseMoved", "x": float(b.get("x", 0)), "y": float(b.get("y", 0))})
    elif t == "wheel":
        ws.call("Input.dispatchMouseEvent", {"type": "mouseWheel", "x": float(b.get("x", 400)), "y": float(b.get("y", 300)), "deltaX": float(b.get("dx", 0)), "deltaY": float(b.get("dy", 0))})
    elif t == "text":
        ws.call("Input.insertText", {"text": str(b.get("text", ""))[:2000]})
    elif t == "key":
        k = str(b.get("key", "")); code = KEYS.get(k, 0); mods = int(b.get("mods", 0))
        if k in ("a", "c", "v", "x", "z", "y") and mods:
            code = ord(k.upper())
        ws.call("Input.dispatchKeyEvent", {"type": "keyDown" if k != "Enter" else "keyDown", "key": k, "code": k if len(k) > 1 else "Key" + k.upper(), "windowsVirtualKeyCode": code, "modifiers": mods, **({"text": "\r"} if k == "Enter" else {})})
        ws.call("Input.dispatchKeyEvent", {"type": "keyUp", "key": k, "code": k if len(k) > 1 else "Key" + k.upper(), "windowsVirtualKeyCode": code, "modifiers": mods})
    elif t == "nav":
        u = _brw_url(str(b.get("url", "")).strip(), "") if re.match(r"^(https?://|[\w-]+\.[\w.-]+(/|$)|localhost|127\.)", str(b.get("url", "")).strip()) else _brw_url("", str(b.get("url", "")))
        s["want"] = u; s["want_at"] = time.time()
        ws.call("Page.navigate", {"url": u})
    elif t in ("back", "forward"):
        h = ws.call("Page.getNavigationHistory")
        i = h.get("currentIndex", 0) + (-1 if t == "back" else 1); e = h.get("entries", [])
        if 0 <= i < len(e):
            ws.call("Page.navigateToHistoryEntry", {"entryId": e[i]["id"]})
    elif t == "reload":
        ws.call("Page.reload")
    elif t == "size":   # sayfayı paneldeki gerçek boyutta çiz (yazılar küçülmesin)
        z = max(0.4, min(2.0, float(b.get("zoom", 1) or 1)))
        w = max(360, min(3000, int(int(b.get("w", 1280)) / z))); h = max(300, min(2000, int(int(b.get("h", 860)) / z)))
        ws.call("Emulation.setDeviceMetricsOverride", {"width": w, "height": h, "deviceScaleFactor": float(b.get("dpr", 1) or 1), "mobile": False})
        s["size"] = (w, h); return {"title": s.get("title", ""), "url": s.get("url", ""), "w": w, "h": h}
    time.sleep(0.05)
    if t in ("nav", "back", "forward", "reload", "click"):
        threading.Thread(target=lambda: (time.sleep(1.8), brw_after_load(sid)), daemon=True).start()
    try:
        info = brw_eval(sid, "[document.title, location.href]", 3)
        s["title"], s["url"] = info[0], info[1]
    except Exception:
        pass
    return {"title": s.get("title", ""), "url": s.get("url", "")}

def brw_alive():
    if BRW["proc"] is not None:
        return BRW["proc"].poll() is None
    return bool(BRW["port"]) and _brw_port_ok(BRW["port"])

def brw_start():
    with BRW["lock"]:
        if BRW["port"] and brw_alive():
            return BRW["port"]
        prof = os.path.join(BRW_DIR, "profil")
        # önceki oturumdan açık kalan kontrollü tarayıcıya yeniden bağlan (profil kilitliyse yenisi açılamaz)
        stale = []
        for pd in (os.listdir("/proc") if os.path.isdir("/proc") else []):
            if not pd.isdigit():
                continue
            try:
                cl = open(f"/proc/{pd}/cmdline", "rb").read().split(b"\0")
            except Exception:
                continue
            args_ = [x.decode(errors="replace") for x in cl]
            if f"--user-data-dir={prof}" in args_ and not any(x.startswith("--type=") for x in args_):
                m = next((re.match(r"--remote-debugging-port=(\d+)", x) for x in args_ if x.startswith("--remote-debugging-port=")), None)
                if m and _brw_port_ok(int(m.group(1))):
                    BRW.update(proc=None, port=int(m.group(1)), sessions={}, headless="--headless=new" in args_ or "--headless" in args_)
                    threading.Thread(target=brw_adopt, daemon=True).start()
                    return BRW["port"]
                stale.append(int(pd))
        for pid in stale:  # yanıt vermeyen eski kontrollü tarayıcı → kapat
            try: os.kill(pid, signal.SIGTERM)
            except Exception: pass
        if stale:
            time.sleep(1.5)
        for f in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
            try: os.remove(os.path.join(prof, f))
            except Exception: pass
        b = next((x for x in BROWSERS if "firefox" not in x and which(x)), "")
        if not b:
            raise RuntimeError("Tarayıcı kontrolü için Chrome, Chromium, Brave ya da Edge gerekli (Firefox desteklenmiyor). Sistem sekmesinden veya paket yöneticisiyle 'chromium' kur.")
        sk = socket.socket(); sk.bind(("127.0.0.1", 0)); port = sk.getsockname()[1]; sk.close()
        headless = bool(cfg().get("browser_headless")) or brw_embed() or not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))
        args = [b, f"--remote-debugging-port={port}", "--remote-allow-origins=*", f"--user-data-dir={prof}",
                "--no-first-run", "--no-default-browser-check", "--lang=tr", "--accept-lang=tr-TR,tr,en-US,en", "--window-size=1280,900", "--disable-features=Translate",
                "--disable-blink-features=AutomationControlled", "--autoplay-policy=no-user-gesture-required", "--hide-scrollbars"]
        if headless:
            args.insert(1, "--headless=new")
        if is_root():
            args[1:1] = ["--no-sandbox", "--test-type"]
        BRW["proc"] = subprocess.Popen(args + ["about:blank"], env=base_env(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        BRW.update(port=port, browser=b, headless=headless, sessions={})
        for _ in range(100):
            try:
                http_get(f"http://127.0.0.1:{port}/json/version", timeout=2); break
            except Exception:
                time.sleep(0.15)
        else:
            raise RuntimeError(f"{b} hata ayıklama modunda başlatılamadı.")
        return port

def brw_bws():
    port = brw_start()
    v = json.loads(http_get(f"http://127.0.0.1:{port}/json/version", timeout=5))
    return WS(v["webSocketDebuggerUrl"])

def brw_sess(sid):
    s = BRW["sessions"].get(sid or "")
    if not s:
        if not sid and len(BRW["sessions"]) == 1:
            return next(iter(BRW["sessions"].values()))
        raise KeyError(f"tarayıcı oturumu '{sid}' yok — açık olanlar: {', '.join(BRW['sessions']) or 'hiç yok (önce browser_open)'}")
    if not brw_alive():
        BRW["sessions"].clear(); raise RuntimeError("Tarayıcı kapanmış; browser_open ile yeniden aç.")
    return s

def brw_eval(sid, js, timeout=30):
    s = brw_sess(sid)
    try:
        r = s["ws"].call("Runtime.evaluate", {"expression": js, "returnByValue": True, "awaitPromise": True}, timeout)
    except (ConnectionError, OSError) as e:
        if isinstance(e, socket.timeout):
            raise RuntimeError("Sayfa yanıt vermiyor (zaman aşımı).")
        BRW["sessions"].pop(s["id"], None); s["ws"].close()
        raise RuntimeError(f"{s['id']} penceresi kapatılmış. Gerekirse browser_open ile yeniden aç.")
    if r.get("exceptionDetails"):
        raise RuntimeError("Sayfa betiği hatası: " + str((r["exceptionDetails"].get("exception") or {}).get("description") or r["exceptionDetails"].get("text"))[:300])
    return (r.get("result") or {}).get("value")

def brw_wait(sid, t=12):
    t0 = time.time(); time.sleep(0.4)
    while time.time() - t0 < t:
        try:
            if brw_eval(sid, "document.readyState", 5) == "complete":
                break
        except Exception:
            pass
        time.sleep(0.3)
    time.sleep(0.3); brw_settle(sid)
    try: brw_after_load(sid)
    except Exception: pass
    try:
        info = brw_eval(sid, "[document.title, location.href]", 5)
        BRW["sessions"][sid].update(title=info[0], url=info[1], at=time.time())
    except Exception:
        pass

SEARCH_ENGINES = {"google": "https://www.google.com/search?q={q}&hl=tr&num=10", "bing": "https://www.bing.com/search?q={q}&setlang=tr",
                  "duckduckgo": "https://duckduckgo.com/?q={q}&kl=tr-tr", "startpage": "https://www.startpage.com/do/search?q={q}&language=turkce"}

def search_url(query):
    e = str((cfg().get("auto") or {}).get("search_engine", "google") or "google")
    tpl = SEARCH_ENGINES.get(e) or (e if "{q}" in e else SEARCH_ENGINES["google"])
    return tpl.replace("{q}", urllib.parse.quote_plus(query))

def _brw_url(url="", query=""):
    if query and not url:
        return search_url(query)
    if url and not re.match(r"^(https?|about|file|chrome):", url):
        url = ("http://" if re.match(r"^(localhost|127\.|10\.|192\.168\.|\[?::1)", url) else "https://") + url
    return url or "about:blank"

# her sayfaya yüklenen küçük betik: yeni sekme bağlantıları aynı sekmede açılsın, alert/prompt sayfayı dondurmasın
BRW_INIT_JS = r"""(()=>{if(window.__ctInit)return;window.__ctInit=1;try{
document.addEventListener('click',e=>{const a=e.target&&e.target.closest&&e.target.closest('a[target]');if(a&&a.target!=='_self'&&a.target!=='_top'&&a.href&&!a.href.startsWith('javascript'))a.target='_self';},true);
const _o=window.open;window.open=function(u){try{if(u){location.href=new URL(u,location.href).href;return window;}}catch(e){}return _o.apply(this,arguments);};
window.alert=function(m){console.log('[uyarı] '+m);};
window.prompt=function(m,d){console.log('[soru] '+m);return d||'';};
}catch(e){}})()"""

def brw_downloads():
    d = ""
    try:
        d = subprocess.run(["xdg-user-dir", "DOWNLOAD"], capture_output=True, text=True, timeout=3).stdout.strip()
    except Exception:
        pass
    if not d or d == os.path.expanduser("~"):
        d = os.path.expanduser("~/İndirilenler") if os.path.isdir(os.path.expanduser("~/İndirilenler")) else os.path.expanduser("~/Downloads")
    os.makedirs(d, exist_ok=True)
    return d

def brw_setup(ws):
    """Sayfa oturumu ayarları: normal Chrome gibi görün (HeadlessChrome yazmasın), Türkçe dil, yeni sekme/uyarı düzeltmesi."""
    try:
        ua = BRW.get("ua")
        if not ua:
            bw = brw_bws(); v = bw.call("Browser.getVersion"); ua = v.get("userAgent", "").replace("HeadlessChrome", "Chrome"); BRW["ua"] = ua
            try: bw.call("Browser.setDownloadBehavior", {"behavior": "allow", "downloadPath": brw_downloads(), "eventsEnabled": False})
            except Exception: pass
            bw.close()
        ws.call("Network.setUserAgentOverride", {"userAgent": ua, "acceptLanguage": "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7", "platform": "Linux x86_64"})
    except Exception:
        pass
    try:  # arka plandaki sekmeler de odaklı sayılsın (yazı/klavye kaybolmasın)
        ws.call("Emulation.setFocusEmulationEnabled", {"enabled": True})
    except Exception:
        pass
    try:
        ws.call("Page.addScriptToEvaluateOnNewDocument", {"source": BRW_INIT_JS})
        ws.call("Runtime.evaluate", {"expression": BRW_INIT_JS})
    except Exception:
        pass

# çerez / izin pencereleri: varsayılan "tümünü reddet" (yoksa kabul) — Google/YouTube AB izin sayfası dahil
CONSENT_JS = r"""(MODE=>{const host=location.hostname;const R=/^\s*(tümünü reddet|hepsini reddet|reddet|reject all|reject|decline( all)?|alle ablehnen|odrzuć wszystko|tout refuser|rifiuta tutto|rechazar todo|only necessary|yalnızca gerekli|sadece gerekli|necessary only)\s*$/i;
const A=/^\s*(tümünü kabul et|hepsini kabul et|kabul et|kabul ediyorum|accept all|accept|i agree|agree|allow all|alle akzeptieren|zaakceptuj wszystko|akceptuję|tout accepter|accetta tutto|aceptar todo|got it|tamam)\s*$/i;
const inCmp=e=>{for(let x=e;x;x=x.parentElement){const s=((x.id||'')+' '+(typeof x.className==='string'?x.className:'')+' '+(x.getAttribute&&x.getAttribute('aria-label')||'')).toLowerCase();if(/cookie|consent|gdpr|onetrust|cmp|didomi|usercentrics|cookiebot|privacy|çerez|qc-cmp|truste|osano|klaro/.test(s))return true;}return false;};
const isConsentPage=/^consent\.|\.consent\./.test(host);
const btns=[...document.querySelectorAll('button,[role=button],input[type=button],input[type=submit],a')].filter(b=>{const r=b.getBoundingClientRect();return r.width>2&&r.height>2;});
const txt=b=>(b.innerText||b.value||b.getAttribute('aria-label')||'').trim();
const pick=re=>btns.find(b=>re.test(txt(b))&&(isConsentPage||inCmp(b)));
const b=(MODE==='accept'?pick(A):(pick(R)||pick(A)));if(b){b.click();return txt(b);}return '';})"""

CAPTCHA_JS = r"""(()=>{const h=location.href,t=document.title.toLowerCase();
if(/google\.[^/]+\/sorry\//.test(h)) return 'Google olağandışı trafik doğrulaması';
if(/just a moment|bir dakika|attention required|verify you are human|robot olmadığınızı/.test(t)) return 'Cloudflare / insan doğrulaması';
if(document.querySelector('iframe[src*="recaptcha"],iframe[src*="hcaptcha"],iframe[src*="challenges.cloudflare"],#cf-challenge-running,.g-recaptcha,.h-captcha')) return 'CAPTCHA';
return '';})()"""

def brw_settle(sid, tmax=6.0):
    """Sayfa içeriği değişmeyi bırakana kadar bekle (SPA / fetch ile yüklenen içerik; 'Yükleniyor…' yazısı)."""
    t0 = time.time(); last = None; same = 0
    while time.time() - t0 < tmax:
        try:
            st = brw_eval(sid, "[document.readyState,(document.body&&document.body.innerText||'').length,document.querySelectorAll('*').length,/(^|\\n)\\s*(yükleniyor|loading|lütfen bekleyin|please wait)\\s*[.…]*\\s*($|\\n)/i.test(document.body&&document.body.innerText||''),!!document.querySelector('[aria-busy=true],.spinner,.loading:not([hidden])')]", 4)
        except Exception:
            return
        key = (st[1], st[2])
        busy = st[0] != "complete" or st[3] or st[4]
        if key == last and not busy:
            same += 1
            if same >= 2:
                return
        else:
            same = 0
        last = key; time.sleep(0.3)

def brw_after_load(sid):
    """Sayfa yüklendikten sonra: çerez penceresini kapat, doğrulama (CAPTCHA) var mı bak."""
    s = BRW["sessions"].get(sid)
    if not s:
        return
    try:  # yeni sekme / alert düzeltmesi bu sayfada da etkin olsun
        if not brw_eval(sid, "!!window.__ctInit", 3):
            brw_eval(sid, BRW_INIT_JS, 3)
    except Exception:
        pass
    mode = (cfg().get("auto") or {}).get("cookies", "reject")
    if not s.get("_back"):
        s["consent"] = ""
    if mode != "off":
        for _ in range(2):
            try:
                pre = brw_eval(sid, "location.href", 3)
                hit = brw_eval(sid, CONSENT_JS + f"({json.dumps(mode)})", 5)
            except Exception:
                hit = ""
            if not hit:
                break
            s["consent"] = hit; time.sleep(1.2)
            # izin sayfası istenen sayfanın yerine açılmıştıysa (Google "devam etmeden önce" vb.), kapattıktan sonra asıl adrese dön
            try:
                cur = brw_eval(sid, "location.href", 5); want = s.get("want") or ""
                # yalnızca: istenen adres az önce açıldıysa VE izin penceresi o adresin yerine gelen bir ara sayfadaysa (consent.* / farklı adres)
                inter = pre.split("#")[0] != want.split("#")[0] and (urllib.parse.urlparse(pre).hostname or "").startswith("consent.") or (pre.split("?")[0] != want.split("?")[0] and time.time() - s.get("want_at", 0) < 20)
                if want and want != "about:blank" and inter and time.time() - s.get("want_at", 0) < 20 and cur.split("#")[0] != want.split("#")[0] and not s.get("_back"):
                    s["_back"] = True
                    try:
                        s["ws"].call("Page.navigate", {"url": want}); brw_wait(sid, 10)
                    finally:
                        s["_back"] = False
            except Exception:
                pass
    try:
        cap = brw_eval(sid, CAPTCHA_JS, 5)
        if cap and "Cloudflare" in cap:   # çoğu kendiliğinden geçer, biraz bekle
            for _ in range(8):
                time.sleep(1); cap = brw_eval(sid, CAPTCHA_JS, 5)
                if not cap: break
        s["captcha"] = cap or ""
    except Exception:
        pass

def brw_captcha_wait(job, sid, con=None, timeout=900):
    """Sayfa insan doğrulaması istiyorsa: kullanıcıya haber ver, o 🌐 sekmesinde çözene kadar bekle, çözülünce kendiliğinden devam et."""
    s = BRW["sessions"].get(sid)
    if not s or not s.get("captcha"):
        return ""
    what = s["captcha"]; t0 = time.time()
    msg = f"🧩 {what} — {s.get('url', '')[:80]}\n   Konsol → 🌐 {sid} sekmesinde doğrulamayı sen çöz; çözünce kendiliğinden devam ediyorum."
    job.log(msg); job.ctx["captcha_wait"] = sid
    if con: console_print(con, msg, "1;33")
    try: notify(APP, f"🧩 Doğrulama gerekiyor: {(urllib.parse.urlparse(s.get('url', '')).hostname or '')}")
    except Exception: pass
    prev = job.status; job.status = "doğrulama bekleniyor"
    try:
        while time.time() - t0 < timeout and not job.cancelled:
            time.sleep(2)
            try:
                cap = brw_eval(sid, CAPTCHA_JS, 5)
            except Exception:
                cap = s.get("captcha", "")
            if not cap:
                s["captcha"] = ""; time.sleep(1.5)
                try: brw_wait(sid, 8)
                except Exception: pass
                job.log("✅ Doğrulama geçildi — devam ediyorum."); 
                if con: console_print(con, "✅ Doğrulama geçildi — devam ediyorum.", "92")
                return "done"
    finally:
        job.status = prev if job.status == "doğrulama bekleniyor" else job.status; job.ctx.pop("captcha_wait", None)
    return "timeout"

def brw_adopt():
    """Uygulama yeniden açıldığında (ya da bir site kendi başına yeni sekme açınca) o sayfaları 🌐 sekmeleri olarak al."""
    with BRW["lock"]:   # liste kilidin İÇİNDE alınır: uygulamanın kendi açtığı sekmeyle yarışıp iki kez eklenmesin
        try:
            L = json.loads(http_get(f"http://127.0.0.1:{BRW['port']}/json/list", timeout=3))
        except Exception:
            return
        _brw_adopt(L)

def _brw_adopt(L):
    known = {x["target"] for x in BRW["sessions"].values()}
    for t in L:
        if t.get("type") != "page" or t.get("id") in known or (t.get("url") or "").startswith(("about:blank", "chrome:", "devtools:")):
            continue
        try:
            ws = WS(t["webSocketDebuggerUrl"], timeout=30)
        except Exception:
            continue
        BRW["n"] += 1; sid = f"t{BRW['n']}"
        BRW["sessions"][sid] = {"id": sid, "name": "🌐 " + ((urllib.parse.urlparse(t.get("url", "")).hostname or "sayfa").replace("www.", "")[:28]), "target": t["id"], "ws": ws,
                                "title": t.get("title", ""), "url": t.get("url", ""), "created": time.time(), "at": time.time(), "elements": [], "shot": ""}
        brw_setup(ws)

def brw_reattach():
    """Sunucu açılırken: önceki oturumdan çalışan kontrollü tarayıcı varsa bağlan (yoksa yeni tarayıcı AÇMA)."""
    prof = os.path.join(BRW_DIR, "profil")
    try:
        for pd in os.listdir("/proc"):
            if not pd.isdigit():
                continue
            try:
                args_ = [x.decode(errors="replace") for x in open(f"/proc/{pd}/cmdline", "rb").read().split(b"\0")]
            except Exception:
                continue
            if f"--user-data-dir={prof}" in args_ and not any(x.startswith("--type=") for x in args_):
                brw_start(); time.sleep(1.5); brw_adopt(); return
    except Exception:
        pass

def brw_open(url="", query="", name=""):
    url = _brw_url(url, query)
    with BRW["lock"]:
        bw = brw_bws()
        try:
            tid = bw.call("Target.createTarget", {"url": "about:blank", "newWindow": True})["targetId"]
        finally:
            bw.close()
        BRW["n"] += 1; sid = f"t{BRW['n']}"
        ws = WS(f"ws://127.0.0.1:{BRW['port']}/devtools/page/{tid}", timeout=30)
        BRW["sessions"][sid] = {"id": sid, "name": (name or "")[:40] or f"Tarayıcı {BRW['n']}", "target": tid, "ws": ws, "title": "", "url": url,
                                "created": time.time(), "at": time.time(), "elements": [], "shot": ""}
    brw_setup(ws)
    try:
        ws.call("Emulation.setDeviceMetricsOverride", {"width": 1280, "height": 860, "deviceScaleFactor": 1, "mobile": False}) if BRW["headless"] else None
    except Exception:
        pass
    if url != "about:blank":
        BRW["sessions"][sid]["want"] = url; BRW["sessions"][sid]["want_at"] = time.time()
        ws.call("Page.navigate", {"url": url}); brw_wait(sid)
    return sid

def brw_go(sid, url):
    s = brw_sess(sid); s["want"] = url; s["want_at"] = time.time()
    s["ws"].call("Page.navigate", {"url": url}); brw_wait(sid)

BRW_READ_JS = r"""(LIMIT,FROMVIEW)=>{
// derin tarama: açık gölge DOM'lar (web bileşenleri) ve aynı kaynaklı iç çerçeveler (iframe) dahil
const SEL='a[href],button,input:not([type=hidden]),textarea,select,[role=button],[role=link],[role=tab],[role=menuitem],[role=checkbox],[role=radio],[role=option],[role=searchbox],[role=textbox],[role=combobox],[role=switch],[contenteditable=true],[contenteditable=""],summary,label[for],[onclick],[tabindex="0"]';
const roots=[];const walk=(root,depth)=>{if(depth>6)return;roots.push(root);
 for(const el of root.querySelectorAll('*')){if(el.shadowRoot)walk(el.shadowRoot,depth+1);
  if(el.tagName==='IFRAME'||el.tagName==='FRAME'){try{const d=el.contentDocument;if(d&&d.body)walk(d,depth+1);}catch(e){}}}};
walk(document,0);
window.__ctOff=e=>{let x=0,y=0,w=e.ownerDocument.defaultView;while(w&&w.frameElement){const r=w.frameElement.getBoundingClientRect();x+=r.left+w.frameElement.clientLeft;y+=r.top+w.frameElement.clientTop;w=w.parent;}return [x,y];};
window.__ctShow=e=>{let w=e.ownerDocument.defaultView;const fr=[];while(w&&w.frameElement){fr.unshift(w.frameElement);w=w.parent;}fr.forEach(f=>f.scrollIntoView({block:'center'}));e.scrollIntoView({block:'center',inline:'center'});};
window.__ctPt=e=>{window.__ctShow(e);const r=e.getBoundingClientRect(),o=window.__ctOff(e);return [o[0]+r.left+Math.min(r.width/2,60),o[1]+r.top+r.height/2];};
window.__ctActive=()=>{let a=document.activeElement;for(let k=0;k<8&&a;k++){if(a.shadowRoot&&a.shadowRoot.activeElement){a=a.shadowRoot.activeElement;continue;}if(a.tagName==='IFRAME'){try{a=a.contentDocument.activeElement;continue;}catch(e){}}break;}return a;};
// numaralar aynı sayfada SABİT: bir öğe hep aynı numarayı alır; yeni çıkanlar yeni numara alır
if(!window.__ctIds){window.__ctIds=new WeakMap();window.__ctById=new Map();window.__ctNext=1;}
window.__ctGet=n=>{const e=window.__ctById.get(n);return e&&e.isConnected?e:null;};
const vis=e=>{const r=e.getBoundingClientRect();if(r.width<2||r.height<2)return false;const s=getComputedStyle(e);return s.visibility!=='hidden'&&s.display!=='none'&&s.opacity!=='0';};
const out=[];const els=[];const seen=new Set();let cnt=0;
const AD=/^(sponsorlu|sponsored|reklam|ad|anzeige|reklama)\b/i;
const isAd=e=>{if(e.href&&/googleadservices|doubleclick|\/aclk\?|[?&]ref=reklam|bing\.com\/aclk/.test(e.href))return true;for(let x=e,k=0;x&&k<5;x=x.parentElement,k++){const t=(x.innerText||'').trim();if(AD.test(t))return true;}return false;};
for(const root of roots){for(const e of root.querySelectorAll(SEL)){if(cnt>=180)break;if(seen.has(e)||!vis(e))continue;
 if(e.tagName==='LABEL'&&e.control&&seen.has(e.control))continue;seen.add(e);cnt++;els.push(e);
 let n=window.__ctIds.get(e);if(!n){n=window.__ctNext++;window.__ctIds.set(e,n);window.__ctById.set(n,e);}
 const lab=e.labels&&e.labels[0]?[...e.labels[0].childNodes].filter(c=>c.nodeType===3||!/^(SELECT|INPUT|TEXTAREA)$/.test(c.tagName)).map(c=>c.textContent).join(' ').trim():'';const ed=(e.tagName==='INPUT'||e.tagName==='TEXTAREA'||e.tagName==='SELECT');
 const t=(ed?(e.getAttribute('aria-label')||lab||e.placeholder||e.name||e.title||''):(e.innerText||e.value||e.getAttribute('aria-label')||e.title||e.getAttribute('alt')||(e.querySelector&&e.querySelector('img[alt]')||{}).alt||'')).trim().replace(/\s+/g,' ').slice(0,90);
 const r=e.getBoundingClientRect(),o=window.__ctOff(e);const fr=e.ownerDocument!==document;const sh=e.getRootNode()!==e.ownerDocument;
 out.push({n,tag:e.tagName.toLowerCase(),type:(e.type||e.getAttribute('role')||''),text:t,checked:(e.type==='checkbox'||e.type==='radio')?!!e.checked:undefined,
  value:(e.tagName==='SELECT'?(e.options[e.selectedIndex]||{}).text:(e.type==='password'||e.type==='checkbox'||e.type==='radio'?'':(e.value||(e.isContentEditable?e.innerText:'')||''))).slice(0,60),
  options:e.tagName==='SELECT'?[...e.options].map(o=>o.text.trim()).slice(0,25):undefined,covered:(()=>{if(!((r.bottom+o[1])>0&&(r.top+o[1])<innerHeight))return false;const rn=e.getRootNode();const cx=r.left+r.width/2,cy=r.top+r.height/2;const tp=(rn.elementFromPoint?rn:e.ownerDocument).elementFromPoint(cx,cy);if(!tp)return false;return !(tp===e||e.contains(tp)||tp.contains(e)||(e.labels&&[...e.labels].some(l=>l.contains(tp))));})(),
  href:e.href?String(e.href).slice(0,140):'',view:(r.bottom+o[1])>0&&(r.top+o[1])<innerHeight,ad:isAd(e),frame:fr,shadow:sh,newtab:(e.target&&e.target!=='_self'&&e.target!=='_top')||false});}}
window.__ctEls=els;
// sayfanın üstünü kaplayan açılır pencere (bülten, reklam, çerez dışı modal)
let overlay='';for(const x of document.querySelectorAll('body *')){const cs=getComputedStyle(x);if(cs.position!=='fixed'&&cs.position!=='absolute')continue;if(cs.display==='none'||cs.visibility==='hidden')continue;const r=x.getBoundingClientRect();if(r.width*r.height<innerWidth*innerHeight*0.45)continue;if(!(parseInt(cs.zIndex)>0)&&x.tagName!=='DIALOG')continue;overlay=(x.innerText||'').trim().replace(/\s+/g,' ').slice(0,90)||'(boş katman)';break;}
const dlg=document.querySelector('dialog[open]');if(!overlay&&dlg)overlay=(dlg.innerText||'').trim().replace(/\s+/g,' ').slice(0,90);
let txt='';
if(FROMVIEW){const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);const parts=[];let x;
 while((x=w.nextNode())){const p=x.parentElement;if(!p||/^(SCRIPT|STYLE|NOSCRIPT)$/.test(p.tagName))continue;const r=p.getBoundingClientRect();if(r.bottom<-40||r.height===0)continue;const v=x.nodeValue.trim();if(v)parts.push(v);}
 txt=parts.join('\n');}
else txt=(document.body?document.body.innerText:'');
for(const root of roots){if(root===document)continue;try{const b=root.body||root;const t=(b.innerText!==undefined?b.innerText:b.textContent||'').trim();if(t)txt+='\n\n['+(root.body?'çerçeve: '+root.location.href:'bileşen')+']\n'+t.slice(0,1500);}catch(e){}}
txt=txt.replace(/\n{3,}/g,'\n\n');
return {title:document.title,url:location.href,text:txt.slice(0,LIMIT),more:txt.length>LIMIT,elements:out,overlay,pos:[Math.round(scrollY),document.documentElement.scrollHeight,innerHeight]};}"""

def brw_read(sid, limit=5000, from_view=False):
    r = brw_eval(sid, "(" + BRW_READ_JS + f")({int(limit)},{'true' if from_view else 'false'})")
    s = BRW["sessions"][sid]; s.update(title=r["title"], url=r["url"], elements=r["elements"], at=time.time())
    return r

def brw_read_text(sid, limit=5000, from_view=False):
    r = brw_read(sid, limit, from_view); s = BRW["sessions"][sid]
    els = "\n".join(f"[{e['n']}] {e['tag']}{('/' + e['type']) if e['type'] and e['type'] not in ('submit', e['tag']) else ''} \"{e['text']}\""
                    + (f" (değer: {e['value']})" if e.get("value") and e["tag"] in ("input", "select", "textarea") else "")
                    + (f" seçenekler: {' | '.join(e['options'][:12])}" if e.get("options") else "")
                    + (" ☑" if e.get("checked") else (" ☐" if e.get("checked") is False else ""))
                    + (" ·ÜSTÜ KAPALI" if e.get("covered") else "")
                    + (f" → {e['href']}" if e.get("href") and e["tag"] == "a" else "") + ("" if e["view"] else " ·ekran dışı")
                    + (" ·REKLAM" if e.get("ad") else "") + (" ·çerçevede" if e.get("frame") else "") + (" ·bileşende" if e.get("shadow") else "")
                    for e in r["elements"])
    cap = s.get("captcha")
    ov = r.get("overlay")
    if str(r.get("url", "")).startswith("chrome-error://") or r.get("title") in ("Privacy error", "Gizlilik hatası") or re.search(r"\bERR_[A-Z_]{4,}\b", r.get("text", "")[:3000]):
        code = (re.search(r"\b(ERR_[A-Z_]{4,}|NET::ERR_[A-Z_]+)\b", r.get("text", "")) or [""])[0]
        why = {"ERR_NAME_NOT_RESOLVED": "adres bulunamadı (yazım hatası ya da site yok)", "ERR_INTERNET_DISCONNECTED": "internet bağlantısı yok",
               "ERR_CONNECTION_TIMED_OUT": "site yanıt vermiyor", "ERR_CONNECTION_REFUSED": "site bağlantıyı reddetti", "ERR_CERT": "güvenlik sertifikası hatası"}
        why.update({"ERR_TUNNEL": "ağ/proxy bu siteye izin vermiyor", "ERR_PROXY": "ağ/proxy bu siteye izin vermiyor", "ERR_SSL": "güvenli bağlantı kurulamadı", "ERR_TOO_MANY_REDIRECTS": "site yönlendirme döngüsünde"})
        hint = next((v for k, v in why.items() if k in code), "sayfa yüklenemedi")
        return (f"⚠ SAYFA AÇILAMADI ({code or r.get('title', '')}): {hint}. Adres: {s.get('want') or s.get('url', '')}\n"
                "Adresi kontrol et, başka bir kaynak/arama sonucu dene ya da biraz sonra tekrar dene. (Sertifika hatasında sayfaya GİRME — güvensiz olabilir.)")
    return ((f"⚠ BU SAYFA İNSAN DOĞRULAMASI İSTİYOR ({cap}). Çözmeye çalışma; sistem kullanıcıya haber verip çözülene kadar bekler, sonra devam edersin.\n" if cap else "")
            + (f"(çerez penceresi kapatıldı: '{s['consent']}')\n" if s.get("consent") else "")
            + (f"⚠ Sayfanın üstünde bir AÇILIR PENCERE var: «{ov}». Altındaki öğelere tıklamadan önce kapat (✕/Kapat düğmesi) — browser_click bunu kendisi de dener.\n" if ov else "")
            + f"TARAYICI OTURUMU {sid} ({s['name']})\nBAŞLIK: {r['title']}\nADRES: {r['url']}\nKAYDIRMA: {r['pos'][0]}/{r['pos'][1]} px (ekran {r['pos'][2]})\n\n"
            f"SAYFA METNİ{' (ilk kısım; browser_scroll ile devamı)' if r['more'] else ''}:\n{r['text']}\n\n"
            f"ETKİLEŞİMLİ ÖĞELER (browser_click / browser_type için numara kullan):\n{els or '(yok)'}")

def brw_el(sid, n):
    s = BRW["sessions"][sid]
    e = next((x for x in s.get("elements", []) if x["n"] == int(n)), None)
    if not e:   # sayfa değişmiş olabilir: bir kez yeniden oku
        try:
            brw_read(sid, 500); e = next((x for x in s.get("elements", []) if x["n"] == int(n)), None)
        except Exception:
            e = None
    if not e:
        raise KeyError(f"[{n}] numaralı öğe şu an görünmüyor (kapanan bir menüde olabilir ya da sayfa değişti) — browser_read ile güncel listeye bak")
    return e

def brw_find(sid, desc):
    """Tekrar oynatma: kayıttaki öğe tanımına (etiket + metin) en çok benzeyen öğenin numarası."""
    els = BRW["sessions"][sid].get("elements", [])
    txt = (desc.get("text") or "").lower(); tag = desc.get("tag", "")
    for e in els:
        if e["tag"] == tag and e["text"].lower() == txt and txt:
            return e["n"]
    for e in els:
        if txt and txt in e["text"].lower() and (not tag or e["tag"] == tag):
            return e["n"]
    if desc.get("href"):
        for e in els:
            if e.get("href") == desc["href"]:
                return e["n"]
    return None

def brw_shot(sid, mark=None):
    s = brw_sess(sid)
    if mark:
        brw_eval(sid, f"(()=>{{const e=window.__ctGet({int(mark)});if(e){{e.scrollIntoView({{block:'center',inline:'center'}});e.dataset.ctOl=e.style.outline;e.style.outline='4px solid #e11d48';e.style.outlineOffset='2px';}}}})()")
        time.sleep(0.25)
    r = s["ws"].call("Page.captureScreenshot", {"format": "jpeg", "quality": 72}, 30)
    if mark:
        try: brw_eval(sid, f"(()=>{{const e=window.__ctGet({int(mark)});if(e){{e.style.outline=e.dataset.ctOl||'';e.style.outlineOffset='';}}}})()")
        except Exception: pass
    fn = f"{sid}-{int(time.time() * 1000)}.jpg"
    open(os.path.join(BRW_SHOTS, fn), "wb").write(base64.b64decode(r["data"]))
    s["shot"] = fn
    try:
        fl = sorted(os.listdir(BRW_SHOTS))
        for f in fl[:-150]:
            os.remove(os.path.join(BRW_SHOTS, f))
    except Exception:
        pass
    return fn

POPUP_CLOSE_JS = r"""(()=>{const R=/^\s*(✕|×|x|kapat|close|hayır,? teşekkürler|no,? thanks|şimdi değil|not now|daha sonra|maybe later|atla|skip|vazgeç)\s*$/i;
const btns=[...document.querySelectorAll('button,[role=button],a,[aria-label],span,div')].filter(b=>{const r=b.getBoundingClientRect();if(r.width<4||r.height<4)return false;const t=(b.innerText||'').trim();const al=b.getAttribute('aria-label')||b.title||'';return R.test(t)||R.test(al)||/^(close|kapat|dismiss)/i.test(al);});
const top=btns.find(b=>{for(let x=b;x;x=x.parentElement){const cs=getComputedStyle(x);if((cs.position==='fixed'||x.tagName==='DIALOG')&&cs.display!=='none')return true;}return false;});
if(top){top.click();return (top.innerText||top.getAttribute('aria-label')||'✕').trim().slice(0,30);}return '';})()"""

def brw_unblock(sid, n):
    """Hedef öğenin üstünü bir açılır pencere kaplıyorsa kapatmayı dene (✕ / Kapat / Esc)."""
    cov = brw_eval(sid, f"(()=>{{const e=window.__ctGet({int(n)});if(!e)return false;const p=window.__ctPt(e);const rn=e.getRootNode();const o=window.__ctOff(e);const tp=(rn.elementFromPoint?rn:e.ownerDocument).elementFromPoint(p[0]-o[0],p[1]-o[1]);return !!tp&&!(tp===e||e.contains(tp)||tp.contains(e)||(e.labels&&[...e.labels].some(l=>l.contains(tp))));}})()")
    if not cov:
        return ""
    s = brw_sess(sid); hit = brw_eval(sid, POPUP_CLOSE_JS)
    if not hit:
        for t_ in ("keyDown", "keyUp"):
            s["ws"].call("Input.dispatchKeyEvent", {"type": t_, "key": "Escape", "code": "Escape", "windowsVirtualKeyCode": 27})
        hit = "Esc"
    time.sleep(0.5)
    return hit

def brw_click(sid, n):
    s = brw_sess(sid)
    closed = brw_unblock(sid, n)
    if closed:
        s["popup_closed"] = closed
    pt = brw_eval(sid, f"(()=>{{const e=window.__ctGet?window.__ctGet({int(n)}):null;if(!e)return null;return window.__ctPt(e);}})()")
    if not pt:
        raise KeyError(f"[{n}] öğesi sayfada artık yok — browser_read ile yeniden oku")
    time.sleep(0.15)
    for t in ("mouseMoved", "mousePressed", "mouseReleased"):
        s["ws"].call("Input.dispatchMouseEvent", {"type": t, "x": pt[0], "y": pt[1], "button": "left", "clickCount": 1 if t != "mouseMoved" else 0})
    brw_wait(sid, 10)

SENSITIVE_RX = re.compile(r"pass|şifre|sifre|parola|cc-|card|kart|cvv|cvc|iban|otp|pin\b|2fa|token|secret", re.I)

def brw_type(sid, n, text, enter=False, clear=True):
    s = brw_sess(sid); e = brw_el(sid, n)
    if e["type"] == "password":
        raise PermissionError("Şifre alanlarına yapay zekâ yazamaz. Şifreyi tarayıcı penceresinde kendin gir.")
    meta = brw_eval(sid, f"(()=>{{const e=window.__ctGet({int(n)});if(!e)return null;return [e.tagName,e.type||'',e.name||'',e.id||'',e.autocomplete||'',e.getAttribute('aria-label')||'',e.placeholder||''];}})()")
    if not meta:
        raise KeyError(f"[{n}] öğesi sayfada artık yok — browser_read ile yeniden oku")
    if SENSITIVE_RX.search(" ".join(meta[1:])):
        raise PermissionError("Bu alan şifre/kart/doğrulama kodu gibi hassas bilgi istiyor; yapay zekâ buraya yazmaz. Tarayıcı penceresinde kendin doldur.")
    if meta[0] == "SELECT":
        ok = brw_eval(sid, f"(()=>{{const e=window.__ctGet({int(n)});const t={json.dumps(str(text).lower())};"
                           "const o=[...e.options].find(o=>o.text.toLowerCase().trim()===t)||[...e.options].find(o=>o.text.toLowerCase().includes(t)||o.value.toLowerCase()===t);"
                           "if(!o)return [...e.options].map(o=>o.text).slice(0,30);e.value=o.value;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));return true;})()")
        if ok is not True:
            raise KeyError(f"Listede '{text}' seçeneği yok. Seçenekler: {ok}")
        brw_wait(sid, 4); return
    brw_unblock(sid, n)
    # gerçek fare tıklaması: bazı siteler (GitHub, YouTube…) arama kutusuna tıklanınca asıl kutuyu bir pencerede açar
    pt = brw_eval(sid, f"(()=>{{const e=window.__ctGet({int(n)});return window.__ctPt(e);}})()")
    for t_ in ("mouseMoved", "mousePressed", "mouseReleased"):
        s["ws"].call("Input.dispatchMouseEvent", {"type": t_, "x": pt[0], "y": pt[1], "button": "left" if t_ != "mouseMoved" else "none", "clickCount": 0 if t_ == "mouseMoved" else 1})
    act_ = None
    for _w in range(8):   # açılan arama penceresinin odaklanmasını bekle (en çok ~2 sn)
        time.sleep(0.25)
        act_ = brw_eval(sid, f"""(()=>{{const a=window.__ctActive();return !!(a&&(a.isContentEditable||/^(INPUT|TEXTAREA)$/.test(a.tagName)));}})()""")
        if act_: break
    act_ = brw_eval(sid, f"""(()=>{{let a=window.__ctActive();const e=window.__ctGet({int(n)});
      const ed=x=>x&&(x.isContentEditable||/^(INPUT|TEXTAREA)$/.test(x.tagName));
      if(!ed(a)){{ if(ed(e)){{e.focus();a=e;}} else return null; }}
      return [a.type||'',a.name||'',a.id||'',a.autocomplete||'',a.getAttribute('aria-label')||'',a.placeholder||'',a===e];}})()""")
    if not act_:
        raise KeyError(f"[{n}] öğesine yazılamıyor (yazı alanı değil). browser_look ile ekrana bakıp doğru kutuyu bul.")
    if act_[0] == "password" or SENSITIVE_RX.search(" ".join(str(x) for x in act_[:6])):
        raise PermissionError("Açılan alan şifre/kart/doğrulama kodu istiyor; yapay zekâ buraya yazmaz. Kullanıcı 🌐 sekmesinde kendisi doldurmalı.")
    if clear:
        brw_eval(sid, "(()=>{const a=window.__ctActive();if('value' in a && a.tagName!=='BUTTON'){a.select&&a.select();}else{const d=a.ownerDocument;const sel=d.getSelection();const rg=d.createRange();rg.selectNodeContents(a);sel.removeAllRanges();sel.addRange(rg);}})()")
    if clear:
        s["ws"].call("Input.dispatchKeyEvent", {"type": "keyDown", "key": "Backspace", "code": "Backspace", "windowsVirtualKeyCode": 8})
        s["ws"].call("Input.dispatchKeyEvent", {"type": "keyUp", "key": "Backspace", "code": "Backspace", "windowsVirtualKeyCode": 8})
    s["ws"].call("Input.insertText", {"text": str(text)})
    if enter:
        for t in ("keyDown", "keyUp"):
            s["ws"].call("Input.dispatchKeyEvent", {"type": t, "key": "Enter", "code": "Enter", "windowsVirtualKeyCode": 13, **({"text": "\r"} if t == "keyDown" else {})})
        brw_wait(sid, 10)
    else:
        time.sleep(0.3)

def brw_close(sid):
    s = BRW["sessions"].pop(sid, None)
    if not s:
        return
    try:
        bw = brw_bws(); bw.call("Target.closeTarget", {"targetId": s["target"]}); bw.close()
    except Exception:
        pass
    s["ws"].close()

def brw_state():
    if BRW["proc"] is not None and BRW["proc"].poll() is not None:
        BRW["sessions"].clear()
    if BRW["sessions"] and BRW["port"] and time.time() - BRW.get("listed", 0) > 4:
        BRW["listed"] = time.time()
        try:  # kullanıcı pencereyi kendisi kapattıysa listeden düş
            live = {t.get("id") for t in json.loads(http_get(f"http://127.0.0.1:{BRW['port']}/json/list", timeout=1.5))}
            for sid, s_ in list(BRW["sessions"].items()):
                if s_["target"] not in live:
                    BRW["sessions"].pop(sid, None); s_["ws"].close()
            known = {x["target"] for x in BRW["sessions"].values()}
            if live - known:   # bir site kendi başına yeni sekme açtıysa onu da 🌐 sekmesi olarak göster
                threading.Thread(target=brw_adopt, daemon=True).start()
        except Exception:
            pass
    return [{"id": s["id"], "name": s["name"], "title": s.get("title", ""), "url": s.get("url", ""), "shot": s.get("shot", ""), "at": s.get("at", 0), "captcha": s.get("captcha", "")}
            for s in BRW["sessions"].values()]

RISKY_RX = re.compile(r"satın al|satin al|ödeme|odeme|öde\b|ode\b|siparişi (tamamla|ver|onayla)|sipariş ver|checkout|\bbuy\b|purchase|\bpay\b|pay now|place order|abonel|subscribe|"
                      r"\bgönder\b|\bgonder\b|\bsend\b|post\b|paylaş|yayınla|publish|tweet|\bsil\b|delete|remove account|hesabı (sil|kapat)|unsubscribe|transfer|bağış|donate|onayla ve", re.I)

SEND_ONLY_RX = re.compile(r"^\W*(gönder|gonder|send|post|paylaş|yayınla|publish|tweet)\W*$", re.I)

def brw_is_risky(sid, e):
    """Geri alınamaz adım mı? Ödeme/silme her zaman; 'Gönder/Paylaş' yalnızca mesaj/e-posta/gönderi bağlamında."""
    t = " ".join(str(e.get(k) or "") for k in ("text", "href"))
    if not RISKY_RX.search(t):
        return False
    if SEND_ONLY_RX.match(str(e.get("text") or "")):
        try:
            ctx = brw_eval(sid, r"""(()=>{const u=location.href;if(/mail|message|mesaj|compose|chat|sohbet|contact|iletisim|iletişim|comment|yorum|status|post|tweet|share|paylas/i.test(u))return true;
              for(const x of document.querySelectorAll('textarea,[contenteditable=true],input[type=email]')){const v=(x.value||x.innerText||'').trim();if(v.length>2)return true;}return false;})()""", 5)
        except Exception:
            ctx = True
        return bool(ctx)
    return True

def brw_auto():
    """Tarayıcıda yapay zekâ kendisi yapar (arama, tıklama, yazma); sadece geri alınamaz adımlarda sorar."""
    return (cfg().get("auto") or {}).get("browser_auto", True) is not False

def _brw_confirm(job, sid, what, mark=None, risky=False):
    """Varsayılan: yapay zekâ kendisi yapar. Ödeme/gönderme/silme gibi geri alınamaz adımlar (ya da 'her adımı sor' seçiliyse her adım) sağ alttaki kartla sorulur."""
    if job.ctx.get("brw_trust") and not risky:
        return True
    if brw_auto() and not risky:
        job.log("🧭 " + what.split("\n")[0]); return True
    if job.ctx.get("unattended"):
        return False  # gözetimsiz çalışmada geri alınamaz adım yapılmaz
    try: shot = brw_shot(sid, mark)
    except Exception: shot = ""
    s = BRW["sessions"][sid]
    r = job.ask("bconfirm", {"message": f"🧭 Yapay zekâ tarayıcıda şunu yapmak istiyor:\n{what}\n\nOturum: {sid} — {s.get('title', '')}\n{s.get('url', '')}",
                            "image": shot, "browser": True})
    return bool(r and r.get("ok"))

def browser_action(job, act, a, auto=False):
    out = _browser_action(job, act, a, auto)
    try:
        for sid_, s_ in list(BRW["sessions"].items()):
            if s_.get("captcha") and (sid_ == str(a.get("session") or "") or s_.get("at", 0) > time.time() - 30):
                r_ = brw_captcha_wait(job, sid_, PROCS.get(job.ctx.get("console", "")))
                if r_ == "done":
                    out = "(Kullanıcı doğrulamayı çözdü, sayfa güncellendi)\n" + brw_read_text(sid_, 4000)
                elif r_ == "timeout":
                    out += "\n\n⚠ Doğrulama 15 dakikada çözülmedi; başka bir kaynak dene."
                break
    except Exception:
        pass
    return out

def _browser_action(job, act, a, auto=False):
    sid = str(a.get("session") or "")
    if act == "browser_open":
        targets = [_brw_url(u) for u in (a.get("urls") or []) if u] + [_brw_url("", q_) for q_ in (a.get("queries") or []) if q_]
        if a.get("url"):
            targets.append(_brw_url(a["url"]))
        if a.get("query"):
            targets.append(_brw_url("", a["query"]))
        targets = targets[:6]
        if not targets:
            targets = ["about:blank"]
        if not auto and not brw_auto():
            r = job.ask("confirm", {"message": "🧭 Yapay zekâ kontrol ettiği tarayıcıda şunları açmak istiyor:\n" + "\n".join("• " + t for t in targets)})
            if not r or not r.get("ok"):
                return "Kullanıcı tarayıcı açmayı onaylamadı."
        res = [None] * len(targets)
        def one(i, t):
            try:
                sid_ = brw_open(t, name=(a.get("name") or "") + (f" {i + 1}" if len(targets) > 1 and a.get("name") else ""))
                res[i] = (sid_, brw_read_text(sid_, 2500 if len(targets) > 1 else 5000))
            except Exception as e:
                res[i] = ("", f"HATA ({t}): {e}")
        ths = [threading.Thread(target=one, args=(i, t)) for i, t in enumerate(targets)]
        [t.start() for t in ths]; [t.join(90) for t in ths]
        mode = " (uygulama içinde: Konsol → 🌐 sekmesi)" if brw_embed() else (" (görünmez mod — bu bilgisayarda ekran yok)" if BRW["headless"] else " (ekranda ayrı pencere(ler) açıldı)")
        if res and res[0] and res[0][0]: BRW["focus"] = res[0][0]
        out = "\n\n════════\n".join((f"Açıldı → oturum: {r_[0]}\n" if r_ and r_[0] else "") + (r_[1] if r_ else "zaman aşımı") for r_ in res)
        job.log(f"🧭 {len(targets)} tarayıcı oturumu açıldı{mode}")
        return out + "\n\n" + mode
    if act == "browser_list":
        st = brw_state()
        return json.dumps(st, ensure_ascii=False) if st else "Açık tarayıcı oturumu yok."
    if act == "browser_read":
        sids = a.get("sessions") or [sid]
        if len(sids) > 1:
            res = {}
            ths = [threading.Thread(target=lambda x=x: res.__setitem__(x, brw_read_text(x, 3000))) for x in sids[:6]]
            [t.start() for t in ths]; [t.join(60) for t in ths]
            return "\n\n════════\n".join(res.get(x, f"{x}: okunamadı") for x in sids[:6])
        return brw_read_text(brw_sess(sid)["id"], int(a.get("limit", 5000)))
    s = brw_sess(sid); sid = s["id"]
    if act == "browser_go":
        url = _brw_url(a.get("url", ""), a.get("query", ""))
        if not auto and not _brw_confirm(job, sid, f"Bu adrese git: {url}"):
            return "Kullanıcı onaylamadı."
        brw_go(sid, url); return "Gidildi.\n" + brw_read_text(sid, 3000)
    if act == "browser_click":
        e = brw_el(sid, a.get("element"))
        what = f"🖱 TIKLA → [{e['n']}] {e['tag']} \"{e['text']}\"" + (f"\n   bağlantı: {e['href']}" if e.get("href") else "")
        risky = brw_is_risky(sid, e)
        if not _brw_confirm(job, sid, what + ("\n   ⚠ Geri alınamaz olabilir (ödeme / gönderme / silme)" if risky else ""), e["n"], risky):
            return ("Bu adım geri alınamaz olabileceği için kullanıcı onayı gerekiyordu ve verilmedi. Kullanıcıya sor." if risky else "Kullanıcı bu tıklamayı onaylamadı. Başka bir yol düşün ya da say ile sor.")
        a["_desc"] = {k: e.get(k) for k in ("tag", "text", "href", "type")}
        brw_click(sid, e["n"]); pc = s.pop("popup_closed", "")
        return ("(önce üstteki açılır pencere kapatıldı: " + pc + ")\n" if pc else "") + "Tıklandı.\n" + brw_read_text(sid, 3000)
    if act == "browser_type":
        e = brw_el(sid, a.get("element")); text = str(a.get("text", ""))
        if e["type"] == "password" or SENSITIVE_RX.search(e.get("text", "") + " " + e.get("type", "")):
            return "HATA: Bu alan şifre/kart/doğrulama kodu gibi hassas bilgi istiyor; yapay zekâ buraya yazmaz. Kullanıcıdan alanı tarayıcıda kendisinin doldurmasını iste."
        what = f"⌨ YAZ → [{e['n']}] {e['tag']} \"{e['text']}\"\n   metin: {text[:300]}" + ("\n   ardından Enter'a basılacak" if a.get("enter") else "")
        if not _brw_confirm(job, sid, what, e["n"]):
            return "Kullanıcı bu yazmayı onaylamadı."
        a["_desc"] = {k: e.get(k) for k in ("tag", "text", "href", "type")}
        brw_type(sid, e["n"], text, bool(a.get("enter")), a.get("clear", True) is not False)
        return "Yazıldı.\n" + brw_read_text(sid, 3000)
    if act == "browser_scroll":
        d = str(a.get("direction", "down"))
        vw = brw_eval(sid, "[innerWidth, innerHeight, scrollY, document.documentElement.scrollHeight]") or [1280, 860, 0, 0]
        if d in ("top", "bottom"):
            brw_eval(sid, "scrollTo(0,0)" if d == "top" else "scrollTo(0,document.documentElement.scrollHeight)")
        # gerçek fare tekerleği: tembel yükleme / sonsuz kaydırma yapan siteler buna tepki verir
        dy = {"up": -0.85, "top": -0.3, "bottom": 0.5}.get(d, 0.85) * vw[1]
        s["ws"].call("Input.dispatchMouseEvent", {"type": "mouseWheel", "x": vw[0] / 2, "y": vw[1] / 2, "deltaX": 0, "deltaY": dy})
        time.sleep(0.6); brw_settle(sid)
        txt = brw_read_text(sid, 6000, from_view=True)
        nw = brw_eval(sid, "[scrollY, document.documentElement.scrollHeight]") or [0, 0]
        note = ("\n(sayfanın sonundasın — daha fazla içerik yok)" if nw[0] + vw[1] >= nw[1] - 5 and nw[1] <= vw[3] + 5 else
                ("\n(aşağı kaydırınca YENİ içerik yüklendi)" if nw[1] > vw[3] + 5 else ""))
        return txt + note
    if act == "browser_back":
        brw_eval(sid, "history.back()"); brw_wait(sid); return brw_read_text(sid, 3000)
    if act == "browser_look":
        # ekran görüntüsü + öğelerin üstüne numara (set-of-marks) → görsel model nereye basılacağını söyler
        r = brw_read(sid, 1500)
        brw_eval(sid, SOM_ON_JS)
        time.sleep(0.15)
        try:
            raw = s["ws"].call("Page.captureScreenshot", {"format": "jpeg", "quality": 70}, 30)["data"]
        finally:
            try: brw_eval(sid, SOM_OFF_JS)
            except Exception: pass
        fn = f"{sid}-{int(time.time() * 1000)}-bak.jpg"; open(os.path.join(BRW_SHOTS, fn), "wb").write(base64.b64decode(raw)); s["shot"] = fn
        job.ctx.setdefault("shots", []).append(fn)
        inview = [e for e in r["elements"] if e.get("view")][:70]
        lst = "\n".join(f"[{e['n']}] {e['tag']}{('/' + e['type']) if e.get('type') else ''} \"{e['text']}\"" + (f" = {e['value']}" if e.get("value") else "") for e in inview)
        goal = a.get("goal") or a.get("question") or "Sayfada ne var?"
        try:
            desc = describe_images(["data:image/jpeg;base64," + raw],
                                   f"Bu bir web sayfasının ekran görüntüsü. Tıklanabilir/yazılabilir öğelerin sol üstünde KIRMIZI KUTULU NUMARALAR var. AMAÇ: {goal}\n"
                                   "1) Sayfada ne gördüğünü 2-3 cümleyle anlat. 2) Amaca ulaşmak için HANGİ NUMARALI öğeye tıklanmalı ya da hangisine ne yazılmalı? "
                                   "Son satırı şu biçimde yaz: ÖNERİ: tıkla [n]  ya da  ÖNERİ: yaz [n] \"metin\"  ya da  ÖNERİ: kaydır aşağı", job.log)
        except Exception as e_:
            desc = f"(görsel model kullanılamadı: {str(e_)[:120]} — aşağıdaki öğe listesine göre karar ver)"
        return f"👁 EKRANA BAKTIM ({r['title']} — {r['url']}):\n{desc}\n\nEKRANDA GÖRÜNEN NUMARALI ÖĞELER:\n{lst}"
    if act == "browser_click_xy":
        x, y = float(a.get("x", 0)), float(a.get("y", 0))
        if not _brw_confirm(job, sid, f"🖱 TIKLA → ekranda ({int(x)}, {int(y)}) noktası", None, bool(a.get("risky"))):
            return "Onay verilmedi."
        brw_input(sid, {"t": "click", "x": x, "y": y}); brw_wait(sid, 8); return "Tıklandı.\n" + brw_read_text(sid, 3000)
    if act == "browser_screenshot":
        fn = brw_shot(sid)
        job.ctx.setdefault("shots", []).append(fn)
        if a.get("look", True) and llm_available():
            try:
                data = "data:image/jpeg;base64," + base64.b64encode(open(os.path.join(BRW_SHOTS, fn), "rb").read()).decode()
                return f"Ekran görüntüsü alındı ({fn}). GÖRÜNTÜNÜN AÇIKLAMASI:\n" + describe_images([data], a.get("question", "Sayfada ne görünüyor?"), job.log)
            except Exception as e:
                return f"Ekran görüntüsü alındı ({fn}) ama görsel model okuyamadı: {str(e)[:150]}. browser_read ile metni oku."
        return f"Ekran görüntüsü alındı: {fn}"
    if act == "browser_close":
        brw_close(sid); return f"{sid} kapatıldı."
    return f"Bilinmeyen tarayıcı eylemi: {act}"

SOM_ON_JS = r"""(()=>{document.querySelectorAll('.ct-som').forEach(x=>x.remove());const box=document.createElement('div');box.className='ct-som';
box.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:2147483647';document.documentElement.appendChild(box);
(window.__ctEls||[]).forEach((e)=>{const ix=(window.__ctIds.get(e)||1)-1;const r0=e.getBoundingClientRect(),of=window.__ctOff?window.__ctOff(e):[0,0];const r={left:r0.left+of[0],top:r0.top+of[1],width:r0.width,height:r0.height,bottom:r0.bottom+of[1]};if(r.bottom<0||r.top>innerHeight||r.width<2)return;
const o=document.createElement('div');o.style.cssText=`position:fixed;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px;outline:2px solid rgba(225,29,72,.85);border-radius:3px`;
const l=document.createElement('div');l.textContent=ix+1;l.style.cssText=`position:fixed;left:${Math.max(0,r.left-2)}px;top:${Math.max(0,r.top-14)}px;background:#e11d48;color:#fff;font:bold 11px/13px monospace;padding:0 3px;border-radius:3px`;
box.appendChild(o);box.appendChild(l);});})()"""
SOM_OFF_JS = "document.querySelectorAll('.ct-som').forEach(x=>x.remove())"

# ═════════════════════════════ 🔌 HESAPLAR: WordPress · Meta Reklamları · Google Ads ═════════════════════════════
# Okuma serbest; para harcatan / yayınlayan / silen her işlem tam otomatikte bile kullanıcıya sorulur.
ACC_FILE = os.path.join(CONF_DIR, "hesaplar.json")
ACC_TYPES = {
    "wordpress": {"label": "WordPress", "fields": ["url", "user", "app_password"], "secret": ["app_password"]},
    "meta": {"label": "Meta (Facebook/Instagram) Reklamları", "fields": ["ad_account_id", "access_token", "api_version"], "secret": ["access_token"]},
    "gads": {"label": "Google Ads", "fields": ["customer_id", "login_customer_id", "developer_token", "client_id", "client_secret", "refresh_token", "api_version"],
             "secret": ["developer_token", "client_secret", "refresh_token"]},
}
META_VER = "v26.0"; GADS_VER = "v26"
SERVER_PORT = [8765]; OAUTH_STATE = {}

def accs():
    return jload(ACC_FILE, [])

def accs_save(L):
    jsave(ACC_FILE, L, private=True)

def acc_public(a):
    t = ACC_TYPES.get(a.get("type"), {})
    return {k: (("•••" + str(v)[-4:]) if k in t.get("secret", []) and v else v) for k, v in a.items() if k != "_tok"}

def acc_get(ref):
    L = accs()
    a = next((x for x in L if x["id"] == ref or x.get("name", "").lower() == str(ref).lower()), None)
    if not a and len(L) == 1 or (not a and not ref):
        a = L[0] if L else None
    if not a:
        raise KeyError(f"'{ref}' adında bağlı hesap yok. Bağlı hesaplar: " + (", ".join(f"{x['name']} ({x['type']})" for x in L) or "hiç yok — Ayarlar → 🔌 Hesaplar'dan ekle"))
    return a

def _acc_by_type(ref, typ):
    if ref:
        a = acc_get(ref)
        if a["type"] != typ:
            raise KeyError(f"'{ref}' bir {ACC_TYPES[typ]['label']} hesabı değil")
        return a
    L = [x for x in accs() if x["type"] == typ]
    if not L:
        raise KeyError(f"Bağlı {ACC_TYPES[typ]['label']} hesabı yok — Ayarlar → 🔌 Hesaplar'dan ekle (ya da uygulama içi tarayıcıda siteye kendin giriş yap, ben oradan yöneteyim)")
    return L[0]

def _http(method, url, headers=None, body=None, form=None, timeout=60):
    data = None; h = {**UA, **(headers or {})}
    if form is not None:
        data = urllib.parse.urlencode(form).encode(); h["Content-Type"] = "application/x-www-form-urlencoded"
    elif body is not None:
        data = json.dumps(body).encode(); h["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            t = r.read().decode("utf-8", "replace"); return json.loads(t) if t.strip() else {}
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}: {e.read().decode('utf-8', 'replace')[:600]}")

# ── WordPress (REST API + Uygulama Parolası)
def wp_call(a, method="GET", path="posts", params=None, body=None):
    base = a["url"].rstrip("/")
    if not re.match(r"^https?://", base): base = "https://" + base
    path = path.lstrip("/")
    url = base + ("/wp-json/" + path if path.startswith(("wp/", "wc/", "wp-site-health/", "oembed/")) or "/v" in path.split("?")[0][:8] else "/wp-json/wp/v2/" + path)
    if params: url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params, doseq=True)
    auth = base64.b64encode(f"{a['user']}:{a['app_password'].replace(' ', '')}".encode()).decode()
    return _http(method.upper(), url, {"Authorization": "Basic " + auth}, body)

# ── Meta Marketing / Graph API
def meta_call(a, method="GET", path="", params=None):
    ver = a.get("api_version") or META_VER
    act = str(a.get("ad_account_id", "")).strip()
    if act and not act.startswith("act_"): act = "act_" + act
    path = (path or act).replace("{act}", act).replace("act_{id}", act).lstrip("/")
    p = dict(params or {}); p["access_token"] = a["access_token"]
    for k, v in list(p.items()):
        if isinstance(v, (dict, list)): p[k] = json.dumps(v)
    url = f"https://graph.facebook.com/{ver}/{path}"
    if method.upper() == "GET":
        return _http("GET", url + "?" + urllib.parse.urlencode(p))
    return _http(method.upper(), url, form=p)

# ── Google Ads API (REST + OAuth yenileme belirteci)
def gads_token(a):
    tk = a.get("_tok") or {}
    if tk.get("exp", 0) > time.time() + 60:
        return tk["at"]
    r = _http("POST", "https://oauth2.googleapis.com/token", form={"grant_type": "refresh_token", "refresh_token": a["refresh_token"], "client_id": a["client_id"], "client_secret": a["client_secret"]})
    a["_tok"] = {"at": r["access_token"], "exp": time.time() + int(r.get("expires_in", 3000))}
    return r["access_token"]

def gads_call(a, kind="search", query="", resource="", operations=None):
    ver = a.get("api_version") or GADS_VER; cid = re.sub(r"\D", "", str(a["customer_id"]))
    h = {"Authorization": "Bearer " + gads_token(a), "developer-token": a["developer_token"]}
    if a.get("login_customer_id"): h["login-customer-id"] = re.sub(r"\D", "", str(a["login_customer_id"]))
    base = f"https://googleads.googleapis.com/{ver}/customers/{cid}"
    if kind == "search":
        rows = []; tok = ""
        for _ in range(10):
            r = _http("POST", base + "/googleAds:search", h, {"query": query, **({"pageToken": tok} if tok else {})})
            rows += r.get("results", []); tok = r.get("nextPageToken", "")
            if not tok or len(rows) > 2000: break
        return {"results": rows[:2000], "count": len(rows)}
    return _http("POST", f"{base}/{resource}:mutate", h, {"operations": operations or [], "partialFailure": False})

def acc_test(a):
    t = a.get("type")
    if t == "wordpress":
        me = wp_call(a, "GET", "users/me", {"context": "edit"}); n = len(wp_call(a, "GET", "posts", {"per_page": 1}))
        return f"✔ Bağlandı: {me.get('name')} ({', '.join(me.get('roles', []))})"
    if t == "meta":
        r = meta_call(a, "GET", "", {"fields": "name,currency,account_status,amount_spent,timezone_name"})
        return f"✔ Bağlandı: {r.get('name')} · {r.get('currency')} · durum {r.get('account_status')}"
    if t == "gads":
        r = gads_call(a, "search", "SELECT customer.descriptive_name, customer.currency_code, customer.time_zone FROM customer LIMIT 1")
        c = ((r.get("results") or [{}])[0]).get("customer", {})
        return f"✔ Bağlandı: {c.get('descriptiveName')} · {c.get('currencyCode')}"
    raise KeyError("bilinmeyen hesap türü")

MONEY_RX = re.compile(r"budget|bütçe|bid|teklif|daily_budget|lifetime_budget|amount|status|spend_cap|campaign_budget", re.I)

def integ_action(job, act, a):
    """Yapay zekânın hesapları yönetmesi. Okuma serbest; değiştiren işlemler her zaman onaylı."""
    def must(msg):
        r = job.ask("confirm", {"must": True, "message": msg})
        return bool(r and r.get("ok"))
    if act == "accounts":
        L = accs()
        return "BAĞLI HESAPLAR:\n" + ("\n".join(f"- {x['name']} · {ACC_TYPES[x['type']]['label']} (id: {x['id']})" + (f" · {x.get('url')}" if x.get("url") else "") for x in L) or "(yok) — kullanıcı Ayarlar → 🔌 Hesaplar'dan ekleyebilir. Yoksa uygulama içi tarayıcıda siteye kullanıcı giriş yapar, sen oradan yönetirsin.")
    if act == "wp":
        acc = _acc_by_type(a.get("account"), "wordpress"); m = str(a.get("method", "GET")).upper(); path = str(a.get("path", "posts"))
        body = a.get("body") or {}
        if m != "GET":
            safe_draft = m == "POST" and re.match(r"^(posts|pages)(/\d+)?$", path) and str(body.get("status", "draft")) in ("draft", "pending", "private") and not re.search(r"/\d+$", path) or (m == "POST" and re.match(r"^media$", path))
            if not safe_draft:
                prev = json.dumps(body, ensure_ascii=False)[:900]
                if not must(f"🌐 WordPress ({acc['name']}) üzerinde DEĞİŞİKLİK yapılacak:\n{m} {path}\n{prev}"):
                    return "Kullanıcı bu WordPress değişikliğini onaylamadı."
            elif "status" not in body and re.match(r"^(posts|pages)$", path):
                body["status"] = "draft"   # yeni içerik varsayılan TASLAK
        r = wp_call(acc, m, path, a.get("params"), body if m != "GET" else None)
        out = json.dumps(r, ensure_ascii=False)
        if isinstance(r, list):  # listeleri kısalt
            out = json.dumps([{k: (v.get("rendered") if isinstance(v, dict) and "rendered" in v else v) for k, v in x.items() if k in ("id", "date", "status", "title", "link", "slug", "name", "plugin", "version", "author_name", "content", "excerpt", "post")} if isinstance(x, dict) else x for x in r], ensure_ascii=False)
        return out[:12000]
    if act == "meta_ads":
        acc = _acc_by_type(a.get("account"), "meta"); m = str(a.get("method", "GET")).upper(); params = dict(a.get("params") or {})
        if m != "GET":
            creating = re.search(r"/(campaigns|adsets|ads)$", str(a.get("path", "")))
            if creating and "status" not in params:
                params["status"] = "PAUSED"   # yeni reklamlar her zaman DURAKLATILMIŞ başlar
            if not must(f"💰 Meta reklam hesabında ({acc['name']}) DEĞİŞİKLİK yapılacak (para harcatabilir):\n{m} {a.get('path', '')}\n"
                        + json.dumps(params, ensure_ascii=False)[:900] + ("\n\nNot: yeni kampanya/reklam DURAKLATILMIŞ oluşturulur." if creating else "")):
                return "Kullanıcı bu reklam değişikliğini onaylamadı."
        return json.dumps(meta_call(acc, m, a.get("path", ""), params), ensure_ascii=False)[:12000]
    if act == "google_ads":
        acc = _acc_by_type(a.get("account"), "gads")
        if a.get("operations"):
            ops = a["operations"]
            for op in ops:
                if isinstance(op.get("create"), dict) and a.get("resource") in ("campaigns", "adGroups", "adGroupAds") and "status" not in op["create"]:
                    op["create"]["status"] = "PAUSED"
            if not must(f"💰 Google Ads ({acc['name']}) üzerinde DEĞİŞİKLİK yapılacak (para harcatabilir):\n{a.get('resource')}:mutate\n" + json.dumps(ops, ensure_ascii=False)[:1200]):
                return "Kullanıcı bu Google Ads değişikliğini onaylamadı."
            return json.dumps(gads_call(acc, "mutate", resource=a.get("resource", ""), operations=ops), ensure_ascii=False)[:12000]
        return json.dumps(gads_call(acc, "search", a.get("query", "")), ensure_ascii=False)[:14000]
    return f"Bilinmeyen hesap eylemi: {act}"

INTEG_SYS = """

HESAP YÖNETİMİ (kullanıcının bağladığı WordPress / Meta reklam / Google Ads hesapları):
- accounts {}  → bağlı hesapları listeler.
- wp {"account": "ad|id", "method": "GET|POST|DELETE", "path": "posts", "params": {"per_page": 10}, "body": {...}}  → WordPress REST API (wp/v2). Örnekler: GET posts / pages / comments?status=hold / plugins / users/me; POST posts {"title","content","status":"draft"} (yeni içerik TASLAK oluşturulur); POST posts/123 {"status":"publish"} yayınlar (onaylı).
- meta_ads {"account": "...", "method": "GET|POST", "path": "act_{id}/campaigns", "params": {"fields": "name,status,daily_budget,objective"}}  → Meta Marketing API. Rapor: GET {act}/insights params {"level":"campaign","date_preset":"last_7d","fields":"campaign_name,spend,impressions,clicks,ctr,cpc,actions"}. Kampanyayı durdur: POST <campaign_id> {"status":"PAUSED"} (onaylı). Bütçe: POST <adset_id> {"daily_budget": kuruş/cent cinsinden} (onaylı).
- google_ads {"account": "...", "query": "GAQL"}  → okuma. Örn: SELECT campaign.id, campaign.name, campaign.status, metrics.cost_micros, metrics.clicks, metrics.impressions, metrics.conversions FROM campaign WHERE segments.date DURING LAST_7_DAYS. (maliyet micros: /1e6)
  google_ads {"account": "...", "resource": "campaigns", "operations": [{"update": {"resourceName": "customers/X/campaigns/Y", "status": "PAUSED"}, "updateMask": "status"}]}  → değişiklik (onaylı).
KURALLAR: Okuma ve rapor serbest. Para harcatan (bütçe, teklif, kampanyayı açma), yayınlayan, silen her işlem kullanıcıya otomatik sorulur — sen ayrıca sorma, sadece ne yapacağını net söyle. Yeni kampanya/reklam her zaman DURAKLATILMIŞ oluşturulur.
Hesap bağlı değilse: uygulama içi tarayıcıda (business.facebook.com, ads.google.com, site.com/wp-admin) kullanıcı giriş yapar, sen browser_* ile yönetirsin (ödeme/yayınla düğmeleri yine sorulur).
Raporları tablo halinde, Türkçe özetle (harcama, tıklama, TO, TBM, dönüşüm) ve iyileştirme öner."""

# ═════════════════════════════ 🖥 MASAÜSTÜ KONTROLÜ (ekran görüntüsü + fare/klavye — X11: xdotool) ═════════════════════════════
DESK = {"job": "", "title": "", "at": 0}

def desk_on():
    return (cfg().get("auto") or {}).get("desktop", True) is not False

def desk_info():
    wl = bool(os.environ.get("WAYLAND_DISPLAY")) or os.environ.get("XDG_SESSION_TYPE") == "wayland"
    return {"x11": bool(os.environ.get("DISPLAY")), "wayland": wl, "xdotool": bool(which("xdotool")), "wmctrl": bool(which("wmctrl"))}

def _desk_run(cmd, timeout=15, inp=None):
    r = subprocess.run(cmd, env=base_env(), capture_output=True, timeout=timeout, input=inp)
    return r.returncode, r.stdout, r.stderr.decode(errors="replace")

def desk_check():
    if not desk_on():
        raise PermissionError("Masaüstü kontrolü Ayarlar → Otomatik işler'den kapatılmış.")
    i = desk_info()
    if not i["x11"] and not i["wayland"]:
        raise RuntimeError("Bu oturumda masaüstü (ekran) yok — Cypher Tool'u masaüstünden aç.")
    if not i["xdotool"]:
        raise RuntimeError("Masaüstünü kullanmak için 'xdotool' gerekli. Kur: run ile `apt-get install -y xdotool wmctrl scrot` (root değilse sudo ile).")
    if i["wayland"] and not i["x11"]:
        raise RuntimeError("Wayland oturumunda fare/klavye kontrolü çalışmaz. Giriş ekranında ⚙ → 'Ubuntu on Xorg' seçip tekrar giriş yapılmalı.")

def desk_size():
    rc, out, _ = _desk_run(["xdotool", "getdisplaygeometry"])
    try:
        w, h = out.decode().split(); return int(w), int(h)
    except Exception:
        return 1920, 1080

def desk_shot_raw():
    """Masaüstünün PNG görüntüsü (PIL → import → scrot → gnome-screenshot → grim)."""
    try:
        from PIL import ImageGrab
        import io
        im = ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")); bio = io.BytesIO(); im.save(bio, "PNG"); return bio.getvalue()
    except Exception:
        pass
    tmp = os.path.join(tempfile.gettempdir(), f"ct-desk-{os.getpid()}.png")
    for cmd in (["import", "-window", "root", tmp], ["scrot", "-o", tmp], ["gnome-screenshot", "-f", tmp], ["grim", tmp], ["xfce4-screenshooter", "-f", "-s", tmp], ["spectacle", "-b", "-n", "-o", tmp]):
        if which(cmd[0]):
            try:
                if os.path.exists(tmp): os.remove(tmp)
                _desk_run(cmd, 20)
                if os.path.exists(tmp) and os.path.getsize(tmp) > 1000:
                    d = open(tmp, "rb").read(); os.remove(tmp); return d
            except Exception:
                pass
    raise RuntimeError("Ekran görüntüsü alınamadı. Kur: `apt-get install -y scrot` (ya da python3-pil / imagemagick).")

def desk_shot(grid=True, maxw=1366):
    """Küçültülmüş görüntü + koordinat ızgarası; (jpeg_b64, ölçek, dosya)."""
    raw = desk_shot_raw(); scale = 1.0
    try:
        from PIL import Image, ImageDraw
        import io
        im = Image.open(io.BytesIO(raw)).convert("RGB")
        if im.width > maxw:
            scale = im.width / maxw; im = im.resize((maxw, int(im.height / scale)))
        if grid:
            dr = ImageDraw.Draw(im)
            try:
                from PIL import ImageFont
                fnt = ImageFont.load_default(size=15)
            except Exception:
                fnt = None
            for x in range(0, im.width, 100):
                dr.line([(x, 0), (x, im.height)], fill=(255, 0, 80), width=1); dr.text((x + 3, 2), str(x), fill=(255, 230, 0), font=fnt, stroke_width=2, stroke_fill=(0, 0, 0))
            for y in range(0, im.height, 100):
                dr.line([(0, y), (im.width, y)], fill=(255, 0, 80), width=1); dr.text((3, y + 2), str(y), fill=(255, 230, 0), font=fnt, stroke_width=2, stroke_fill=(0, 0, 0))
        bio = io.BytesIO(); im.save(bio, "JPEG", quality=70); data = bio.getvalue(); w, h = im.width, im.height
    except Exception:
        data = raw; w, h = desk_size()
    fn = f"desk-{int(time.time() * 1000)}.jpg"
    try:
        open(os.path.join(BRW_SHOTS, fn), "wb").write(data)
    except Exception:
        pass
    return base64.b64encode(data).decode(), scale, fn, (w, h)

def desk_windows():
    if which("wmctrl"):
        rc, out, _ = _desk_run(["wmctrl", "-lx"])
        return [l.split(None, 4)[-1][:140] for l in out.decode(errors="replace").splitlines() if l.strip()][:40]
    rc, out, _ = _desk_run(["xdotool", "search", "--onlyvisible", "--name", "."])
    names = []
    for wid in out.decode().split()[:40]:
        _, n, _ = _desk_run(["xdotool", "getwindowname", wid]); n = n.decode(errors="replace").strip()
        if n and n not in names: names.append(n)
    return names

def desktop_action(job, act, a):
    try:
        desk_check()
    except Exception as e:
        return f"HATA: {e}"
    if job.cancelled:
        return "İptal edildi."
    DESK.update(job=job.id, title=job.title, at=time.time())
    sc = float(job.ctx.get("desk_scale", 1.0) or 1.0)
    P = lambda k: str(int(float(a.get(k, 0)) * sc))
    if act == "desktop_look":
        b64, scale, fn, (w, h) = desk_shot(True)
        job.ctx["desk_scale"] = scale; job.ctx.setdefault("shots", []).append(fn)
        wins = desk_windows()
        goal = a.get("goal") or a.get("question") or "Ekranda ne var?"
        try:
            desc = describe_images(["data:image/jpeg;base64," + b64],
                                   f"Bu bir Linux masaüstünün ekran görüntüsü ({w}x{h}). Üzerinde her 100 pikselde KIRMIZI IZGARA çizgileri ve sarı koordinat sayıları var. AMAÇ: {goal}\n"
                                   "1) Ekranda ne gördüğünü (açık pencereler, düğmeler, menüler, yazılar) kısaca anlat. 2) Amaca ulaşmak için NEREYE tıklanmalı ya da ne yazılmalı? "
                                   "Koordinatı ızgaraya bakarak bu görüntünün pikseli olarak ver. Son satır: ÖNERİ: tıkla (x, y)  |  ÖNERİ: yaz \"metin\"  |  ÖNERİ: tuş ctrl+s", job.log)
        except Exception as e:
            desc = f"(görsel model kullanılamadı: {str(e)[:150]})"
        return f"🖥 MASAÜSTÜNE BAKTIM ({w}x{h} görüntü):\n{desc}\n\nAÇIK PENCERELER:\n" + "\n".join("- " + x for x in wins)
    if act == "desktop_click":
        btn = {"left": "1", "middle": "2", "right": "3"}.get(str(a.get("button", "left")), "1")
        cmd = ["xdotool", "mousemove", "--sync", P("x"), P("y"), "click"] + (["--repeat", "2", "--delay", "80"] if a.get("double") else []) + [btn]
        rc, _, er = _desk_run(cmd); time.sleep(0.6)
        return "Tıklandı." if rc == 0 else f"Tıklanamadı: {er[:200]}"
    if act == "desktop_type":
        t = str(a.get("text", ""))
        rc, _, er = _desk_run(["xdotool", "type", "--delay", "25", "--", t], 120)
        if a.get("enter"): _desk_run(["xdotool", "key", "Return"])
        time.sleep(0.4); return "Yazıldı." if rc == 0 else f"Yazılamadı: {er[:200]}"
    if act == "desktop_key":
        keys = str(a.get("keys", "Return")).replace("ctrl", "ctrl").split()
        rc, _, er = _desk_run(["xdotool", "key", "--delay", "60"] + keys); time.sleep(0.4)
        return "Tuşa basıldı." if rc == 0 else f"Basılamadı: {er[:200]}"
    if act == "desktop_scroll":
        n = max(1, min(30, int(a.get("amount", 5)))); b = "4" if str(a.get("direction", "down")) == "up" else "5"
        if a.get("x") is not None: _desk_run(["xdotool", "mousemove", P("x"), P("y")])
        _desk_run(["xdotool", "click", "--repeat", str(n), "--delay", "40", b]); time.sleep(0.4); return "Kaydırıldı."
    if act == "desktop_windows":
        return "AÇIK PENCERELER:\n" + "\n".join("- " + x for x in desk_windows())
    if act == "desktop_focus":
        nm = str(a.get("name", ""))
        rc = 1
        if which("wmctrl"):
            rc, _, _ = _desk_run(["wmctrl", "-a", nm])
        if rc != 0:
            rc, out, _ = _desk_run(["xdotool", "search", "--onlyvisible", "--name", nm])
            ids = out.decode().split()
            if ids:
                rc, _, _ = _desk_run(["xdotool", "windowactivate", "--sync", ids[-1]])
        time.sleep(0.5); return f"'{nm}' penceresi öne getirildi." if rc == 0 else f"'{nm}' adında pencere yok. desktop_windows ile bak."
    return f"Bilinmeyen masaüstü eylemi: {act}"

DESKTOP_SYS = """

MASAÜSTÜ KONTROLÜ (bilgisayarın masaüstündeki uygulamaları SEN kullanırsın — kullanıcı ekranda izler, sağ alttaki ⏹ ile durdurabilir):
- open_app {"app": "gimp"} ile uygulamayı aç, sonra:
- desktop_look {"goal": "ne yapmaya çalışıyorsun"}  → EKRAN GÖRÜNTÜSÜ alır (koordinat ızgaralı), görsel modelle bakıp nereye tıklanacağını söyler. HER ADIMDAN ÖNCE ve SONRA bak.
- desktop_click {"x": 640, "y": 300, "button": "left|right", "double": false}  → desktop_look görüntüsündeki koordinata tıklar.
- desktop_type {"text": "...", "enter": false}   desktop_key {"keys": "ctrl+s"} (birden fazla: "ctrl+l Return")   desktop_scroll {"direction": "down|up", "amount": 5}
- desktop_windows {}  → açık pencereler.   desktop_focus {"name": "pencere adı"}  → pencereyi öne getirir.
KURALLAR: Şifre/kart bilgisini ASLA yazma (kullanıcıya bırak). Ödeme, mesaj/e-posta gönderme, dosya/hesap silme gibi geri alınamaz bir adımdan önce ask_user ile sor. Kullanıcının dosyalarının üzerine yazma.
Bir uygulamayı İLK KEZ kullanacaksan önce recall ile bak; bilgin yoksa ÖĞREN: README / resmi belge (web_search + fetch_url) ve gerekirse youtube {"query": "<uygulama> nasıl kullanılır"} ile video özeti çıkar, learn ile kaydet; sonra kullan."""

BROWSER_SYS = """

TARAYICI KONTROLÜ (tarayıcıyı SEN yönetirsin; kullanıcı her şeyi uygulamanın içindeki 🌐 sekmesinde canlı izler):
İŞİ KENDİN YAP: yaz, ara, tıkla, sayfalara gir. Bir şeyi bilmiyorsan önce Google'da ara (browser_open {"query": ...}), sonuçlara gir, oku, öğren, sonra devam et. Kullanıcıya "şunu yapayım mı?" diye sorma; sadece şifre/kart girmek ya da ödeme/gönderme/silme gibi geri alınamaz bir adım gerekiyorsa sor.
- browser_open {"url": "..."} | {"query": "google araması"} | {"urls": ["...", "..."]} | {"queries": ["...", "..."]}, isteğe bağlı "name"  → kontrol ettiğin tarayıcıda yeni pencere(ler) açar; birden fazla adres verirsen HEPSİNİ AYNI ANDA açar. Dönüşte her pencerenin oturum kimliği (t1, t2…), sayfa metni ve numaralı öğeleri gelir.
- browser_read {"session": "t1"} veya {"sessions": ["t1","t2"]}  → sayfa metni + numaralı tıklanabilir/yazılabilir öğeler (birden fazla oturumu aynı anda okur).
- browser_click {"session": "t1", "element": 5}  → [5] numaralı öğeye tıklar (KENDİN yaparsın; sadece ödeme/gönderme/silme gibi geri alınamaz adımlar kullanıcıya sorulur).
- browser_type {"session": "t1", "element": 3, "text": "...", "enter": true}  → alana yazar / açılır listeden seçer (onaylı). Şifre, kart, doğrulama kodu alanlarına ASLA yazma; kullanıcıdan kendisinin girmesini iste.
- browser_go {"session": "t1", "url": "..."}  → aynı pencerede başka adrese gider.   browser_back {"session": "t1"}  → geri.
- browser_scroll {"session": "t1", "direction": "down|up|top|bottom"}  → kaydırır ve yeniden okur.
- browser_look {"session": "t1", "goal": "arama kutusuna yaz"}  → EKRAN GÖRÜNTÜSÜ ALIR, öğelerin üstüne numara koyar ve görsel modelle bakıp nereye basman/yazman gerektiğini söyler. Nereye basacağından emin değilsen, sayfa karışıksa ya da metin yetmiyorsa bunu kullan.
- browser_click_xy {"session": "t1", "x": 640, "y": 300}  → numarası olmayan bir yere (harita, tuval vb.) ekran koordinatıyla tıklar.
- browser_screenshot {"session": "t1", "question": "neye bakayım?"}  → ekran görüntüsü alır ve görsel modelle tarif eder (grafik, resim, düzen sorularında).
- browser_list {}  → açık oturumlar.   browser_close {"session": "t1"}  → kapatır.
Öğe etiketleri: ·REKLAM (sponsorlu — kullanıcı istemedikçe TIKLAMA, organik sonuçları seç) · ·çerçevede / ·bileşende (iç çerçeve / web bileşeni içinde, normal tıklanır) · ☑/☐ (işaret kutusu durumu) · ·ekran dışı.
KURALLAR: Öğe numaraları aynı sayfada sabittir, sayfa değişince yenilenir; tıklamadan/yazmadan önce güncel browser_read çıktısındaki numarayı kullan. Satın alma, ödeme, mesaj/e-posta gönderme, hesap silme, form gönderme gibi geri alınamaz adımlardan ÖNCE say ile ne yapacağını açıkça söyleyip izin iste. Birden fazla siteyi karşılaştırırken urls ile aynı anda aç, sessions ile aynı anda oku.
Sadece bakmak/okumak için browse/fetch_url yeterli; tıklama, yazma, giriş yapılmış sayfalar ya da kullanıcının ekranda görmesi gerekiyorsa browser_* kullan."""


# ═════════════════════════════ ✨ ARAÇ GELİŞTİRME (onar · özellik öner · istenen özelliği ekle) ═════════════════════════════
DEV_BRANCH = "cypher-gelistirme"
DEV_ID = ["-c", "user.name=Cypher Tool", "-c", "user.email=cyphertool@localhost", "-c", "commit.gpgsign=false"]
DEV_EXCLUDE = [".venv/", "venv/", "env/", "node_modules/", "__pycache__/", "*.pyc", ".pytest_cache/", ".mypy_cache/", "dist/", "build/",
               "target/", ".cypher-*", "*.log", ".env", ".DS_Store"]

def _gitc(root, *a, timeout=120):
    return _git(root, *DEV_ID, *a, timeout=timeout)

def dev_branch(root):
    if not os.path.exists(os.path.join(root, ".git")):
        return ""
    return _git(root, "rev-parse", "--abbrev-ref", "HEAD")[1]

def dev_base(root):
    return _git(root, "config", "--get", "cypher.base")[1], _git(root, "config", "--get", "cypher.basecommit")[1]

def upstream_head(root):
    """Güncelleme karşılaştırması için: geliştirme dalındaysak dallandığımız orijinal commit, değilse HEAD."""
    if dev_branch(root) == DEV_BRANCH:
        return dev_base(root)[1] or git_head(root)
    return git_head(root)

def dev_prepare(root, log=None):
    """İlk düzenlemeden önce: git deposu yoksa başlangıç hali kaydedilir, 'cypher-gelistirme' dalı açılır. Her şey geri alınabilir kalır."""
    root = os.path.realpath(root)
    if dev_branch(root) == DEV_BRANCH:
        return "zaten geliştirme dalında"
    if not os.path.exists(os.path.join(root, ".git")):
        _gitc(root, "init", "-q")
        os.makedirs(os.path.join(root, ".git", "info"), exist_ok=True)
        open(os.path.join(root, ".git", "info", "exclude"), "a").write("\n".join(DEV_EXCLUDE) + "\n")
        _gitc(root, "add", "-A"); _gitc(root, "commit", "-q", "-m", "Cypher Tool: orijinal hali (geliştirmeden önce)", "--allow-empty")
        if log: log("🗂️ Araç git deposu değildi; orijinal hali kaydedildi (git init).")
    else:
        try:
            ex = os.path.join(root, ".git", "info", "exclude"); old = open(ex).read() if os.path.exists(ex) else ""
            add = [x for x in DEV_EXCLUDE if x not in old.split("\n")]
            if add:
                open(ex, "a").write("\n# Cypher Tool\n" + "\n".join(add) + "\n")
        except Exception:
            pass
    br = dev_branch(root) or "HEAD"; head = git_head(root)
    _git(root, "config", "cypher.base", br); _git(root, "config", "cypher.basecommit", head)
    rc, out, err = _git(root, "rev-parse", "--verify", "--quiet", DEV_BRANCH)
    if rc == 0:
        rc, out, err = _git(root, "checkout", "-q", DEV_BRANCH)
    else:
        rc, out, err = _git(root, "checkout", "-q", "-b", DEV_BRANCH)
    if rc != 0:
        raise RuntimeError("Geliştirme dalı açılamadı: " + (err or out)[-300:])
    if _git(root, "status", "--porcelain")[1]:
        _gitc(root, "add", "-A"); _gitc(root, "commit", "-q", "-m", "Cypher Tool: geliştirme öncesi yerel değişiklikler")
    if log: log(f"🌿 '{DEV_BRANCH}' dalı açıldı (orijinal: {br} @ {head[:7]}). Tüm değişiklikler buraya kaydedilir; istediğin an orijinale dönebilirsin.")
    return f"'{DEV_BRANCH}' dalı açıldı"

def dev_commit(root, msg):
    root = os.path.realpath(root)
    if dev_branch(root) != DEV_BRANCH:
        dev_prepare(root)
    if not _git(root, "status", "--porcelain")[1]:
        return "Kaydedilecek değişiklik yok."
    _gitc(root, "add", "-A")
    rc, out, err = _gitc(root, "commit", "-q", "-m", ("✨ " + (msg or "Cypher Tool geliştirmesi"))[:200])
    if rc != 0:
        return "Kaydedilemedi: " + (err or out)[-300:]
    h = git_head(root)[:7]
    for s_, t in tools().items():
        if os.path.realpath(t.get("path", "")) == root:
            dv = t.get("dev") or []
            dv.append({"hash": h, "msg": msg[:200], "at": now()}); update_tool(s_, dev=dv[-50:], developed=True)
    return f"Kaydedildi: {h} — {msg[:120]}"

def dev_history(root):
    root = os.path.realpath(os.path.expanduser(root))
    br = dev_branch(root); base, basec = dev_base(root)
    has_dev = _git(root, "rev-parse", "--verify", "--quiet", DEV_BRANCH)[0] == 0
    commits = []
    if has_dev:
        rng = f"{basec}..{DEV_BRANCH}" if basec else DEV_BRANCH
        _, out, _ = _git(root, "log", "--format=%h|%ct|%s", rng, "-n", "60")
        for l in out.splitlines():
            h, ts, s_ = (l.split("|", 2) + ["", ""])[:3]
            _, st, _ = _git(root, "show", "--stat", "--format=", h)
            commits.append({"hash": h, "ts": int(ts or 0), "msg": s_, "stat": st[-600:]})
    return {"root": root, "branch": br, "on_dev": br == DEV_BRANCH, "has_dev": has_dev, "base": base, "basecommit": basec[:7],
            "dirty": bool(_git(root, "status", "--porcelain")[1]), "commits": commits}

def dev_switch(root, to):
    root = os.path.realpath(os.path.expanduser(root)); base, _ = dev_base(root)
    if _git(root, "status", "--porcelain")[1]:
        _gitc(root, "add", "-A"); _gitc(root, "commit", "-q", "-m", "Cypher Tool: kaydedilmemiş değişiklikler")
    target = DEV_BRANCH if to == "dev" else (base if base and base != "HEAD" else _git(root, "config", "--get", "cypher.basecommit")[1])
    rc, out, err = _git(root, "checkout", "-q", target)
    if rc != 0:
        raise RuntimeError((err or out)[-300:])
    return target

def dev_rebase_update(root, log):
    """Geliştirme dalındayken güncelleme: orijinalin yeni sürümü indirilir, senin geliştirmelerin onun üstüne yeniden uygulanır."""
    base, basec = dev_base(root)
    shallow = os.path.exists(os.path.join(root, ".git", "shallow"))
    rc, out, err = _git(root, "fetch", *(["--depth", "1"] if shallow else []), "origin", base if base and base != "HEAD" else "HEAD", timeout=300)
    log("$ git fetch\n" + out + err)
    if rc != 0:
        return False
    new = _git(root, "rev-parse", "FETCH_HEAD")[1]
    if new == basec:
        log("✔ Orijinal araçta yeni değişiklik yok."); return True
    rc, out, err = _gitc(root, "rebase", "--onto", new, basec, DEV_BRANCH, timeout=300)
    log("$ git rebase (geliştirmelerin yeni sürümün üstüne taşınıyor)\n" + out + err)
    if rc != 0:
        _git(root, "rebase", "--abort")
        log("✖ Senin geliştirmelerin yeni sürümle ÇAKIŞTI; hiçbir şey değişmedi. ✨ Geliştir → 'Şu çalışmıyor' ile yapay zekâdan birleştirmesini isteyebilirsin.")
        return False
    _git(root, "config", "cypher.basecommit", new)
    if base and base != "HEAD":
        _git(root, "branch", "-f", base, new)
    log(f"✅ Yeni sürüm alındı ({basec[:7]} → {new[:7]}) ve geliştirmelerin üstüne yeniden uygulandı.")
    return True

def repo_issues(full_name, n=20):
    if not full_name or "/" not in full_name:
        return "Bu aracın GitHub deposu bilinmiyor."
    try:
        r = gh_api(f"/repos/{full_name}/issues?state=open&per_page=40&sort=reactions")
    except Exception as e:
        return f"GitHub konuları alınamadı: {str(e)[:150]}"
    out = []
    for it in r:
        if it.get("pull_request"):
            continue
        out.append({"no": it.get("number"), "baslik": it.get("title", "")[:150], "etiketler": [l.get("name") for l in it.get("labels", [])][:5],
                    "yorum": it.get("comments", 0), "begeni": (it.get("reactions") or {}).get("total_count", 0), "adres": it.get("html_url"),
                    "ozet": re.sub(r"\s+", " ", (it.get("body") or ""))[:240]})
        if len(out) >= n:
            break
    return json.dumps(out, ensure_ascii=False) if out else "Açık konu (issue) yok."

def dev_task(name, root, mode, text, full_name=""):
    head = f"✨ GELİŞTİRME MODU — araç: '{name}' (klasör: {root}{', repo: ' + full_name if full_name else ''}).\n"
    if mode == "fix":
        body = ("GÖREV: Aracın ÇALIŞMAYAN özelliklerini bul ve onar. README'deki özellikleri/komutları ve --help çıktısını çıkar, her birini küçük örneklerle DENE "
                "(run). Hata verenlerin kök nedenini kodda bul (read_file), internette araştır (web_search + fetch_url; GitHub issues'a da bak: repo_issues), "
                "düzelt (edit_file), tekrar dene, çalışınca dev_commit ile kaydet. Sonunda hangi özellik çalışıyordu / bozuktu / onarıldı tablo halinde raporla.")
    elif mode == "suggest":
        body = ("GÖREV: Aracı tanı (README, kod yapısı, --help, repo_issues ile kullanıcıların istekleri) ve bu araca eklenebilecek 4-6 SOMUT, işe yarar yeni özellik öner. "
                "Her öneri için 1 cümle fayda + zorluk (kolay/orta/zor) yaz. say ile sun; options içine kısa özellik adlarını ve 'Kendi isteğimi yazacağım' seçeneğini koy. "
                "Kullanıcı hangisini seçerse onu uygula.")
    elif mode == "bug":
        body = (f"GÖREV: Kullanıcı şu sorunu bildiriyor: \"{text}\". Sorunu önce yeniden üret (run), kök nedenini kodda bul, gerekirse internette araştır, "
                "düzelt, aynı adımla tekrar test et ve çalışınca dev_commit ile kaydet.")
    else:
        body = (f"GÖREV: Kullanıcının istediği özelliği bu araca EKLE: \"{text}\". Önce kodun ilgili kısımlarını oku ve nasıl ekleyeceğini kısaca planla "
                "(belirsizlik varsa say ile 1 kısa soru sor). Gerekirse resmi belgelerden/örneklerden öğren (web_search + fetch_url). Mevcut kod stiline uy, "
                "küçük adımlarla değiştir, her adımda dene, çalışınca dev_commit ile kaydet. README'ye yeni özelliğin kullanımını ekle.")
    return head + body + ("\nSONDA: finish ile Türkçe rapor ver (ne değişti, hangi dosyalar, nasıl kullanılır, test sonucu) ve next_options içinde "
                          "'Şu özellikleri de ekleyebilirim' diye 3-4 yeni somut öneri sun.")

TOOL_DEV_SYS = """

GELİŞTİRME / ONARIM EYLEMLERİ (aracın kodunu değiştirmek için):
- read_file {"path": "dosya", "start": 1, "end": 200}  → dosyayı satır numaralarıyla okur (düzenlemeden ÖNCE mutlaka oku).
- edit_file {"path": "dosya", "old": "değişecek metin (dosyada AYNEN ve tek bir yerde geçmeli)", "new": "yeni metin"}  → küçük, hedefli değişiklik. Yeni dosya için write_file.
- dev_commit {"message": "Türkçe kısa açıklama"}  → çalışan bir değişikliği kaydeder (geri alınabilir sürüm noktası). Her çalışan adımdan sonra kullan.
- repo_issues {"repo": "sahip/ad"}  → GitHub'daki açık konular: bilinen hatalar ve kullanıcıların istediği özellikler (öneri ve onarım için çok değerli).
KURALLAR: Değişiklikler otomatik olarak '""" + DEV_BRANCH + """' adlı ayrı git dalında tutulur; orijinal hal korunur, kullanıcı tek tıkla geri dönebilir. ASLA git push yapma, uzak depoya bir şey gönderme.
Kodu anlamadan değiştirme: önce ilgili dosyaları read_file ile oku. Büyük yeniden yazımlar yerine küçük değişiklikler yap. Her değişiklikten sonra çalıştırıp DENE; bozduysan düzelt.
Bilmediğin bir kütüphane/API kullanacaksan önce resmi belgesini ya da örnek kodu fetch_url ile oku ve ondan öğren; okuduğun kaynakları raporda adresleriyle belirt.
Bağımlılık eklemen gerekirse aracın kendi ortamına kur (.venv / yerel npm) ve requirements/package dosyasını da güncelle."""

# 🔎 görünür araştırma: aramalar kullanıcının göreceği Chrome penceresinde yapılır
GOOGLE_RES_JS = r"""(()=>{const out=[];const seen=new Set();
const cand=[...document.querySelectorAll('a h3, h3 a, h2 a, a h2, [data-testid=result-title-a], #b_results h2 a')];
for(const h of cand){const a=h.tagName==='A'?h:h.closest('a');if(!a||!a.href||seen.has(a.href)||!/^https?:/.test(a.href))continue;
 if(/google\.[a-z.]+\/(search|url|aclk)|accounts\.google|support\.google|policies\.google|bing\.com\/(search|aclk)|duckduckgo\.com\/(\?|y\.js)/.test(a.href)&&!/[?&](url|q|uddg)=http/.test(a.href))continue;
 if(new URL(a.href).hostname===location.hostname&&/\/(search|ara|sonuc)/.test(new URL(a.href).pathname))continue;seen.add(a.href);
 let box=a.closest('[data-hveid]')||a.parentElement;let sn='';for(let i=0;i<4&&box;i++){if(box.querySelectorAll('h3,h2').length>1)break;const t=box.innerText||'';sn=t;if(t.length>h.innerText.length+40)break;box=box.parentElement;}
 const ad=/^(sponsorlu|sponsored|reklam|ad)\b/i.test((box&&box.innerText||'').trim())||/aclk|[?&]ref=reklam/.test(a.href);
 sn=sn.replace(h.innerText,'').replace(/\s+/g,' ').trim().slice(0,320);out.push({title:h.innerText.slice(0,150),url:a.href,snippet:sn,ad});if(out.length>=10)break;}
return {url:location.href,title:document.title,res:out,consent:/consent\.|before you continue|devam etmeden önce/i.test(location.href+' '+document.title),
 sorry:/\/sorry\//.test(location.href)||/unusual traffic|olağan dışı trafik/i.test(document.body?document.body.innerText:'')};})()"""

def visible_ok():
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY") or brw_embed()) and bool(next((x for x in BROWSERS if "firefox" not in x and which(x)), ""))

def _research_sid(job):
    sid = job.ctx.get("research_sid")
    if sid and sid in BRW["sessions"]:
        return sid
    sid = brw_open("about:blank", name="🔎 Araştırma")
    job.ctx["research_sid"] = sid
    return sid

def visible_search(job, query, con=None):
    sid = _research_sid(job)
    brw_go(sid, search_url(query))
    brw_captcha_wait(job, sid, con)
    r = brw_eval(sid, GOOGLE_RES_JS)
    if r.get("consent"):
        brw_read(sid)
        btn = next((e for e in BRW["sessions"][sid]["elements"] if re.search(r"tümünü kabul|accept all|alle akzeptieren|zaakceptuj wszystko|kabul et", e["text"], re.I)), None)
        if btn and _brw_confirm(job, sid, f"Google ilk kullanımda çerez onayı istiyor. '{btn['text']}' düğmesine tıklayayım mı? (sadece bu tarayıcının profili için, bir kere)", btn["n"]):
            brw_click(sid, btn["n"])
            brw_go(sid, search_url(query)); r = brw_eval(sid, GOOGLE_RES_JS)
    if r.get("sorry") or not r.get("res"):
        why = "Arama motoru doğrulama (robot kontrolü) istedi" if r.get("sorry") else "Arama sonuçları okunamadı"
        alt = web_search(query)
        return (f"({why}; sonuçlar yedek arama motorundan:)\n" + json.dumps(alt, ensure_ascii=False)) if alt else why + "."
    if con: console_print(con, f"🔎 Chrome'da arandı ({sid}): {query} → {len(r['res'])} sonuç", "95")
    return (f"(Uygulama içi tarayıcıda arandı — oturum {sid}; sonuca girmek için browser_click ya da fetch_url/browser_go kullan)\n"
            + "\n".join(f"{i + 1}. {'[REKLAM] ' if x.get('ad') else ''}{x['title']}\n   {x['url']}\n   {x['snippet'][:260]}" for i, x in enumerate(r["res"])))

def visible_fetch(job, url, con=None, limit=9000):
    if re.search(r"\.(pdf|zip|tar|gz|deb|rpm|exe|png|jpe?g|gif|mp[34])(\?|$)", url, re.I):
        return fetch_url(url, limit)
    sid = _research_sid(job)
    brw_go(sid, url)
    brw_captcha_wait(job, sid, con)
    r = brw_read(sid, limit)
    if con: console_print(con, f"📄 Chrome'da okunuyor ({sid}): {r['title'][:80]}", "95")
    txt = r["text"]
    if str(r.get("url", "")).startswith("chrome-error://"):
        return brw_read_text(sid, 600)   # açılamadı: nedenini söyle
    if len(txt.strip()) < 15:   # neredeyse boş (betik bekliyor olabilir): bir kez daha bekle, yine boşsa düz HTTP ile dene
        brw_settle(sid, 4); r = brw_read(sid, limit); txt = r["text"]
        if len(txt.strip()) < 15:
            return fetch_url(url, limit)
    vid = ""
    try:
        if brw_eval(sid, "!!(window.ytInitialPlayerResponse&&window.ytInitialPlayerResponse.videoDetails)", 3):
            vid = "\n\n(Bu bir VİDEO sayfası: içeriğini öğrenmek için youtube {\"url\": \"" + r["url"] + "\"} eylemiyle altyazısını okuyup özetle.)"
    except Exception:
        pass
    return f"(Uygulama içi tarayıcıda açıldı — oturum {sid})\nBAŞLIK: {r['title']}\nADRES: {r['url']}\n\n{txt}{vid}"


# ═════════════════════════════ 🖥️ bilgisayardaki uygulamalar ═════════════════════════════
ICON_SEARCH = ["/usr/share/icons/hicolor/128x128/apps", "/usr/share/icons/hicolor/64x64/apps", "/usr/share/icons/hicolor/48x48/apps",
               "/usr/share/icons/hicolor/256x256/apps", "/usr/share/icons/hicolor/scalable/apps", "/usr/share/pixmaps",
               "/var/lib/flatpak/exports/share/icons/hicolor/128x128/apps", "/var/lib/flatpak/exports/share/icons/hicolor/scalable/apps",
               os.path.expanduser("~/.local/share/icons/hicolor/128x128/apps"), "/usr/share/icons/Papirus/64x64/apps", "/usr/share/icons/Adwaita/scalable/apps"]

def resolve_icon(name):
    if not name:
        return ""
    if os.path.isabs(name):
        return name if os.path.isfile(name) else ""
    for d in ICON_SEARCH:
        for ext in (".png", ".svg", ".xpm"):
            f = os.path.join(d, name + ext)
            if os.path.isfile(f):
                return f
    return ""

POPULAR_CLI = ["ffmpeg", "yt-dlp", "convert", "magick", "pandoc", "libreoffice", "soffice", "pdftotext", "qpdf", "gs", "tesseract", "git", "python3", "node",
               "docker", "curl", "wget", "rsync", "zip", "7z", "unrar", "tar", "htop", "btop", "nmap", "sqlite3", "jq", "ollama", "gh", "vim", "nano",
               "ncdu", "tmux", "aria2c", "exiftool", "optipng", "sox", "lame", "espeak-ng", "sshpass", "ssh", "ufw", "fail2ban-client", "clamscan"]

def desktop_apps(flt=""):
    flt = (flt or "").lower(); out = []; seen = set()
    dirs = ["/usr/share/applications", "/usr/local/share/applications", os.path.expanduser("~/.local/share/applications"),
            "/var/lib/flatpak/exports/share/applications", os.path.expanduser("~/.local/share/flatpak/exports/share/applications"), "/var/lib/snapd/desktop/applications"]
    for d in dirs:
        if not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            if not fn.endswith(".desktop") or fn in seen or fn.startswith("cyphertool"):
                continue
            seen.add(fn)
            try:
                txt = open(os.path.join(d, fn), encoding="utf-8", errors="replace").read().split("\n[", 1)[0]
            except Exception:
                continue
            if re.search(r"^(NoDisplay|Hidden)=true", txt, re.M):
                continue
            g = lambda k: (re.search(rf"^{re.escape(k)}=(.*)$", txt, re.M) or [None, ""])[1].strip()
            name = g("Name[tr]") or g("Name")
            if not name:
                continue
            com = g("Comment[tr]") or g("Comment") or g("GenericName[tr]") or g("GenericName")
            ex = re.sub(r"\s%\w", "", g("Exec")).strip()
            cats = g("Categories")
            if flt and flt not in (name + com + fn + ex + cats).lower():
                continue
            out.append({"kind": "app", "id": fn[:-8], "name": name, "desc": com[:160], "exec": ex[:160], "cats": cats[:80],
                        "terminal": g("Terminal") == "true", "icon": g("Icon")})
    return out

def cli_apps(flt=""):
    flt = (flt or "").lower(); names = set()
    for d in base_env()["PATH"].split(os.pathsep):
        try:
            for fn in os.listdir(d):
                if os.access(os.path.join(d, fn), os.X_OK) and not os.path.isdir(os.path.join(d, fn)):
                    names.add(fn)
        except Exception:
            continue
    sel = sorted(n for n in names if flt in n.lower())[:80] if flt else [n for n in POPULAR_CLI if n in names]
    desc = {}
    if sel and which("whatis"):
        try:
            r = subprocess.run(["whatis"] + sel, capture_output=True, text=True, timeout=8)
            for l in r.stdout.splitlines():
                m = re.match(r"^(\S+)\s*\([^)]*\)\s*-\s*(.*)$", l)
                if m and m.group(1) not in desc:
                    desc[m.group(1)] = m.group(2)[:160]
        except Exception:
            pass
    return [{"kind": "cli", "id": n, "name": n, "desc": desc.get(n, ""), "exec": n, "icon": ""} for n in sel], len(names)

def app_info_text(kind, app_id):
    """Uygulama hakkında ham bilgi: masaüstü girdisi, --help, man."""
    parts = []; binname = app_id
    if kind == "app":
        a = next((x for x in desktop_apps() if x["id"] == app_id), None)
        if a:
            parts.append(f"Ad: {a['name']}\nAçıklama: {a['desc']}\nKomut: {a['exec']}\nKategori: {a['cats']}")
            binname = (a["exec"].split() or [app_id])[0]
            if binname in ("env", "flatpak"):
                binname = a["exec"].split()[-1]
    if kind == "cli" and which(binname):
        try:
            r = subprocess.run([binname, "--help"], capture_output=True, text=True, timeout=6, stdin=subprocess.DEVNULL, env={**base_env(), "DISPLAY": ""})
            h = (r.stdout or "") + (r.stderr or "")
            if len(h) > 40:
                parts.append("--help çıktısı:\n" + clean_term(h)[:5000])
        except Exception:
            pass
    if which("man"):
        try:
            r = subprocess.run(["bash", "-c", f"MANWIDTH=100 man -P cat {q(os.path.basename(binname))} 2>/dev/null | col -b 2>/dev/null | head -150"], capture_output=True, text=True, timeout=8)
            if len(r.stdout) > 100:
                parts.append("man sayfası (ilk kısım):\n" + r.stdout[:6000])
        except Exception:
            pass
    return "\n\n".join(parts) or f"{app_id} hakkında yerel bilgi bulunamadı."

def app_explain(kind, app_id, question=""):
    raw = app_info_text(kind, app_id)
    if not llm_available():
        return {"text": "ℹ Yapay zekâ API'si bağlı olmadığı için ham bilgiyi gösteriyorum:\n\n```\n" + raw[:6000] + "\n```", "ai": False}
    txt, prov = llm_ask([{"role": "user", "content": f"Program: {app_id} ({'grafik uygulama' if kind == 'app' else 'terminal programı'})\n"
                          f"Kullanıcının sorusu: {question or 'Bu nedir, nasıl kullanılır?'}\n\nBİLGİSAYARDAN TOPLANAN BİLGİ:\n{raw[:9000]}"}],
                         "Kullanıcıya bu programı TÜRKÇE, sade ve samimi anlat (Markdown). Bölümler: '## Ne işe yarar?' (2-3 cümle), "
                         "'## Nasıl kullanılır?' (adım adım; grafik uygulamaysa menü/düğme mantığıyla, terminal programıysa ```bash örnekleriyle), "
                         "'## Sık yapılan işler' (5-8 madde, her biri somut örnek), '## İpuçları'. "
                         "En sona ayrı satırda şunu yaz: '🤖 **İstersen ben halledeyim** — ne yapmak istediğini yaz, bu programı senin yerine kullanayım.' "
                         "Uydurma seçenek yazma.", log=None, feature="guide")
    return {"text": txt, "ai": True, "api": f"{prov.get('name')} · {prov.get('model')}"}

# ═════════════════════════════ 🛠️ GELİŞTİRME STÜDYOSU ═════════════════════════════
PROJ_DIR = os.path.join(DATA, "projeler")
os.makedirs(PROJ_DIR, exist_ok=True)
DEV_TEMPLATES = {
    "python": {"label": "🐍 Python programı", "run": "python3 main.py", "files": {
        "main.py": '#!/usr/bin/env python3\n"""{name} — {desc}"""\nimport argparse\n\n\ndef main():\n    ap = argparse.ArgumentParser(description="{desc}")\n    ap.add_argument("girdi", nargs="?", help="isteğe bağlı girdi")\n    a = ap.parse_args()\n    print("Merhaba! {name} çalışıyor.", a.girdi or "")\n\n\nif __name__ == "__main__":\n    main()\n',
        "requirements.txt": "", "README.md": "# {name}\n\n{desc}\n\n## Çalıştırma\n```bash\npython3 main.py\n```\n"}},
    "web": {"label": "🌐 Web sitesi (HTML/CSS/JS)", "run": "python3 -m http.server 8090", "files": {
        "index.html": '<!doctype html>\n<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">\n<title>{name}</title><link rel="stylesheet" href="style.css"></head>\n<body><main><h1>{name}</h1><p>{desc}</p><button id="b">Tıkla</button></main><script src="app.js"></script></body></html>\n',
        "style.css": "body{font-family:system-ui;background:#0b0614;color:#eee;display:grid;place-items:center;min-height:100vh;margin:0}\nh1{color:#c084fc}button{background:#7c3aed;color:#fff;border:0;padding:10px 18px;border-radius:10px;cursor:pointer}\n",
        "app.js": "document.getElementById('b').onclick=()=>alert('Merhaba!');\n", "README.md": "# {name}\n\n{desc}\n\nÇalıştır: `python3 -m http.server 8090` → http://127.0.0.1:8090\n"}},
    "node": {"label": "🟢 Node.js uygulaması", "run": "node index.js", "files": {
        "index.js": "// {name} — {desc}\nconsole.log('Merhaba! {name} çalışıyor.');\n",
        "package.json": '{{\n  "name": "{slug}",\n  "version": "0.1.0",\n  "description": "{desc}",\n  "main": "index.js",\n  "scripts": {{ "start": "node index.js" }}\n}}\n',
        "README.md": "# {name}\n\n{desc}\n\n```bash\nnode index.js\n```\n"}},
    "bash": {"label": "🐚 Bash betiği", "run": "bash run.sh", "files": {
        "run.sh": "#!/usr/bin/env bash\n# {name} — {desc}\nset -euo pipefail\necho \"Merhaba! {name} çalışıyor.\"\n", "README.md": "# {name}\n\n{desc}\n\n```bash\nbash run.sh\n```\n"}},
    "bos": {"label": "📄 Boş proje", "run": "", "files": {"README.md": "# {name}\n\n{desc}\n"}},
}

def proj_path(name):
    p = os.path.realpath(os.path.join(PROJ_DIR, slugify(name)))
    if not p.startswith(os.path.realpath(PROJ_DIR) + os.sep):
        raise KeyError(name)
    return p

def proj_meta(name, **upd):
    root = proj_path(name); f = os.path.join(root, ".cypher", "proje.json")
    m = jload(f, {"name": name})
    if upd:
        m.update(upd); os.makedirs(os.path.dirname(f), exist_ok=True); jsave(f, m)
    return m

def git(root, *args, timeout=60):
    pre = []
    try:
        if not subprocess.run(["git", "config", "user.email"], cwd=root, capture_output=True, text=True).stdout.strip():
            pre = ["-c", "user.name=Cypher Tool", "-c", "user.email=cypher@localhost"]
    except Exception:
        pass
    r = subprocess.run(["git", *pre, *args], cwd=root, capture_output=True, text=True, timeout=timeout, errors="replace")
    return r.returncode, (r.stdout + r.stderr).strip()

def proj_commit(root, msg):
    if not which("git"):
        return ""
    git(root, "add", "-A")
    rc, out = git(root, "commit", "-m", msg[:200])
    return out if rc == 0 else ""

def proj_new(name, template="python", desc="", ai=False):
    slug = slugify(name) or "proje"
    root = unique_dir(PROJ_DIR, slug); os.makedirs(root); slug = os.path.basename(root)
    tp = DEV_TEMPLATES.get(template) or DEV_TEMPLATES["bos"]
    for rel, content in tp["files"].items():
        ap = os.path.join(root, rel); os.makedirs(os.path.dirname(ap), exist_ok=True)
        open(ap, "w", encoding="utf-8").write(content.format(name=name, desc=desc or "Cypher Tool ile geliştirildi.", slug=slug))
        if content.startswith("#!"):
            os.chmod(ap, 0o755)
    open(os.path.join(root, ".gitignore"), "w").write(".venv/\nnode_modules/\n__pycache__/\n*.pyc\n.env\n")
    os.makedirs(os.path.join(root, ".cypher"), exist_ok=True)
    jsave(os.path.join(root, ".cypher", "proje.json"), {"name": name, "slug": slug, "desc": desc, "template": template, "run": tp["run"], "created": now(), "issues": []})
    if which("git"):
        git(root, "init", "-q", "-b", "main"); proj_commit(root, "🎉 Proje oluşturuldu")
    return slug

def proj_list():
    out = []
    for d in sorted(os.listdir(PROJ_DIR)):
        root = os.path.join(PROJ_DIR, d)
        if not os.path.isdir(root):
            continue
        m = jload(os.path.join(root, ".cypher", "proje.json"), {"name": d})
        last = ""; br = ""
        if os.path.isdir(os.path.join(root, ".git")):
            _, last = git(root, "log", "-1", "--format=%s · %cr"); _, br = git(root, "branch", "--show-current")
        n = sum(len([f for f in fs]) for dp, ds, fs in os.walk(root) if not any(x in dp for x in (".git", ".venv", "node_modules")))
        out.append({"slug": d, "name": m.get("name", d), "desc": m.get("desc", ""), "template": m.get("template", ""), "run": m.get("run", ""),
                    "last": last if "fatal" not in last else "", "branch": br, "files": n, "tool": m.get("tool", ""),
                    "issues_open": len([i for i in m.get("issues", []) if not i.get("done")]), "path": root})
    return out

def proj_tree(slug):
    root = proj_path(slug); out = []
    for dp, ds, fs in os.walk(root):
        ds[:] = sorted(x for x in ds if x not in (".git", ".venv", "node_modules", "__pycache__", ".cypher"))
        for f in sorted(fs):
            ap = os.path.join(dp, f)
            out.append({"path": os.path.relpath(ap, root), "size": os.path.getsize(ap)})
        if len(out) > 800:
            break
    return out

def proj_file(slug, rel):
    root = proj_path(slug); ap = safe_path(os.path.join(root, rel), [root])
    if not ap or "/.git/" in ap + "/":
        raise KeyError(rel)
    return root, ap

def proj_context(root, limit=45000):
    files = []; total = 0
    for dp, ds, fs in os.walk(root):
        ds[:] = [x for x in ds if x not in (".git", ".venv", "node_modules", "__pycache__", "dist", "build", ".cypher")]
        for f in fs:
            ap = os.path.join(dp, f)
            try:
                if os.path.getsize(ap) > 60000:
                    files.append((os.path.relpath(ap, root), "(büyük dosya, içerik gösterilmedi)")); continue
                b = open(ap, "rb").read()
                if b"\0" in b[:2000]:
                    continue
                files.append((os.path.relpath(ap, root), b.decode("utf-8", "replace")))
            except Exception:
                continue
    files.sort(key=lambda x: (x[0] != "README.md", len(x[1])))
    out = []
    for rel, c in files:
        if total + len(c) > limit:
            out.append(f"=== {rel} === (yer yok, atlandı)"); continue
        out.append(f"=== {rel} ===\n{c}"); total += len(c)
    return "\n\n".join(out)

DEV_SYS = """Sen Cypher Tool Geliştirme Stüdyosu'nun YAZILIM GELİŞTİRİCİ yapay zekâsısın. Kullanıcının projesindeki dosyaları okur, isteğini uygulayan TEMİZ, ÇALIŞAN, hata kontrollü kod yazarsın.
Linux için yaz. Bağımlılık gerekiyorsa requirements.txt / package.json'a ekle ve install komutlarını ver (proje içi .venv veya yerel npm; global kurulum yok).
SADECE TEK BİR JSON döndür:
{"aciklama_tr": "ne yaptığını 2-5 madde Türkçe", "files": {"yol/dosya.py": "DOSYANIN TAM YENİ İÇERİĞİ"}, "delete": ["silinecek/yol"],
 "install": ["python3 -m venv .venv", ".venv/bin/pip install -r requirements.txt"], "run": "programı başlatan komut (değiştiyse)",
 "test": "HIZLI ve ETKİLEŞİMSİZ doğrulama komutu (ör. python3 -m py_compile main.py && python3 main.py --help ; node --check index.js)"}
Kurallar: Değiştirdiğin her dosyanın TAM içeriğini yaz (parça değil). Değişmeyen dosyaları yazma. README.md'yi Türkçe güncel tut. test komutu girdi beklememeli ve 60 sn'den kısa sürmeli."""

def dev_ai_flow(job, slug, request, opts):
    root = proj_path(slug); m = proj_meta(slug)
    job.slug = ""; job.title = f"🛠️ {m.get('name', slug)}: {request[:60]}"; job.ctx["project"] = slug
    auto = bool(opts.get("auto")); attempts = int(opts.get("attempts", 4)); req = request; changed_all = []
    if not llm_available():
        job.log("✖ Yapay zekâ API'si bağlı değil. 🔑 API'ler ya da 🆓 Ücretsiz AI sekmesinden bir model ekle."); job.status = "hata"; return
    for att in range(1, attempts + 1):
        job.status = f"kod yazıyor (deneme {att})"
        job.log(f"\n🤖 {'İstek' if att == 1 else 'Düzeltme'}: {req[:400]}")
        txt, prov = llm_ask([{"role": "user", "content": f"PROJE: {m.get('name')} — {m.get('desc', '')}\nÇALIŞTIRMA: {m.get('run', '')}\n\nMEVCUT DOSYALAR:\n{proj_context(root)}\n\nİSTEK:\n{req}"}],
                            DEV_SYS, opts.get("provider", ""), log=job.log, feature="agent")
        job.ctx["api"] = f"{prov.get('name')} · {prov.get('model')}"
        try:
            d = extract_json(txt)
        except Exception:
            job.log("⚠ Yanıt JSON değildi, tekrar isteniyor…"); req = request + "\n(ÖNEMLİ: sadece istenen JSON biçiminde yanıt ver)"; continue
        files = {k: v for k, v in (d.get("files") or {}).items() if isinstance(v, str)}
        dels = [x for x in (d.get("delete") or []) if isinstance(x, str)]
        job.log("📝 " + (d.get("aciklama_tr") or "") + "\n   Değişen: " + (", ".join(files) or "-") + (("\n   Silinecek: " + ", ".join(dels)) if dels else ""))
        if not auto:
            prev = "\n\n".join(f"── {k} ({len(v.splitlines())} satır) ──\n" + v[:1200] for k, v in list(files.items())[:6])
            r = job.ask("confirm", {"message": f"🤖 Yapay zekâ şu değişiklikleri yapmak istiyor:\n{d.get('aciklama_tr', '')}\n\nDosyalar: {', '.join(files)}{(' | Silinecek: ' + ', '.join(dels)) if dels else ''}\n\n{prev}"})
            if not r or not r.get("ok"):
                job.log("✖ Değişiklikler onaylanmadı."); job.status = "iptal"; return
        for rel, content in files.items():
            ap = safe_path(os.path.join(root, rel), [root])
            if not ap or "/.git/" in ap:
                continue
            os.makedirs(os.path.dirname(ap), exist_ok=True); open(ap, "w", encoding="utf-8").write(content)
            if content.startswith("#!"):
                os.chmod(ap, 0o755)
            changed_all.append(rel)
        for rel in dels:
            ap = safe_path(os.path.join(root, rel), [root])
            if ap and os.path.isfile(ap):
                os.remove(ap)
        if d.get("run"):
            proj_meta(slug, run=d["run"]); m["run"] = d["run"]
        c = proj_commit(root, ("🤖 " if att == 1 else "🔧 ") + request[:120])
        if c:
            job.log("📌 Sürüm kaydedildi (git commit)")
        for ic in d.get("install") or []:
            job.status = "bağımlılık kuruyor"
            rc, out = run_capture(job, ic, root, 900)
            if rc != 0:
                dg = diagnose(out)
                job.log("⚠ Kurulum komutu hata verdi" + (": " + dg[0]["title"] if dg else ""))
        test = (d.get("test") or "").strip()
        if not test:
            job.log("✅ Tamamlandı (test komutu verilmedi)."); break
        job.status = "test ediyor"
        rc, out = run_capture(job, test, root, 90)
        if rc == 0:
            job.log(f"✅ Test başarılı: {test}"); break
        dg = diagnose(out)
        job.log(f"✖ Test başarısız (kod {rc}) — yapay zekâ hatayı kendisi düzeltiyor…")
        req = (f"Az önce yaptığın değişiklikten sonra test komutu HATA verdi. Hatayı düzelt (asıl istek: {request}).\nKomut: {test}\nÇıktı:\n{out[-3500:]}" +
               ("\nBilgi bankası ipuçları: " + "; ".join(f"{x['title']} → {x['commands'] or x['advice']}" for x in dg[:3]) if dg else ""))
    else:
        job.log("⚠ Birkaç denemede test geçmedi; son hali kaydedildi. Konsoldan bakabilir ya da yeniden isteyebilirsin.")
    job.ctx["changed"] = sorted(set(changed_all))
    notify(APP, f"🛠️ {m.get('name')}: yapay zekâ işini bitirdi")

def proj_register(slug):
    root = proj_path(slug); m = proj_meta(slug)
    tslug = m.get("tool") or ("proje-" + slug)
    icon = tslug + ".svg"
    try: shutil.copy(os.path.join(WEB_DIR, "logo.svg"), os.path.join(ICON_DIR, icon))
    except Exception: icon = ""
    acts = [{"label": "Başlat", "command": m["run"], "terminal": True}] if m.get("run") else []
    tool = {"slug": tslug, "name": m.get("name", slug), "path": root, "source": "yerel proje (Geliştirme Stüdyosu)", "full_name": "proje/" + slug,
            "meta": {"description": m.get("desc", "")}, "summary": m.get("desc", ""), "category": "Kendi projem", "steps": [], "actions": acts,
            "runtimes": [], "system_packages": [], "optional": [], "icon": icon, "installed_at": now(), "status": "kuruldu",
            "guide_tr": "", "update_mode": "kapali", "inject_keys": True, "catalog_id": "", "kind": "tool", "project": slug}
    with _lock:
        t = tools(); old = t.get(tslug, {}); tool["installed_at"] = old.get("installed_at", tool["installed_at"]); t[tslug] = {**old, **tool}; save_tools(t)
    if acts:
        make_shortcuts(tools()[tslug])
    proj_meta(slug, tool=tslug)
    return tslug

def proj_zip(slug):
    root = proj_path(slug); out = os.path.join(EXPORT_DIR, f"{slug}-{time.strftime('%Y%m%d-%H%M')}.zip")
    import zipfile
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, ds, fs in os.walk(root):
            ds[:] = [x for x in ds if x not in (".venv", "node_modules", "__pycache__")]
            for f in fs:
                ap = os.path.join(dp, f); z.write(ap, os.path.join(slug, os.path.relpath(ap, root)))
    return out

# ═════════════════════════════ ⏰ ZAMANLANMIŞ GÖREVLER ═════════════════════════════
SCHED_FILE = os.path.join(CONF_DIR, "zamanlanmis.json")

def schedules():
    return jload(SCHED_FILE, [])

def sched_next(s, base=None):
    base = base or time.time(); lt = time.localtime(base)
    hh, mm = (int(x) for x in (s.get("time") or "09:00").split(":")[:2])
    ev = s.get("every", "daily")
    if ev == "hourly":
        t = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, lt.tm_hour, mm, 0, 0, 0, -1))
        return t if t > base else t + 3600
    t = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, hh, mm, 0, 0, 0, -1))
    if ev == "weekly":
        wd = int(s.get("weekday", 0))
        t += ((wd - lt.tm_wday) % 7) * 86400
        return t if t > base else t + 7 * 86400
    if ev == "once":
        if s.get("date"):
            try:
                y, mo, dd = (int(x) for x in s["date"].split("-"))
                return time.mktime((y, mo, dd, hh, mm, 0, 0, 0, -1))
            except Exception:
                pass
        return t if t > base else t + 86400
    return t if t > base else t + 86400

def sched_run(s):
    opts = {"unattended": True, "auto": bool(s.get("auto")), "workdir": s.get("workdir") or ""}
    if s.get("kind") == "workflow":
        j = start_job(f"⏰ {s['name']}", "workflow", workflow_flow, s.get("workflow"), s.get("task", ""), auto=bool(s.get("auto")))
    else:
        j = start_job(f"⏰ {s['name']}", "agent", agent_flow, s.get("task", ""), opts)
    j.ctx["schedule"] = s["id"]
    return j

def scheduler_loop():
    while True:
        time.sleep(30)
        try:
            with _lock:
                L = schedules(); ch = False
                for s in L:
                    if not s.get("enabled", True):
                        continue
                    if not s.get("next"):
                        s["next"] = sched_next(s); ch = True
                    if time.time() >= s["next"]:
                        j = sched_run(s); s["last"] = now(); s["last_job"] = j.id
                        if s.get("every") == "once":
                            s["enabled"] = False
                        s["next"] = sched_next(s, time.time() + 61); ch = True
                if ch:
                    jsave(SCHED_FILE, L)
        except Exception:
            pass

# ═════════════════════════════ 🔗 İŞ AKIŞLARI (ajan zincirleri) ═════════════════════════════
WF_FILE = os.path.join(CONF_DIR, "is_akislari.json")
WF_TEMPLATES = [
    {"id": "arastir-yaz-denetle", "name": "🔎 Araştır → ✍️ Yaz → ✅ Denetle", "steps": [
        {"kind": "web", "name": "Araştırmacı", "prompt": "Konu: {girdi}\nWeb sonuçlarını oku, önemli bilgileri ve kaynak adreslerini madde madde çıkar."},
        {"kind": "llm", "name": "Yazar", "prompt": "Aşağıdaki araştırma notlarından '{girdi}' konusunda düzenli, Türkçe bir rapor yaz (başlıklar, özet, kaynaklar).\n\nNOTLAR:\n{onceki}"},
        {"kind": "llm", "name": "Denetçi", "prompt": "Bu raporu denetle: hataları, eksikleri, kaynaksız iddiaları düzelt ve SON HALİNİ yaz.\n\n{onceki}"}]},
    {"id": "kod-incele-duzelt", "name": "💻 Kod yaz → 🔍 İncele → 🔧 Düzelt", "steps": [
        {"kind": "llm", "name": "Yazılımcı", "prompt": "Şu isteği yerine getiren tam, çalışan kodu yaz:\n{girdi}"},
        {"kind": "llm", "name": "İnceleyici", "prompt": "Bu kodu güvenlik, hata ve okunabilirlik açısından incele; sorunları madde madde yaz.\n\n{onceki}"},
        {"kind": "llm", "name": "Düzeltici", "prompt": "İstek: {girdi}\n\nKod ve inceleme notları aşağıda. Tüm sorunları düzeltilmiş SON KODU yaz.\n\n{tum}"}]},
    {"id": "cevir-duzelt", "name": "🌐 Çevir → ✨ Akıcılaştır", "steps": [
        {"kind": "llm", "name": "Çevirmen", "prompt": "Şu metni Türkçeye çevir (zaten Türkçeyse İngilizceye):\n{girdi}"},
        {"kind": "llm", "name": "Editör", "prompt": "Bu çeviriyi doğal, akıcı ve doğru hale getir; sadece son metni yaz.\n\n{onceki}"}]},
    {"id": "fikir-plan-gorev", "name": "💡 Fikir → 📋 Plan → 🎯 Görev Ajanı yapsın", "steps": [
        {"kind": "llm", "name": "Planlayıcı", "prompt": "Şu hedef için adım adım uygulanabilir bir Linux planı çıkar:\n{girdi}"},
        {"kind": "agent", "name": "Görev Ajanı", "prompt": "Şu planı uygula ve sonucu raporla:\n{onceki}"}]},
]

def workflows():
    user = jload(WF_FILE, [])
    ids = {w["id"] for w in user}
    return user + [w | {"template": True} for w in WF_TEMPLATES if w["id"] not in ids]

def workflow_flow(job, wf_id, text):
    wf = next((w for w in workflows() if w["id"] == wf_id), None)
    if not wf:
        raise KeyError(wf_id)
    job.title = f"🔗 {wf['name']}"; outs = []; prev = text
    job.ctx["outputs"] = outs
    for i, st in enumerate(wf["steps"], 1):
        if job.cancelled:
            job.status = "iptal"; return
        job.status = f"{i}/{len(wf['steps'])}: {st.get('name', '')}"
        prompt = st.get("prompt", "{onceki}").replace("{girdi}", text).replace("{onceki}", prev).replace("{tum}", "\n\n".join(f"### {o['name']}\n{o['text']}" for o in outs))
        job.log(f"\n━━ {i}. {st.get('name', '')} ({st.get('kind')}) ━━")
        if st.get("kind") == "web":
            res = web_search(text); src = []
            for r in res[:3]:
                try: src.append(f"KAYNAK: {r.get('url')}\n{fetch_url(r.get('url'), 4000)}")
                except Exception: pass
            job.log(f"🌐 {len(res)} sonuç, {len(src)} sayfa okundu")
            prompt += "\n\nWEB SONUÇLARI:\n" + json.dumps(res, ensure_ascii=False)[:3000] + "\n\n" + "\n\n".join(src)[:12000]
        if st.get("kind") == "agent":
            sub = start_job(f"🎯 {wf['name']} → ajan", "agent", agent_flow, prompt, {"unattended": True, "auto": bool(job.auto)})
            job.log(f"🎯 Görev Ajanı başlatıldı (görev {sub.id})")
            while sub.status not in ("tamamlandı", "hata", "iptal"):
                if job.cancelled:
                    sub.cancelled = True; break
                time.sleep(2)
            out = sub.ctx.get("report") or "\n".join(sub.lines[-30:])
        else:
            out, prov = llm_ask([{"role": "user", "content": prompt}], f"Sen bir iş akışında '{st.get('name')}' rolündesin. Türkçe yaz. {st.get('system', '')}", st.get("provider", ""), log=job.log, feature="chat")
            job.ctx["api"] = f"{prov.get('name')} · {prov.get('model')}"
        outs.append({"name": st.get("name", f"Adım {i}"), "text": out}); prev = out
        job.log(out[:3000])
    job.ctx["report"] = prev
    notify(APP, f"🔗 İş akışı bitti: {wf['name']}")

# ═════════════════════════════ 📄 BELGELERLE SOHBET ═════════════════════════════
DOC_INDEX = os.path.join(DATA, "belge_dizini.json")
DOC_UP = os.path.join(DATA, "belgeler"); os.makedirs(DOC_UP, exist_ok=True)
DOC_EXT = (".txt", ".md", ".pdf", ".docx", ".odt", ".html", ".htm", ".csv", ".json", ".py", ".js", ".ts", ".sh", ".yml", ".yaml", ".toml", ".ini", ".log", ".rst", ".tex", ".xml", ".c", ".cpp", ".go", ".rs", ".java")

def doc_text(path):
    ext = os.path.splitext(path)[1].lower()
    import zipfile, html as _h
    if ext == ".pdf":
        if which("pdftotext"):
            r = subprocess.run(["pdftotext", "-layout", path, "-"], capture_output=True, text=True, timeout=120, errors="replace")
            return r.stdout
        try:
            from pypdf import PdfReader
            return "\n".join((pg.extract_text() or "") for pg in PdfReader(path).pages)
        except Exception:
            raise RuntimeError("PDF okumak için 'poppler-utils' (pdftotext) gerekli — 🩺 Sistem sekmesinden kurabilirsin")
    if ext in (".docx", ".odt"):
        with zipfile.ZipFile(path) as z:
            x = z.read("word/document.xml" if ext == ".docx" else "content.xml").decode("utf-8", "replace")
        x = re.sub(r"</w:p>|</text:p>|</text:h>", "\n", x)
        return _h.unescape(re.sub(r"<[^>]+>", "", x))
    t = open(path, encoding="utf-8", errors="replace").read()
    if ext in (".html", ".htm"):
        t = re.sub(r"(?is)<(script|style).*?</\1>", "", t); t = _h.unescape(re.sub(r"<[^>]+>", " ", t))
    return t

def doc_tokens(s):
    return [w for w in re.findall(r"\w+", s.lower()) if len(w) > 1]

def docs_index():
    return jload(DOC_INDEX, {"docs": [], "chunks": []})

def docs_add(paths, log=None):
    idx = docs_index(); have = {d["path"] for d in idx["docs"]}; added = 0; errs = []
    files = []
    for p in paths:
        p = os.path.expanduser(p.strip())
        if os.path.isdir(p):
            for dp, ds, fs in os.walk(p):
                ds[:] = [x for x in ds if not x.startswith(".") and x not in SKIP_DIRS]
                files += [os.path.join(dp, f) for f in fs if f.lower().endswith(DOC_EXT)]
        elif os.path.isfile(p):
            files.append(p)
        else:
            errs.append(f"bulunamadı: {p}")
    for f in files[:2000]:
        f = os.path.realpath(f)
        if f in have or os.path.getsize(f) > 30_000_000:
            continue
        try:
            txt = doc_text(f)
        except Exception as e:
            errs.append(f"{os.path.basename(f)}: {str(e)[:100]}"); continue
        if not txt.strip():
            continue
        did = uuid.uuid4().hex[:8]
        idx["docs"].append({"id": did, "path": f, "name": os.path.basename(f), "chars": len(txt), "added": now()})
        paras = re.split(r"\n\s*\n", txt); cur = ""; n = 0
        for para in paras:
            if len(cur) + len(para) > 1400 and cur:
                idx["chunks"].append({"doc": did, "n": n, "text": cur.strip()}); n += 1; cur = ""
            cur += para + "\n\n"
            while len(cur) > 2200:
                idx["chunks"].append({"doc": did, "n": n, "text": cur[:1600].strip()}); n += 1; cur = cur[1400:]
        if cur.strip():
            idx["chunks"].append({"doc": did, "n": n, "text": cur.strip()})
        added += 1
        if log: log(f"📄 {os.path.basename(f)} ({n + 1} parça)")
    jsave(DOC_INDEX, idx)
    return {"added": added, "errors": errs[:20], "total": len(idx["docs"])}

def docs_search(qs, k=6, doc_ids=None):
    import math
    idx = docs_index(); ch = [c for c in idx["chunks"] if not doc_ids or c["doc"] in doc_ids]
    if not ch:
        return []
    qt = set(doc_tokens(qs)); N = len(ch); df = {}
    toks = [doc_tokens(c["text"]) for c in ch]
    for t in toks:
        for w in set(t) & qt:
            df[w] = df.get(w, 0) + 1
    avg = sum(len(t) for t in toks) / N or 1; sc = []
    for i, t in enumerate(toks):
        tf = {}
        for w in t:
            if w in qt: tf[w] = tf.get(w, 0) + 1
        s = sum(math.log(1 + (N - df[w] + .5) / (df[w] + .5)) * (f * 2.2) / (f + 1.2 * (.25 + .75 * len(t) / avg)) for w, f in tf.items())
        if s > 0:
            sc.append((s, i))
    names = {d["id"]: d["name"] for d in idx["docs"]}
    return [{**ch[i], "name": names.get(ch[i]["doc"], "?"), "score": round(s, 2)} for s, i in sorted(sc, reverse=True)[:k]]

def docs_ask(question, hist=None, doc_ids=None):
    hits = docs_search(question + " " + " ".join(h.get("text", "") for h in (hist or [])[-2:] if h.get("role") == "user"), 7, doc_ids)
    if not hits:
        return {"answer": "Belgelerinde bu soruyla ilgili bir şey bulamadım. Farklı kelimelerle sor ya da belge ekle.", "sources": []}
    ctx = "\n\n".join(f"[{i + 1}] ({h['name']}, parça {h['n'] + 1})\n{h['text']}" for i, h in enumerate(hits))
    msgs = [{"role": "user" if h["role"] == "user" else "assistant", "content": h["text"]} for h in (hist or [])[-6:]]
    msgs.append({"role": "user", "content": f"BELGE PARÇALARI:\n{ctx}\n\nSORU: {question}"})
    ans, prov = llm_ask(msgs, "Kullanıcının belgelerinden cevap veriyorsun. SADECE verilen belge parçalarına dayan; bilgiyi kullandığın parçayı [1], [2] gibi belirt. "
                        "Belgelerde yoksa açıkça 'belgelerde bulamadım' de. Türkçe, net yaz.", log=None, feature="chat")
    return {"answer": ans, "sources": [{"i": i + 1, "name": h["name"], "n": h["n"] + 1, "text": h["text"][:500]} for i, h in enumerate(hits)], "api": f"{prov.get('name')} · {prov.get('model')}"}

# ═════════════════════════════ 🎤 SES ═════════════════════════════
WHISPER_ENV = os.path.join(RT, "whisper")

def multipart(fields, files):
    bnd = "----ct" + uuid.uuid4().hex; out = b""
    for k, v in fields.items():
        out += f"--{bnd}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode()
    for k, (fn, data, ct) in files.items():
        out += f"--{bnd}\r\nContent-Disposition: form-data; name=\"{k}\"; filename=\"{fn}\"\r\nContent-Type: {ct}\r\n\r\n".encode() + data + b"\r\n"
    return out + f"--{bnd}--\r\n".encode(), "multipart/form-data; boundary=" + bnd

def transcribe(audio, mime="audio/webm"):
    ext = "webm" if "webm" in mime else ("ogg" if "ogg" in mime else ("mp4" if "mp4" in mime else "wav"))
    for p in [x for x in cfg().get("providers", []) if x.get("enabled", True) and x.get("api_key")]:
        u = p.get("base_url", "")
        model = "whisper-large-v3-turbo" if "groq" in u else ("whisper-1" if "api.openai.com" in u else "")
        if not model:
            continue
        try:
            body, ct = multipart({"model": model, "language": "tr", "response_format": "json"}, {"file": (f"ses.{ext}", audio, mime)})
            req = urllib.request.Request(u.rstrip("/") + "/audio/transcriptions", data=body, headers={**UA, "Content-Type": ct, "Authorization": "Bearer " + p["api_key"]})
            with urllib.request.urlopen(req, timeout=90) as r:
                return {"text": json.loads(r.read()).get("text", "").strip(), "engine": p["name"] + " · " + model}
        except Exception:
            continue
    py = os.path.join(WHISPER_ENV, "bin", "python")
    if os.path.exists(py):
        fd, f = tempfile.mkstemp(suffix="." + ext); os.write(fd, audio); os.close(fd)
        try:
            r = subprocess.run([py, "-c", "import sys;from faster_whisper import WhisperModel as W;m=W('small',compute_type='int8');s,_=m.transcribe(sys.argv[1],language='tr');print(' '.join(x.text for x in s).strip())", f],
                               capture_output=True, text=True, timeout=600)
            if r.returncode == 0:
                return {"text": r.stdout.strip(), "engine": "yerel Whisper (small)"}
            raise RuntimeError(r.stderr[-300:])
        finally:
            os.remove(f)
    raise RuntimeError("Ses tanıma için bir motor yok: 🔑 API'ler'e ücretsiz bir Groq anahtarı ekle ya da Ayarlar → 🎤 'Yerel Whisper kur'a bas.")

def whisper_install_flow(job):
    job.title = "🎤 Yerel ses tanıma (Whisper) kuruluyor"
    py = which("python3") or "python3"
    for c in ([f"{q(which('uv'))} venv {q(WHISPER_ENV)}"] if which("uv") else [f"{q(py)} -m venv {q(WHISPER_ENV)}"]) + \
             [f"{q(os.path.join(WHISPER_ENV, 'bin', 'python'))} -m pip install -U pip faster-whisper" if not which("uv") else
              f"VIRTUAL_ENV={q(WHISPER_ENV)} {q(which('uv'))} pip install --python {q(os.path.join(WHISPER_ENV, 'bin', 'python'))} faster-whisper"]:
        rc, out = run_capture(job, c, DATA, 1800)
        if rc != 0:
            job.log("✖ Kurulamadı. python3-venv paketi eksik olabilir (🩺 Sistem)."); job.status = "hata"; return
    job.log("✅ Yerel Whisper hazır. İlk kullanımda model (~460 MB) indirilecek.")

# ═════════════════════════════ 💡 AKILLI ÖNERİLER ═════════════════════════════
SUGG_FILE = os.path.join(CONF_DIR, "oneriler.json")

def suggestions(force=False):
    c = jload(SUGG_FILE, {})
    if not force and c.get("items") and time.time() - c.get("at", 0) < 6 * 3600:
        return c
    if not llm_available():
        return {"items": [], "error": "Öneriler için bir yapay zekâ API'si bağla."}
    tl = [{"ad": t["name"], "ne_yapar": (t.get("summary") or "")[:150], "yetenekler": (t.get("capabilities") or {}).get("yapabilecekleri", [])[:5]} for t in tools().values()][:30]
    recent = [j.title for j in sorted(JOBS.values(), key=lambda j: -j.created)[:10]]
    txt, _ = llm_ask([{"role": "user", "content": f"KURULU ARAÇLAR: {json.dumps(tl, ensure_ascii=False)}\nHAFIZA: {mem_context('öneri', 15)}\nSON İŞLER: {recent}\n"
                       f"SİSTEM: {os_info().get('PRETTY_NAME')} RAM {mem_gb()} GB\n\nBu kullanıcıya Cypher Tool'la yapabileceği 6 YARARLI, SOMUT iş öner (kurulu araçları ve programları kullanarak). "
                       "SADECE JSON: {\"items\": [{\"title\": \"kısa başlık (emoji ile)\", \"why\": \"neden yararlı, 1 cümle\", \"task\": \"Görev Ajanı'na verilecek tam Türkçe görev\"}]}"}],
                     "Kısa, pratik ve kişisel öneriler ver.", log=None, feature="chat")
    try:
        items = extract_json(txt).get("items", [])[:8]
    except Exception:
        items = []
    out = {"items": items, "at": time.time()}; jsave(SUGG_FILE, out)
    return out

# ═════════════════════════════ 🩺 SİSTEM ASİSTANI ═════════════════════════════
def sh(cmd, timeout=8):
    try:
        return subprocess.run(["bash", "-c", cmd], capture_output=True, text=True, timeout=timeout, errors="replace").stdout.strip()
    except Exception:
        return ""

def system_snapshot():
    mi = {l.split(":")[0]: int(l.split()[1]) for l in open("/proc/meminfo") if len(l.split()) > 1 and l.split()[1].isdigit()}
    tot = mi.get("MemTotal", 1); avail = mi.get("MemAvailable", 0)
    la = os.getloadavg(); n = os.cpu_count() or 1
    disks = []
    for line in sh("df -hP -x tmpfs -x devtmpfs -x squashfs -x overlay 2>/dev/null | tail -n +2").splitlines():
        f = line.split()
        if len(f) >= 6:
            disks.append({"fs": f[0], "size": f[1], "used": f[2], "free": f[3], "pct": int(f[4].rstrip("%") or 0), "mount": f[5]})
    snap = {"cpu_count": n, "load": [round(x, 2) for x in la], "load_pct": int(la[0] / n * 100),
            "ram_total_gb": round(tot / 1048576, 1), "ram_used_pct": int((tot - avail) / tot * 100),
            "swap_used_mb": int((mi.get("SwapTotal", 0) - mi.get("SwapFree", 0)) / 1024), "disks": disks,
            "uptime": sh("uptime -p"), "top_cpu": sh("ps -eo pid,comm,%cpu,%mem --sort=-%cpu | head -8"),
            "top_mem": sh("ps -eo pid,comm,%mem,rss --sort=-%mem | head -6"),
            "failed_services": sh("systemctl --failed --no-legend --plain 2>/dev/null | head -10"),
            "net": "çalışıyor" if sh("ping -c1 -W2 1.1.1.1 >/dev/null 2>&1 && echo ok", 5) == "ok" else "ping başarısız",
            "dns": "çalışıyor" if sh("getent hosts github.com >/dev/null && echo ok", 6) == "ok" else "DNS çözülemiyor",
            "temp": sh("cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null | head -1"),
            "journal_size": sh("journalctl --disk-usage 2>/dev/null | grep -oE '[0-9.]+[KMGT]'"),
            "cache_size": sh("du -sh ~/.cache 2>/dev/null | cut -f1")}
    try:
        snap["temp"] = f"{int(snap['temp']) / 1000:.0f}°C" if snap["temp"] else ""
    except Exception:
        snap["temp"] = ""
    warn = []
    if snap["ram_used_pct"] > 85: warn.append(f"RAM %{snap['ram_used_pct']} dolu")
    if snap["load_pct"] > 90: warn.append(f"İşlemci yükü yüksek (%{snap['load_pct']})")
    for d in disks:
        if d["pct"] >= 90: warn.append(f"Disk {d['mount']} %{d['pct']} dolu")
    if snap["failed_services"]: warn.append("Çöken sistem servisleri var")
    if snap["net"] != "çalışıyor" or snap["dns"] != "çalışıyor": warn.append("İnternet/DNS sorunu")
    snap["warnings"] = warn
    return snap

SYS_TASKS = {
    "yavas": "Bilgisayarım yavaş. Aşağıdaki sistem durumuna ve gerekirse ek komutlara (top, free, iotop yoksa ps) bakarak NEDEN yavaş olduğunu bul, Türkçe açıkla ve güvenli çözümler öner; benim onayımla uygula.",
    "disk": "Diskimde ne yer kaplıyor? En büyük klasörleri/dosyaları bul (du, ncdu yoksa du -h --max-depth), tablo halinde göster, güvenle silinebilecekleri ayır. HİÇBİR ŞEYİ sormadan silme.",
    "temizle": "Güvenli sistem temizliği yap: paket önbelleği (apt clean/autoremove vb.), eski journal kayıtları (journalctl --vacuum-time=7d), ~/.cache içindeki gereksizler, çöp kutusu. Önce ne kadar yer açılacağını göster, onayımla uygula.",
    "guvenlik": "Bilgisayarımın güvenlik kontrolünü yap: açık portlar (ss -tulpn), güvenlik duvarı durumu, bekleyen güvenlik güncellemeleri, şüpheli başlangıç öğeleri ve cron işleri, SSH ayarları. Riskleri Türkçe açıkla ve düzeltme öner.",
    "internet": "İnternet bağlantımı kontrol et: ağ arayüzleri, ping, DNS, varsayılan ağ geçidi, hız için basit test. Sorun varsa nedenini bul ve çözmeye çalış.",
    "guncelle": "Sistemimi güncelle: paket yöneticisiyle güncellemeleri listele, ne güncelleneceğini Türkçe özetle, onayımla güncelle. Cypher Tool araçlarının güncellemelerini de kontrol et.",
    "surucu": "Donanımımı ve sürücülerimi kontrol et (lspci, lsusb, ekran kartı sürücüsü, ses). Eksik/uygunsuz sürücü varsa öner.",
}

# ═════════════════════════════ 📱 TELEFONDAN ERİŞİM ═════════════════════════════
PHONE_SRV = [None]; PHONE_SESS = {}; PHONE_FAIL = {}

def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("10.255.255.255", 1)); ip = s.getsockname()[0]; s.close(); return ip
    except Exception:
        return "127.0.0.1"

def phone_cfg():
    return cfg().get("phone") or {}

def phone_set_password(pw):
    salt = secrets.token_hex(8)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000).hex()
    c = cfg(); c["phone"] = {**(c.get("phone") or {}), "salt": salt, "hash": h}; save_cfg(c)

def phone_check(pw):
    p = phone_cfg()
    if not p.get("hash"):
        return False
    return secrets.compare_digest(hashlib.pbkdf2_hmac("sha256", pw.encode(), p["salt"].encode(), 200_000).hex(), p["hash"])

PHONE_LOGIN = """<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cypher Tool</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#07040d;color:#ece6f7;font-family:system-ui}form{background:#120a20;border:1px solid #3b2463;padding:28px;border-radius:18px;width:min(340px,90vw)}
h1{margin:0 0 6px;color:#c084fc;font-size:22px}input,button{width:100%;box-sizing:border-box;padding:12px;border-radius:10px;font-size:16px;margin-top:12px}input{background:#07040d;color:#fff;border:1px solid #3b2463}button{background:#7c3aed;color:#fff;border:0}p{color:#f87171}</style></head>
<body><form method="post" action="/giris"><h1>🔐 Cypher Tool</h1><div style="opacity:.7">Telefondan erişim — şifreni gir</div>%ERR%<input type="password" name="pw" autofocus placeholder="Şifre"><button>Giriş</button></form></body></html>"""

def start_phone():
    pc = phone_cfg()
    if not pc.get("enabled") or not pc.get("hash") or PHONE_SRV[0]:
        return
    class PhoneHandler(Handler):
        def _host_ok(self):
            return True
        def _sess(self):
            m = re.search(r"ctp=([0-9a-f]{40})", self.headers.get("Cookie") or "")
            return bool(m and PHONE_SESS.get(m.group(1), 0) > time.time())
        def _auth(self):
            return self._sess()
        def do_GET(self):
            if not self._sess() and urllib.parse.urlparse(self.path).path in ("/", "/index.html"):
                return self._send(200, PHONE_LOGIN.replace("%ERR%", ""), "text/html; charset=utf-8")
            return Handler.do_GET(self)
        def do_POST(self):
            if urllib.parse.urlparse(self.path).path == "/giris":
                ip = self.client_address[0]; fl = [t for t in PHONE_FAIL.get(ip, []) if time.time() - t < 600]
                if len(fl) >= 5:
                    return self._send(429, PHONE_LOGIN.replace("%ERR%", "<p>Çok fazla hatalı deneme. 10 dakika bekle.</p>"), "text/html; charset=utf-8")
                n = int(self.headers.get("Content-Length") or 0)
                pw = (urllib.parse.parse_qs(self.rfile.read(min(n, 4096)).decode()).get("pw") or [""])[0]
                if phone_check(pw):
                    sid = secrets.token_hex(20); PHONE_SESS[sid] = time.time() + 12 * 3600
                    self.send_response(303); self.send_header("Location", "/#telefon")
                    self.send_header("Set-Cookie", f"ctp={sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200"); self.end_headers(); return
                PHONE_FAIL[ip] = fl + [time.time()]
                return self._send(401, PHONE_LOGIN.replace("%ERR%", "<p>Şifre yanlış.</p>"), "text/html; charset=utf-8")
            if urllib.parse.urlparse(self.path).path == "/api/shutdown":
                return self._send(403, {"error": "telefondan kapatılamaz"})
            return Handler.do_POST(self)
    try:
        srv = ThreadingHTTPServer(("0.0.0.0", int(pc.get("port", 8766))), PhoneHandler)
    except OSError:
        return
    PHONE_SRV[0] = srv
    threading.Thread(target=srv.serve_forever, daemon=True).start()

def stop_phone():
    if PHONE_SRV[0]:
        try: PHONE_SRV[0].shutdown(); PHONE_SRV[0].server_close()
        except Exception: pass
        PHONE_SRV[0] = None
    PHONE_SESS.clear()


# ═════════════════════════════ ⚙️ sistem ayarlarını açma ═════════════════════════════
SETTINGS_PANELS = {
    "ag": ("network", "nm-connection-editor", "xfce4-network-settings"), "network": ("network", "nm-connection-editor", None),
    "wifi": ("wifi", "nm-connection-editor", None), "ekran": ("display", "xfce4-display-settings", "arandr"), "display": ("display", "xfce4-display-settings", "arandr"),
    "ses": ("sound", "pavucontrol", "xfce4-mixer"), "sound": ("sound", "pavucontrol", None), "bluetooth": ("bluetooth", "blueman-manager", None),
    "guc": ("power", "xfce4-power-manager-settings", None), "power": ("power", "xfce4-power-manager-settings", None),
    "kullanicilar": ("users", "users-admin", None), "users": ("users", "users-admin", None), "klavye": ("keyboard", "xfce4-keyboard-settings", None),
    "fare": ("mouse", "xfce4-mouse-settings", None), "gorunum": ("background", "xfce4-appearance-settings", None), "yazici": ("printers", "system-config-printer", None),
    "tarih": ("datetime", "time-admin", None), "dil": ("region", "xfce4-settings-manager", None), "uygulamalar": ("applications", "xfce4-mime-settings", None),
    "guncelleme": (None, "software-properties-gtk", "update-manager"), "disk": (None, "gnome-disks", "gparted"), "gorev": (None, "xfce4-taskmanager", "gnome-system-monitor"),
    "guvenlik_duvari": (None, "gufw", None), "genel": (None, "xfce4-settings-manager", "gnome-control-center"),
}

def open_settings(panel="genel"):
    key = slugify(panel or "genel").replace("-", "_")
    gpanel, a, b = SETTINGS_PANELS.get(key, (None, "xfce4-settings-manager", None))
    cands = []
    if which("gnome-control-center") and gpanel:
        cands.append(["gnome-control-center", gpanel])
    cands += [[x] for x in (a, b) if x]
    cands += [["xfce4-settings-manager"], ["gnome-control-center"], ["systemsettings"], ["cinnamon-settings"], ["mate-control-center"]]
    for c in cands:
        if which(c[0]):
            subprocess.Popen(c, env=base_env(), start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return "Açıldı: " + " ".join(c)
    return "Bu masaüstünde uygun ayar programı bulunamadı. Mevcut paneller: " + ", ".join(SETTINGS_PANELS)

# ═════════════════════════════ 👁 AÇILAN UYGULAMAYI TANIMA ═════════════════════════════
WATCH = {"events": [], "seen": set(), "cool": {}, "map": {}, "map_at": 0, "last_fg": ""}
WATCH_IGNORE = {"bash", "sh", "zsh", "dash", "sudo", "cyphertool", "python3", "python", "sleep", "cat", "ls", "cd", "grep", "less", "more", "man", "clear",
                "head", "tail", "echo", "printf", "env", "xdg-open", "gtk-launch", "dbus-daemon", "dbus-launch", "at-spi-bus-launcher", "gvfsd", "pkexec",
                "chrome", "google-chrome", "chromium", "chrome_crashpad", "xfce4-terminal", "gnome-terminal", "konsole", "xterm", "tilix", "kitty", "alacritty", "nano", "vim", "vi", "ps", "top"}

def watch_on():
    return cfg().get("app_watch", False)

def watch_map():
    if time.time() - WATCH["map_at"] > 300:
        m = {}
        for a in desktop_apps():
            tok = [x for x in shlex.split(a["exec"]) if "=" not in x] if a["exec"] else []
            if tok and tok[0] in ("env", "flatpak", "snap"):
                tok = tok[-1:]
            if tok:
                b = os.path.basename(tok[0])
                if b and b not in WATCH_IGNORE:
                    m.setdefault(b, a)
        WATCH["map"] = m; WATCH["map_at"] = time.time()
    return WATCH["map"]

def watch_event(kind, item, name, source):
    key = f"{kind}:{item}"
    if time.time() - WATCH["cool"].get(key, 0) < 1800:
        return
    WATCH["cool"][key] = time.time()
    ev = {"kind": kind, "id": item, "name": name, "source": source, "at": now(), "ts": time.time(), "job": ""}
    busy = any(j.kind == "agent" and j.status not in ("tamamlandı", "hata", "iptal") and (j.ctx.get("console") or j.ctx.get("watch")) for j in JOBS.values())
    if llm_available() and not busy:
        con = console_get()
        task = console_agent_task(kind, item) + (
            f"\n\nÖNEMLİ: Kullanıcı '{name}' uygulamasını AZ ÖNCE KENDİSİ AÇTI ({source}); sen bunu fark ettin. Uygulamayı yeniden BAŞLATMA. "
            "Kısaca 'Görüyorum ki {ad} açtın 👋' diye başla; ne işe yaradığını, bununla birlikte neler yapabileceğinizi somut maddelerle anlat, 3-5 öneri sun ve ne istediğini sor. "
            "Kullanıcı bir iş isterse mümkünse komut satırından (o programın CLI karşılığı ile) konsolda yap; grafik arayüzde yapılması gerekiyorsa adım adım nereye tıklayacağını söyle.".replace("{ad}", name))
        j = start_job("Konsol AI", "agent", agent_flow, task, {"console": con.id, "workdir": os.path.expanduser("~"), "title": f"👁 {name} açıldı"})
        j.ctx["watch"] = key; ev["job"] = j.id
    WATCH["events"] = (WATCH["events"] + [ev])[-20:]
    notify(APP, f"👁 {name} açıldı — yapay zekâ ne yapabileceğinizi anlatıyor")

def app_watch_loop():
    first = True
    while True:
        time.sleep(3)
        if not watch_on():
            continue
        try:
            uid = os.getuid(); cur = set(); new = []
            for pid in os.listdir("/proc"):
                if not pid.isdigit():
                    continue
                try:
                    if os.stat(f"/proc/{pid}").st_uid != uid:
                        continue
                    comm = open(f"/proc/{pid}/comm").read().strip()
                    args = open(f"/proc/{pid}/cmdline", "rb").read().replace(b"\0", b" ").decode("utf-8", "replace").strip()
                except Exception:
                    continue
                cur.add(pid)
                if pid not in WATCH["seen"] and not first:
                    new.append((pid, comm, args))
            WATCH["seen"] = cur; first = False
            mp = watch_map(); tl = tools()
            for pid, comm, args in new:
                if LAUNCH_DIR in args:
                    m = re.search(re.escape(LAUNCH_DIR) + r"/([\w.-]+?)__\d+\.sh", args)
                    if m and m.group(1) in tl and tl[m.group(1)].get("active", True) is not False:
                        # Cypher Tool'un kendi yapay zekâsı başlattıysa değil, kullanıcı başlattıysa
                        if not any(j.kind == "agent" and j.status not in ("tamamlandı", "hata", "iptal") for j in JOBS.values()):
                            watch_event("tool", m.group(1), tl[m.group(1)]["name"], "Cypher Tool aracı")
                        continue
                b = os.path.basename(args.split(" ")[0]) if args else comm
                a = mp.get(b) or mp.get(comm)
                if a and comm not in WATCH_IGNORE:
                    watch_event("app", a["id"], a["name"], "masaüstü uygulaması")
            # konsolda kullanıcının kendi başlattığı program (ön plandaki süreç)
            con = console_get(create=False)
            if con:
                try:
                    pg = os.tcgetpgrp(con.m)
                    comm = open(f"/proc/{pg}/comm").read().strip()
                except Exception:
                    comm = ""
                ai_busy = any(j.ctx.get("console") == con.id and j.status not in ("tamamlandı", "hata", "iptal") and not (j.pending and j.pending.get("kind") == "question") for j in JOBS.values())
                if comm and comm != WATCH["last_fg"]:
                    WATCH["last_fg"] = comm
                    if comm not in WATCH_IGNORE and not ai_busy and pg != con.p.pid:
                        time.sleep(2)  # kısa komutları atla
                        try:
                            still = os.tcgetpgrp(con.m) == pg
                        except Exception:
                            still = False
                        if still:
                            watch_event("cli", comm, comm, "konsolda")
        except Exception:
            pass


# ═════════════════════════════ 🌐 TARAYICI (görünür açma + gerçek tarayıcıyla okuma) ═════════════════════════════
BROWSERS = ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "brave-browser", "microsoft-edge", "firefox", "firefox-esr"]

def find_browser(prefer=""):
    for b in ([prefer] if prefer else []) + BROWSERS:
        if b and which(b):
            return b
    return ""

def open_browser(url="", query="", browser=""):
    if brw_embed() and not re.search(r"firefox|dış|dis|harici|external|system", browser or "", re.I) and next((x for x in BROWSERS if "firefox" not in x and which(x)), ""):
        try:
            u = url or ""
            if u and not re.match(r"^https?://", u): u = _brw_url(u, "")
            nm = ("🔎 " + query[:30]) if query and not url else ("🌐 " + (urllib.parse.urlparse(u).hostname or "Google").replace("www.", "")[:30])
            sid = brw_open(u, query, nm)
            BRW["focus"] = sid
            return f"Uygulama içi tarayıcıda açıldı (Konsol → 🌐 {sid} sekmesi): {BRW['sessions'][sid].get('url') or u or query}"
        except Exception as e:
            pass  # olmadıysa normal tarayıcıya düş
    if query and not url:
        url = "https://www.google.com/search?" + urllib.parse.urlencode({"q": query, "hl": "tr"})
    if not re.match(r"^https?://", url or ""):
        raise RuntimeError("Geçerli bir adres ya da arama metni ver")
    b = find_browser(browser)
    cmd = [b, "--new-window", url] if b and "firefox" not in b else ([b, "--new-tab", url] if b else ["xdg-open", url])
    if b and is_root() and "firefox" not in b:
        cmd[1:1] = ["--no-sandbox", "--test-type"]
    subprocess.Popen(cmd, env=base_env(), start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return f"Tarayıcıda açıldı ({b or 'varsayılan tarayıcı'}): {url}"

def browse(url="", query="", limit=9000):
    """Sayfayı gerçek (görünmez) Chrome ile açıp JavaScript çalıştıktan sonraki metnini okur; arama ise sonuç linklerini döndürür."""
    if query and not url:
        url = search_url(query)
    b = next((x for x in BROWSERS if "firefox" not in x and which(x)), "")
    html = ""
    if b:
        prof = tempfile.mkdtemp(prefix="ct-hl-")
        try:
            r = subprocess.run([b, "--headless=new", "--disable-gpu", "--no-sandbox", "--no-first-run", f"--user-data-dir={prof}", "--lang=tr",
                                "--virtual-time-budget=8000", "--user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36",
                                "--dump-dom", url], capture_output=True, text=True, timeout=45, errors="replace")
            html = r.stdout
        except Exception:
            html = ""
        finally:
            shutil.rmtree(prof, ignore_errors=True)
    if re.search(r"Ã.|Ä.|Å.|Ă.", html[:20000]):
        for enc in ("iso-8859-2", "cp1250", "cp1252", "iso-8859-9", "latin-1"):
            try:
                html = html.encode(enc).decode("utf-8"); break
            except Exception:
                continue
    if not html:
        if query:
            return json.dumps(web_search(query), ensure_ascii=False)
        return fetch_url(url, limit, _nobrowse=True)
    if query or "google.com/search" in url:
        links = []
        for m in re.finditer(r'<a[^>]+href="(https?://(?!www\.google|accounts\.google|support\.google|policies\.google|maps\.google)[^"]+)"[^>]*>(.*?)</a>', html, re.S):
            t = html_to_text(m.group(2)).strip()
            if t and len(t) > 3 and m.group(1) not in [l["url"] for l in links]:
                links.append({"title": t[:150], "url": urllib.parse.unquote(m.group(1).replace("&amp;", "&"))})
            if len(links) >= 10:
                break
        if links:
            return json.dumps(links, ensure_ascii=False)
        if "unusual traffic" in html or "/sorry/" in html:
            return "Google otomatik aramayı engelledi; sonuçlar başka motordan:\n" + json.dumps(web_search(query or url), ensure_ascii=False)
    title = re.search(r"(?is)<title[^>]*>(.*?)</title>", html)
    return ((html_to_text(title.group(1)) + "\n\n") if title else "") + html_to_text(html)[:limit]

def uninstall_tool(slug):
    t = tools()[slug]
    remove_shortcuts(slug)
    if os.path.realpath(t["path"]).startswith(os.path.realpath(TOOLS_DIR) + os.sep):
        shutil.rmtree(t["path"], ignore_errors=True)
    for f in os.listdir(ICON_DIR):
        if f.startswith(slug + "."):
            os.remove(os.path.join(ICON_DIR, f))
    with _lock:
        tt = tools(); tt.pop(slug, None); save_tools(tt)


class Handler(BaseHTTPRequestHandler):
    server_version = "CypherTool"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8", extra=None):
        data = body if isinstance(body, bytes) else (json.dumps(body, ensure_ascii=False).encode() if not isinstance(body, str) else body.encode())
        self.send_response(code)
        self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store"); self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers(); self.wfile.write(data)

    def _host_ok(self):
        h = (self.headers.get("Host") or "").split(":")[0]
        return h in ("127.0.0.1", "localhost")

    def _auth(self):
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        tok = self.headers.get("X-Token") or (qs.get("t") or [""])[0]
        return secrets.compare_digest(tok, TOKEN)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}") if n else {}

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, {"error": "host"})
        LAST_SEEN[0] = time.time()
        u = urllib.parse.urlparse(self.path); p = u.path
        if p in ("/", "/index.html"):
            return self._send(200, open(os.path.join(WEB_DIR, "index.html"), "rb").read(), "text/html; charset=utf-8",
                              {"Cache-Control": "no-store, max-age=0", "X-CypherTool-Version": VERSION})
        if p.startswith("/vendor/"):
            f = os.path.join(WEB_DIR, "vendor", os.path.basename(p))
            if os.path.isfile(f):
                ct = "text/css" if f.endswith(".css") else "application/javascript"
                return self._send(200, open(f, "rb").read(), ct + "; charset=utf-8")
        if p in ("/logo.svg",):
            return self._send(200, open(os.path.join(WEB_DIR, "logo.svg"), "rb").read(), "image/svg+xml")
        if p.startswith("/icons/"):
            f = os.path.join(ICON_DIR, os.path.basename(p))
            if os.path.isfile(f):
                ct = "image/svg+xml" if f.endswith(".svg") else "image/png"
                return self._send(200, open(f, "rb").read(), ct, {"Content-Security-Policy": "script-src 'none'"})
            return self._send(404, {"error": "yok"})
        if p == "/oauth/google":   # Google Ads OAuth geri dönüşü (state ile doğrulanır; belirteç olmadan gelir)
            qs_ = urllib.parse.parse_qs(u.query); st = (qs_.get("state") or [""])[0]; code = (qs_.get("code") or [""])[0]
            aid = OAUTH_STATE.pop(st, None)
            if not aid or not code:
                return self._send(400, "<h3>Geçersiz ya da süresi dolmuş istek.</h3>", "text/html; charset=utf-8")
            try:
                L = accs(); e = next(x for x in L if x["id"] == aid)
                r = _http("POST", "https://oauth2.googleapis.com/token", form={"grant_type": "authorization_code", "code": code, "client_id": e["client_id"], "client_secret": e["client_secret"],
                                                                             "redirect_uri": f"http://127.0.0.1:{SERVER_PORT[0]}/oauth/google"})
                if not r.get("refresh_token"):
                    raise RuntimeError("Google yenileme belirteci vermedi (izin ekranında 'İzin ver'e bastığından emin ol).")
                e["refresh_token"] = r["refresh_token"]; accs_save(L)
                try: msg = acc_test(e)
                except Exception as ex: msg = f"Belirteç alındı ama test başarısız: {str(ex)[:300]}"
                return self._send(200, f"<html><body style='font:16px sans-serif;padding:40px;background:#120d1f;color:#eee'><h2>✅ Google Ads bağlandı</h2><p>{msg}</p><p>Bu sekmeyi kapatabilirsin.</p></body></html>", "text/html; charset=utf-8")
            except Exception as ex:
                return self._send(500, f"<h3>✖ {str(ex)[:400]}</h3>", "text/html; charset=utf-8")
        if not self._auth():
            return self._send(401, {"error": "yetkisiz"})
        try:
            if p == "/api/state":
                return self._send(200, public_state())
            if p == "/api/pool":
                P = pool()
                out = []
                for x in P["items"]:
                    sm, infos = pool_summary(x)
                    out.append({k: v for k, v in x.items() if k not in ("key", "model_list", "model_meta")} | {"has_key": bool(x.get("key")), "summary": sm, "models_info": infos})
                return self._send(200, {"items": out, "last_test": P.get("last_test", 0)})
            if p == "/api/kb":
                items = []
                for e in kb_errors():
                    items.append({"id": e["id"], "cat": e.get("cat", ""), "title": kb_text(e["title"], "…"),
                                  "cause": e.get("cause", ""), "learned": bool(e.get("learned")), "auto": e.get("auto", True),
                                  "fix": [x for x in (kb_render(f, "örnek", None) for f in e.get("fix", [])) if x]})
                return self._send(200, {"items": items, "pm": detect_pm()})
            if p == "/api/logs/read":
                f = os.path.join(LOG_DIR, os.path.basename((urllib.parse.parse_qs(u.query).get("file") or [""])[0]))
                if not os.path.isfile(f):
                    return self._send(404, {"error": "kayıt yok"})
                if (urllib.parse.parse_qs(u.query).get("dl") or [""])[0]:
                    return self._send(200, open(f, "rb").read(), "text/plain; charset=utf-8", {"Content-Disposition": f'attachment; filename="{os.path.basename(f)}"'})
                return self._send(200, {"text": open(f, encoding="utf-8", errors="replace").read()[-200000:]})
            if p == "/api/report":
                slug = (urllib.parse.parse_qs(u.query).get("slug") or [""])[0]
                return self._send(200, {"text": error_report(slug)})
            if p == "/api/memory":
                return self._send(200, {"memory": mem_all(), "recipes": [{k: v for k, v in r.items() if k not in ("guide_tr",)} for r in jload(USER_CATALOG, [])]})
            if p == "/api/system":
                return self._send(200, {"items": system_checks(), "ollama_models": OLLAMA_MODELS, "keyless": KEYLESS_CANDIDATES})
            m = re.match(r"^/api/jobs/(\w+)$", p)
            if m:
                j = JOBS.get(m.group(1))
                if not j:
                    return self._send(404, {"error": "görev yok"})
                since = int((urllib.parse.parse_qs(u.query).get("since") or ["0"])[0])
                return self._send(200, {**j.summary(), "lines": j.lines[since:], "next": len(j.lines), "ctx": {k: v for k, v in j.ctx.items() if k in ("found", "github", "chat", "steps", "report", "task", "installed", "candidates", "outputs", "changed", "project", "console")}})
            m = re.match(r"^/api/procs/(\w+)$", p)
            if m:
                pr = PROCS.get(m.group(1))
                if not pr:
                    return self._send(404, {"error": "süreç yok"})
                since = int((urllib.parse.parse_qs(u.query).get("since") or ["0"])[0])
                return self._send(200, {**pr.summary(), "text": "".join(pr.chunks[since:]), "next": len(pr.chunks)})
            m = re.match(r"^/api/tools/([\w.-]+)/guide$", p)
            if m:
                t = tools().get(m.group(1))
                if not t:
                    return self._send(404, {"error": "araç yok"})
                rec = next((c for c in catalog() if c.get("id") == t.get("catalog_id")), None)
                g = t.get("guide_tr") or (rec or {}).get("guide_tr", "")
                return self._send(200, {"guide": g, "readme": read_readme(t["path"], 60000), "can_ai": llm_available()})
            if p == "/api/browser/frame":
                qs_ = urllib.parse.parse_qs(u.query)
                try:
                    return self._send(200, brw_frame((qs_.get("id") or [""])[0], int((qs_.get("q") or ["55"])[0])), "image/jpeg", {"Cache-Control": "no-store"})
                except Exception as e:
                    return self._send(404, {"error": str(e)[:200]})
            if p == "/api/browser/shot":
                f = os.path.join(BRW_SHOTS, os.path.basename((urllib.parse.parse_qs(u.query).get("file") or [""])[0]))
                if os.path.isfile(f):
                    return self._send(200, open(f, "rb").read(), "image/jpeg", {"Cache-Control": "max-age=3600"})
                return self._send(404, {"error": "görüntü yok"})
            if p == "/api/appicon":
                f = resolve_icon((urllib.parse.parse_qs(u.query).get("name") or [""])[0])
                if f and (f.startswith(("/usr/share/", "/var/lib/flatpak/", "/var/lib/snapd/", "/snap/")) or f.startswith(os.path.expanduser("~/.local/share/"))):
                    ct = "image/svg+xml" if f.endswith(".svg") else ("image/png" if f.endswith(".png") else "image/x-xpixmap")
                    return self._send(200, open(f, "rb").read(), ct, {"Content-Security-Policy": "script-src 'none'", "Cache-Control": "max-age=86400"})
                return self._send(404, {"error": "ikon yok"})
            if p == "/api/export/download":
                f = os.path.join(EXPORT_DIR, os.path.basename((urllib.parse.parse_qs(u.query).get("file") or [""])[0]))
                if os.path.isfile(f):
                    return self._send(200, open(f, "rb").read(), "application/octet-stream",
                                      {"Content-Disposition": f'attachment; filename="{os.path.basename(f)}"'})
                return self._send(404, {"error": "dosya yok"})
        except Exception as e:
            return self._send(500, {"error": str(e)})
        self._send(404, {"error": "bulunamadı"})

    def do_POST(self):
        if not self._host_ok() or not self._auth():
            return self._send(401, {"error": "yetkisiz"})
        LAST_SEEN[0] = time.time()
        p = urllib.parse.urlparse(self.path).path
        try:
            if p == "/api/import":
                n = int(self.headers.get("Content-Length") or 0)
                fn = os.path.basename(self.headers.get("X-Filename") or "import.json")
                dst = os.path.join(EXPORT_DIR, "gelen-" + fn)
                with open(dst, "wb") as f:
                    while n > 0:
                        b = self.rfile.read(min(n, 1 << 20)); f.write(b); n -= len(b)
                j = start_job("İçe aktarma", "import", import_flow, dst)
                return self._send(200, {"job": j.id})
            b = self._body()
            return self._send(200, self.route(p, b) or {"ok": True})
        except KeyError as e:
            return self._send(404, {"error": f"bulunamadı: {e}"})
        except Exception as e:
            return self._send(500, {"error": str(e)})

    def route(self, p, b):
        if p == "/api/install":
            urls = [u.strip() for u in re.split(r"[\s,]+", b.get("urls", "")) if u.strip()] if isinstance(b.get("urls"), str) else b.get("urls", [])
            ids = []
            for u in urls:
                ids.append(start_job(f"Kurulum: {u}", "install", install_flow, u, b.get("opts", {}), auto=bool((b.get("opts") or {}).get("auto"))).id)
            return {"jobs": ids}
        m = re.match(r"^/api/jobs/(\w+)/(respond|cancel)$", p)
        if m:
            j = JOBS[m.group(1)]
            if m.group(2) == "cancel":
                j.cancelled = True; j.respond(False); j.status = "iptal"
            else:
                j.respond(bool(b.get("ok")), b.get("data"))
            return
        if p == "/api/jobs/approve_all":
            n = 0
            for j in JOBS.values():
                if j.pending and j.pending["kind"] in ("plan", "fix"):
                    j.respond(True, j.pending["payload"]); n += 1
            return {"approved": n}
        if p == "/api/jobs/clear":
            for k in [k for k, j in JOBS.items() if j.status in ("tamamlandı", "hata", "iptal")]:
                del JOBS[k]
            for k in [k for k, pr in PROCS.items() if pr.rc is not None]:
                del PROCS[k]
            return
        m = re.match(r"^/api/tools/([\w.-]+)/(\w+)$", p)
        if m:
            slug, act = m.groups(); t = tools()[slug]
            if act == "run":
                pr = run_tool(slug, int(b.get("action", 0)), b.get("args", ""), b.get("mode", "app"))
                return {"proc": pr.id if pr else None}
            if act == "doctor":
                return {"job": start_job(f"Doktor: {t['name']}", "doctor", doctor_flow, slug).id}
            if act == "update":
                return {"job": start_job(f"Güncelleme: {t['name']}", "update", update_flow, slug).id}
            if act == "check_update":
                has, why = check_update(t); update_tool(slug, update_available=has, update_info=why, last_check=now())
                return {"update": has, "info": why}
            if act == "optional":
                return {"job": start_job("İsteğe bağlı kurulum", "optional", optional_flow, slug, int(b.get("index", 0))).id}
            if act == "commands":
                return {"job": start_job(b.get("title", "Komutlar"), "commands", commands_flow, slug, b.get("commands", []), b.get("title", "Komutları çalıştır")).id}
            if act == "shortcut":
                return {"made": make_shortcuts(t, desktop=b.get("desktop", True))}
            if act == "agent_repair":
                j = start_job(f"🛠 Onarım: {t['name']}", "repair", repair_flow, slug); return {"job": j.id}
            if act == "extract_apis" and not b.get("ai"):
                return {"job": start_job("🧪 API havuzu", "pool", pool_test_flow, None, True).id, "pool": True}
            if act == "extract_apis":
                d = cfg().get("agent_defaults", {}) or {}
                task = (f"'{t['name']}' ({t.get('full_name')}) bir ücretsiz yapay zekâ API listesi. read_tool ile listeyi oku (slug: {slug}). "
                        "İçinden kayıt ve anahtar GEREKTİRMEYEN veya ücretsiz anahtar veren RESMİ servisleri seç (izinsiz proxy/çalıntı anahtar servislerini KULLANMA). "
                        "Anahtarsız olanları add_provider ile canlı test edip ekle. Anahtar isteyenleri say ile bana tablo halinde listele: servis, ücretsiz kota, anahtar alma adresi. "
                        "Sonunda neleri eklediğini raporla.")
                j = start_job(f"🆓 API çıkar: {t['name']}", "agent", agent_flow, task, {"workdir": t["path"], "provider": d.get("provider", ""), "auto": True})
                return {"job": j.id}
            if act == "guide":
                return {"guide": make_guide(slug)}
            if act == "edit":
                allowed = {k: b[k] for k in ("name", "actions", "update_mode", "inject_keys", "summary", "category") if k in b}
                update_tool(slug, **allowed); return
            if act == "open_folder":
                subprocess.Popen(["xdg-open", t["path"]], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return
            if act == "delete":
                remove_shortcuts(slug)
                if b.get("files", True):
                    shutil.rmtree(t["path"], ignore_errors=True)
                    for f in os.listdir(ICON_DIR):
                        if f.startswith(slug + "."):
                            os.remove(os.path.join(ICON_DIR, f))
                with _lock:
                    tt = tools(); tt.pop(slug, None); save_tools(tt)
                return
        m = re.match(r"^/api/procs/(\w+)/(input|stop|resize)$", p)
        if m:
            pr = PROCS[m.group(1)]
            if m.group(2) == "stop":
                pr.stop()
            elif m.group(2) == "resize":
                pr.resize(b.get("cols", 120), b.get("rows", 36))
            else:
                pr.write(b.get("text", "") + ("\n" if b.get("enter", True) else ""))
            return
        if p == "/api/run_command":
            slug = b.get("slug", "")
            return {"job": start_job("Ajan komutu", "commands", commands_flow, slug, [x for x in b.get("command", "").splitlines() if x.strip()], "Ajanın önerdiği komut").id}
        if p == "/api/providers/save":
            c = cfg(); old = {x.get("id"): x for x in c["providers"]}; new = []
            for x in b.get("providers", []):
                x = dict(x); x["id"] = x.get("id") or uuid.uuid4().hex[:8]
                if not x.get("api_key") and x["id"] in old:
                    x["api_key"] = old[x["id"]].get("api_key", "")
                if x.get("clear_key"):
                    x["api_key"] = ""
                x.pop("has_key", None); x.pop("clear_key", None)
                new.append(x)
            c["providers"] = new
            if b.get("default_provider") is not None:
                c["default_provider"] = b["default_provider"]
            if not any(x["id"] == c.get("default_provider") for x in new):
                c["default_provider"] = new[0]["id"] if new else ""
            save_cfg(c); return
        if p == "/api/providers/test":
            c = cfg(); pv = next((x for x in c["providers"] if x["id"] == b.get("id")), None)
            if not pv:
                raise KeyError("sağlayıcı")
            t0 = time.time()
            out = llm_call(pv, [{"role": "user", "content": "Tek kelimeyle 'çalışıyor' yaz."}], timeout=60)
            return {"ok": True, "reply": out.strip()[:200], "ms": int((time.time() - t0) * 1000)}
        if p == "/api/providers/models":
            c = cfg(); pv = next((x for x in c["providers"] if x["id"] == b.get("id")), None) or b
            base = pv.get("base_url", "").rstrip("/"); key = pv.get("api_key", "")
            if pv.get("type") == "anthropic":
                r = http_json(base + "/models", headers={"x-api-key": key, "anthropic-version": "2023-06-01"})
                return {"models": [x["id"] for x in r.get("data", [])]}
            if pv.get("type") == "gemini":
                r = http_json(f"{base}/models?key={urllib.parse.quote(key)}")
                return {"models": [x["name"].split("/")[-1] for x in r.get("models", [])]}
            r = http_json(base + "/models", headers={"Authorization": f"Bearer {key}"} if key else {})
            ms = [x["id"] for x in r.get("data", [])]
            if "openrouter.ai" in base and b.get("free_only"):
                ms = [x["id"] for x in r.get("data", []) if str((x.get("pricing") or {}).get("prompt")) in ("0", "0.0")]
            return {"models": sorted(ms)}
        if p == "/api/agents/save":
            c = cfg(); c["agents"] = [dict(a, id=a.get("id") or uuid.uuid4().hex[:8]) for a in b.get("agents", [])]; save_cfg(c); return
        if p == "/api/chat":
            return chat(b.get("agent"), b.get("messages", []), b.get("slug", ""))
        if p == "/api/chat_all":
            res = []; c = cfg()
            def one(a):
                try:
                    r = chat(a["id"], [{"role": "user", "content": b.get("message", ""), **({"images": b["images"]} if b.get("images") else {})}], b.get("slug", ""))
                except Exception as e:
                    r = {"reply": f"⚠ {e}", "agent": a["name"], "provider": "-"}
                res.append(r)
            th = [threading.Thread(target=one, args=(a,)) for a in c["agents"] if a["id"] in (b.get("agents") or [x["id"] for x in c["agents"]])]
            [x.start() for x in th]; [x.join(240) for x in th]
            return {"replies": res}
        if p == "/api/settings":
            c = cfg()
            for k in ("failover", "use_ai", "auto_shortcut", "release_assets", "update_check", "update_default_mode", "auto_agent_repair", "security_scan", "app_watch"):
                if k in b:
                    c[k] = b[k]
            if b.get("github_token") is not None:
                c["github_token"] = b["github_token"].strip()
            save_cfg(c); return
        if p == "/api/updates/check":
            return {"updates": check_all_updates()}
        if p == "/api/system/fix":
            return {"job": start_job("Sistem bağımlılıkları", "system", system_fix_flow, b.get("keys", [])).id}
        if p == "/api/agent/settings":
            c = cfg()
            if "rules" in b:
                c["agent_rules"] = b["rules"][:8000]
            if "defaults" in b:
                c["agent_defaults"] = {k: b["defaults"].get(k) for k in ("workdir", "provider", "persona", "auto")}
            save_cfg(c); return
        if p == "/api/pool/scan":
            return {"job": start_job("🧪 API havuzu", "pool", pool_test_flow, b.get("ids") or None, bool(b.get("extract", True))).id}
        if p == "/api/pool/key":
            P = pool(); it = next(x for x in P["items"] if x["id"] == b["id"])
            it["key"] = (b.get("key") or "").strip()
            it["key_env"] = b.get("env") or it.get("key_env") or (re.sub(r"[^A-Z0-9]", "_", it["name"].upper()) + "_API_KEY")
            st, info, model, ms = test_api(it, it["key"])
            it.update({"status": st if st != "needs_key" else "fails", "info": info if st != "needs_key" else "Anahtar kabul edilmedi", "model": model or it.get("model", ""), "ms": ms, "tested": now()})
            save_pool(P); pool_apply(it)
            return {"status": it["status"], "info": it["info"], "model": it["model"]}
        if p == "/api/providers/toggle":
            c = cfg(); pid = b.get("id"); pool_id_ = b.get("pool_id")
            x = next((x for x in c["providers"] if x["id"] == pid or (pool_id_ and x.get("pool_id") == pool_id_)), None)
            if not x and pool_id_:
                it = next((i for i in pool()["items"] if i["id"] == pool_id_), None)
                if it and it["status"] == "works":
                    pool_apply(it); c = cfg(); x = next((x for x in c["providers"] if x.get("pool_id") == pool_id_), None)
            if not x:
                raise KeyError("API")
            x["enabled"] = bool(b.get("enabled", True)); x["user_choice"] = True; save_cfg(c); return {"enabled": x["enabled"]}
        if p == "/api/providers/prefer":
            c = cfg(); x = next((x for x in c["providers"] if x["id"] == b.get("id") or (b.get("pool_id") and x.get("pool_id") == b.get("pool_id"))), None)
            if not x:
                raise KeyError("API")
            x["enabled"] = True; c["preferred"] = x["id"]; c["default_provider"] = x["id"]; save_cfg(c); return {"ok": True}
        if p == "/api/ai/settings":
            c = cfg()
            if b.get("ai_mode") in ("auto", "manual"):
                c["ai_mode"] = b["ai_mode"]
            if isinstance(b.get("routing"), dict):
                c["routing"] = {k: v for k, v in b["routing"].items() if k in FEATURES and isinstance(v, str)}
            if isinstance(b.get("gateway"), dict):
                g = c.get("gateway") or {}; g.update({k: bool(v) for k, v in b["gateway"].items() if k in ("enabled", "inject", "autostart")}); c["gateway"] = g
            save_cfg(c)
            g = c.get("gateway") or {}
            (start_gateway() if g.get("enabled", True) else stop_gateway())
            set_autostart(bool(g.get("enabled", True) and g.get("autostart")))
            for slug, t in tools().items():  # başlatıcıları güncelle
                for i in range(len(t.get("actions", []))):
                    try: make_launcher(t, i)
                    except Exception: pass
            return
        if p == "/api/gateway/test":
            t0 = time.time()
            r = http_json(f"http://127.0.0.1:{GATEWAY_PORT}/v1/chat/completions", {"model": b.get("model", "otomatik"), "messages": [{"role": "user", "content": "Tek kelimeyle 'çalışıyor' yaz."}]},
                          {"Authorization": f"Bearer {gateway_key()}"}, timeout=90)
            return {"reply": r["choices"][0]["message"]["content"][:200], "ms": int((time.time() - t0) * 1000)}
        if p == "/api/gateway/newkey":
            c = cfg(); g = c.get("gateway") or {}; g["key"] = "ct-" + secrets.token_urlsafe(18); c["gateway"] = g; save_cfg(c); return {"ok": True}
        if p == "/api/api_secret":
            if b.get("source") == "gateway":
                return {"key": gateway_key()}
            if b.get("source") == "providers":
                x = next((x for x in cfg()["providers"] if x["id"] == b.get("id")), {})
                return {"key": x.get("api_key", "")}
            x = next((x for x in pool()["items"] if x["id"] == b.get("id")), {})
            return {"key": x.get("key", "")}
        if p == "/api/export_apis":
            src = b.get("source", "pool"); ids = set(b.get("ids") or [])
            if src == "gateway":
                ents = [{"name": "Cypher Köprüsü", "base_url": f"http://127.0.0.1:{GATEWAY_PORT}/v1", "model": "otomatik", "api_key": gateway_key(), "type": "openai", "status": "works"}]
            elif src == "providers":
                ents = [x for x in cfg()["providers"] if not ids or x["id"] in ids]
            else:
                ents = [x for x in pool()["items"] if (not ids and x["status"] == "works") or x["id"] in ids]
            return {"text": api_export(ents, b.get("format", "json"), bool(b.get("include_keys", True))), "count": len(ents)}
        if p == "/api/pool/remove":
            P = pool(); P["items"] = [x for x in P["items"] if x["id"] != b.get("id")]; save_pool(P)
            c = cfg(); c["providers"] = [x for x in c["providers"] if x.get("pool_id") != b.get("id")]; save_cfg(c); return
        if p == "/api/repair/settings":
            c = cfg(); r = c.get("repair") or {}
            for k in ("provider", "model", "auto_approve", "on_run"):
                if k in b:
                    r[k] = b[k]
            c["repair"] = r
            if "on_install" in b:
                c["auto_agent_repair"] = bool(b["on_install"])
            save_cfg(c); return
        if p == "/api/diagnose":
            t = tools().get(b.get("slug", "")) if b.get("slug") else None
            return {"results": diagnose(b.get("text", ""), t, 12)}
        if p == "/api/kb/learned/delete":
            jsave(LEARNED_ERR, [x for x in jload(LEARNED_ERR, []) if x["id"] != b.get("id")]); return
        if p == "/api/memory/save":
            with _lock:
                jsave(MEMORY_FILE, b.get("entries", []))
            return
        if p == "/api/memory/add":
            mem_add(b.get("text", ""), b.get("kind", "tercih")); return
        if p == "/api/recipes/delete":
            jsave(USER_CATALOG, [x for x in jload(USER_CATALOG, []) if x["id"] != b.get("id")]); return
        # ── 💻 konsol
        if p == "/api/console/open":
            return {"proc": console_get(cid=b.get("console", "")).id}
        if p == "/api/console/new":
            return {"proc": console_new(b.get("title", ""), os.path.expanduser(b.get("cwd") or "")).id}
        if p == "/api/console/rename":
            con = console_get(False, b.get("console", ""))
            if con: con.title = (b.get("title") or con.title)[:40]
            return
        if p == "/api/console/suggest":
            return {"suggestions": cmd_suggestions(int(cfg().get("quick_min", 3))), "quick": quick_cmds()}
        if p == "/api/console/quick/save":
            c = cfg(); items = []
            for x in b.get("items", []):
                if (x.get("command") or "").strip():
                    items.append({"id": x.get("id") or uuid.uuid4().hex[:8], "name": (x.get("name") or x["command"])[:40], "command": x["command"].strip(),
                                  "alias": x.get("alias", "") if re.match(r"^[A-Za-z_][\w-]{0,30}$", x.get("alias", "") or "") else ""})
            c["quick_cmds"] = items; save_cfg(c); console_rc()
            for con in console_list():  # açık konsollara yeni alias'ları yükle
                if any(i["alias"] for i in items):
                    try:
                        if os.tcgetpgrp(con.m) == con.p.pid: con.write(f" source {q(os.path.join(CONF_DIR, 'konsol.rc'))} >/dev/null 2>&1\n")
                    except Exception: pass
            return {"quick": items}
        if p == "/api/console/quick/dismiss":
            c = cfg(); c["quick_dismissed"] = list(dict.fromkeys((c.get("quick_dismissed") or []) + [b.get("command", "")]))[-200:]; save_cfg(c); return
        if p == "/api/console/ai":
            con = console_get(cid=b.get("console", "")); o = dict(b.get("opts", {})); o["console"] = con.id
            o["workdir"] = o.get("workdir") or console_cwd(con)  # yapay zekâ konsolun o anki klasöründe çalışsın
            ctl = console_tools(con)
            if ctl:
                o["tool_key"] = ctl[0] if len(ctl) == 1 else ""
                b["task"] = (f"(Bu konsol sekmesi şu araç(lar) için açıldı: " + ", ".join(f"{tools()[x]['name']} [{x}]" for x in ctl)
                             + " — kullanıcı aksini söylemedikçe ÖNCELİKLE bunları kullan.)\n" + str(b.get("task", "")))
            if b.get("images"):
                o["images"] = b["images"][:6]
            return {"job": start_job("Konsol AI", "agent", agent_flow, b.get("task", ""), o).id, "proc": con.id}
        if p == "/api/console/apps":
            flt = (b.get("filter") or "").lower()
            tl = [{"kind": "tool", "id": s, "name": t["name"], "desc": ((t.get("capabilities") or {}).get("ozet") or t.get("summary") or (t.get("meta") or {}).get("description") or "")[:200],
                   "icon": t.get("icon", ""), "full_name": t.get("full_name", ""), "status": t.get("status"), "actions": len(t.get("actions", []))}
                  for s, t in tools().items() if not flt or flt in (t["name"] + s + (t.get("summary") or "")).lower()]
            da = desktop_apps(flt) if b.get("desktop", True) else []
            cl, ncli = cli_apps(flt) if b.get("cli", True) else ([], 0)
            rp = github_repos(bool(b.get("rescan"))) if b.get("repos", True) else []
            rc_ = repo_cache(); _bai = tool_ai_labels()
            rp = [r | {"best_ai": _bai.get(r["path"], "")} for r in rp]
            rp = [r | {"info": {k: (rc_.get(r["path"]) or {}).get(k) for k in ("score", "grade", "update", "checked")} | {"stars": ((rc_.get(r["path"]) or {}).get("gh") or {}).get("stars")}} if r["path"] in rc_ else r for r in rp]
            if flt:
                rp = [r for r in rp if flt in (r["name"] + r["full_name"] + r["path"] + r["desc"]).lower()]
            bw = find_browser()
            BNAME = {"google-chrome": "Google Chrome", "google-chrome-stable": "Google Chrome", "chromium": "Chromium", "chromium-browser": "Chromium",
                     "brave-browser": "Brave", "microsoft-edge": "Microsoft Edge", "firefox": "Firefox", "firefox-esr": "Firefox"}
            chrome = {"kind": "chrome", "id": bw, "name": BNAME.get(bw, bw), "desc": "İnternet tarayıcısı — tıkla, aç", "icon": "google-chrome" if "chrome" in bw else bw} if bw else None
            return {"tools": tl, "apps": da[:300], "cli": cl, "cli_total": ncli, "repos": rp, "chrome": chrome}
        if p == "/api/console/use":
            kind = b.get("kind", "tool"); item = b.get("id", "")
            if kind == "tool" and item in tools() and not b.get("here"):
                t_ = tools()[item]
                con = console_for(item, "▶ " + t_["name"], t_["path"], t_.get("console_mode"), t_.get("console_group", "") if (t_.get("console_mode") or auto_cfg()["console_mode"]) != "active" else "", b.get("console", ""))
            elif kind == "repo" and not b.get("here"):
                con = console_for(os.path.realpath(os.path.expanduser(item)), "▶ " + os.path.basename(item.rstrip("/")), os.path.realpath(os.path.expanduser(item)), None, "", b.get("console", ""))
            else:
                con = console_get(cid=b.get("console", ""))
            if b.get("ai") == "auto":
                b["ai"] = auto_cfg()["click_ai"]
            broken = ""  # 🛠 açılamazsa yapay zekâ hemen onarmaya başlar
            if kind == "tool" and b.get("repair"):
                t = tools()[item]
                broken = "Kullanıcı '🛠 Ajanla onar' dedi. " + ((t.get("last_error") or t.get("last_run_error") or "")[-800:] or "Araç düzgün çalışmıyor.")
            elif kind == "tool":
                t = tools()[item]
                if not t.get("actions"):
                    broken = "Çalıştırma komutu yok (aracın nasıl başlatılacağı bilinmiyor)."
                elif t.get("status") == "hata":
                    broken = "Kurulumu hata vermiş: " + (t.get("last_error") or "")[-800:]
                elif b.get("launch", True):
                    oz = (t.get("capabilities") or {}).get("ozet") or t.get("summary") or ""
                    if oz and b.get("ai") is not False:
                        console_print(con, f"ℹ {t['name']}: {oz[:400]}", "96")
                    con.write(f" cd {q(t['path'])} && {q(make_launcher(t, 0))}\n")
            elif kind == "chrome":
                try: console_print(con, "🌐 " + open_browser(b.get("url") or "https://www.google.com", "", item), "95")
                except Exception as e:
                    console_print(con, f"✖ {e}", "31"); broken = f"Tarayıcı açılamadı: {e}"
                if not broken:
                    return {"proc": con.id}
            elif kind == "app" and b.get("launch", True):
                try: console_print(con, "🖥 " + open_app(item), "95")
                except Exception as e:
                    console_print(con, f"✖ {e}", "31"); broken = f"Uygulama açılamadı: {e}"
            elif kind == "cli" and b.get("launch", True):
                if not which(item):
                    raise KeyError(item)
                con.write(f" {q(item)} --help 2>&1 | head -40\n")
            elif kind == "repo":
                rp = os.path.realpath(os.path.expanduser(item))
                if not os.path.isdir(os.path.join(rp, ".git")) and not os.path.isfile(os.path.join(rp, ".git")):
                    raise KeyError(item)
                item = rp
                cmd, _ = repo_launch_cmd(rp)
                if b.get("launch", True):
                    con.write(f" cd {q(rp)} && " + (cmd if (cmd and b.get("run")) else "ls") + "\n")
                if b.get("run") and not cmd:
                    broken = "Bu deponun nasıl çalıştırılacağı bulunamadı (başlatma komutu yok)."
            nm = tools()[item]["name"] if kind == "tool" and item in tools() else os.path.basename(item.rstrip("/")) or item
            if broken and (llm_available() or kind == "tool"):
                console_print(con, (f"🛠 {nm} — yapay zekâ onarıyor (araştırır, gerekirse kendisi yazar)…" if b.get("repair") else f"🛠 {nm} açılamadı: {broken[:200]} — yapay zekâ onarıyor…"), "1;33")
                if kind == "tool":
                    t = tools()[item]
                    task = repair_task(item) + f"\nKONSOLDA ÇALIŞ: Kullanıcı aracı açmak istedi ama açılamadı: {broken}\nOnardıktan sonra aracı konsolda başlat ve kullanıcıya neler yapabileceğini söyle."
                    o = {"console": con.id, "workdir": t["path"], "develop_root": t["path"], "full_name": t.get("full_name", ""), "repair": True,
                         "auto": bool(b.get("auto")) or repair_cfg()["auto_approve"], "provider": b.get("provider", "") or repair_cfg()["provider"],
                         "title": f"🛠 {nm}", "shown": f"🛠 {nm} açılamadı ({broken[:80]}) — onar ve çalıştır", "tool_key": item}
                    if not llm_available():
                        j = start_job(f"🛠 Onarım: {nm}", "repair", repair_flow, item); j.ctx["console"] = con.id; j.ctx["mirror"] = con.id
                        return {"proc": con.id, "job": j.id, "repair": True}
                else:
                    task = (f"'{nm}' açılamadı: {broken}\n" + (f"Klasör: {item}\n" if kind == "repo" else "") +
                            "Nedenini bul (hata mesajı, eksik paket, yanlış komut), internette araştır, düzelt ve programı çalıştır. Sonra kullanıcıya ne yaptığını ve programla neler yapabileceğini anlat.")
                    o = {"console": con.id, "workdir": item if kind == "repo" else os.path.expanduser("~"), "auto": bool(b.get("auto")), "provider": b.get("provider", ""),
                         "title": f"🛠 {nm}", "shown": f"🛠 {nm} açılamadı — onar ve çalıştır", **({"develop_root": item, "tool_key": item} if kind == "repo" else {})}
                if kind == "tool":
                    extra = f"KONSOLDA ÇALIŞ: Kullanıcı aracı açmak istedi ama açılamadı: {broken}\nOnardıktan sonra aracı konsolda başlat."
                    j = start_job("Konsol AI", "agent", escalating_repair_flow, item, extra,
                                  {"console": con.id, "auto": bool(b.get("auto", True)) or o["auto"], "multi": True, **({"provider": o["provider"]} if b.get("provider") else {})})
                    j.slug = item; j.icon = tools()[item].get("icon", ""); j.ctx["console"] = con.id
                else:
                    j = start_job("Konsol AI", "agent", agent_flow, task, o)
                return {"proc": con.id, "job": j.id, "repair": True}
            task = console_agent_task(kind, item) + (("\nKullanıcının isteği: " + b["task"]) if b.get("task") else "")
            if not b.get("ai", True):
                return {"proc": con.id}
            wd = item if kind == "repo" else os.path.expanduser("~")
            o = {"console": con.id, "workdir": wd, "auto": bool(b.get("auto")), "title": f"📱 {nm}", "provider": b.get("provider", ""),
                 "shown": b.get("task") or f"📱 {nm} aracını aç, incele ve onunla neler yapabileceğimi söyle", "tool_key": item if kind in ("tool", "repo") else ""}
            return {"proc": con.id, "job": start_job("Konsol AI", "agent", agent_flow, task, o).id}
        if p == "/api/proc/password":
            pr = PROCS.get(b.get("id", ""))
            if not pr or pr.rc is not None:
                raise KeyError("işlem")
            if b.get("cancel"):
                os.write(pr.m, b"\x03")
            else:
                os.write(pr.m, (str(b.get("password", "")) + "\n").encode())   # günlüğe/geçmişe yazılmaz (terminal yankısı kapalı)
            pr.pw_prompt = ""
            return {}
        if p == "/api/console/type":
            con = console_get(cid=b.get("console", "")); con.write(str(b.get("text", "")) + ("\n" if b.get("enter", True) else "")); return {"proc": con.id}
        # ── 📜 konsol tarifleri
        if p == "/api/con_recipes/preview":
            j = JOBS.get(b.get("job", ""))
            if not j:
                raise KeyError("görev")
            st = [x for x in j.ctx.get("steps_full", []) if x.get("action") in REPLAY_ACTS]
            return {"name": (j.ctx.get("task") or j.title)[:80], "steps": [{"i": i, "text": step_text(x), "ok": x.get("ok"), "action": x["action"]} for i, x in enumerate(st)]}
        if p == "/api/con_recipes/save":
            j = JOBS.get(b.get("job", ""))
            if not j:
                raise KeyError("görev")
            rec = recipe_from_job(j, b.get("name", ""), b.get("pick"))
            return {"recipe": recipe_save(rec)}
        if p == "/api/con_recipes/get":
            return {"recipe": next(r for r in con_recipes() if r["id"] == b.get("id")) | {"lines": [step_text(x) for x in next(r for r in con_recipes() if r["id"] == b.get("id"))["steps"]]}}
        if p == "/api/con_recipes/rename":
            with _lock:
                l = con_recipes()
                for r_ in l:
                    if r_["id"] == b.get("id"): r_["name"] = (b.get("name") or r_["name"])[:80]
                jsave(CON_RECIPES, l)
            return
        if p == "/api/con_recipes/delete":
            with _lock: jsave(CON_RECIPES, [r_ for r_ in con_recipes() if r_["id"] != b.get("id")])
            return
        if p == "/api/con_recipes/run":
            rec = next((r_ for r_ in con_recipes() if r_["id"] == b.get("id")), None)
            if not rec:
                raise KeyError("tarif")
            con = console_get(cid=b.get("console", ""))
            if b.get("mode") == "ai":
                o = {"console": con.id, "workdir": console_cwd(con), "auto": bool(b.get("auto")), "provider": b.get("provider", ""), "title": f"📜 {rec['name']}",
                     "shown": f"📜 Tarifi uygula: {rec['name']}" + (f" — {b['input']}" if b.get("input") else "")}
                return {"job": start_job("Konsol AI", "agent", agent_flow, recipe_ai_task(rec, b.get("input", "")), o).id, "proc": con.id}
            j = start_job("Konsol tarifi", "agent", recipe_replay_flow, rec["id"], con.id, b.get("input", ""))
            j.ctx["console"] = con.id
            return {"job": j.id, "proc": con.id}
        # ── 🐙 diskteki depolar
        if p == "/api/repos/info":
            return {"info": repo_info(b.get("path", ""), net=b.get("net", True), scan=b.get("scan", True), ai=bool(b.get("ai")))}
        if p == "/api/repos/cache":
            return {"items": repo_cache()}
        if p == "/api/repos/check_all":
            return {"job": start_job("🐙 Depo kontrolü", "update", repos_check_flow, b.get("paths") or [], bool(b.get("scan"))).id}
        if p == "/api/repos/update":
            return {"job": start_job("⬆ Depo güncelleme", "update", repo_update_flow, b.get("path", "")).id}
        if p == "/api/repos/compare":
            return repo_compare(b.get("paths", []), b.get("ai", True))
        if p == "/api/repos/adopt":
            slug = adopt_repo(b.get("path", ""), bool(b.get("shortcut")))
            return {"slug": slug, "name": tools()[slug]["name"], "actions": len(tools()[slug].get("actions", []))}
        # ── ✨ araç geliştirme
        if p == "/api/develop/start":
            kind = b.get("kind", "tool"); item = b.get("id", "")
            if kind == "tool":
                t = tools()[item]; root = t["path"]; name = t["name"]; fn = t.get("full_name", "")
            else:
                root = os.path.realpath(os.path.expanduser(item)); name = os.path.basename(root)
                if not os.path.isdir(root):
                    raise KeyError(item)
                fn = _repo_full_name(_git_remote(os.path.join(root, ".git")))
            mode = b.get("mode", "suggest"); text = (b.get("text") or "").strip()
            if mode in ("feature", "bug") and not text:
                raise RuntimeError("Ne eklemek / neyin çalışmadığını yaz.")
            con = console_new(f"✨ {name}"[:30], root)
            shown = {"fix": f"🩺 {name}: çalışmayan özellikleri bul ve onar", "suggest": f"💡 {name}: bana yeni özellikler öner",
                     "feature": f"✍️ {name}: şu özelliği ekle — {text}", "bug": f"🐞 {name}: şu çalışmıyor — {text}"}.get(mode, name)
            o = {"console": con.id, "workdir": root, "develop_root": root, "full_name": fn, "auto": bool(b.get("auto")), "provider": b.get("provider", ""),
                 "title": f"✨ {name}", "shown": shown, "visible": b.get("visible", cfg().get("visible_research", True)), "max_steps": 40,
                 "tool_key": item if kind == "tool" else root}
            j = start_job("Konsol AI", "agent", agent_flow, dev_task(name, root, mode, text, fn), o)
            if kind == "tool":
                j.slug = item; j.icon = tools()[item].get("icon", "")
            return {"job": j.id, "proc": con.id}
        if p == "/api/develop/history":
            root = tools()[b["slug"]]["path"] if b.get("slug") else b.get("path", "")
            return dev_history(root)
        if p == "/api/develop/revert":
            root = os.path.realpath(os.path.expanduser(b.get("path", "")))
            if dev_branch(root) != DEV_BRANCH:
                dev_switch(root, "dev")
            rc, out, err = _gitc(root, "revert", "--no-edit", b.get("hash", ""))
            if rc != 0:
                _git(root, "revert", "--abort")
                raise RuntimeError("Geri alınamadı (sonraki değişikliklerle çakışıyor olabilir): " + (err or out)[-300:])
            return dev_history(root)
        if p == "/api/develop/switch":
            dev_switch(b.get("path", ""), b.get("to", "original")); return dev_history(b.get("path", ""))
        if p == "/api/tools/active":
            sl = b.get("slugs") or []; on = bool(b.get("active", True))
            if b.get("only"):  # sadece seçilenler aktif
                for s_ in tools():
                    update_tool(s_, active=(s_ in sl))
            else:
                for s_ in sl:
                    if s_ in tools(): update_tool(s_, active=on)
            stopped = 0
            for pr in list(PROCS.values()):  # pasif olan araç çalışıyorsa durdur — "sadece seçtiklerim çalışsın"
                if pr.rc is not None: continue
                k_ = getattr(pr, "key", "")
                own = (not pr.console and pr.slug in tools() and not tool_active(pr.slug)) or (k_.startswith("tool:") and k_[5:] in tools() and not tool_active(k_[5:]))
                grp = k_.startswith("grp:") and console_tools(pr) and not any(tool_active(x) for x in console_tools(pr))
                if own or grp:
                    pr.stop(); stopped += 1
            return {"active": [s_ for s_ in tools() if tool_active(s_)], "stopped": stopped}
        if p == "/api/tools/console":
            sl = b.get("slugs") or []; g = (b.get("group") or "").strip()[:30]; md = b.get("mode", "")
            for s_ in sl:
                if s_ in tools(): update_tool(s_, console_group=g, console_mode=(md or ("group" if g else "")))
            if b.get("open") and sl:
                t0 = tools()[sl[0]]
                con = console_for(sl[0], "▶ " + t0["name"], t0["path"], md or ("group" if g else "own"), g)
                return {"proc": con.id}
            return {}
        if p == "/api/auto/settings":
            c = cfg(); a = c.get("auto") or {}
            for k in ("click_ai", "bench"):
                if k in b: a[k] = bool(b[k])
            if b.get("console_mode") in ("own", "active", "group"): a["console_mode"] = b["console_mode"]
            c["auto"] = a
            if "app_watch" in b: c["app_watch"] = bool(b["app_watch"])
            if "on_run" in b: c.setdefault("repair", {})["on_run"] = bool(b["on_run"])
            if "auto_agent_repair" in b: c["auto_agent_repair"] = bool(b["auto_agent_repair"])
            if "full_repair" in b: a["full_repair"] = bool(b["full_repair"]); c["auto"] = a
            if b.get("heavy") in ("ask", "never", "always"): a["heavy"] = b["heavy"]; c["auto"] = a
            if "browser_auto" in b: a["browser_auto"] = bool(b["browser_auto"]); c["auto"] = a
            if "desktop" in b: a["desktop"] = bool(b["desktop"]); c["auto"] = a
            if b.get("cookies") in ("reject", "accept", "off"): a["cookies"] = b["cookies"]; c["auto"] = a
            if "search_engine" in b: a["search_engine"] = str(b["search_engine"])[:300]; c["auto"] = a
            if "learn_first" in b: a["learn_first"] = bool(b["learn_first"]); c["auto"] = a
            if "browser_embed" in b: c["browser_embed"] = bool(b["browser_embed"])
            save_cfg(c); return {"auto": auto_cfg()}
        if p == "/api/hunt/start":
            con = console_get(cid=b.get("console", "")) if b.get("console") is not None else None
            o = {"n": b.get("n", 3), "auto": bool(b.get("auto")), "remove": b.get("remove"), "console": con.id if con else ""}
            j = start_job("🏁 Araç yarışması", "agent", tool_hunt_flow, (b.get("request") or "").strip(), o)
            if con: j.ctx["console"] = con.id
            return {"job": j.id, "proc": con.id if con else ""}
        if p == "/api/tool_ai/get":
            k = b.get("key", ""); sc = tool_ai_scores(k); e = tool_ai().get(k) or {}
            return {"scores": sorted(({"id": i} | v for i, v in sc.items()), key=lambda x: -x["score"]), "best": tool_ai_best(k), "bench_at": e.get("bench_at", ""),
                    "providers": len([p_ for p_ in cfg().get("providers", []) if p_.get("enabled", True)])}
        if p == "/api/tool_ai/bench":
            k = b.get("key", "")
            def fl(job, k):
                job.title = f"🧠 En iyi API: {tool_ai_ctx(k)[0]}"; best = tool_ai_bench(k, job.log)
                job.ctx["report"] = f"En iyi: {tool_ai_scores(k).get(best, {}).get('name', '-')}"; job.log("✅ " + job.ctx["report"])
            return {"job": start_job("🧠 API yarışı", "doctor", fl, k).id}
        if p == "/api/tool_ai/reset":
            d = tool_ai(); d.pop(b.get("key", ""), None); _tai_save(d); return
        if p == "/api/tools_caps":
            return {"job": start_job("🧠 Araç açıklamaları", "doctor", caps_all_flow, bool(b.get("force"))).id}
        if p == "/api/research/settings":
            c = cfg(); c["visible_research"] = bool(b.get("visible", True)); save_cfg(c); return
        # ── 🧭 tarayıcı kontrolü
        if p == "/api/browser/open":
            sid = brw_open(b.get("url", ""), b.get("query", ""), b.get("name", "")); return {"id": sid, "shot": brw_shot(sid)}
        if p == "/api/accounts":
            L = accs()
            if b.get("save"):
                d = b["save"]; t = d.get("type")
                if t not in ACC_TYPES:
                    raise KeyError("hesap türü")
                old = next((x for x in L if x["id"] == d.get("id")), None)
                e = old or {"id": uuid.uuid4().hex[:6], "type": t}
                e["name"] = (d.get("name") or ACC_TYPES[t]["label"]).strip()[:40]
                for f in ACC_TYPES[t]["fields"]:
                    v = str(d.get(f, "")).strip()
                    if v and not v.startswith("•••"):
                        e[f] = v
                    elif f not in e:
                        e[f] = ""
                if not old: L.append(e)
                accs_save(L)
                try:
                    msg = acc_test(e); e["ok"] = True
                except Exception as ex:
                    msg = f"✖ Bağlanamadı: {str(ex)[:300]}"; e["ok"] = False
                e["checked"] = now(); accs_save(L)
                return {"msg": msg, "items": [acc_public(x) for x in L]}
            if b.get("delete"):
                L = [x for x in L if x["id"] != b["delete"]]; accs_save(L)
            if b.get("test"):
                e = acc_get(b["test"])
                try: return {"msg": acc_test(e), "items": [acc_public(x) for x in L]}
                except Exception as ex: return {"msg": f"✖ {str(ex)[:300]}", "items": [acc_public(x) for x in L]}
            return {"items": [acc_public(x) for x in L], "types": {k: v["label"] for k, v in ACC_TYPES.items()}}
        if p == "/api/accounts/gads_oauth":
            # Google OAuth (masaüstü uygulaması istemcisi): onay sayfası → localhost geri dönüş → yenileme belirteci kaydedilir
            e = acc_get(b.get("id", ""))
            st = secrets.token_urlsafe(12); OAUTH_STATE[st] = e["id"]
            red = f"http://127.0.0.1:{SERVER_PORT[0]}/oauth/google"
            url = "https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode({"client_id": e["client_id"], "redirect_uri": red, "response_type": "code",
                  "scope": "https://www.googleapis.com/auth/adwords", "access_type": "offline", "prompt": "consent", "state": st})
            return {"url": url}
        if p == "/api/knowledge":
            if b.get("delete"):
                with _lock:
                    jsave(KNOW_FILE, [x for x in know_all() if x.get("id") != b["delete"]])
            if b.get("add"):
                know_add(b["add"].get("topic", ""), b["add"].get("summary", ""), b["add"].get("source", ""))
            k = know_all()
            if b.get("q"):
                k = know_find(b["q"], 50)
            return {"items": list(reversed(k))[:300], "total": len(know_all())}
        if p == "/api/browser/input":
            return brw_input(b.get("id", ""), b)
        if p == "/api/browser/new":
            sid = brw_open(b.get("url", "") if re.match(r"^(https?://|[\w-]+\.[\w.-]+(/|$)|localhost)", str(b.get("url", ""))) else "", "" if re.match(r"^(https?://|[\w-]+\.[\w.-]+(/|$)|localhost)", str(b.get("url", ""))) else str(b.get("url", "")), b.get("name") or "🌐 Google")
            return {"id": sid}
        if p == "/api/browser/snap":
            sid = brw_sess(b.get("id"))["id"]
            try: brw_wait(sid, 3)
            except Exception: pass
            return {"shot": brw_shot(sid), **{k: BRW["sessions"][sid].get(k, "") for k in ("title", "url", "name")}}
        if p == "/api/browser/close":
            brw_close(b.get("id", "")); return
        if p == "/api/browser/close_all":
            for sid in list(BRW["sessions"]): brw_close(sid)
            return
        # ── 🖥️ bilgisayardaki uygulamalar
        if p == "/api/apps/explain":
            return app_explain(b.get("kind", "app"), b.get("id", ""), b.get("question", ""))
        if p == "/api/apps/use":
            task = (f"'{b.get('name') or b.get('id')}' programını ({'grafik uygulama, id: ' + b.get('id', '') if b.get('kind') == 'app' else 'terminal programı'}) kullanarak şunu yap: {b.get('task', '')}\n"
                    "Önce programın nasıl kullanıldığını öğren (--help/man), sonra işi yap ve sonucu doğrula. Grafik uygulamaysa mümkünse komut satırı karşılığını kullan; yoksa open_app ile aç ve kullanıcıya adımları söyle.")
            if b.get("console"):
                con = console_get()
                return {"job": start_job("Konsol AI", "agent", agent_flow, task, {"console": con.id, "workdir": os.path.expanduser("~"), "auto": bool(b.get("auto"))}).id, "proc": con.id}
            return {"job": start_job("Görev Ajanı", "agent", agent_flow, task, {"auto": bool(b.get("auto"))}).id}
        if p == "/api/apps/open":
            return {"msg": open_app(b.get("id", ""), b.get("file", ""))}
        if p == "/api/settings_panel":
            return {"msg": open_settings(b.get("panel", "genel"))}
        # ── 🛡️ güvenlik
        m = re.match(r"^/api/tools/([\w.-]+)/scan$", p)
        if m:
            t = tools()[m.group(1)]; sec = security_scan(t["path"], ai=b.get("ai", True)); update_tool(m.group(1), security=sec); return sec
        # ── 🛠️ stüdyo
        if p == "/api/dev/list":
            return {"projects": proj_list(), "templates": {k: v["label"] for k, v in DEV_TEMPLATES.items()}, "git": bool(which("git")), "gh": bool(which("gh"))}
        if p == "/api/dev/new":
            slug = proj_new(b.get("name") or "proje", b.get("template", "python"), b.get("desc", ""))
            out = {"slug": slug}
            if b.get("ai") and b.get("desc"):
                out["job"] = start_job("Stüdyo", "dev", dev_ai_flow, slug, f"Bu projeyi sıfırdan geliştir: {b['desc']}", {"auto": bool(b.get("auto"))}).id
            return out
        if p == "/api/dev/tree":
            return {"files": proj_tree(b["slug"]), "meta": proj_meta(b["slug"])}
        if p == "/api/dev/read":
            root, ap = proj_file(b["slug"], b["path"])
            raw = open(ap, "rb").read()
            if b"\0" in raw[:4000]:
                return {"binary": True, "size": len(raw)}
            return {"content": raw.decode("utf-8", "replace")}
        if p == "/api/dev/write":
            root, ap = proj_file(b["slug"], b["path"]); os.makedirs(os.path.dirname(ap), exist_ok=True)
            open(ap, "w", encoding="utf-8").write(b.get("content", "")); return {"ok": True}
        if p == "/api/dev/delete":
            root, ap = proj_file(b["slug"], b["path"])
            if os.path.isfile(ap): os.remove(ap)
            return
        if p == "/api/dev/remove_project":
            root = proj_path(b["slug"]); m_ = proj_meta(b["slug"])
            if m_.get("tool") and m_["tool"] in tools():
                with _lock:
                    t = tools(); t.pop(m_["tool"], None); save_tools(t)
            shutil.rmtree(root, ignore_errors=True); return
        if p == "/api/dev/meta":
            return proj_meta(b["slug"], **{k: v for k, v in b.items() if k in ("name", "desc", "run")})
        if p == "/api/dev/ai":
            return {"job": start_job("Stüdyo", "dev", dev_ai_flow, b["slug"], b.get("request", ""), {"auto": bool(b.get("auto")), "provider": b.get("provider", "")}).id}
        if p == "/api/dev/run":
            root = proj_path(b["slug"]); cmd = b.get("cmd") or proj_meta(b["slug"]).get("run") or "ls -la"
            if b.get("console"):
                con = console_get(); con.write(f"cd {q(root)} && {cmd}\n"); return {"proc": con.id}
            return {"proc": Proc(f"🛠️ {b['slug']} — {cmd[:40]}", cmd, root, "").id}
        if p == "/api/dev/git":
            root = proj_path(b["slug"]); op = b.get("op", "log")
            if not which("git"):
                return {"out": "git kurulu değil (🩺 Sistem sekmesinden kur)."}
            if op == "log":
                _, o = git(root, "log", "--format=%h|%s|%cr|%an", "-n", "60"); return {"commits": [dict(zip(("hash", "msg", "when", "who"), l.split("|", 3))) for l in o.splitlines() if "|" in l]}
            if op == "status":
                _, o = git(root, "status", "--short"); _, br = git(root, "branch", "--format=%(refname:short)"); _, cur = git(root, "branch", "--show-current")
                return {"out": o, "branches": br.splitlines(), "current": cur}
            if op == "commit":
                return {"out": proj_commit(root, b.get("msg") or "Değişiklikler") or "Kaydedilecek değişiklik yok."}
            if op == "show":
                _, o = git(root, "show", "--stat", "--patch", "--format=%h %s%n%an · %cr%n", re.sub(r"[^0-9a-f]", "", b.get("hash", ""))[:40]); return {"out": o[:60000]}
            if op == "diff":
                _, o = git(root, "diff"); return {"out": o[:60000] or "(değişiklik yok)"}
            if op == "branch":
                nm = re.sub(r"[^\w./-]", "-", b.get("name", "yeni-dal")); _, o = git(root, "checkout", "-b", nm); return {"out": o}
            if op == "checkout":
                nm = re.sub(r"[^\w./-]", "-", b.get("name", "main")); _, o = git(root, "checkout", nm); return {"out": o}
            if op == "revert":
                h = re.sub(r"[^0-9a-f]", "", b.get("hash", ""))[:40]; _, o = git(root, "revert", "--no-edit", h); return {"out": o}
            raise KeyError(op)
        if p == "/api/dev/register":
            return {"tool": proj_register(b["slug"])}
        if p == "/api/dev/zip":
            return {"file": os.path.basename(proj_zip(b["slug"]))}
        if p == "/api/dev/github":
            root = proj_path(b["slug"]); name = re.sub(r"[^\w.-]", "-", b.get("repo") or b["slug"]); vis = "--private" if b.get("private", True) else "--public"
            con = console_get()
            if which("gh"):
                cmd = f"cd {q(root)} && (gh auth status >/dev/null 2>&1 || gh auth login) && gh repo create {q(name)} {vis} --source . --remote origin --push"
            else:
                user = re.sub(r"[^\w-]", "", b.get("user", ""))
                cmd = (f"cd {q(root)} && echo '⚠ gh (GitHub CLI) yok: önce github.com/new adresinden {name} adlı boş depo oluştur. Şifre yerine kişisel erişim anahtarı (token) gir.' && "
                       f"(git remote get-url origin >/dev/null 2>&1 || git remote add origin https://github.com/{user or 'KULLANICI_ADIN'}/{name}.git) && git push -u origin HEAD")
            con.write(cmd + "\n"); return {"proc": con.id}
        m = re.match(r"^/api/dev/issues$", p)
        if m:
            mt = proj_meta(b["slug"]); iss = mt.get("issues", [])
            if b.get("add"):
                iss.append({"id": uuid.uuid4().hex[:6], "title": b["add"][:200], "body": b.get("body", ""), "done": False, "at": now()})
            for i in iss:
                if i["id"] == b.get("toggle"): i["done"] = not i["done"]
            iss = [i for i in iss if i["id"] != b.get("delete")]
            proj_meta(b["slug"], issues=iss); return {"issues": iss}
        # ── ⏰ zamanlanmış görevler
        if p == "/api/schedules/save":
            L = [s_ for s_ in (b.get("items") or []) if s_.get("task") or s_.get("workflow")]
            for s_ in L:
                s_.setdefault("id", uuid.uuid4().hex[:8]); s_["next"] = sched_next(s_)
            with _lock:
                jsave(SCHED_FILE, L)
            return {"items": L}
        if p == "/api/schedules/run":
            s_ = next(x for x in schedules() if x["id"] == b["id"]); return {"job": sched_run(s_).id}
        # ── 🔗 iş akışları
        if p == "/api/workflows/save":
            jsave(WF_FILE, [w for w in (b.get("items") or []) if w.get("steps")]); return {"items": workflows()}
        if p == "/api/workflows/run":
            return {"job": start_job("İş akışı", "workflow", workflow_flow, b["id"], b.get("input", ""), auto=bool(b.get("auto"))).id}
        # ── 📄 belgeler
        if p == "/api/docs/list":
            i_ = docs_index(); return {"docs": i_["docs"], "chunks": len(i_["chunks"])}
        if p == "/api/docs/add":
            paths = list(b.get("paths") or [])
            for f in b.get("uploads") or []:
                dst = os.path.join(DOC_UP, os.path.basename(f.get("name", "belge.txt")))
                open(dst, "wb").write(base64.b64decode(f.get("b64", "").split(",")[-1])); paths.append(dst)
            return docs_add(paths)
        if p == "/api/docs/remove":
            i_ = docs_index(); ids = set(b.get("ids") or [])
            i_["docs"] = [d for d in i_["docs"] if d["id"] not in ids]; i_["chunks"] = [c_ for c_ in i_["chunks"] if c_["doc"] not in ids]
            jsave(DOC_INDEX, i_); return
        if p == "/api/docs/ask":
            return docs_ask(b.get("question", ""), b.get("hist"), b.get("docs") or None)
        # ── 🎤 ses
        if p == "/api/transcribe":
            return transcribe(base64.b64decode(b.get("b64", "").split(",")[-1]), b.get("mime", "audio/webm"))
        if p == "/api/voice/install_local":
            return {"job": start_job("Whisper", "setup", whisper_install_flow).id}
        # ── 💡 öneriler / 🩺 sistem asistanı
        if p == "/api/suggest":
            return suggestions(bool(b.get("force")))
        if p == "/api/system/snapshot":
            return system_snapshot()
        if p == "/api/system/assist":
            snap = system_snapshot(); base = SYS_TASKS.get(b.get("kind", ""), b.get("task", ""))
            task = base + "\n\nŞU ANKİ SİSTEM DURUMU:\n" + json.dumps(snap, ensure_ascii=False, indent=1)[:5000]
            o = {"auto": False}
            if b.get("console"):
                o["console"] = console_get().id; o["workdir"] = os.path.expanduser("~")
            return {"job": start_job("Sistem Asistanı", "agent", agent_flow, task, o).id, "proc": o.get("console", "")}
        # ── 📱 telefon
        if p == "/api/phone":
            c = cfg(); pc = c.get("phone") or {}
            if b.get("password"):
                if len(b["password"]) < 6:
                    raise ValueError("Şifre en az 6 karakter olmalı")
                phone_set_password(b["password"]); c = cfg(); pc = c.get("phone") or {}
            if "enabled" in b:
                if b["enabled"] and not pc.get("hash"):
                    raise ValueError("Önce bir telefon şifresi belirle")
                pc["enabled"] = bool(b["enabled"]); c["phone"] = pc; save_cfg(c)
                stop_phone()
                if pc["enabled"]:
                    start_phone()
            return {"running": bool(PHONE_SRV[0]), "url": f"http://{lan_ip()}:{pc.get('port', 8766)}"}
        if p == "/api/agent/start":
            o = dict(b.get("opts", {}))
            if b.get("images"):
                o["images"] = b["images"][:6]
            return {"job": start_job("Görev Ajanı", "agent", agent_flow, b.get("task", ""), o).id}
        if p == "/api/freeai/scan":
            return {"job": start_job("Ücretsiz AI taraması", "freeai", free_ai_scan, bool(b.get("add", True))).id}
        if p == "/api/freeai/ollama":
            return {"job": start_job("Yerel AI kurulumu", "ollama", ollama_setup_flow, b.get("model", "qwen2.5-coder:7b")).id}
        if p == "/api/export":
            f = export_all(bool(b.get("full")), bool(b.get("include_keys")))
            return {"file": os.path.basename(f), "path": f, "size": os.path.getsize(f)}
        if p == "/api/shutdown":
            threading.Timer(0.5, lambda: os._exit(0)).start(); return
        raise KeyError(p)

# ───────────────────────────── 🌉 Cypher Yapay Zekâ Köprüsü (yerel OpenAI uyumlu API) ─────────────────────────────
def gateway_key():
    c = cfg(); g = c.get("gateway") or {}
    if not g.get("key"):
        g["key"] = "ct-" + secrets.token_urlsafe(18); c["gateway"] = g; save_cfg(c)
    return g["key"]

def provider_alias(p):
    return slugify(re.sub(r"\(havuz\)", "", p.get("name", "api"))) or p["id"]

def _flat_messages(msgs):
    sysm, out = [], []
    for m in msgs or []:
        c = m.get("content")
        if isinstance(c, list):
            c = "\n".join(x.get("text", "") for x in c if isinstance(x, dict) and x.get("type") in ("text", "input_text"))
        if m.get("role") == "system":
            sysm.append(c or "")
        elif m.get("role") in ("user", "assistant"):
            out.append({"role": m["role"], "content": c or ""})
    return "\n".join(sysm), out

class GatewayHandler(BaseHTTPRequestHandler):
    server_version = "CypherToolKopru"
    protocol_version = "HTTP/1.1"
    def log_message(self, *a):
        pass
    def _json(self, code, obj):
        d = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(d))); self.end_headers(); self.wfile.write(d)
    def _ok(self):
        h = (self.headers.get("Host") or "").split(":")[0]
        if h not in ("127.0.0.1", "localhost"):
            self._json(403, {"error": {"message": "Sadece bu bilgisayardan erişilebilir"}}); return False
        auth = (self.headers.get("Authorization") or "").removeprefix("Bearer ").strip() or self.headers.get("x-api-key", "")
        if not secrets.compare_digest(auth, gateway_key()):
            self._json(401, {"error": {"message": "Geçersiz anahtar. Cypher Tool → API'ler → Köprü bölümündeki anahtarı kullan.", "type": "invalid_api_key"}}); return False
        return True
    def do_OPTIONS(self):
        self._json(403, {"error": {"message": "CORS kapalı"}})
    def do_GET(self):
        p = urllib.parse.urlparse(self.path).path.rstrip("/")
        if p in ("", "/health", "/v1"):
            return self._json(200, {"ok": True, "app": APP, "providers": len([x for x in cfg()["providers"] if x.get("enabled", True)])})
        if not self._ok():
            return
        if p in ("/v1/models", "/models"):
            data = [{"id": "otomatik", "object": "model", "owned_by": "cypher-tool"}] + \
                   [{"id": provider_alias(x), "object": "model", "owned_by": x.get("name"), "model": x.get("model")} for x in cfg()["providers"] if x.get("enabled", True)]
            return self._json(200, {"object": "list", "data": data})
        self._json(404, {"error": {"message": "bulunamadı"}})
    def do_POST(self):
        if not self._ok():
            return
        p = urllib.parse.urlparse(self.path).path.rstrip("/")
        n = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return self._json(400, {"error": {"message": "Geçersiz JSON"}})
        if p not in ("/v1/chat/completions", "/chat/completions"):
            return self._json(404, {"error": {"message": "Bu köprü şimdilik /v1/chat/completions destekliyor"}})
        want = str(body.get("model") or "otomatik")
        provs = ordered_providers("", "gateway")
        alias = next((x for x in provs if provider_alias(x) == want.split("/")[-1] or x["id"] == want), None)
        if alias:
            provs = [alias] + [x for x in provs if x is not alias]
        stream = bool(body.get("stream")); errs = []
        for prov in provs:
            t0 = time.time()
            try:
                if prov.get("type", "openai") == "openai":
                    fb = dict(body); fb["model"] = prov.get("model") or want
                    h = {**UA, "Content-Type": "application/json"}
                    if prov.get("api_key"):
                        h["Authorization"] = f"Bearer {prov['api_key']}"
                    if "openrouter.ai" in prov.get("base_url", ""):
                        h.update({"HTTP-Referer": "https://cyphertool.local", "X-Title": APP})
                    req = urllib.request.Request(prov["base_url"].rstrip("/") + "/chat/completions", data=json.dumps(fb).encode(), headers=h, method="POST")
                    r = urllib.request.urlopen(req, timeout=180)
                    if stream:
                        self.send_response(200); self.send_header("Content-Type", "text/event-stream"); self.send_header("Cache-Control", "no-cache")
                        self.send_header("Connection", "close"); self.end_headers()
                        while True:
                            ch = r.read1(8192) if hasattr(r, "read1") else r.read(8192)
                            if not ch:
                                break
                            self.wfile.write(ch); self.wfile.flush()
                        self.close_connection = True
                    else:
                        d = r.read()
                        self.send_response(200); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(d)))
                        self.send_header("X-Cypher-Provider", urllib.parse.quote(prov.get("name", ""))); self.end_headers(); self.wfile.write(d)
                else:
                    sysm, msgs = _flat_messages(body.get("messages"))
                    out = llm_call(prov, msgs, sysm)
                    cid = "ct-" + uuid.uuid4().hex[:12]
                    if stream:
                        self.send_response(200); self.send_header("Content-Type", "text/event-stream"); self.send_header("Connection", "close"); self.end_headers()
                        for chunk in ({"choices": [{"index": 0, "delta": {"role": "assistant", "content": out}}]}, {"choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}]}):
                            self.wfile.write(("data: " + json.dumps({"id": cid, "object": "chat.completion.chunk", "model": want, **chunk}, ensure_ascii=False) + "\n\n").encode())
                        self.wfile.write(b"data: [DONE]\n\n"); self.wfile.flush(); self.close_connection = True
                    else:
                        self._json(200, {"id": cid, "object": "chat.completion", "created": int(time.time()), "model": want,
                                         "choices": [{"index": 0, "message": {"role": "assistant", "content": out}, "finish_reason": "stop"}],
                                         "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}})
                ai_stat(prov["id"], True, (time.time() - t0) * 1000)
                g = LIVE["gateway"]; g["count"] += 1; g["last"] = f"{prov.get('name')} · {prov.get('model')}"; g["at"] = time.time()
                g["client"] = (self.headers.get("User-Agent") or "")[:60]
                return
            except urllib.error.HTTPError as e:
                ai_stat(prov["id"], False, 0); errs.append(f"{prov.get('name')}: HTTP {e.code} {e.read()[:200].decode('utf-8', 'replace')}")
            except Exception as e:
                ai_stat(prov["id"], False, 0); errs.append(f"{prov.get('name')}: {str(e)[:200]}")
                if stream and "Broken pipe" in str(e):
                    return
        self._json(502, {"error": {"message": "Tüm API'ler başarısız: " + " | ".join(errs)[:1500], "type": "upstream_error"}})

GATEWAY_SRV = [None]

def start_gateway():
    if not (cfg().get("gateway") or {}).get("enabled", True) or GATEWAY_SRV[0]:
        return
    gateway_key(); write_env_file(cfg())
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", GATEWAY_PORT), GatewayHandler)
    except OSError:
        return  # port dolu (başka bir kopya çalışıyor olabilir)
    GATEWAY_SRV[0] = srv
    threading.Thread(target=srv.serve_forever, daemon=True).start()

def stop_gateway():
    if GATEWAY_SRV[0]:
        try: GATEWAY_SRV[0].shutdown(); GATEWAY_SRV[0].server_close()
        except Exception: pass
        GATEWAY_SRV[0] = None

def set_autostart(on):
    d = os.path.expanduser("~/.config/autostart"); f = os.path.join(d, "cyphertool-kopru.desktop")
    if on:
        os.makedirs(d, exist_ok=True)
        open(f, "w").write(f"[Desktop Entry]\nType=Application\nName=Cypher Tool Köprüsü\nComment=Yerel yapay zekâ köprüsü (arka planda)\n"
                           f"Exec=\"{os.path.realpath(__file__)}\" sunucu\nX-GNOME-Autostart-enabled=true\nNoDisplay=true\n")
    elif os.path.exists(f):
        os.remove(f)

def open_window(url):
    """Arayüzü uygulama penceresi olarak açar. Root iken Chrome/Chromium --no-sandbox ister."""
    logf = open(os.path.join(CONF_DIR, "pencere.log"), "a")
    logf.write(f"\n[{now()}] pencere açılıyor: uid={os.geteuid()} DISPLAY={os.environ.get('DISPLAY')}\n"); logf.flush()
    # WSL (Windows içindeki Linux): arayüzü Windows'un tarayıcısında aç
    try:
        is_wsl = "microsoft" in open("/proc/version").read().lower()
    except Exception:
        is_wsl = False
    if is_wsl:
        for cmd in (["wslview", url], ["cmd.exe", "/c", "start", "", url], ["powershell.exe", "-NoProfile", "-Command", f"Start-Process '{url}'"]):
            if shutil.which(cmd[0]):
                subprocess.Popen(cmd, cwd="/mnt/c" if os.path.isdir("/mnt/c") else None, start_new_session=True, stdout=logf, stderr=logf)
                logf.write(f"WSL: Windows tarayıcısında açıldı ({cmd[0]})\n"); logf.flush()
                return
    root_flags = ["--no-sandbox", "--test-type"] if is_root() else []
    for b in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "brave-browser", "microsoft-edge", "vivaldi"):
        if shutil.which(b):
            subprocess.Popen([b, f"--app={url}", "--class=CypherTool", "--window-size=1400,900",
                              f"--user-data-dir={os.path.join(CONF_DIR, 'pencere')}", "--no-first-run", "--no-default-browser-check"] + root_flags,
                             start_new_session=True, stdout=logf, stderr=logf)
            return
    if shutil.which("firefox"):
        subprocess.Popen(["firefox", "--new-window", url], start_new_session=True, stdout=logf, stderr=logf); return
    subprocess.Popen(["xdg-open", url], start_new_session=True, stdout=logf, stderr=logf)

def existing_session():
    s = jload(SESSION_FILE, {})
    if not s.get("port"):
        return None
    try:
        r = http_json(f"http://127.0.0.1:{s['port']}/api/state", headers={"X-Token": s["token"]}, timeout=3)
        return s if r.get("app") == APP else None
    except Exception:
        return None

def serve(open_ui=True, port=8765):
    global TOKEN
    s = existing_session()
    if s:
        url = f"http://127.0.0.1:{s['port']}/#{s['token']}"
        print(f"{APP} zaten çalışıyor: {url}")
        if open_ui:
            open_window(url)
        return
    srv = None
    for pt in [port] + list(range(port + 1, port + 30)):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", pt), Handler); break
        except OSError:
            continue
    pt = srv.server_address[1]
    jsave(SESSION_FILE, {"port": pt, "token": TOKEN, "pid": os.getpid()}, private=True)
    SERVER_PORT[0] = pt
    write_env_file(cfg())
    url = f"http://127.0.0.1:{pt}/#{TOKEN}"
    print(f"{APP} {VERSION} çalışıyor → {url}")
    threading.Thread(target=update_scheduler, daemon=True).start()
    threading.Thread(target=auto_system_setup, daemon=True).start()
    start_gateway()
    threading.Thread(target=scheduler_loop, daemon=True).start()
    threading.Thread(target=app_watch_loop, daemon=True).start()
    threading.Thread(target=brw_reattach, daemon=True).start()   # açık kalan 🌐 sekmelerini geri al
    start_phone()
    try:  # eski kayıtları temizle
        fl = sorted(os.listdir(LOG_DIR))
        for f in fl[:-400]:
            os.remove(os.path.join(LOG_DIR, f))
    except Exception:
        pass
    def idle_watch():  # pencere kapanınca ve iş yokken 10 dk sonra kapan
        while True:
            time.sleep(60)
            busy = any(j.status not in ("tamamlandı", "hata", "iptal") for j in JOBS.values()) or any(p.rc is None for p in PROCS.values())
            if not busy and time.time() - LAST_SEEN[0] > 600 and os.environ.get("CT_KEEPALIVE") != "1" and not GATEWAY_SRV[0] and not PHONE_SRV[0] and not any(x.get("enabled", True) for x in schedules()):
                os._exit(0)
    threading.Thread(target=idle_watch, daemon=True).start()
    if open_ui:
        threading.Timer(0.6, open_window, args=(url,)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass

# ───────────────────────────── CLI ─────────────────────────────
def cli_ask(kind, payload):
    B, P, R = "\033[1m", "\033[95m", "\033[0m"
    if kind in ("plan", "fix"):
        print(f"\n{P}{B}━━━ {'KURULUM PLANI' if kind == 'plan' else 'DÜZELTME ÖNERİSİ'}: {payload.get('name', '')} ━━━{R}")
        if payload.get("summary"): print("  " + payload["summary"])
        for w in payload.get("why", []): print(f"  • {w}")
        if payload.get("runtimes_missing"): print(f"{B}  Yerel çalışma ortamı indirilecek:{R} " + ", ".join(payload["runtimes_missing"]))
        if payload.get("deps"): print(f"{B}  Eksik sistem paketleri:{R}\n    " + "\n    ".join(payload["deps"]))
        print(f"{B}  Adımlar:{R}")
        for s in payload.get("steps", []): print("    $ " + s)
        for a in payload.get("actions", []): print(f"{B}  Çalıştırma:{R} [{a['label']}] {a['command']}")
        for w in payload.get("warnings", []): print(f"\033[93m  ⚠ {w}{R}")
        a = input(f"{P}Onaylıyor musun? [E/h]: {R}").strip().lower()
        return {"ok": a in ("", "e", "evet", "y", "yes"), "data": None}
    if kind in ("confirm", "bconfirm"):
        if payload.get("image"):
            print(f"  (ekran görüntüsü: {os.path.join(BRW_SHOTS, payload['image'])})")
        return {"ok": input(payload.get("message", "") + " [e/H]: ").strip().lower() in ("e", "evet", "y")}
    if kind == "question":
        print(f"\n{P}{B}🤖 Ajan:{R} {payload.get('question', '')}")
        for i, o in enumerate(payload.get("options", []), 1):
            print(f"   {P}{i}){R} {o}")
        a = input(f"{P}Sen (numara ya da yaz, boş = bitir): {R}").strip()
        if a.isdigit() and 1 <= int(a) <= len(payload.get("options", [])):
            a = payload["options"][int(a) - 1]
        return {"ok": bool(a), "data": {"answer": a}}
    if kind == "choose":
        for i, c in enumerate(payload["candidates"], 1):
            print(f"  {i}) {c['repo']} ⭐{c['stars']} — {c['description'][:90]}")
        a = input("Hangisi kurulsun? [1]: ").strip() or "1"
        return {"ok": True, "data": {"repo": payload["candidates"][int(a) - 1]["repo"]}} if a.isdigit() else {"ok": False}
    if kind == "manual":
        print(f"Şu komutu başka bir terminalde çalıştır:\n  cd {payload['cwd']} && {payload['command']}")
        return {"ok": input("Tamamlandı mı? [E/h]: ").strip().lower() in ("", "e", "evet")}
    return {"ok": False}

def main():
    args = sys.argv[1:]
    if not args:
        return serve(True)
    cmd = args[0]
    if cmd.startswith(("http://", "https://", "git@")) or re.match(r"^[\w.-]+/[\w.-]+$", cmd):
        args = ["kur"] + args; cmd = "kur"
    if cmd in ("kur", "install"):
        if len(args) < 2:
            print("Kullanım: cyphertool kur <github-link> [<link> ...]"); return
        for u in args[1:]:
            start_job(f"Kurulum: {u}", "install", install_flow, u, {}, cli=True)
    elif cmd in ("gorev", "görev", "ajan", "task"):
        start_job("Görev Ajanı", "agent", agent_flow, " ".join(args[1:]), {"workdir": os.getcwd()}, cli=True)
    elif cmd in ("liste", "list"):
        for slug, t in tools().items():
            print(f"{slug:28} {t.get('status', ''):10} {t.get('full_name', '')}  {'⬆ ' + t.get('update_info', '') if t.get('update_available') else ''}")
    elif cmd in ("calistir", "run"):
        t = tools().get(args[1]) if len(args) > 1 else None
        if not t:
            print("Araç bulunamadı. 'cyphertool liste' ile bak."); return
        os.execv(make_launcher(t, int(args[2]) if len(args) > 2 and args[2].isdigit() else 0), ["x"] + args[3:])
    elif cmd in ("kontrol", "check"):
        res = check_all_updates(cli=True)
        print("\n".join(f"⬆ {s}: {w}" for s, w in res) or "Tüm araçlar güncel.")
    elif cmd in ("guncelle", "update"):
        for s in (args[1:] or [s for s, t in tools().items() if t.get("update_available")]):
            start_job("Güncelleme", "update", update_flow, s, cli=True)
    elif cmd in ("disa-aktar", "export"):
        print("Dışa aktarıldı:", export_all("--tam" in args or "--full" in args, "--anahtarlar" in args))
    elif cmd in ("ice-aktar", "import"):
        start_job("İçe aktarma", "import", import_flow, os.path.abspath(args[1]), cli=True)
    elif cmd in ("sunucu", "server"):
        serve(False)
    elif cmd in ("-h", "--help", "yardim"):
        print(__doc__)
    else:
        print(__doc__)

if __name__ == "__main__":
    main()
