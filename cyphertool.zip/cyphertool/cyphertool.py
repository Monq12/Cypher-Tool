#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cypher Tool — GitHub araç kurucu, çalıştırıcı ve çoklu-API ajan paneli (Linux)

Kullanım:
  cyphertool                      Arayüzü aç
  cyphertool kur <link> [<link>]  Terminalden kur (ct <link> de olur)
  cyphertool liste                Kurulu araçları listele
  cyphertool calistir <ad>        Aracı terminalde çalıştır
  cyphertool gorev "<istek>"      Görev Ajanı: araştır, kur, dene, kullan (ct gorev ...)
  cyphertool kontrol              Güncellemeleri kontrol et (günlük zamanlayıcı bunu çağırır)
  cyphertool disa-aktar [--tam]   Tüm araçları dışa aktar
  cyphertool ice-aktar <dosya>    Dışa aktarılmış dosyayı içe aktar
  cyphertool sunucu               Sadece sunucuyu başlat (pencere açmadan)
"""
import os, sys, re, json, time, uuid, shutil, shlex, base64, platform, secrets, signal
import tarfile, zipfile, threading, subprocess, hashlib, tempfile, importlib.util, pty, fcntl
import urllib.request, urllib.error, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

APP = "Cypher Tool"
VERSION = "1.0.0"
APP_DIR = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(APP_DIR, "web")
CATALOG_FILE = os.path.join(APP_DIR, "catalog.json")
CONF_DIR = os.path.expanduser("~/.config/cyphertool")
CONF_FILE = os.path.join(CONF_DIR, "config.json")
TOOLS_FILE = os.path.join(CONF_DIR, "tools.json")
ENV_FILE = os.path.join(CONF_DIR, "env.sh")
SESSION_FILE = os.path.join(CONF_DIR, "session.json")
DATA = os.path.expanduser("~/CypherTool")
TOOLS_DIR = os.path.join(DATA, "tools")
ICON_DIR = os.path.join(DATA, "icons")
LAUNCH_DIR = os.path.join(DATA, "launchers")
EXPORT_DIR = os.path.join(DATA, "exports")
RT = os.path.join(DATA, "runtimes")
RT_BIN = os.path.join(RT, "bin")
UA = {"User-Agent": "CypherTool/" + VERSION}
SKIP_DIRS = {".git", "node_modules", ".venv", "venv", "__pycache__", "target", "dist", "build", ".tox"}

for d in (CONF_DIR, DATA, TOOLS_DIR, ICON_DIR, LAUNCH_DIR, EXPORT_DIR, RT_BIN):
    os.makedirs(d, exist_ok=True)

# ───────────────────────────── yardımcılar ─────────────────────────────
_lock = threading.RLock()

def jload(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return json.loads(json.dumps(default))

def jsave(path, obj, private=False):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    if private:
        os.chmod(tmp, 0o600)
    os.replace(tmp, path)

TR_MAP = str.maketrans("çğıöşüÇĞİÖŞÜâîû", "cgiosuCGIOSUaiu")

def slugify(s):
    s = s.strip().translate(TR_MAP)
    s = re.sub(r"[^A-Za-z0-9._-]+", "-", s).strip("-.").lower()
    return s or "arac"

def unique_dir(base, name):
    p = os.path.join(base, name); i = 2
    while os.path.exists(p):
        p = os.path.join(base, f"{name}-{i}"); i += 1
    return p

def q(s):
    return shlex.quote(str(s))

def now():
    return time.strftime("%Y-%m-%d %H:%M")

def is_root():
    return os.geteuid() == 0

def arch_vars():
    m = platform.machine().lower()
    go = {"x86_64": "amd64", "amd64": "amd64", "aarch64": "arm64", "arm64": "arm64"}.get(m, "arm" if m.startswith("armv7") else "386" if re.match(r"i\d86", m) else m)
    x64 = {"amd64": "x64", "arm64": "arm64"}.get(go, go)
    raw = {"amd64": "x86_64", "arm64": "aarch64"}.get(go, m)
    return {"arch_go": go, "arch_x64": x64, "arch": raw}

def os_info():
    info = {"name": platform.system()}
    try:
        for line in open("/etc/os-release"):
            k, _, v = line.strip().partition("=")
            info[k] = v.strip('"')
    except Exception:
        pass
    return info

def detect_pm():
    for pm in ("apt-get", "dnf", "pacman", "zypper", "apk"):
        if shutil.which(pm):
            return pm
    return None

def mem_gb():
    try:
        for line in open("/proc/meminfo"):
            if line.startswith("MemTotal"):
                return round(int(line.split()[1]) / 1024 / 1024, 1)
    except Exception:
        pass
    return 0

def gpu_info():
    if shutil.which("nvidia-smi"):
        try:
            out = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
                                 capture_output=True, text=True, timeout=5).stdout.strip().splitlines()
            if out:
                name, mem = out[0].rsplit(",", 1)
                return {"name": name.strip(), "vram_gb": round(int(mem) / 1024, 1)}
        except Exception:
            pass
    return {"name": "", "vram_gb": 0}

def base_env():
    env = dict(os.environ)
    env["PATH"] = os.pathsep.join([RT_BIN, os.path.join(RT, "node", "bin"), os.path.expanduser("~/.local/bin"), env.get("PATH", "")])
    env["DEBIAN_FRONTEND"] = "noninteractive"
    env["PYTHONUNBUFFERED"] = "1"
    env["UV_PYTHON_INSTALL_DIR"] = os.path.join(RT, "python")
    env.update(provider_env())
    return env

ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(\x07|\x1b\\)|\x1b[()][A-Za-z0-9]|\x1b[=>78]")

def clean_term(t):
    t = ANSI_RE.sub("", t).replace("\r\n", "\n")
    return re.sub(r"[^\n]*\r(?!\n)", "", t)

def http_get(url, timeout=30, headers=None, raw=False):
    req = urllib.request.Request(url, headers={**UA, **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read()
        return data if raw else data.decode("utf-8", "replace")

def http_json(url, body=None, headers=None, timeout=120, method=None):
    data = json.dumps(body).encode() if body is not None else None
    h = {**UA, "Content-Type": "application/json", **(headers or {})}
    req = urllib.request.Request(url, data=data, headers=h, method=method or ("POST" if data else "GET"))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            txt = r.read().decode("utf-8", "replace")
            return json.loads(txt) if txt.strip() else {}
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}: {e.read().decode('utf-8', 'replace')[:400]}")

def download(url, dest, log=None, headers=None):
    req = urllib.request.Request(url, headers={**UA, **(headers or {})})
    os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    with urllib.request.urlopen(req, timeout=60) as r, open(dest + ".part", "wb") as f:
        total = int(r.headers.get("Content-Length") or 0); got = 0; last = 0
        while True:
            chunk = r.read(1 << 16)
            if not chunk:
                break
            f.write(chunk); got += len(chunk)
            if log and got - last > 8 << 20:
                last = got
                log(f"   … {got >> 20} MB" + (f" / {total >> 20} MB" if total else ""))
        final_url = r.geturl()
    os.replace(dest + ".part", dest)
    return final_url

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()

# ───────────────────────────── yapılandırma ─────────────────────────────
PROVIDER_PRESETS = [
    {"preset": "OpenAI", "type": "openai", "base_url": "https://api.openai.com/v1", "model": "gpt-4o-mini", "env": "OPENAI_API_KEY", "signup": "https://platform.openai.com/api-keys"},
    {"preset": "Anthropic (Claude)", "type": "anthropic", "base_url": "https://api.anthropic.com/v1", "model": "claude-sonnet-5-5", "env": "ANTHROPIC_API_KEY", "signup": "https://console.anthropic.com/"},
    {"preset": "Google Gemini", "type": "gemini", "base_url": "https://generativelanguage.googleapis.com/v1beta", "model": "gemini-2.5-flash", "env": "GEMINI_API_KEY", "signup": "https://aistudio.google.com/apikey", "free": True},
    {"preset": "OpenRouter", "type": "openai", "base_url": "https://openrouter.ai/api/v1", "model": "openrouter/free", "env": "OPENROUTER_API_KEY", "signup": "https://openrouter.ai/keys", "free": True},
    {"preset": "Groq", "type": "openai", "base_url": "https://api.groq.com/openai/v1", "model": "llama-3.3-70b-versatile", "env": "GROQ_API_KEY", "signup": "https://console.groq.com/keys", "free": True},
    {"preset": "Mistral", "type": "openai", "base_url": "https://api.mistral.ai/v1", "model": "mistral-small-latest", "env": "MISTRAL_API_KEY", "signup": "https://console.mistral.ai/api-keys", "free": True},
    {"preset": "Cerebras", "type": "openai", "base_url": "https://api.cerebras.ai/v1", "model": "llama3.1-8b", "env": "CEREBRAS_API_KEY", "signup": "https://cloud.cerebras.ai/", "free": True},
    {"preset": "GitHub Models", "type": "openai", "base_url": "https://models.github.ai/inference", "model": "openai/gpt-4o-mini", "env": "GITHUB_TOKEN", "signup": "https://github.com/settings/tokens", "free": True},
    {"preset": "DeepSeek", "type": "openai", "base_url": "https://api.deepseek.com/v1", "model": "deepseek-chat", "env": "DEEPSEEK_API_KEY", "signup": "https://platform.deepseek.com/"},
    {"preset": "xAI (Grok)", "type": "openai", "base_url": "https://api.x.ai/v1", "model": "grok-3-mini", "env": "XAI_API_KEY", "signup": "https://console.x.ai/"},
    {"preset": "Ollama (yerel, anahtarsız)", "type": "openai", "base_url": "http://127.0.0.1:11434/v1", "model": "qwen2.5-coder:7b", "env": "", "keyless": True},
    {"preset": "LM Studio (yerel, anahtarsız)", "type": "openai", "base_url": "http://127.0.0.1:1234/v1", "model": "local-model", "env": "", "keyless": True},
    {"preset": "Pollinations (anahtarsız, bulut)", "type": "openai", "base_url": "https://text.pollinations.ai/openai", "model": "openai", "env": "", "keyless": True},
    {"preset": "Özel (OpenAI uyumlu)", "type": "openai", "base_url": "", "model": "", "env": ""},
]

DEFAULT_AGENTS = [
    {"id": "kod", "name": "Kod Ustası", "provider": "", "model": "", "icon": "💻",
     "system": "Sen deneyimli bir yazılım mühendisisin. Temiz, çalışan, test edilmiş kod yazarsın. Kodu tam ve eksiksiz verirsin, kısa açıklama eklersin. Türkçe cevap ver."},
    {"id": "kurulum", "name": "Kurulum Uzmanı", "provider": "", "model": "", "icon": "🛠️",
     "system": "Linux kurulum uzmanısın. Bir aracın kurulumu, bağımlılıkları ve hataları için adım adım, kopyala-yapıştır yapılabilir komutlar verirsin. Komutları ```bash blokları içinde ver. Türkçe cevap ver."},
    {"id": "hata", "name": "Hata Ayıklayıcı", "provider": "", "model": "", "icon": "🐞",
     "system": "Hata çıktılarını analiz edip kök nedeni bulursun ve kesin çözüm önerirsin. Türkçe cevap ver."},
    {"id": "guvenlik", "name": "Güvenlik Denetçisi", "provider": "", "model": "", "icon": "🛡️",
     "system": "Bir aracın kurulum betiklerini ve komutlarını güvenlik açısından incelersin: şüpheli indirmeler, gereksiz root yetkisi, veri sızdırma riskleri. Riskleri net sırala. Türkçe cevap ver."},
    {"id": "arastirma", "name": "Araştırmacı", "provider": "", "model": "", "icon": "🔎",
     "system": "Konuları derinlemesine açıklarsın, farklı görüşleri dengeli verirsin, emin olmadığın yerleri belirtirsin. Türkçe cevap ver."},
]

DEFAULT_CFG = {
    "providers": [], "default_provider": "", "failover": True, "github_token": "",
    "agents": DEFAULT_AGENTS, "use_ai": True, "auto_shortcut": True, "release_assets": True,
    "update_check": True, "update_default_mode": "sor", "last_update_check": 0,
    "agent_rules": "", "agent_defaults": {"workdir": "", "provider": "", "persona": "", "auto": False},
}

def cfg():
    with _lock:
        c = jload(CONF_FILE, DEFAULT_CFG)
        for k, v in DEFAULT_CFG.items():
            c.setdefault(k, json.loads(json.dumps(v)))
        return c

def save_cfg(c):
    with _lock:
        jsave(CONF_FILE, c, private=True)
        write_env_file(c)

def tools():
    with _lock:
        return jload(TOOLS_FILE, {})

def save_tools(t):
    with _lock:
        jsave(TOOLS_FILE, t)

def update_tool(_slug, **kw):
    with _lock:
        t = tools()
        if _slug in t:
            t[_slug].update(kw); save_tools(t)
            return t[_slug]

def provider_env(c=None):
    c = c or cfg(); env = {}
    for p in c.get("providers", []):
        if not p.get("enabled", True):
            continue
        var = p.get("env") or ""
        if var and p.get("api_key"):
            env.setdefault(var, p["api_key"])
            if var == "GEMINI_API_KEY":
                env.setdefault("GOOGLE_API_KEY", p["api_key"])
        if "11434" in p.get("base_url", ""):
            env.setdefault("OLLAMA_HOST", "http://127.0.0.1:11434")
            env.setdefault("OLLAMA_API_BASE", "http://127.0.0.1:11434")
    return env

def write_env_file(c):
    lines = ["# Cypher Tool tarafından oluşturuldu — API anahtarları (sadece senin okuyabileceğin dosya)"]
    for k, v in provider_env(c).items():
        lines.append(f"export {k}={q(v)}")
    with open(ENV_FILE, "w") as f:
        f.write("\n".join(lines) + "\n")
    os.chmod(ENV_FILE, 0o600)

def catalog():
    return jload(CATALOG_FILE, {"tools": []}).get("tools", [])

MEMORY_FILE = os.path.join(CONF_DIR, "ajan_hafiza.json")
USER_CATALOG = os.path.join(CONF_DIR, "ogrenilen_tarifler.json")

def mem_all():
    return jload(MEMORY_FILE, [])

def mem_add(text, kind="ders", tags=None):
    text = (text or "").strip()
    if not text:
        return
    with _lock:
        m = mem_all()
        if any(x["text"].lower() == text.lower() for x in m):
            return
        m.append({"id": uuid.uuid4().hex[:8], "text": text[:600], "kind": kind, "tags": tags or [], "at": now()})
        jsave(MEMORY_FILE, m[-400:])

def mem_context(task, n=40):
    m = mem_all()
    if not m:
        return ""
    words = {w for w in re.findall(r"\w{4,}", task.lower())}
    rel = [x for x in m if words & set(re.findall(r"\w{4,}", x["text"].lower()))]
    pick = (rel[-20:] + [x for x in m if x["kind"] == "tercih"][-10:] + m[-n:])
    seen, out = set(), []
    for x in pick:
        if x["id"] not in seen:
            seen.add(x["id"]); out.append(f"- [{x['kind']}] {x['text']}")
    return "\n".join(out[-n:])

def save_user_recipe(tool, tested=None):
    """Başarılı kurulumun tarifini saklar; aynı araç bir dahaki sefere analiz edilmeden kurulur."""
    if not tool.get("source", "").startswith("http") or tool.get("catalog_id"):
        return
    with _lock:
        uc = jload(USER_CATALOG, [])
        src = tool["source"].lower().rstrip("/")
        uc = [x for x in uc if x["source"].lower().rstrip("/") != src]
        uc.append({"id": "ogrenilen-" + tool["slug"], "source": tool["source"], "full_name": tool.get("full_name", ""), "name": tool["name"],
                   "category": tool.get("category") or "Öğrenilen tarif", "learned": True, "tested": tested,
                   "install": [{"type": "release", **json.loads(x[9:])} if x.startswith("@release ") else {"type": "shell", "command": x} for x in tool.get("steps", [])],
                   "actions": tool.get("actions", []), "runtimes": tool.get("runtimes", []), "system_packages": tool.get("system_packages", []),
                   "guide_tr": tool.get("guide_tr", ""), "at": now()})
        jsave(USER_CATALOG, uc)

# ───────────────────────────── LLM yönlendirici ─────────────────────────────
def llm_call(p, messages, system="", model=None, timeout=180):
    t = p.get("type", "openai"); m = model or p.get("model"); key = p.get("api_key", "")
    base = (p.get("base_url") or "").rstrip("/")
    if t == "anthropic":
        body = {"model": m, "max_tokens": 4096, "messages": messages}
        if system:
            body["system"] = system
        r = http_json(base + "/messages", body, {"x-api-key": key, "anthropic-version": "2023-06-01"}, timeout)
        return "".join(b.get("text", "") for b in r.get("content", []))
    if t == "gemini":
        contents = [{"role": "model" if x["role"] == "assistant" else "user", "parts": [{"text": x["content"]}]} for x in messages]
        body = {"contents": contents}
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        r = http_json(f"{base}/models/{m}:generateContent?key={urllib.parse.quote(key)}", body, {}, timeout)
        return "".join(x.get("text", "") for x in r["candidates"][0]["content"]["parts"])
    h = {"Authorization": f"Bearer {key}"} if key else {}
    if "openrouter.ai" in base:
        h.update({"HTTP-Referer": "https://cyphertool.local", "X-Title": APP})
    msgs = ([{"role": "system", "content": system}] if system else []) + messages
    r = http_json(base + "/chat/completions", {"model": m, "messages": msgs, "temperature": 0.3}, h, timeout)
    return r["choices"][0]["message"]["content"] or ""

def llm_available():
    return any(p.get("enabled", True) for p in cfg().get("providers", []))

def llm_ask(messages, system="", provider_id="", model="", log=None):
    c = cfg(); provs = [p for p in c.get("providers", []) if p.get("enabled", True)]
    if not provs:
        raise RuntimeError("Hiç API eklenmemiş. 'API'ler' veya 'Ücretsiz AI' sekmesinden ekleyin.")
    first = provider_id or c.get("default_provider", "")
    provs.sort(key=lambda p: 0 if p.get("id") == first else 1)
    if not c.get("failover", True):
        provs = provs[:1]
    errs = []
    for p in provs:
        try:
            return llm_call(p, messages, system, model if p.get("id") == first and model else None), p
        except Exception as e:
            errs.append(f"{p.get('name')}: {e}")
            if log:
                log(f"⚠ {p.get('name')} hata verdi, sıradakine geçiliyor… ({str(e)[:120]})")
    raise RuntimeError("Tüm API'ler başarısız:\n" + "\n".join(errs))

def extract_json(text):
    m = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.S)
    s = m.group(1) if m else text[text.find("{"): text.rfind("}") + 1]
    return json.loads(s)

# ───────────────────────────── bağımlılıklar ─────────────────────────────
# anahtar: (apt, dnf, pacman, zypper, apk)
PKG = {
    "python3": ("python3", "python3", "python", "python3", "python3"),
    "venv": ("python3-venv", "python3", "python", "python3", "py3-virtualenv"),
    "pip": ("python3-pip", "python3-pip", "python-pip", "python3-pip", "py3-pip"),
    "git": ("git", "git", "git", "git", "git"),
    "git-lfs": ("git-lfs", "git-lfs", "git-lfs", "git-lfs", "git-lfs"),
    "curl": ("curl", "curl", "curl", "curl", "curl"),
    "wget": ("wget", "wget", "wget", "wget", "wget"),
    "make": ("make", "make", "make", "make", "make"),
    "gcc": ("build-essential", "gcc gcc-c++", "base-devel", "gcc gcc-c++", "build-base"),
    "cmake": ("cmake", "cmake", "cmake", "cmake", "cmake"),
    "pkg-config": ("pkg-config", "pkgconf-pkg-config", "pkgconf", "pkg-config", "pkgconf"),
    "nodejs": ("nodejs", "nodejs", "nodejs", "nodejs", "nodejs"),
    "npm": ("npm", "npm", "npm", "npm", "npm"),
    "cargo": ("cargo", "cargo", "rust", "cargo", "cargo"),
    "go": ("golang-go", "golang", "go", "go", "go"),
    "java": ("default-jdk", "java-latest-openjdk", "jdk-openjdk", "java-21-openjdk", "openjdk21"),
    "maven": ("maven", "maven", "maven", "maven", "maven"),
    "ruby": ("ruby-full", "ruby", "ruby", "ruby", "ruby"),
    "php": ("php-cli", "php-cli", "php", "php", "php"),
    "docker": ("docker.io", "docker", "docker", "docker", "docker"),
    "ffmpeg": ("ffmpeg", "ffmpeg", "ffmpeg", "ffmpeg", "ffmpeg"),
    "unzip": ("unzip", "unzip", "unzip", "unzip", "unzip"),
    "7z": ("p7zip-full", "p7zip p7zip-plugins", "p7zip", "p7zip-full", "p7zip"),
    "unrar": ("unrar-free", "unrar", "unrar", "unrar", "unrar"),
    "bsdtar": ("libarchive-tools", "bsdtar", "libarchive", "bsdtar", "libarchive-tools"),
    "tk": ("python3-tk", "python3-tkinter", "tk", "python3-tk", "py3-tkinter"),
    "xdg-utils": ("xdg-utils", "xdg-utils", "xdg-utils", "xdg-utils", "xdg-utils"),
    "zstd": ("zstd", "zstd", "zstd", "zstd", "zstd"),
    "notify-send": ("libnotify-bin", "libnotify", "libnotify", "libnotify-tools", "libnotify"),
}
PM_IDX = {"apt-get": 0, "dnf": 1, "pacman": 2, "zypper": 3, "apk": 4}
CMD2KEY = {"python3": "python3", "python": "python3", "pip": "pip", "pip3": "pip", "git": "git", "curl": "curl",
           "wget": "wget", "make": "make", "gcc": "gcc", "g++": "gcc", "cc": "gcc", "cmake": "cmake",
           "pkg-config": "pkg-config", "cargo": "cargo", "rustc": "cargo", "go": "go", "java": "java",
           "javac": "java", "mvn": "maven", "ruby": "ruby", "gem": "ruby", "php": "php", "docker": "docker",
           "ffmpeg": "ffmpeg", "unzip": "unzip", "7z": "7z", "unrar": "unrar", "bsdtar": "bsdtar", "zstd": "zstd"}
RUNTIME_CMDS = {"node": "node22", "npm": "node22", "npx": "node22", "uv": "uv", "uvx": "uv"}
NAME_OK = re.compile(r"^[A-Za-z0-9][A-Za-z0-9.+_:@-]*$")

def which(cmd):
    return shutil.which(cmd, path=base_env()["PATH"])

def check_key(k):
    if k == "venv":
        return subprocess.run(["python3", "-c", "import venv, ensurepip"], capture_output=True).returncode == 0 if shutil.which("python3") else False
    if k == "tk":
        return subprocess.run(["python3", "-c", "import tkinter"], capture_output=True).returncode == 0
    if k == "gcc":
        return bool(shutil.which("gcc") and shutil.which("make"))
    if k == "7z":
        return bool(shutil.which("7z") or shutil.which("7za"))
    if k == "nodejs":
        return bool(which("node"))
    if k == "notify-send":
        return bool(shutil.which("notify-send"))
    cmd = {"java": "java", "maven": "mvn", "ruby": "ruby", "docker": "docker", "go": "go", "cargo": "cargo"}.get(k, k)
    return bool(shutil.which(cmd))

def pkg_installed(pm, name):
    try:
        cmd = {"apt-get": ["dpkg", "-s", name], "dnf": ["rpm", "-q", name], "zypper": ["rpm", "-q", name],
               "pacman": ["pacman", "-Q", name], "apk": ["apk", "info", "-e", name]}[pm]
        return subprocess.run(cmd, capture_output=True).returncode == 0
    except Exception:
        return False

def install_line(pm, pkgs):
    s = "" if is_root() else "sudo "
    p = " ".join(pkgs)
    return {"apt-get": f"{s}apt-get install -y {p}", "dnf": f"{s}dnf install -y {p}",
            "pacman": f"{s}pacman -S --needed --noconfirm {p}", "zypper": f"{s}zypper --non-interactive install {p}",
            "apk": f"{s}apk add {p}"}[pm]

def dep_commands(keys, raw_pkgs=()):
    """Eksik anahtarlar için paket yöneticisi komutları üretir."""
    pm = detect_pm()
    missing = [k for k in sorted(set(keys)) if k in PKG and not check_key(k)]
    if not pm:
        return [], missing
    pkgs = []
    for k in missing:
        pkgs += PKG[k][PM_IDX[pm]].split()
    for r in raw_pkgs:
        if NAME_OK.match(r or "") and not pkg_installed(pm, r) and r not in pkgs:
            pkgs.append(r)
    if not pkgs:
        return [], missing
    cmds = []
    if pm == "apt-get":
        cmds.append(("" if is_root() else "sudo ") + "apt-get update")
    cmds.append(install_line(pm, pkgs))
    return cmds, missing

# ───────────────────────────── çalışma zamanları (sudo gerektirmez) ─────────────────────────────
def node_version(path="node"):
    try:
        out = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=10, env=base_env()).stdout.strip()
        return tuple(int(x) for x in out.lstrip("v").split(".")[:3])
    except Exception:
        return (0, 0, 0)

def runtime_ok(name):
    if name == "node22":
        n = which("node")
        return bool(n) and node_version(n) >= (22, 12, 0)
    if name == "uv":
        return bool(which("uv"))
    return True

def ensure_runtime(name, log):
    if runtime_ok(name):
        return True
    av = arch_vars()
    if name == "node22":
        log("⬇ Node.js 22 (LTS) indiriliyor → ~/CypherTool/runtimes/node (sudo gerekmez)")
        idx = json.loads(http_get("https://nodejs.org/dist/index.json"))
        v = next(x["version"] for x in idx if x["version"].startswith("v22."))
        fn = f"node-{v}-linux-{av['arch_x64']}.tar.xz"
        tmp = os.path.join(RT, fn)
        download(f"https://nodejs.org/dist/{v}/{fn}", tmp, log)
        sums = http_get(f"https://nodejs.org/dist/{v}/SHASUMS256.txt")
        exp = next((l.split()[0] for l in sums.splitlines() if l.endswith(fn)), "")
        if exp and exp != sha256(tmp):
            raise RuntimeError("Node.js sağlama (SHA256) uyuşmadı")
        log("✔ SHA256 doğrulandı")
        with tarfile.open(tmp) as tf:
            safe_tar_extract(tf, RT)
        os.remove(tmp)
        link = os.path.join(RT, "node")
        if os.path.islink(link) or os.path.exists(link):
            os.remove(link) if os.path.islink(link) else shutil.rmtree(link)
        os.symlink(os.path.join(RT, fn[:-7]), link)
        log(f"✔ Node.js {v} hazır")
        return True
    if name == "uv":
        log("⬇ uv (Python yöneticisi) indiriliyor → ~/CypherTool/runtimes/bin")
        fn = f"uv-{av['arch']}-unknown-linux-gnu.tar.gz"
        tmp = os.path.join(RT, fn)
        download(f"https://github.com/astral-sh/uv/releases/latest/download/{fn}", tmp, log)
        try:
            exp = http_get(f"https://github.com/astral-sh/uv/releases/latest/download/{fn}.sha256").split()[0]
            if exp != sha256(tmp):
                raise RuntimeError("uv sağlaması uyuşmadı")
            log("✔ SHA256 doğrulandı")
        except urllib.error.HTTPError:
            pass
        with tarfile.open(tmp) as tf:
            for m in tf.getmembers():
                b = os.path.basename(m.name)
                if b in ("uv", "uvx") and m.isfile():
                    with tf.extractfile(m) as src, open(os.path.join(RT_BIN, b), "wb") as dst:
                        shutil.copyfileobj(src, dst)
                    os.chmod(os.path.join(RT_BIN, b), 0o755)
        os.remove(tmp)
        log("✔ uv hazır")
        return True
    return False

# ───────────────────────────── arşivler ─────────────────────────────
ARCH_EXT = (".zip", ".rar", ".7z", ".tar.gz", ".tgz", ".tar.xz", ".txz", ".tar.bz2", ".tbz2", ".tar", ".tar.zst")

def is_archive(p):
    return p.lower().endswith(ARCH_EXT)

def safe_tar_extract(tf, out):
    try:
        tf.extractall(out, filter="data")
    except TypeError:
        root = os.path.realpath(out)
        for m in tf.getmembers():
            if not os.path.realpath(os.path.join(out, m.name)).startswith(root):
                raise RuntimeError("Arşivde güvensiz yol: " + m.name)
        tf.extractall(out)

def extractor_available(path):
    low = path.lower()
    if low.endswith((".zip",)) or re.search(r"\.(tar(\.(gz|xz|bz2))?|tgz|txz|tbz2)$", low):
        return True
    if low.endswith(".tar.zst"):
        return bool(shutil.which("zstd") or shutil.which("bsdtar"))
    return any(shutil.which(x) for x in ("7z", "7za", "unrar", "unar", "bsdtar"))

def extract(path, out, log):
    os.makedirs(out, exist_ok=True); low = path.lower()
    log(f"📦 Arşiv açılıyor: {os.path.basename(path)}")
    if low.endswith(".zip"):
        with zipfile.ZipFile(path) as z:
            root = os.path.realpath(out)
            for n in z.namelist():
                if not os.path.realpath(os.path.join(out, n)).startswith(root):
                    raise RuntimeError("Arşivde güvensiz yol: " + n)
            z.extractall(out)
            for info in z.infolist():  # çalıştırılabilir izinlerini koru
                mode = info.external_attr >> 16
                if mode & 0o111:
                    try: os.chmod(os.path.join(out, info.filename), mode & 0o777)
                    except Exception: pass
        return
    if re.search(r"\.(tar(\.(gz|xz|bz2))?|tgz|txz|tbz2)$", low):
        with tarfile.open(path) as tf:
            safe_tar_extract(tf, out)
        return
    tries = [["7z", "x", "-y", f"-o{out}", path], ["7za", "x", "-y", f"-o{out}", path],
             ["unrar", "x", "-o+", path, out + "/"], ["unar", "-f", "-o", out, path], ["bsdtar", "-xf", path, "-C", out]]
    if low.endswith(".tar.zst"):
        tries.insert(0, ["tar", "--zstd", "-xf", path, "-C", out])
    for t in tries:
        if shutil.which(t[0]):
            r = subprocess.run(t, capture_output=True, text=True)
            if r.returncode == 0:
                return
            log(f"   {t[0]} başarısız: {r.stderr[-300:]}")
    raise RuntimeError("Bu arşivi açacak araç yok (7z / unrar / bsdtar).")

def find_archives(root, depth=2):
    res = []
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS]
        if d[len(root):].count(os.sep) >= depth:
            dirs[:] = []
        for f in files:
            p = os.path.join(d, f)
            if is_archive(f) and os.path.getsize(p) < 800 << 20 and "_acik" not in d and "_indirilen" not in d and ".dl-" not in d and "_release" not in d:
                res.append(p)
    return res

# ───────────────────────────── GitHub ─────────────────────────────
GH_RE = re.compile(r"^https?://(?:www\.)?github\.com/([^/\s]+)/([^/\s#?]+?)(?:\.git)?(?:/tree/([^?#\s]+))?/?(?:[?#].*)?$")

def parse_source(s):
    s = s.strip().strip("'\"")
    if os.path.exists(os.path.expanduser(s)):
        return {"kind": "local", "path": os.path.abspath(os.path.expanduser(s)), "name": os.path.basename(s.rstrip("/"))}
    if re.match(r"^[\w.-]+/[\w.-]+$", s):
        s = "https://github.com/" + s
    if s.startswith("git@github.com:"):
        s = "https://github.com/" + s.split(":", 1)[1]
    path = urllib.parse.urlparse(s).path
    if is_archive(path) or path.lower().endswith((".appimage", ".deb")):
        m = GH_RE.match(s.split("/releases/")[0]) if "/releases/" in s else None
        return {"kind": "archive", "url": s, "name": os.path.basename(path),
                "owner": m.group(1) if m else "", "repo": m.group(2) if m else ""}
    m = GH_RE.match(s)
    if m:
        return {"kind": "git", "owner": m.group(1), "repo": m.group(2), "branch": m.group(3) or "",
                "url": f"https://github.com/{m.group(1)}/{m.group(2)}", "name": m.group(2)}
    if re.match(r"^https?://", s):
        return {"kind": "git", "owner": "", "repo": "", "branch": "", "url": s, "name": os.path.basename(path).removesuffix(".git") or "repo"}
    raise ValueError(f"Tanınmayan kaynak: {s}")

def gh_api(path):
    tok = cfg().get("github_token", "")
    h = {"Accept": "application/vnd.github+json"}
    if tok:
        h["Authorization"] = f"Bearer {tok}"
    return http_json("https://api.github.com" + path, headers=h, timeout=30)

def gh_meta(owner, repo):
    try:
        r = gh_api(f"/repos/{owner}/{repo}")
        return {"full_name": r.get("full_name"), "description": r.get("description") or "",
                "stars": r.get("stargazers_count", 0), "language": r.get("language") or "",
                "license": (r.get("license") or {}).get("spdx_id") or "", "topics": r.get("topics", []),
                "homepage": r.get("homepage") or "", "default_branch": r.get("default_branch", ""),
                "html_url": r.get("html_url"), "owner_avatar": (r.get("owner") or {}).get("avatar_url", ""),
                "fork": r.get("fork", False), "parent": ((r.get("parent") or {}).get("full_name") or "")}
    except Exception:
        return {"full_name": f"{owner}/{repo}", "html_url": f"https://github.com/{owner}/{repo}"}

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None

def latest_release_tag(repo):
    """Önce API kotası harcamadan /releases/latest yönlendirmesinden, olmazsa API'den etiket okunur."""
    try:
        op = urllib.request.build_opener(_NoRedirect)
        try:
            r = op.open(urllib.request.Request(f"https://github.com/{repo}/releases/latest", headers=UA), timeout=20)
            loc = r.geturl()
        except urllib.error.HTTPError as e:
            loc = e.headers.get("Location") or ""
        m = re.search(r"/releases/tag/([^/?#]+)", loc)
        if m:
            return urllib.parse.unquote(m.group(1))
    except Exception:
        pass
    try:
        return gh_api(f"/repos/{repo}/releases/latest").get("tag_name", "")
    except Exception:
        return ""

BAD_ASSET = (".exe", ".msi", ".dmg", ".pkg", ".apk", ".sha256", ".sha512", ".sig", ".asc", ".sbom", ".pem", ".txt",
             "windows", "win64", "win32", "-win-", "macos", "darwin", "apple", "freebsd", "android", ".ps1", ".nupkg")

def pick_asset(assets):
    av = arch_vars(); best = None; bs = -99
    other_arch = [a for a in ("arm64", "aarch64", "armv7", "i386", "i686", "386", "x86_64", "amd64", "x64") if a not in (av["arch_go"], av["arch"], av["arch_x64"])]
    for a in assets:
        n = a["name"].lower()
        if any(b in n for b in BAD_ASSET):
            continue
        s = 0
        if "linux" in n: s += 5
        if any(x in n for x in (av["arch_go"], av["arch"], av["arch_x64"])): s += 4
        elif any(x in n for x in other_arch): s -= 8
        if n.endswith(".appimage"): s += 4
        elif n.endswith((".tar.gz", ".tgz", ".tar.xz")): s += 3
        elif n.endswith((".zip", ".rar", ".7z")): s += 2
        elif n.endswith(".deb") and detect_pm() == "apt-get": s += 1
        elif n.endswith(".rpm") and detect_pm() in ("dnf", "zypper"): s += 1
        elif "." not in n.rsplit("/", 1)[-1][-6:] and "linux" in n: s += 2  # çıplak ikili
        else: s -= 3
        if s > bs:
            bs, best = s, a
    return best if bs >= 3 else None

def fetch_icon(slug, root, owner, prefer=""):
    """Önce repodaki logo, yoksa GitHub sahibinin avatarı."""
    for f in os.listdir(ICON_DIR):
        if f.startswith(slug + "."):
            os.remove(os.path.join(ICON_DIR, f))
    cands = []
    if root and os.path.isdir(root):
        for d, dirs, files in os.walk(root):
            dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not x.startswith(".")]
            if d[len(root):].count(os.sep) >= 3:
                dirs[:] = []
            for f in files:
                fl = f.lower()
                if fl.endswith((".png", ".svg")) and re.search(r"(^|[-_.])(logo|icon|app-icon|favicon)", fl) and os.path.getsize(os.path.join(d, f)) > 600:
                    cands.append(os.path.join(d, f))
        cands.sort(key=lambda p: (0 if "logo" in p.lower() else 1, 0 if p.endswith(".png") else 1, len(p)))
    if prefer and root and os.path.isfile(os.path.join(root, prefer)):
        cands.insert(0, os.path.join(root, prefer))
    if cands:
        ext = os.path.splitext(cands[0])[1].lower()
        dst = os.path.join(ICON_DIR, slug + ext)
        shutil.copy(cands[0], dst)
        return os.path.basename(dst)
    if owner:
        try:
            dst = os.path.join(ICON_DIR, slug + ".png")
            download(f"https://github.com/{owner}.png?size=256", dst)
            return os.path.basename(dst)
        except Exception:
            pass
    return ""

# ───────────────────────────── README / analiz ─────────────────────────────
README_RE = re.compile(r"^(readme|install|installation|kurulum|setup|building|usage|quickstart)(\.[\w]+)?$", re.I)

def find_readmes(root):
    out = []
    for d, dirs, files in os.walk(root):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS and not x.startswith("."))
        depth = d[len(root):].count(os.sep)
        if depth >= 3:
            dirs[:] = []
        for f in files:
            if README_RE.match(f):
                out.append((depth, 0 if f.lower().startswith("readme") else 1, os.path.join(d, f)))
    return [p for _, _, p in sorted(out)]

def read_readme(root, limit=14000):
    txt = ""
    for p in find_readmes(root)[:4]:
        try:
            t = open(p, encoding="utf-8", errors="replace").read()
        except Exception:
            continue
        txt += f"\n\n===== {os.path.relpath(p, root)} =====\n" + t
        if len(txt) > limit:
            break
    return txt[:limit]

def file_tree(root, limit=120):
    lines = []
    for d, dirs, files in os.walk(root):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS and not x.startswith("."))
        depth = d[len(root):].count(os.sep)
        if depth >= 2:
            dirs[:] = []
        for f in sorted(files)[:40]:
            lines.append(os.path.relpath(os.path.join(d, f), root))
            if len(lines) >= limit:
                return "\n".join(lines)
    return "\n".join(lines)

def readme_intro(root):
    for p in find_readmes(root)[:1]:
        for para in re.split(r"\n\s*\n", open(p, encoding="utf-8", errors="replace").read()):
            s = para.strip()
            if s and not s.startswith(("#", "<", "[!", "![", "[![", "|", "```", "---")) and len(s) > 40:
                return re.sub(r"\s+", " ", re.sub(r"[*_`]", "", s))[:500]
    return ""

IMPORT_MAP = {"cv2": "opencv-python", "PIL": "pillow", "yaml": "pyyaml", "sklearn": "scikit-learn", "bs4": "beautifulsoup4",
              "Crypto": "pycryptodome", "Cryptodome": "pycryptodomex", "dotenv": "python-dotenv", "serial": "pyserial",
              "usb": "pyusb", "telegram": "python-telegram-bot", "discord": "discord.py", "dateutil": "python-dateutil",
              "jwt": "PyJWT", "magic": "python-magic", "docx": "python-docx", "pptx": "python-pptx", "attr": "attrs",
              "OpenSSL": "pyOpenSSL", "nmap": "python-nmap", "whois": "python-whois", "dns": "dnspython", "socks": "PySocks",
              "skimage": "scikit-image", "fitz": "PyMuPDF", "Xlib": "python-xlib", "pkg_resources": "setuptools",
              "yt_dlp": "yt-dlp", "speech_recognition": "SpeechRecognition", "websocket": "websocket-client",
              "github": "PyGithub", "git": "GitPython", "MySQLdb": "mysqlclient", "psycopg2": "psycopg2-binary",
              "zmq": "pyzmq", "google.generativeai": "google-generativeai", "Levenshtein": "python-Levenshtein",
              "win32api": None, "win32con": None, "winreg": None, "msvcrt": None, "_winapi": None, "gi": None, "google": None}

def scan_py_imports(root, limit=500):
    names, local = set(), set(); n = 0
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not x.startswith(".")]
        for x in dirs:
            local.add(x)
        for f in files:
            if f.endswith(".py"):
                local.add(f[:-3]); n += 1
                if n > limit:
                    break
                try:
                    src = open(os.path.join(d, f), encoding="utf-8", errors="replace").read()
                except Exception:
                    continue
                for m in re.finditer(r"^\s*(?:from\s+([\w.]+)\s+import|import\s+([\w.,\s]+?))\s*(?:#.*)?$", src, re.M):
                    for part in (m.group(1) or m.group(2) or "").split(","):
                        top = part.strip().split(" ")[0].split(".")[0]
                        if top:
                            names.add(top)
    std = set(getattr(sys, "stdlib_module_names", ())) | {"__future__"}
    return sorted(n for n in names if n not in std and n not in local and not n.startswith("_"))

def pip_names(mods):
    out = []
    for m in mods:
        v = IMPORT_MAP.get(m, m)
        if v and v not in out:
            out.append(v)
    return out

DANGER = [(r"rm\s+-rf\s+(/|~|\$HOME)(\s|$)", "Kök/ev dizinini silen komut!"), (r"\bmkfs\b|\bdd\s+if=.*of=/dev/", "Disk biçimlendirme/yazma!"),
          (r"(curl|wget)[^|]*\|\s*(sudo\s+)?(ba)?sh", "İnternetten indirilen betik doğrudan çalıştırılıyor (kaynağa güvendiğinden emin ol)."),
          (r"chmod\s+-R\s+777\s+/", "Tüm sisteme 777 izni!"), (r":\(\)\s*\{", "Fork bombası!"), (r">\s*/dev/sd", "Diske doğrudan yazma!")]

def danger_warnings(cmds):
    w = []
    for c in cmds:
        for rx, msg in DANGER:
            if re.search(rx, c):
                w.append(f"{msg}  →  {c[:120]}")
    return w

def heuristic_plan(root, name):
    f = lambda p: os.path.exists(os.path.join(root, p))
    steps, actions, runtimes, warn = [], [], [], []
    slug = slugify(name)
    top = sorted(os.listdir(root)) if os.path.isdir(root) else []
    appimgs = [os.path.relpath(os.path.join(d, x), root) for d, _, fs in os.walk(root) for x in fs if x.lower().endswith(".appimage")]
    if appimgs:
        steps.append(f"chmod +x {q(appimgs[0])}")
        actions.append({"label": "Başlat", "command": "./" + appimgs[0], "terminal": False})
    pyproj = open(os.path.join(root, "pyproject.toml"), encoding="utf-8", errors="replace").read() if f("pyproject.toml") else ""
    has_py = f("requirements.txt") or pyproj or f("setup.py") or any(x.endswith(".py") for x in top)
    if f("package.json"):
        pkg = jload(os.path.join(root, "package.json"), {})
        eng = (pkg.get("engines") or {}).get("node", "")
        mver = re.search(r"(\d+)", eng)
        if not which("node") or (mver and node_version(which("node") or "node")[0] < int(mver.group(1))):
            runtimes.append("node22")
        steps.append("npm ci" if f("package-lock.json") else "npm install")
        sc = pkg.get("scripts") or {}
        if "build" in sc:
            steps.append("npm run build")
        b = pkg.get("bin")
        if isinstance(b, dict) and b:
            actions.append({"label": "Başlat", "command": "node " + list(b.values())[0], "terminal": True})
        elif isinstance(b, str):
            actions.append({"label": "Başlat", "command": "node " + b, "terminal": True})
        for k in ("start", "dev", "serve"):
            if k in sc:
                actions.append({"label": f"npm {k}", "command": f"npm run {k}", "terminal": True}); break
    elif has_py:
        req = re.search(r'requires-python\s*=\s*"[^"]*?(\d+)\.(\d+)', pyproj)
        need = (int(req.group(1)), int(req.group(2))) if req else (3, 8)
        if sys.version_info[:2] < need or not check_key("venv"):
            runtimes.append("uv")
            steps.append("uv venv --python 3.12 .venv")
            pipc = "uv pip install --python .venv/bin/python"
        else:
            steps.append("python3 -m venv .venv")
            steps.append(".venv/bin/python -m pip install --upgrade pip")
            pipc = ".venv/bin/pip install"
        if f("requirements.txt"):
            steps.append(f"{pipc} -r requirements.txt")
        if pyproj or f("setup.py"):
            steps.append(f"{pipc} .")
        else:
            libs = pip_names(scan_py_imports(root))
            if libs:
                steps.append(f"{pipc} " + " ".join(q(l) for l in libs))
        scripts = re.findall(r"^\s*([\w][\w.-]*)\s*=\s*\"[\w.]+:[\w.]+\"", pyproj.split("[project.scripts]", 1)[1].split("\n[", 1)[0], re.M) if "[project.scripts]" in pyproj else []
        if scripts:
            actions.append({"label": "Başlat", "command": f".venv/bin/{scripts[0]}", "terminal": True})
        else:
            for e in ("main.py", "app.py", "run.py", f"{slug}.py", f"{name}.py", "cli.py", "start.py", "__main__.py"):
                if f(e):
                    actions.append({"label": "Başlat", "command": f".venv/bin/python {e}", "terminal": True}); break
            else:
                pys = [x for x in top if x.endswith(".py") and x not in ("setup.py", "requirements.py", "conftest.py")]
                if pys:
                    actions.append({"label": "Başlat", "command": f".venv/bin/python {pys[0]}", "terminal": True})
    elif f("Cargo.toml"):
        steps.append("cargo build --release")
        m = re.search(r'^name\s*=\s*"([^"]+)"', open(os.path.join(root, "Cargo.toml")).read(), re.M)
        actions.append({"label": "Başlat", "command": f"./target/release/{m.group(1) if m else slug}", "terminal": True})
    elif f("go.mod"):
        steps.append(f"go build -o {q(slug)} ./...") if not f("main.go") else steps.append(f"go build -o {q(slug)} .")
        actions.append({"label": "Başlat", "command": f"./{slug}", "terminal": True})
    elif f("CMakeLists.txt"):
        steps += ["cmake -B build -DCMAKE_BUILD_TYPE=Release", "cmake --build build -j\"$(nproc)\""]
        actions.append({"label": "Başlat", "command": f"./build/{name}", "terminal": True})
    elif f("meson.build"):
        steps += ["meson setup build", "ninja -C build"]
    elif f("Makefile") or f("makefile"):
        steps.append("make -j\"$(nproc)\"")
    if not steps:
        for sh in ("install.sh", "setup.sh", "build.sh"):
            if f(sh):
                steps.append(f"bash {sh}"); warn.append(f"Projenin kendi {sh} betiği çalıştırılacak — içeriğini kontrol et."); break
    if not actions:
        for x in top:
            p = os.path.join(root, x)
            if os.path.isfile(p) and os.access(p, os.X_OK) and not x.endswith((".sh", ".py")) or x in ("run.sh", "start.sh"):
                actions.append({"label": "Başlat", "command": f"./{x}", "terminal": True}); break
    return {"name": name, "summary": "", "steps": steps, "actions": actions, "runtimes": runtimes,
            "system_packages": [], "warnings": warn, "optional": []}

ANALYZE_SYS = """Sen bir Linux kurulum uzmanısın. Sana bir GitHub projesinin README'si ve dosya listesi verilecek.
Görevin: projeyi BU KLASÖRDE (proje kök dizini, cwd) kurup çalışır hale getirecek bir plan çıkarmak.
SADECE geçerli JSON döndür, başka metin yazma. Şema:
{
 "name": "kısa okunur ad",
 "summary_tr": "Türkçe 2-4 cümle: ne işe yarar",
 "runtimes": ["node22" ve/veya "uv" — sistemde yoksa/eskiyse Cypher Tool sudo'suz kurar],
 "system_packages": ["dağıtıma uygun paket adları (sadece gerçekten gerekenler)"],
 "steps": ["proje kökünde sırayla çalışacak bash komutları"],
 "actions": [{"label":"Başlat","command":"proje köküne göre çalıştırma komutu","terminal":true}],
 "optional": [{"label":"açıklama","command":"isteğe bağlı komut"}],
 "warnings": ["riskli ya da kullanıcının bilmesi gereken şeyler, Türkçe"]
}
Kurallar:
- Global kurulum YAPMA. Python için proje içinde .venv kullan (python3 -m venv .venv ; .venv/bin/pip install ...), Python sürümü yetmiyorsa runtimes'a "uv" ekle ve "uv venv --python 3.12 .venv" + "uv pip install --python .venv/bin/python ..." kullan.
- npm için yerel "npm install"/"npm ci"; "npm install -g" kullanma; çalıştırmak için "node bin/x.js" veya "npx" tercih et.
- Hazır Linux ikilisi (release) en kolay yolsa şu özel adımı kullanabilirsin: "@release {\\"repo\\":\\"sahip/repo\\",\\"match\\":[\\"linux\\",\\"{arch_go}\\"],\\"save_as\\":\\"bin/ad\\",\\"chmod\\":\\"bin/ad\\"}" (arşivse save_as yerine "extract_to":"bin").
- sudo gerekiyorsa komutun başına sudo koy (paketleri system_packages'a yazman daha iyi).
- curl|sh tarzı betikleri sadece README'nin tek resmi yolu buysa kullan ve warnings'e yaz.
- Etkileşimli (kullanıcı girişi isteyen) kurulum adımlarının başına "@terminal " ekle.
- cd ile proje dışına çıkma. Komutlar tek satır olsun.
- terminal: CLI/TUI araçlar için true, grafik (GUI) uygulamalar ve arka plan servisleri için false.
"""

def analyze(root, name, meta, log, provider_id=""):
    plan = heuristic_plan(root, name)
    plan["summary"] = meta.get("description") or readme_intro(root)
    if not (cfg().get("use_ai", True) and llm_available()):
        log("ℹ Yapay zekâ analizi kapalı/API yok → otomatik algılama kullanıldı.")
        return plan
    log("🤖 README yapay zekâ ile analiz ediliyor…")
    oi = os_info()
    user = (f"Sistem: {oi.get('PRETTY_NAME', 'Linux')} | paket yöneticisi: {detect_pm()} | mimari: {platform.machine()} | "
            f"Python {platform.python_version()} | node: {'.'.join(map(str, node_version(which('node')))) if which('node') else 'yok'}\n"
            f"Proje: {meta.get('full_name', name)} — {meta.get('description', '')}\n"
            f"Otomatik algılamanın önerisi (yanlış olabilir): {json.dumps({k: plan[k] for k in ('steps', 'actions', 'runtimes')}, ensure_ascii=False)}\n\n"
            f"DOSYALAR:\n{file_tree(root)}\n\nREADME:\n{read_readme(root)}")
    try:
        txt, p = llm_ask([{"role": "user", "content": user}], ANALYZE_SYS, provider_id, log=log)
        j = extract_json(txt)
        steps = []
        for s in j.get("steps", []):
            if isinstance(s, dict) and "release" in s:
                steps.append("@release " + json.dumps(s["release"]))
            elif isinstance(s, str) and s.strip():
                steps.append(s.strip())
        plan.update({"name": j.get("name") or name, "summary": j.get("summary_tr") or plan["summary"], "steps": steps,
                     "actions": [a for a in j.get("actions", []) if isinstance(a, dict) and a.get("command")] or plan["actions"],
                     "runtimes": [r for r in j.get("runtimes", []) if r in ("node22", "uv")],
                     "system_packages": [x for x in j.get("system_packages", []) if isinstance(x, str) and NAME_OK.match(x)],
                     "optional": [o for o in j.get("optional", []) if isinstance(o, dict) and o.get("command")],
                     "warnings": plan["warnings"] + [w for w in j.get("warnings", []) if isinstance(w, str)]})
        log(f"✔ Analiz tamam ({p.get('name')})")
    except Exception as e:
        log(f"⚠ Yapay zekâ analizi başarısız, otomatik algılama kullanılıyor: {str(e)[:200]}")
    return plan

def required_keys(root, plan):
    keys = set(); rts = set(plan.get("runtimes", []))
    f = lambda p: os.path.exists(os.path.join(root, p))
    if f("CMakeLists.txt"): keys |= {"cmake", "gcc"}
    if f("Makefile") or f("makefile"): keys |= {"make"}
    if f("meson.build"): keys |= {"gcc"}
    if f("Cargo.toml"): keys.add("cargo")
    if f("go.mod") and not any(s.startswith("@release") for s in plan.get("steps", [])): keys.add("go")
    if f("pom.xml"): keys |= {"maven", "java"}
    if f("Gemfile"): keys.add("ruby")
    if f(".gitattributes") and "lfs" in open(os.path.join(root, ".gitattributes"), errors="replace").read(): keys.add("git-lfs")
    cmds = list(plan.get("steps", [])) + [a.get("command", "") for a in plan.get("actions", [])]
    for c in cmds:
        if c.startswith("@release"):
            continue
        c = c.removeprefix("@terminal ")
        for seg in re.split(r"&&|\|\||;|\|", c):
            try:
                toks = shlex.split(seg)
            except ValueError:
                toks = seg.split()
            toks = [t for t in toks if t not in ("sudo", "env", "exec", "time") and not re.match(r"^\w+=", t)]
            if not toks:
                continue
            b = os.path.basename(toks[0])
            if toks[0].startswith((".venv/", "./", "bin/")):
                continue
            if b in RUNTIME_CMDS:
                if not runtime_ok(RUNTIME_CMDS[b]):
                    rts.add(RUNTIME_CMDS[b])
            elif b in CMD2KEY:
                keys.add(CMD2KEY[b])
            if b in ("python3", "python") and "venv" in toks:
                keys.add("venv")
    return keys, rts

# ───────────────────────────── komut çalıştırma ─────────────────────────────
SUDO_RE = re.compile(r"(^|&&|\|\||;|\|)\s*sudo\s+(-\w+\s+)*")

def needs_root(cmd):
    return bool(SUDO_RE.search(cmd))

def strip_sudo(cmd):
    return SUDO_RE.sub(lambda m: m.group(1) + " ", cmd).strip()

def find_terminal():
    for t, a in (("x-terminal-emulator", ["-e"]), ("gnome-terminal", ["--"]), ("konsole", ["-e"]), ("xfce4-terminal", ["-x"]),
                 ("mate-terminal", ["-x"]), ("tilix", ["-e"]), ("kitty", []), ("alacritty", ["-e"]), ("wezterm", ["start", "--"]),
                 ("foot", []), ("lxterminal", ["-e"]), ("xterm", ["-e"])):
        if shutil.which(t):
            return [t] + a
    return None

def open_in_terminal(script):
    t = find_terminal()
    if not t:
        return False
    subprocess.Popen(t + [script], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return True

def run_shell(job, cmd, cwd, interactive=False, secret=None, show=None):
    job.log(f"$ {show or cmd}")
    tail = []
    p = subprocess.Popen(["bash", "-lc", cmd], cwd=cwd, env=base_env(), text=True, errors="replace",
                         stdin=subprocess.PIPE if secret is not None else (None if interactive else subprocess.DEVNULL),
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
    if secret is not None:
        try:
            p.stdin.write(secret + "\n"); p.stdin.flush(); p.stdin.close()
        except Exception:
            pass
        secret = None
    job.proc = p
    for line in p.stdout:
        line = clean_term(line.rstrip("\n"))
        job.log("  " + line)
        tail.append(line); tail = tail[-60:]
        if job.cancelled:
            try: os.killpg(p.pid, signal.SIGTERM)
            except Exception: pass
    rc = p.wait(); job.proc = None
    if rc != 0:
        job.log(f"✖ Komut başarısız (çıkış kodu {rc})")
    return rc, tail

def run_in_terminal_wait(job, cmd, cwd, why):
    fd, path = tempfile.mkstemp(prefix="ct-", suffix=".sh", dir=LAUNCH_DIR)
    done = path + ".done"
    with os.fdopen(fd, "w") as f:
        f.write(f"#!/usr/bin/env bash\nexport PATH={q(base_env()['PATH'])}\ncd {q(cwd)}\necho '▶ Cypher Tool: {why}'\necho '$ {cmd.replace(chr(39), '')}'\n"
                f"{cmd}\nrc=$?\necho $rc > {q(done)}\necho; [ $rc -eq 0 ] && echo '✔ Bitti.' || echo \"✖ Hata (kod $rc)\"\nread -rp 'Kapatmak için Enter…' _\n")
    os.chmod(path, 0o700)
    if job.cli:
        rc = subprocess.call(["bash", path]); os.remove(path); return rc, []
    if not open_in_terminal(path):
        r = job.ask("manual", {"command": cmd, "cwd": cwd, "why": why})
        return (0 if r and r.get("ok") else 1), []
    job.log(f"🖥 Terminal penceresi açıldı: {why} — orada tamamla.")
    while not os.path.exists(done) and not job.cancelled:
        time.sleep(1)
    rc = int(open(done).read().strip() or 1) if os.path.exists(done) else 1
    for x in (path, done):
        try: os.remove(x)
        except Exception: pass
    return rc, []

def sudo_check(pw):
    """Şifreyi doğrular. (True, '') | (False, sebep)"""
    r = subprocess.run(["sudo", "-S", "-k", "-p", "", "-v"], input=pw + "\n", text=True, capture_output=True, timeout=30)
    if r.returncode == 0:
        return True, ""
    err = r.stderr.lower()
    if "sudoers" in err or "not allowed" in err or "izin" in err:
        return False, "nosudo"
    return False, "wrong"

def run_privileged(job, script, cwd):
    if job.cli:
        return run_shell(job, "sudo bash -c " + q(script), cwd, interactive=True)
    inner = f"cd {q(cwd)} && export DEBIAN_FRONTEND=noninteractive && {script}"
    if subprocess.run(["sudo", "-n", "true"], capture_output=True).returncode == 0:
        return run_shell(job, "sudo -n bash -c " + q(inner), cwd, show="sudo " + script)
    has_pk = bool(shutil.which("pkexec") and (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")))
    if not shutil.which("sudo"):
        if has_pk:
            return run_shell(job, f"pkexec bash -c {q(inner)}", cwd, show="pkexec " + script)
        return run_in_terminal_wait(job, "su -c " + q(script), cwd, "yönetici izni gereken adım")
    notify(APP, "🔐 Yönetici şifresi gerekiyor — Cypher Tool penceresine bak")
    job.log("🔐 Yönetici (sudo) şifresi isteniyor…")
    retry = ""
    for _ in range(3):
        r = job.ask("password", {"name": job.title, "commands": script, "retry": retry, "pkexec": has_pk, "user": os.environ.get("USER", "")})
        if not r or not r.get("ok"):
            job.log("✖ Yönetici izni verilmedi."); return 1, ["Yönetici izni verilmedi"]
        d = r.get("data") or {}
        if d.get("use_pkexec") and has_pk:
            job.log("🔐 Sistem parola penceresi açılıyor…")
            return run_shell(job, f"pkexec bash -c {q(inner)}", cwd, show="pkexec " + script)
        if d.get("use_terminal"):
            return run_in_terminal_wait(job, "sudo bash -c " + q(script), cwd, "yönetici (sudo) izni gereken adım")
        pw = d.get("password", "")
        ok, why = sudo_check(pw)
        if ok:
            job.log("✔ Şifre kabul edildi")
            res = run_shell(job, "sudo -S -p '' bash -c " + q(inner), cwd, secret=pw, show="sudo " + script)
            pw = None; d.clear()
            return res
        pw = None; d.clear()
        if why == "nosudo":
            job.log("✖ Bu kullanıcının sudo yetkisi yok."); return 1, ["Kullanıcının sudo yetkisi yok"]
        retry = "Şifre yanlış, tekrar dene."
        job.log("⚠ Şifre yanlış")
    job.log("✖ 3 kez yanlış şifre."); return 1, ["Şifre yanlış"]

def release_step(job, spec, cwd):
    av = arch_vars(); fmt = lambda s: s.format(**av)
    repo = spec["repo"]; tag = ""
    if spec.get("asset"):
        name = fmt(spec["asset"])
        url = f"https://github.com/{repo}/releases/latest/download/{name}"
        tag = latest_release_tag(repo)
        assets = None
    else:
        try:
            rel = gh_api(f"/repos/{repo}/releases/latest")
        except Exception as e:
            if not spec.get("fallback_asset"):
                raise
            job.log(f"   GitHub API kullanılamadı ({str(e)[:60]}), yedek dosya adı deneniyor")
            spec = {**spec, "asset": spec["fallback_asset"]}
            return release_step(job, spec, cwd)
        tag = rel.get("tag_name", ""); assets = rel.get("assets", [])
        if spec.get("match_regex"):
            a = next((x for x in assets if re.search(spec["match_regex"], x["name"])), None)
        elif spec.get("match"):
            ms = [fmt(m).lower() for m in spec["match"]]; ex = [e.lower() for e in spec.get("exclude", [])]
            a = next((x for x in assets if all(m in x["name"].lower() for m in ms) and not any(e in x["name"].lower() for e in ex)), None)
        else:
            a = pick_asset(assets)
        if not a:
            raise RuntimeError(f"{repo} sürümünde bu sisteme uygun dosya bulunamadı.")
        name, url = a["name"], a["browser_download_url"]
    job.log(f"⬇ Sürüm dosyası: {repo} {tag} → {name}")
    tmpd = tempfile.mkdtemp(dir=cwd, prefix=".dl-")
    tmp = os.path.join(tmpd, name)
    final = download(url, tmp, job.log)
    m = re.search(r"/download/([^/]+)/", final)
    tag = tag or (urllib.parse.unquote(m.group(1)) if m else "")
    exp = ""
    try:
        if spec.get("checksums"):
            txt = http_get(f"https://github.com/{repo}/releases/download/{tag}/{fmt(spec['checksums'])}") if tag else http_get(f"https://github.com/{repo}/releases/latest/download/{fmt(spec['checksums'])}")
            exp = next((l.split()[0] for l in txt.splitlines() if l.split() and l.split()[-1].lstrip("*") == name), "")
        elif spec.get("checksum_file"):
            exp = http_get(f"https://github.com/{repo}/releases/latest/download/{fmt(spec['checksum_file'])}").split()[0]
        elif assets:
            sa = next((x for x in assets if x["name"] in (name + ".sha256", name + ".sha256sum")), None)
            if sa:
                exp = http_get(sa["browser_download_url"]).split()[0]
    except Exception as e:
        job.log(f"   (sağlama dosyası alınamadı: {str(e)[:100]})")
    if exp:
        if exp.lower() != sha256(tmp):
            shutil.rmtree(tmpd, ignore_errors=True)
            raise RuntimeError("SHA256 sağlaması uyuşmadı — dosya bozuk veya değiştirilmiş, kurulum durduruldu.")
        job.log("   ✔ SHA256 doğrulandı")
    if spec.get("extract_to"):
        out = os.path.join(cwd, spec["extract_to"]); extract(tmp, out, job.log)
    elif spec.get("save_as"):
        dst = os.path.join(cwd, spec["save_as"]); os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.move(tmp, dst)
    else:
        sd = os.path.join(cwd, spec.get("save_dir", "_release")); os.makedirs(sd, exist_ok=True)
        dst = os.path.join(sd, name); shutil.move(tmp, dst)
        if is_archive(name) and spec.get("save_dir") is None:
            extract(dst, os.path.join(sd, re.sub(r"(\.tar)?\.\w+$", "", name)), job.log)
        if name.lower().endswith(".appimage"):
            os.chmod(dst, 0o755)
    shutil.rmtree(tmpd, ignore_errors=True)
    if spec.get("chmod"):
        os.chmod(os.path.join(cwd, spec["chmod"]), 0o755)
    job.ctx["release_tag"] = tag; job.ctx["release_repo"] = repo
    return 0, []

def run_steps(job, steps, cwd):
    """Adımları sırayla çalıştırır. Başarısızsa (False, kalan_adımlar, son_çıktı)."""
    i = 0
    while i < len(steps):
        if job.cancelled:
            return False, steps[i:], ["İptal edildi"]
        c = steps[i].strip()
        if not c or c.startswith("#"):
            i += 1; continue
        try:
            if c.startswith("@release "):
                rc, tail = release_step(job, json.loads(c[9:]), cwd); j = i + 1
            elif c.startswith("@terminal "):
                rc, tail = run_in_terminal_wait(job, c[10:], cwd, "etkileşimli kurulum adımı"); j = i + 1
            elif needs_root(c) and not is_root():
                group = [strip_sudo(c)]; j = i + 1
                while j < len(steps) and needs_root(steps[j]) and not steps[j].startswith("@"):
                    group.append(strip_sudo(steps[j])); j += 1
                rc, tail = run_privileged(job, " && ".join(group), cwd)
            else:
                rc, tail = run_shell(job, strip_sudo(c) if is_root() else c, cwd); j = i + 1
        except Exception as e:
            job.log(f"✖ {e}"); rc, tail, j = 1, [str(e)], i + 1
        if rc != 0:
            return False, steps[i:], tail
        i = j
    return True, [], []

def quick_fixes(text, tool=None):
    """Hata çıktısından eksik şeyleri tespit edip düzeltme komutları üretir."""
    fixes, seen = [], set()
    venv = tool and os.path.isdir(os.path.join(tool.get("path", ""), ".venv"))
    for m in re.finditer(r"(?:ModuleNotFoundError|ImportError): No module named '([\w.]+)'", text):
        mod = m.group(1).split(".")[0]; pkg = IMPORT_MAP.get(mod, mod)
        if pkg and pkg not in seen:
            seen.add(pkg)
            fixes.append({"why": f"Eksik Python kütüphanesi: {mod}",
                          "command": (f".venv/bin/python -m pip install {q(pkg)}" if venv else f"python3 -m pip install --user {q(pkg)}")})
    for m in re.finditer(r"(?:^|\s)(?:bash: |sh: |/bin/sh: |line \d+: )?([\w.+-]+): (?:command not found|komut bulunamadı|not found)", text, re.M):
        cmd = m.group(1)
        if cmd in RUNTIME_CMDS and RUNTIME_CMDS[cmd] not in seen:
            seen.add(RUNTIME_CMDS[cmd]); fixes.append({"why": f"Eksik çalışma ortamı: {cmd}", "runtime": RUNTIME_CMDS[cmd]})
        elif cmd in CMD2KEY and cmd not in seen:
            seen.add(cmd); dc, _ = dep_commands([CMD2KEY[cmd]])
            for c in dc[-1:]:
                fixes.append({"why": f"Eksik sistem programı: {cmd}", "command": c})
    for m in re.finditer(r"Cannot find module '([^']+)'", text):
        if "npm" not in seen:
            seen.add("npm"); fixes.append({"why": f"Eksik Node modülü: {m.group(1)}", "command": "npm install"})
    if re.search(r"ensurepip is not available|No module named venv", text) and "venv" not in seen:
        seen.add("venv"); dc, _ = dep_commands(["venv"])
        fixes += [{"why": "Python venv modülü eksik", "command": c} for c in dc[-1:]] or [{"why": "Python venv eksik → uv kullan", "runtime": "uv"}]
    for m in re.finditer(r"error while loading shared libraries: (lib[\w+-]+)\.so", text):
        fixes.append({"why": f"Eksik sistem kütüphanesi: {m.group(1)} (paket adı dağıtıma göre değişir; 'AI ile düzelt' önerebilir)", "command": ""})
    return fixes

# ───────────────────────────── görevler (jobs) ─────────────────────────────
JOBS = {}

class Job:
    def __init__(self, title, kind, cli=False):
        self.id = uuid.uuid4().hex[:10]; self.title = title; self.kind = kind; self.cli = cli
        self.status = "bekliyor"; self.lines = []; self.pending = None; self.response = None
        self.event = threading.Event(); self.cancelled = False; self.proc = None; self.ctx = {}
        self.created = time.time(); self.slug = ""; self.auto = False; self.icon = ""
        JOBS[self.id] = self

    def log(self, s):
        for line in str(s).split("\n"):
            self.lines.append(line)
            if self.cli:
                print(line, flush=True)
        if len(self.lines) > 8000:
            del self.lines[:2000]

    def set(self, status):
        self.status = status
        self.log(f"── {status} ──") if self.cli else None

    def ask(self, kind, payload):
        if self.auto and kind in ("plan", "confirm", "fix"):
            return {"ok": True, "data": payload}
        if self.cli:
            return cli_ask(kind, payload)
        self.pending = {"kind": kind, "payload": payload}; self.event.clear()
        prev = self.status; self.status = "onay bekliyor"
        while not self.event.wait(1):
            if self.cancelled:
                break
        self.pending = None; self.status = prev
        r = self.response; self.response = None
        return r  # şifre yanıtı yalnızca çağırana gider, saklanmaz

    def respond(self, ok, data=None):
        self.response = {"ok": ok, "data": data}; self.event.set()

    def summary(self):
        return {"id": self.id, "title": self.title, "kind": self.kind, "status": self.status, "slug": self.slug,
                "icon": self.icon, "pending": self.pending, "created": self.created, "nlines": len(self.lines)}

def start_job(title, kind, fn, *args, cli=False, auto=False):
    job = Job(title, kind, cli=cli); job.auto = auto
    def runner():
        try:
            job.status = "çalışıyor"; fn(job, *args)
            if job.status in ("çalışıyor",):
                job.status = "tamamlandı"
        except Exception as e:
            job.log(f"✖ Hata: {e}"); job.status = "hata"
    if cli:
        runner()
    else:
        threading.Thread(target=runner, daemon=True).start()
    return job

# ───────────────────────────── araç kaydı / kısayol ─────────────────────────────
def desktop_dir():
    try:
        d = subprocess.run(["xdg-user-dir", "DESKTOP"], capture_output=True, text=True).stdout.strip()
        if d and os.path.isdir(d) and d != os.path.expanduser("~"):
            return d
    except Exception:
        pass
    for n in ("Masaüstü", "Desktop"):
        p = os.path.expanduser("~/" + n)
        if os.path.isdir(p):
            return p
    return None

def make_launcher(tool, idx=0):
    a = tool["actions"][idx]
    p = os.path.join(LAUNCH_DIR, f"{tool['slug']}__{idx}.sh")
    with open(p, "w") as f:
        f.write("#!/usr/bin/env bash\n# Cypher Tool başlatıcı\n")
        f.write(f"export PATH={q(RT_BIN)}:{q(os.path.join(RT, 'node', 'bin'))}:\"$HOME/.local/bin:$PATH\"\n")
        f.write(f"export UV_PYTHON_INSTALL_DIR={q(os.path.join(RT, 'python'))}\n")
        if tool.get("inject_keys", True):
            f.write(f"[ -f {q(ENV_FILE)} ] && . {q(ENV_FILE)}\n")
        f.write(f"cd {q(tool['path'])} || exit 1\n")
        f.write(f"{a['command']} \"$@\"\nrc=$?\n")
        if a.get("terminal", True):
            f.write('if [ -t 1 ] && [ "${CT_NOPAUSE:-0}" != 1 ]; then echo; echo "[çıkış kodu $rc]"; read -rp "Kapatmak için Enter…" _; fi\n')
        f.write("exit $rc\n")
    os.chmod(p, 0o755)
    return p

def make_shortcuts(tool, desktop=True):
    if not tool.get("actions"):
        return []
    launcher = make_launcher(tool, 0)
    icon = os.path.join(ICON_DIR, tool["icon"]) if tool.get("icon") else "utilities-terminal"
    entry = (f"[Desktop Entry]\nType=Application\nName={tool['name']}\nComment={(tool.get('summary') or '')[:120].replace(chr(10), ' ')}\n"
             f"Exec=\"{launcher}\"\nPath={tool['path']}\nIcon={icon}\nTerminal={'true' if tool['actions'][0].get('terminal', True) else 'false'}\n"
             f"Categories=Development;Utility;\nStartupWMClass={tool['slug']}\nX-CypherTool={tool['slug']}\n")
    made = []
    apps = os.path.expanduser("~/.local/share/applications"); os.makedirs(apps, exist_ok=True)
    targets = [os.path.join(apps, f"cyphertool-{tool['slug']}.desktop")]
    dd = desktop_dir()
    if desktop and dd:
        targets.append(os.path.join(dd, f"{tool['slug']}.desktop"))
    for t in targets:
        with open(t, "w") as f:
            f.write(entry)
        os.chmod(t, 0o755)
        if shutil.which("gio"):
            subprocess.run(["gio", "set", t, "metadata::trusted", "true"], capture_output=True)
        made.append(t)
    return made

def remove_shortcuts(slug):
    for p in [os.path.expanduser(f"~/.local/share/applications/cyphertool-{slug}.desktop")] + \
             ([os.path.join(desktop_dir(), f"{slug}.desktop")] if desktop_dir() else []):
        try: os.remove(p)
        except Exception: pass
    for f in os.listdir(LAUNCH_DIR):
        if f.startswith(slug + "__"):
            os.remove(os.path.join(LAUNCH_DIR, f))

def notify(title, body):
    if shutil.which("notify-send"):
        subprocess.run(["notify-send", "-a", APP, "-i", os.path.join(WEB_DIR, "logo.svg"), title, body], capture_output=True)

# ───────────────────────────── kurulum akışı ─────────────────────────────
def find_catalog(src):
    s = src.strip().rstrip("/").lower().removesuffix(".git")
    for c in catalog() + jload(USER_CATALOG, []):
        if c["source"].lower() == s or c.get("id") == s:
            return c
    return None

def guide_summary(g):
    m = re.search(r"## Ne işe yarar\?\s*\n(.+?)(\n\s*\n|$)", g or "", re.S)
    return re.sub(r"[*`]", "", m.group(1)).strip() if m else ""

def recipe_to_plan(rec):
    steps = []
    for st in rec.get("install", []):
        steps.append("@release " + json.dumps({k: v for k, v in st.items() if k != "type"}) if st["type"] == "release" else st["command"])
    return {"name": rec["name"], "summary": "", "steps": steps, "actions": rec.get("actions", []), "runtimes": rec.get("runtimes", []),
            "system_packages": rec.get("system_packages", []), "warnings": ([rec["note"]] if rec.get("note") else []),
            "optional": rec.get("optional_install", []), "guide_tr": rec.get("guide_tr", ""), "category": rec.get("category", ""),
            "icon_repo_path": rec.get("icon_repo_path", "")}

def fetch_source(job, src, opts):
    if opts.get("no_clone"):
        dest = unique_dir(TOOLS_DIR, slugify(src.get("repo") or src["name"])); os.makedirs(dest)
        job.log("ℹ Bu araç paket olarak kurulur; kaynak deposu indirilmez (büyük depo).")
        return dest
    if src["kind"] == "local" and os.path.isdir(src["path"]):
        dest = unique_dir(TOOLS_DIR, slugify(src["name"]))
        job.log(f"📁 Yerel klasör kopyalanıyor: {src['path']}")
        shutil.copytree(src["path"], dest, symlinks=True, ignore=shutil.ignore_patterns(".venv", "node_modules"))
        return dest
    base = src.get("repo") or re.sub(r"(\.tar)?\.(zip|rar|7z|gz|tgz|xz|txz|bz2|tbz2|zst|tar|appimage|deb)$", "", src["name"], flags=re.I)
    dest = unique_dir(TOOLS_DIR, slugify(base))
    if src["kind"] in ("archive", "local"):
        os.makedirs(dest)
        fn = os.path.join(dest, "_indirilen", src["name"])
        if src["kind"] == "local":
            os.makedirs(os.path.dirname(fn)); shutil.copy(src["path"], fn)
        else:
            job.log(f"⬇ İndiriliyor: {src['url']}"); download(src["url"], fn, job.log)
        if is_archive(fn):
            ensure_extractor(job, fn); extract(fn, dest, job.log)
            items = [x for x in os.listdir(dest) if x != "_indirilen"]
            if len(items) == 1 and os.path.isdir(os.path.join(dest, items[0])):  # tek üst klasörü düzleştir
                inner = os.path.join(dest, items[0])
                for x in os.listdir(inner):
                    shutil.move(os.path.join(inner, x), os.path.join(dest, x))
                os.rmdir(inner)
        elif fn.lower().endswith(".appimage"):
            os.chmod(fn, 0o755)
        return dest
    if not which("git"):
        r = job.ask("plan", {"name": "git", "summary": "Depoyu indirmek için git gerekli.", "steps": dep_commands(["git"])[0],
                             "actions": [], "deps_only": True, "warnings": []})
        if r and r.get("ok"):
            run_steps(job, (r.get("data") or {}).get("steps") or dep_commands(["git"])[0], DATA)
    if which("git"):
        cmd = ["git", "clone", "--depth", "1", "--recurse-submodules", "--shallow-submodules"]
        if src.get("branch"):
            cmd += ["-b", src["branch"]]
        job.log(f"⬇ git clone {src['url']}")
        env = base_env(); env["GIT_TERMINAL_PROMPT"] = "0"; env["GIT_LFS_SKIP_SMUDGE"] = "1"
        r = subprocess.run(cmd + [src["url"] + ".git" if "github.com" in src["url"] else src["url"], dest], capture_output=True, text=True, env=env)
        if r.returncode != 0:
            shutil.rmtree(dest, ignore_errors=True)
            raise RuntimeError("Depo indirilemedi (gizli/silinmiş olabilir): " + r.stderr.strip()[-300:])
    else:
        job.log("⬇ git yok → zip olarak indiriliyor (güncelleme için git önerilir)")
        os.makedirs(dest); z = os.path.join(dest, "_src.zip")
        download(f"https://codeload.github.com/{src['owner']}/{src['repo']}/zip/{src.get('branch') or 'HEAD'}", z, job.log)
        tmp = dest + "_tmp"; extract(z, tmp, job.log); os.remove(z)
        inner = os.path.join(tmp, os.listdir(tmp)[0])
        for x in os.listdir(inner):
            shutil.move(os.path.join(inner, x), dest)
        shutil.rmtree(tmp, ignore_errors=True)
    return dest

def ensure_extractor(job, path):
    if extractor_available(path):
        return
    cmds, _ = dep_commands(["7z"] if not path.lower().endswith(".tar.zst") else ["zstd"])
    r = job.ask("plan", {"name": "Arşiv açıcı", "summary": f"{os.path.basename(path)} dosyasını açmak için 7-Zip gerekli.",
                         "steps": cmds, "actions": [], "deps_only": True, "warnings": []})
    if r and r.get("ok"):
        run_steps(job, (r.get("data") or {}).get("steps") or cmds, DATA)

def install_flow(job, source, opts, preset=None):
    opts = opts or {}
    rec = preset or find_catalog(source)
    if rec and rec.get("unavailable"):
        raise RuntimeError(rec.get("note", "Bu depo erişilemiyor."))
    src = parse_source(rec["source"] if rec else source)
    job.title = f"Kurulum: {src.get('owner') + '/' if src.get('owner') else ''}{src.get('repo') or src['name']}"
    job.set("indiriliyor")
    meta = gh_meta(src["owner"], src["repo"]) if src.get("owner") else {"full_name": src["name"], "html_url": src.get("url", "")}
    root = fetch_source(job, src, {**opts, "no_clone": (rec or {}).get("clone") is False})
    slug = os.path.basename(root); job.slug = slug
    # repodaki arşivleri (rar/zip/7z) aç
    for a in find_archives(root):
        try:
            ensure_extractor(job, a)
            extract(a, os.path.splitext(a)[0] + "_acik", job.log)
        except Exception as e:
            job.log(f"⚠ {os.path.basename(a)} açılamadı: {e}")
    icon = fetch_icon(slug, root, src.get("owner", ""), (rec or {}).get("icon_repo_path", ""))
    job.icon = icon
    # plan
    job.set("analiz ediliyor")
    if rec:
        plan = recipe_to_plan(rec); plan["summary"] = guide_summary(rec.get("guide_tr")) or meta.get("description", "")
        job.log("🧠 Daha önce öğrenilmiş tarif kullanılıyor (analiz atlandı)." if rec.get("learned") else "📗 Hazır katalog tarifi kullanılıyor (test edilmiş kurulum).")
    else:
        plan = analyze(root, src.get("repo") or src["name"], meta, job.log, opts.get("provider", ""))
        if not plan["steps"] and not plan["actions"] and cfg().get("release_assets", True) and src.get("owner"):
            try:
                rel = gh_api(f"/repos/{src['owner']}/{src['repo']}/releases/latest"); a = pick_asset(rel.get("assets", []))
                if a:
                    job.log(f"ℹ Kaynakta kurulum yöntemi yok; Linux sürüm dosyası bulundu: {a['name']}")
                    spec = {"repo": f"{src['owner']}/{src['repo']}", "match_regex": "^" + re.escape(a["name"]) + "$"}
                    if a["name"].lower().endswith(".appimage"):
                        spec.update({"save_as": "bin/" + a["name"], "chmod": "bin/" + a["name"]})
                        plan["actions"] = [{"label": "Başlat", "command": "./bin/" + a["name"], "terminal": False}]
                    elif is_archive(a["name"]):
                        spec["extract_to"] = "bin"
                    elif a["name"].endswith(".deb"):
                        spec["save_dir"] = "_release"
                        plan["steps"].append("sudo apt-get install -y ./_release/" + a["name"])
                    else:
                        spec.update({"save_as": "bin/" + src["repo"], "chmod": "bin/" + src["repo"]})
                        plan["actions"] = [{"label": "Başlat", "command": "./bin/" + src["repo"], "terminal": True}]
                    plan["steps"].insert(0, "@release " + json.dumps(spec))
            except Exception:
                pass
    plan = finalize_plan(root, plan)
    plan["full_name"] = meta.get("full_name"); plan["icon"] = icon; plan["slug"] = slug
    if meta.get("fork") and meta.get("parent"):
        plan["warnings"].append(f"Bu depo {meta['parent']} projesinin bir çatalı (fork).")
    r = job.ask("plan", plan)
    if not r or not r.get("ok"):
        job.log("İptal edildi; indirilen dosyalar siliniyor."); shutil.rmtree(root, ignore_errors=True)
        try: os.remove(os.path.join(ICON_DIR, icon))
        except Exception: pass
        job.status = "iptal"; return
    plan.update(r.get("data") or {})
    tool = {"slug": slug, "name": plan.get("name") or slug, "path": root, "source": src.get("url") or source,
            "full_name": meta.get("full_name") or slug, "meta": meta, "summary": plan.get("summary", ""),
            "category": plan.get("category", ""), "steps": plan["steps"], "actions": plan.get("actions", []),
            "runtimes": plan.get("runtimes", []), "system_packages": plan.get("system_packages", []),
            "optional": plan.get("optional", []), "icon": icon, "installed_at": now(), "status": "kuruluyor",
            "guide_tr": plan.get("guide_tr", ""), "update_mode": cfg().get("update_default_mode", "sor"),
            "inject_keys": True, "catalog_id": (rec or {}).get("id", "")}
    with _lock:
        t = tools(); t[slug] = tool; save_tools(t)
    ok = execute_plan(job, tool, plan)
    tool = tools().get(slug, tool)
    tool["status"] = "kuruldu" if ok else "hata"
    tool["release_tag"] = job.ctx.get("release_tag", tool.get("release_tag", ""))
    tool["commit"] = git_head(root)
    update_tool(slug, **tool)
    if tool.get("actions") and opts.get("shortcut", cfg().get("auto_shortcut", True)):
        made = make_shortcuts(tool); job.log("🔗 Kısayol: " + ", ".join(made))
    if ok:
        save_user_recipe(tools().get(slug, tool))
    if not tool.get("guide_tr") and llm_available():
        try:
            job.log("📘 Türkçe kullanım rehberi hazırlanıyor…"); make_guide(slug, job.log)
        except Exception as e:
            job.log(f"⚠ Rehber oluşturulamadı: {str(e)[:150]}")
    job.status = "tamamlandı" if ok else "hata"
    job.log("✅ Kurulum tamamlandı!" if ok else "❌ Kurulum hatalarla bitti. 'Doktor' veya 'AI ile düzelt' deneyebilirsin.")
    notify(APP, f"{tool['name']}: " + ("kuruldu ✅" if ok else "kurulum hatası ❌"))

def finalize_plan(root, plan):
    keys, rts = required_keys(root, plan)
    plan["runtimes"] = sorted(set(plan.get("runtimes", [])) | rts)
    plan["runtimes_missing"] = [r for r in plan["runtimes"] if not runtime_ok(r)]
    dcmds, missing = dep_commands(keys, plan.get("system_packages", []))
    plan["deps"] = dcmds; plan["deps_missing"] = missing
    plan["warnings"] = list(dict.fromkeys(plan.get("warnings", []) + danger_warnings(plan["steps"] + dcmds)))
    return plan

def git_head(root):
    if os.path.isdir(os.path.join(root, ".git")):
        r = subprocess.run(["git", "-C", root, "rev-parse", "HEAD"], capture_output=True, text=True)
        return r.stdout.strip()
    return ""

def execute_plan(job, tool, plan):
    root = tool["path"]
    job.set("kuruluyor")
    for rt in plan.get("runtimes", []):
        try:
            ensure_runtime(rt, job.log)
        except Exception as e:
            job.log(f"✖ Çalışma ortamı kurulamadı ({rt}): {e}"); return False
    if plan.get("deps"):
        job.log("🧩 Eksik sistem bağımlılıkları kuruluyor: " + ", ".join(plan.get("deps_missing", [])))
        ok, _, _ = run_steps(job, plan["deps"], root)
        if not ok:
            job.log("⚠ Bağımlılık kurulumu başarısız, yine de devam ediliyor…")
    steps = list(plan.get("steps", [])); attempts = 0
    while True:
        ok, remaining, tail = run_steps(job, steps, root)
        if ok:
            return True
        attempts += 1
        if attempts > 3:
            return False
        out = "\n".join(tail)
        fixes = quick_fixes(out, tool)
        fix_cmds = [f["command"] for f in fixes if f.get("command")]
        for f in fixes:
            if f.get("runtime"):
                try: ensure_runtime(f["runtime"], job.log)
                except Exception as e: job.log(f"✖ {e}")
        if fixes:
            job.log("🔧 Eksik tespit edildi: " + "; ".join(f["why"] for f in fixes))
            r = job.ask("fix", {"why": [f["why"] for f in fixes], "steps": fix_cmds + remaining, "failed": remaining[0], "output": out[-3000:]})
            if r and r.get("ok"):
                steps = (r.get("data") or {}).get("steps") or (fix_cmds + remaining); continue
            return False
        if llm_available():
            job.log("🤖 Hata yapay zekâya soruluyor…")
            try:
                txt, _ = llm_ask([{"role": "user", "content":
                    f"Linux: {os_info().get('PRETTY_NAME')} ({detect_pm()}). Proje: {tool['full_name']}. Klasör: proje kökü.\n"
                    f"Başarısız komut: {remaining[0]}\nKalan adımlar: {json.dumps(remaining[1:], ensure_ascii=False)}\n"
                    f"Çıktının sonu:\n{out[-3500:]}\n\nREADME özeti:\n{read_readme(root, 5000)}\n\n"
                    "Sorunu çözüp kurulumu tamamlayacak yeni adım listesini ver. SADECE JSON: {\"explanation_tr\":\"...\",\"steps\":[...]}"}],
                    "Sen Linux kurulum hatası çözme uzmanısın. Global kurulum yerine proje içi .venv/yerel npm kullan.")
                j = extract_json(txt)
                r = job.ask("fix", {"why": [j.get("explanation_tr", "AI önerisi")], "steps": j.get("steps", []), "failed": remaining[0], "output": out[-3000:], "ai": True})
                if r and r.get("ok"):
                    steps = (r.get("data") or {}).get("steps") or j.get("steps", []); continue
            except Exception as e:
                job.log(f"⚠ AI düzeltmesi alınamadı: {str(e)[:200]}")
        return False

def make_guide(slug, log=None):
    t = tools()[slug]
    txt, _ = llm_ask([{"role": "user", "content":
        f"Araç: {t['full_name']}\nAçıklama: {t.get('meta', {}).get('description', '')}\n"
        f"Cypher Tool içindeki eylemler (proje klasöründe çalışır): {json.dumps(t.get('actions', []), ensure_ascii=False)}\n\n"
        f"README (İngilizce veya başka dilde olabilir):\n{read_readme(t['path'], 16000)}"}],
        "README'yi okuyup TÜRKÇE, sade ve anlaşılır bir kullanım rehberi yaz (Markdown). Başlıklar: "
        "'## Ne işe yarar?', '## İlk kullanım', '## Örnek komutlar' (```bash blokları, komutları Cypher Tool eylemlerine uygun yollarla yaz), "
        "'## Önemli seçenekler', '## İpuçları ve uyarılar'. Teknik terimleri gerektiğinde parantez içinde İngilizce bırak. Uydurma özellik yazma.", log=log)
    update_tool(slug, guide_tr=txt.strip())
    return txt

# ───────────────────────────── doktor / güncelleme ─────────────────────────────
def doctor_flow(job, slug):
    t = tools()[slug]; root = t["path"]; job.slug = slug; job.icon = t.get("icon", ""); job.title = f"Doktor: {t['name']}"
    findings, fixes = [], []
    if not os.path.isdir(root):
        raise RuntimeError("Araç klasörü yok — yeniden kurman gerekiyor.")
    plan = {"steps": t.get("steps", []), "actions": t.get("actions", []), "runtimes": t.get("runtimes", []), "system_packages": t.get("system_packages", [])}
    keys, rts = required_keys(root, plan)
    for r in sorted(set(t.get("runtimes", [])) | rts):
        if not runtime_ok(r):
            findings.append(f"Çalışma ortamı eksik: {r}"); fixes.append(f"@runtime {r}")
    dc, miss = dep_commands(keys, t.get("system_packages", []))
    if miss:
        findings.append("Eksik sistem programları: " + ", ".join(miss)); fixes += dc
    vpy = os.path.join(root, ".venv", "bin", "python")
    uses_venv = any(".venv" in s for s in t.get("steps", []) + [a["command"] for a in t.get("actions", [])])
    if uses_venv and not os.path.exists(vpy):
        findings.append("Python sanal ortamı (.venv) yok / bozuk → kurulum adımları yeniden çalıştırılmalı"); fixes += t.get("steps", [])
    elif os.path.exists(vpy):
        mods = scan_py_imports(root)
        if mods:
            code = "import importlib.util,json,sys;print(json.dumps([m for m in sys.argv[1:] if importlib.util.find_spec(m) is None]))"
            r = subprocess.run([vpy, "-c", code, *mods], capture_output=True, text=True, cwd=root)
            try:
                missing = json.loads(r.stdout.strip().splitlines()[-1])
            except Exception:
                missing = []
            missing = [m for m in missing if IMPORT_MAP.get(m, m)]
            if missing:
                findings.append("Kodda kullanılıp kurulu olmayan Python kütüphaneleri: " + ", ".join(missing))
                fixes.append(".venv/bin/python -m pip install " + " ".join(q(p) for p in pip_names(missing)))
        r = subprocess.run([vpy, "-m", "pip", "check"], capture_output=True, text=True, cwd=root)
        if r.returncode != 0 and "No module named pip" not in r.stderr:
            findings.append("pip uyumsuzlukları:\n" + r.stdout.strip()[:800])
    if os.path.exists(os.path.join(root, "package.json")) and not os.path.isdir(os.path.join(root, "node_modules")) \
            and any("npm" in s for s in t.get("steps", [])):
        findings.append("node_modules eksik"); fixes.append("npm install")
    for a in t.get("actions", []):
        first = a["command"].split()[0]
        if first.startswith(("./", ".venv/", "bin/")) and not os.path.exists(os.path.join(root, first)):
            findings.append(f"Çalıştırılabilir dosya yok: {first}")
            if not set(t.get("steps", [])) <= set(fixes):
                fixes += t.get("steps", [])
    fixes = list(dict.fromkeys(fixes))
    if not findings:
        job.log("✅ Sorun bulunamadı — araç sağlıklı görünüyor."); return
    job.log("🩺 Bulgular:\n  • " + "\n  • ".join(findings))
    r = job.ask("fix", {"why": findings, "steps": fixes, "failed": "", "output": ""})
    if not r or not r.get("ok"):
        job.status = "iptal"; return
    steps = (r.get("data") or {}).get("steps") or fixes
    for s in [s for s in steps if s.startswith("@runtime ")]:
        ensure_runtime(s.split()[1], job.log)
    ok, _, _ = run_steps(job, [s for s in steps if not s.startswith("@runtime ")], root)
    update_tool(slug, status="kuruldu" if ok else "hata")
    job.status = "tamamlandı" if ok else "hata"

def check_update(t):
    """(güncelleme_var, açıklama)"""
    root = t["path"]
    if os.path.isdir(os.path.join(root, ".git")):
        try:
            env = base_env(); env["GIT_TERMINAL_PROMPT"] = "0"
            r = subprocess.run(["git", "-C", root, "ls-remote", "origin", "HEAD"], capture_output=True, text=True, timeout=40, env=env)
            remote = r.stdout.split()[0] if r.stdout.split() else ""
            local = git_head(root)
            if remote and local and remote != local:
                return True, f"Yeni commit: {local[:7]} → {remote[:7]}"
        except Exception:
            pass
    repo = t.get("release_repo") or next((json.loads(s[9:]).get("repo") for s in t.get("steps", []) if s.startswith("@release ")), "")
    if repo and t.get("release_tag"):
        tag = latest_release_tag(repo)
        if tag and tag != t["release_tag"]:
            return True, f"Yeni sürüm: {t['release_tag']} → {tag}"
    return False, ""

def check_all_updates(auto_apply=True, cli=False):
    res = []
    for slug, t in tools().items():
        if t.get("update_mode") == "kapali":
            continue
        has, why = check_update(t)
        update_tool(slug, update_available=has, update_info=why, last_check=now())
        if has:
            res.append((slug, why))
            if t.get("update_mode") == "otomatik" and auto_apply:
                start_job(f"Otomatik güncelleme: {t['name']}", "update", update_flow, slug, True, cli=cli, auto=True)
    c = cfg(); c["last_update_check"] = time.time(); save_cfg(c)
    if res:
        notify(APP, "Güncelleme var: " + ", ".join(tools()[s]["name"] for s, _ in res))
    return res

def update_flow(job, slug, auto=False):
    t = tools()[slug]; root = t["path"]; job.slug = slug; job.icon = t.get("icon", ""); job.title = f"Güncelleme: {t['name']}"
    if os.path.isdir(os.path.join(root, ".git")):
        env = base_env(); env["GIT_TERMINAL_PROMPT"] = "0"
        job.log("⬇ git pull")
        r = subprocess.run(["git", "-C", root, "pull", "--ff-only", "--depth", "1"], capture_output=True, text=True, env=env)
        job.log(r.stdout + r.stderr)
        if r.returncode != 0:
            job.log("⚠ Hızlı ileri alma başarısız (yerel değişiklik olabilir). Uzak sürüme sıfırlamayı deneyebilirsin.")
            rr = job.ask("confirm", {"message": "Yerel değişiklikler atılıp uzak sürüme eşitlensin mi? (git fetch + reset --hard)"}) if not auto else None
            if rr and rr.get("ok"):
                subprocess.run(["git", "-C", root, "fetch", "--depth", "1", "origin"], env=env)
                subprocess.run(["git", "-C", root, "reset", "--hard", "FETCH_HEAD"], env=env)
            else:
                job.status = "hata"; return
    plan = finalize_plan(root, {"name": t["name"], "steps": t.get("steps", []), "actions": t.get("actions", []),
                                "runtimes": t.get("runtimes", []), "system_packages": t.get("system_packages", []), "warnings": []})
    plan["summary"] = "Güncelleme sonrası kurulum adımları yeniden çalıştırılacak."
    r = job.ask("plan", plan)
    if not r or not r.get("ok"):
        job.status = "iptal"; return
    plan.update(r.get("data") or {})
    ok = execute_plan(job, t, plan)
    update_tool(slug, status="kuruldu" if ok else "hata", update_available=not ok, update_info="" if ok else t.get("update_info", ""),
                commit=git_head(root), release_tag=job.ctx.get("release_tag") or t.get("release_tag", ""), updated_at=now(),
                steps=plan.get("steps", t.get("steps")), actions=plan.get("actions", t.get("actions")))
    if ok:
        make_shortcuts(tools()[slug], desktop=bool(desktop_dir()) and os.path.exists(os.path.join(desktop_dir() or "/x", f"{slug}.desktop")))
    job.status = "tamamlandı" if ok else "hata"
    notify(APP, f"{t['name']}: güncellendi ✅" if ok else f"{t['name']}: güncelleme hatası ❌")

def update_scheduler():
    while True:
        try:
            c = cfg()
            if c.get("update_check", True) and time.time() - c.get("last_update_check", 0) > 86400:
                check_all_updates()
        except Exception:
            pass
        time.sleep(1800)

def optional_flow(job, slug, idx):
    t = tools()[slug]; o = t["optional"][idx]; job.slug = slug; job.icon = t.get("icon", ""); job.title = f"{t['name']}: {o['label']}"
    plan = finalize_plan(t["path"], {"name": o["label"], "steps": [o["command"]], "actions": [], "warnings": [], "summary": o["label"]})
    r = job.ask("plan", plan)
    if not r or not r.get("ok"):
        job.status = "iptal"; return
    plan.update(r.get("data") or {})
    ok, _, _ = run_steps(job, plan.get("deps", []) + plan["steps"], t["path"])
    job.status = "tamamlandı" if ok else "hata"

def commands_flow(job, slug, cmds, title):
    t = tools()[slug] if slug else None; cwd = t["path"] if t else DATA; job.slug = slug or ""; job.title = title
    plan = finalize_plan(cwd, {"name": title, "steps": cmds, "actions": [], "warnings": [], "summary": title})
    r = job.ask("plan", plan)
    if not r or not r.get("ok"):
        job.status = "iptal"; return
    plan.update(r.get("data") or {})
    for rt in plan.get("runtimes", []):
        ensure_runtime(rt, job.log)
    ok, _, _ = run_steps(job, plan.get("deps", []) + plan["steps"], cwd)
    job.status = "tamamlandı" if ok else "hata"

# ───────────────────────────── süreçler (araçları uygulama içinde çalıştırma) ─────────────────────────────
PROCS = {}

class Proc:
    def __init__(self, title, cmd, cwd, slug=""):
        self.id = uuid.uuid4().hex[:10]; self.title = title; self.slug = slug; self.chunks = []; self.rc = None
        self.started = time.time(); self.fixes = []
        import codecs; self.dec = codecs.getincrementaldecoder("utf-8")("replace")
        m, s = pty.openpty()
        try:
            import termios, struct
            fcntl.ioctl(s, termios.TIOCSWINSZ, struct.pack("HHHH", 40, 140, 0, 0))
        except Exception:
            pass
        env = base_env(); env.update({"TERM": "xterm-256color", "CT_NOPAUSE": "1", "COLUMNS": "140", "LINES": "40"})
        self.p = subprocess.Popen(["bash", "-lc", cmd], cwd=cwd, stdin=s, stdout=s, stderr=s, env=env, start_new_session=True, close_fds=True)
        os.close(s); self.m = m
        PROCS[self.id] = self
        threading.Thread(target=self._read, daemon=True).start()

    def _read(self):
        buf = ""
        while True:
            try:
                d = os.read(self.m, 8192)
            except OSError:
                break
            if not d:
                break
            t = self.dec.decode(d); buf += t; buf = buf[-40000:]
            self.chunks.append(t)
            if len(self.chunks) > 6000:
                del self.chunks[:1000]
        self.rc = self.p.wait()
        self.chunks.append(f"\r\n\x1b[35m[süreç bitti — çıkış kodu {self.rc}]\x1b[0m\r\n")
        if self.rc not in (0, None):
            t = tools().get(self.slug)
            self.fixes = quick_fixes(clean_term(buf[-20000:]), t)
        try: os.close(self.m)
        except Exception: pass

    def resize(self, cols, rows):
        try:
            import termios, struct
            fcntl.ioctl(self.m, termios.TIOCSWINSZ, struct.pack("HHHH", int(rows), int(cols), 0, 0))
        except Exception:
            pass

    def write(self, text):
        try:
            os.write(self.m, text.encode())
        except OSError:
            pass

    def stop(self):
        try:
            os.killpg(self.p.pid, signal.SIGTERM)
            threading.Timer(3, lambda: self.p.poll() is None and os.killpg(self.p.pid, signal.SIGKILL)).start()
        except Exception:
            pass

    def summary(self):
        return {"id": self.id, "title": self.title, "slug": self.slug, "running": self.rc is None, "rc": self.rc,
                "started": self.started, "fixes": self.fixes}

def run_tool(slug, idx=0, args="", mode="app"):
    t = tools()[slug]
    if not t.get("actions"):
        raise RuntimeError("Bu aracın çalıştırma komutu yok. ⚙️ menüsünden bir eylem ekle.")
    launcher = make_launcher(t, idx)
    a = t["actions"][idx]
    if mode == "terminal":
        cmd_file = launcher
        if args:
            fd, cmd_file = tempfile.mkstemp(prefix=slug + "-", suffix=".sh", dir=LAUNCH_DIR)
            with os.fdopen(fd, "w") as f:
                f.write(f"#!/usr/bin/env bash\nexec {q(launcher)} {args}\n")
            os.chmod(cmd_file, 0o700)
        if not open_in_terminal(cmd_file):
            raise RuntimeError("Terminal uygulaması bulunamadı; 'Uygulama içinde' çalıştır.")
        return None
    if not a.get("terminal", True) and mode == "detached":
        subprocess.Popen([launcher], cwd=t["path"], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return None
    return Proc(f"{t['name']} — {a['label']}", f"{q(launcher)} {args}", t["path"], slug)

# ───────────────────────────── ücretsiz AI bulucu ─────────────────────────────
KEYLESS_CANDIDATES = [
    {"name": "Ollama (bu bilgisayar)", "type": "openai", "base_url": "http://127.0.0.1:11434/v1", "local": True, "env": ""},
    {"name": "LM Studio (bu bilgisayar)", "type": "openai", "base_url": "http://127.0.0.1:1234/v1", "local": True, "env": ""},
    {"name": "llama.cpp sunucusu (bu bilgisayar)", "type": "openai", "base_url": "http://127.0.0.1:8080/v1", "local": True, "env": ""},
    {"name": "Jan (bu bilgisayar)", "type": "openai", "base_url": "http://127.0.0.1:1337/v1", "local": True, "env": ""},
    {"name": "Pollinations (bulut, anahtarsız)", "type": "openai", "base_url": "https://text.pollinations.ai/openai", "model": "openai", "env": ""},
]

OLLAMA_MODELS = [
    {"id": "qwen2.5-coder:7b", "ad": "Qwen2.5 Coder 7B", "tur": "Kodlama", "boyut_gb": 4.7, "ram": 8, "not": "Hafif ve iyi bir kodlama modeli; çoğu bilgisayarda çalışır."},
    {"id": "qwen3-coder:30b", "ad": "Qwen3 Coder 30B (MoE)", "tur": "Kodlama / ajan", "boyut_gb": 19, "ram": 32, "not": "Yerelde en güçlü kodlama seçeneklerinden; 24 GB+ VRAM veya 32 GB+ RAM ister."},
    {"id": "gpt-oss:20b", "ad": "gpt-oss 20B", "tur": "Genel + kod + akıl yürütme", "boyut_gb": 14, "ram": 16, "not": "16 GB RAM ile çalışabilen güçlü genel model."},
    {"id": "qwen3.5:9b", "ad": "Qwen3.5 9B", "tur": "Genel sohbet", "boyut_gb": 6.6, "ram": 12, "not": "Bütçe dostu genel model (ARIA'nın varsayılanı)."},
    {"id": "gemma3:4b", "ad": "Gemma 3 4B", "tur": "Hafif sohbet", "boyut_gb": 3.3, "ram": 6, "not": "Zayıf donanım için; hızlı."},
    {"id": "deepseek-r1:8b", "ad": "DeepSeek-R1 8B", "tur": "Akıl yürütme", "boyut_gb": 5.2, "ram": 10, "not": "Adım adım düşünen akıl yürütme modeli."},
    {"id": "llama3.2:3b", "ad": "Llama 3.2 3B", "tur": "Çok hafif sohbet", "boyut_gb": 2.0, "ram": 4, "not": "En düşük donanım için."},
]

def test_endpoint(c, model=None):
    base = c["base_url"].rstrip("/"); t0 = time.time()
    models = []
    try:
        r = http_json(base + "/models", timeout=6)
        models = [m.get("id") for m in r.get("data", []) if m.get("id")]
    except Exception:
        if c.get("local"):
            return {"ok": False, "error": "çalışmıyor"}
    mdl = model or c.get("model") or (models[0] if models else "")
    if not mdl:
        return {"ok": False, "error": "model yok", "models": models}
    try:
        out = llm_call({"type": "openai", "base_url": base, "model": mdl}, [{"role": "user", "content": "Sadece 'tamam' yaz."}], timeout=40)
        return {"ok": bool(out.strip()), "model": mdl, "models": models, "ms": int((time.time() - t0) * 1000), "sample": out.strip()[:60]}
    except Exception as e:
        return {"ok": False, "error": str(e)[:200], "models": models}

def free_ai_scan(job, add):
    job.title = "Ücretsiz AI taraması"
    found = []
    job.log("🔎 Anahtarsız uç noktalar canlı test ediliyor…")
    for c in KEYLESS_CANDIDATES:
        r = test_endpoint(c)
        job.log(f"  {'✅' if r['ok'] else '✖'} {c['name']}: " + (f"{r['model']} ({r.get('ms')} ms)" if r["ok"] else r.get("error", "")))
        if r["ok"]:
            found.append({**c, "model": r["model"], "models": r.get("models", [])})
    job.log("🔎 GitHub'da ücretsiz LLM API listeleri aranıyor…")
    gh = []
    for qy in ("free llm api resources", "free ai api list", "awesome free llm"):
        try:
            r = gh_api("/search/repositories?" + urllib.parse.urlencode({"q": qy, "sort": "stars", "per_page": 6}))
            for it in r.get("items", []):
                if it["full_name"] not in [g["full_name"] for g in gh]:
                    gh.append({"full_name": it["full_name"], "url": it["html_url"], "stars": it["stargazers_count"], "description": it.get("description") or ""})
        except Exception as e:
            job.log(f"  GitHub araması başarısız: {str(e)[:120]}"); break
    gh.sort(key=lambda g: -g["stars"])
    job.ctx["github"] = gh[:12]
    if add:
        c = cfg(); existing = {p["base_url"].rstrip("/") for p in c["providers"]}
        for f in found:
            if f["base_url"].rstrip("/") not in existing:
                c["providers"].append({"id": uuid.uuid4().hex[:8], "name": f["name"], "type": "openai", "base_url": f["base_url"],
                                       "model": f["model"], "api_key": "", "env": "", "enabled": True, "keyless": True})
                job.log(f"➕ Eklendi: {f['name']} ({f['model']})")
        if not c.get("default_provider") and c["providers"]:
            c["default_provider"] = c["providers"][0]["id"]
        save_cfg(c)
    job.ctx["found"] = found
    job.log(f"✔ Bitti: {len(found)} çalışan anahtarsız uç nokta, {len(gh)} GitHub listesi.")
    if not found:
        job.log("ℹ Hiç anahtarsız uç nokta çalışmıyor. En sağlam çözüm: Ollama kurup bir model indirmek (aşağıdan tek tuşla).")

def ollama_setup_flow(job, model):
    job.title = f"Yerel AI: Ollama + {model}"
    if not which("ollama"):
        r = job.ask("plan", {"name": "Ollama", "summary": "Yerel modelleri API anahtarı olmadan çalıştırmak için Ollama kurulacak (resmi kurulum betiği, yönetici izni ister).",
                             "steps": ["@terminal curl -fsSL https://ollama.com/install.sh | sh"], "actions": [], "deps": [],
                             "warnings": ["Resmi Ollama kurulum betiği internetten indirilip çalıştırılır (ollama.com)."]})
        if not r or not r.get("ok"):
            job.status = "iptal"; return
        ok, _, _ = run_steps(job, (r.get("data") or {}).get("steps") or ["@terminal curl -fsSL https://ollama.com/install.sh | sh"], DATA)
        if not ok or not which("ollama"):
            job.log("✖ Ollama kurulamadı."); job.status = "hata"; return
    try:
        http_get("http://127.0.0.1:11434/api/version", timeout=3)
    except Exception:
        job.log("▶ Ollama sunucusu başlatılıyor…")
        subprocess.Popen(["ollama", "serve"], env=base_env(), start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(3)
    rc, _ = run_shell(job, f"ollama pull {q(model)}", DATA)
    if rc != 0:
        job.status = "hata"; return
    c = cfg()
    p = next((p for p in c["providers"] if "11434" in p.get("base_url", "")), None)
    if p:
        p["model"] = model
    else:
        p = {"id": uuid.uuid4().hex[:8], "name": "Ollama (yerel)", "type": "openai", "base_url": "http://127.0.0.1:11434/v1",
             "model": model, "api_key": "", "env": "", "enabled": True, "keyless": True}
        c["providers"].append(p)
    if not c.get("default_provider"):
        c["default_provider"] = p["id"]
    save_cfg(c)
    job.log(f"✅ Hazır! '{model}' API anahtarsız olarak sağlayıcılara eklendi. Ajanlar sekmesinden sohbet edebilirsin.")

# ───────────────────────────── dışa / içe aktarma ─────────────────────────────
def export_all(full=False, include_keys=False):
    c = cfg(); ts = time.strftime("%Y%m%d-%H%M")
    man = {"app": APP, "version": VERSION, "exported_at": now(), "tools": [], "agents": c.get("agents", []),
           "providers": [{k: v for k, v in p.items() if include_keys or k != "api_key"} for p in c.get("providers", [])],
           "settings": {k: c[k] for k in ("failover", "use_ai", "auto_shortcut", "release_assets", "update_check", "update_default_mode")},
           "memory": mem_all(), "learned_recipes": jload(USER_CATALOG, []), "agent_rules": c.get("agent_rules", "")}
    for slug, t in tools().items():
        e = {k: v for k, v in t.items() if k != "path"}
        if t.get("icon") and os.path.exists(os.path.join(ICON_DIR, t["icon"])):
            e["icon_b64"] = base64.b64encode(open(os.path.join(ICON_DIR, t["icon"]), "rb").read()).decode()
        man["tools"].append(e)
    if not full:
        p = os.path.join(EXPORT_DIR, f"cyphertool-araclar-{ts}.json")
        jsave(p, man, private=include_keys)
        return p
    p = os.path.join(EXPORT_DIR, f"cyphertool-tam-{ts}.tar.gz")
    ex = {".venv", "node_modules", "__pycache__", "target", ".dl-"}
    def filt(ti):
        parts = ti.name.split("/")
        return None if any(x in ex or x.startswith(".dl-") for x in parts) else ti
    with tarfile.open(p, "w:gz") as tf:
        data = json.dumps(man, ensure_ascii=False, indent=2).encode()
        info = tarfile.TarInfo("manifest.json"); info.size = len(data); info.mtime = time.time()
        import io
        tf.addfile(info, io.BytesIO(data))
        for slug, t in tools().items():
            if os.path.isdir(t["path"]):
                tf.add(t["path"], arcname=f"tools/{slug}", filter=filt)
    if include_keys:
        os.chmod(p, 0o600)
    return p

def import_flow(job, path):
    job.title = f"İçe aktarma: {os.path.basename(path)}"
    tmpdir = None
    if path.endswith(".json"):
        man = jload(path, {})
    else:
        tmpdir = tempfile.mkdtemp(prefix="ct-import-")
        with tarfile.open(path) as tf:
            safe_tar_extract(tf, tmpdir)
        man = jload(os.path.join(tmpdir, "manifest.json"), {})
    if man.get("app") != APP:
        raise RuntimeError("Bu dosya bir Cypher Tool dışa aktarımı değil.")
    c = cfg()
    have = {(a.get("id"), a.get("name")) for a in c["agents"]}
    c["agents"] += [a for a in man.get("agents", []) if (a.get("id"), a.get("name")) not in have]
    urls = {p["base_url"] for p in c["providers"]}
    for p in man.get("providers", []):
        if p.get("base_url") not in urls:
            c["providers"].append(p)
    save_cfg(c)
    if man.get("agent_rules") and not c.get("agent_rules"):
        c["agent_rules"] = man["agent_rules"]; save_cfg(c)
    for x in man.get("memory", []):
        mem_add(x.get("text", ""), x.get("kind", "ders"))
    if man.get("learned_recipes"):
        uc = jload(USER_CATALOG, []); have = {x["source"] for x in uc}
        jsave(USER_CATALOG, uc + [x for x in man["learned_recipes"] if x["source"] not in have])
    job.log(f"🧠 {len(man.get('memory', []))} hafıza notu ve {len(man.get('learned_recipes', []))} öğrenilmiş tarif alındı.")
    job.log(f"✔ {len(man.get('agents', []))} ajan ve {len(man.get('providers', []))} API ayarı alındı (anahtarlar dahil değilse API'ler sekmesinden gir).")
    for e in man.get("tools", []):
        name = e.get("name", e.get("slug"))
        if tmpdir and os.path.isdir(os.path.join(tmpdir, "tools", e["slug"])):
            dest = unique_dir(TOOLS_DIR, e["slug"]); shutil.move(os.path.join(tmpdir, "tools", e["slug"]), dest)
            slug = os.path.basename(dest)
            icon = ""
            if e.get("icon_b64"):
                icon = slug + os.path.splitext(e.get("icon", ".png"))[1]
                open(os.path.join(ICON_DIR, icon), "wb").write(base64.b64decode(e["icon_b64"]))
            t = {k: v for k, v in e.items() if k != "icon_b64"}; t.update({"slug": slug, "path": dest, "icon": icon, "status": "kuruluyor"})
            with _lock:
                tt = tools(); tt[slug] = t; save_tools(tt)
            job.log(f"📁 {name}: dosyalar alındı, ortam yeniden kuruluyor…")
            plan = finalize_plan(dest, {"name": name, "steps": t.get("steps", []), "actions": t.get("actions", []),
                                        "runtimes": t.get("runtimes", []), "system_packages": t.get("system_packages", []), "warnings": []})
            plan["summary"] = "İçe aktarılan aracın ortamı (.venv, node_modules vb.) bu bilgisayarda yeniden kuruluyor."
            r = job.ask("plan", plan)
            ok = bool(r and r.get("ok")) and execute_plan(job, t, {**plan, **((r or {}).get("data") or {})})
            update_tool(slug, status="kuruldu" if ok else "hata")
            make_shortcuts(tools()[slug])
        else:
            job.log(f"⬇ {name}: kaynaktan yeniden kuruluyor…")
            rec = find_catalog(e.get("source", ""))
            preset = rec or {"source": e.get("source"), "name": name, "install": [
                {"type": "release", **json.loads(s[9:])} if s.startswith("@release ") else {"type": "shell", "command": s} for s in e.get("steps", [])],
                "actions": e.get("actions", []), "runtimes": e.get("runtimes", []), "system_packages": e.get("system_packages", []),
                "guide_tr": e.get("guide_tr", ""), "category": e.get("category", "")}
            try:
                sub = Job(job.title, "install"); sub.lines = job.lines; sub.cli = job.cli
                sub.ask = job.ask  # aynı onay kanalı
                install_flow(sub, e.get("source"), {}, preset=preset)
            except Exception as ex:
                job.log(f"✖ {name}: {ex}")
    if tmpdir:
        shutil.rmtree(tmpdir, ignore_errors=True)
    job.log("✅ İçe aktarma bitti.")

# ───────────────────────────── ajan sohbeti ─────────────────────────────
def chat(agent_id, messages, slug=""):
    c = cfg(); ag = next((a for a in c["agents"] if a["id"] == agent_id), c["agents"][0])
    sysmsg = ag["system"] + f"\n\nKullanıcının sistemi: {os_info().get('PRETTY_NAME', 'Linux')} ({detect_pm()}), {platform.machine()}."
    if slug and slug in tools():
        t = tools()[slug]
        sysmsg += (f"\n\nBağlam — kullanıcının Cypher Tool ile kurduğu araç: {t['full_name']} (klasör: {t['path']}).\n"
                   f"Eylemler: {json.dumps(t.get('actions', []), ensure_ascii=False)}\n"
                   f"Önerdiğin ```bash bloklarındaki komutlar kullanıcı onaylarsa bu araç klasöründe çalıştırılır.\n"
                   f"README:\n{read_readme(t['path'], 7000)}")
    txt, p = llm_ask(messages[-30:], sysmsg, ag.get("provider", ""), ag.get("model", ""))
    return {"reply": txt, "provider": p.get("name"), "agent": ag["name"]}

# ───────────────────────────── görev ajanı (araştır → kur → dene → kullan → gerekirse geliştir) ─────────────────────────────
WORK_DIR = os.path.join(DATA, "workspace")
os.makedirs(WORK_DIR, exist_ok=True)

def run_capture(job, cmd, cwd, timeout=180):
    """Komutu zaman aşımıyla çalıştırır, çıktıyı hem kayda hem dönüşe verir."""
    if needs_root(cmd) and not is_root():
        rc, tail = run_privileged(job, strip_sudo(cmd), cwd)
        return rc, "\n".join(tail)
    job.log(f"$ {cmd}")
    env = base_env(); env["CT_NOPAUSE"] = "1"
    p = subprocess.Popen(["bash", "-lc", cmd], cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, text=True, errors="replace", start_new_session=True)
    out = []
    def rd():
        for line in p.stdout:
            line = clean_term(line.rstrip("\n")); out.append(line); job.log("  " + line)
            if len(out) > 4000:
                del out[:1000]
    th = threading.Thread(target=rd, daemon=True); th.start()
    try:
        rc = p.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        try: os.killpg(p.pid, signal.SIGKILL)
        except Exception: pass
        rc = -9; job.log(f"⏱ Zaman aşımı ({timeout} sn) — süreç durduruldu")
    th.join(3)
    return rc, "\n".join(out)

def gh_search(query, n=8):
    q = query.strip()
    if "fork:" not in q:
        q += " fork:false archived:false"
    r = gh_api("/search/repositories?" + urllib.parse.urlencode({"q": q, "sort": "stars", "order": "desc", "per_page": max(n, 10)}))
    res = []
    for it in r.get("items", [])[:n]:
        res.append({"repo": it["full_name"], "stars": it["stargazers_count"], "description": (it.get("description") or "")[:200],
                    "language": it.get("language") or "", "updated": (it.get("pushed_at") or "")[:10],
                    "license": ((it.get("license") or {}).get("spdx_id") or ""), "url": it["html_url"], "topics": it.get("topics", [])[:6]})
    return res

def gh_readme(repo, limit=7000):
    try:
        tok = cfg().get("github_token", "")
        h = {"Accept": "application/vnd.github.raw"}
        if tok:
            h["Authorization"] = f"Bearer {tok}"
        return http_get(f"https://api.github.com/repos/{repo}/readme", headers=h)[:limit]
    except Exception:
        for br in ("HEAD", "main", "master"):
            for fn in ("README.md", "readme.md", "README.rst", "README"):
                try:
                    return http_get(f"https://raw.githubusercontent.com/{repo}/{br}/{fn}")[:limit]
                except Exception:
                    continue
    return ""

def smoke_test(job, slug, timeout=25):
    """Aracı etkileşimsiz olarak dener (--help / --version). (geçti_mi, özet)"""
    t = tools()[slug]
    if not t.get("actions"):
        return False, "Çalıştırma komutu yok"
    base = t["actions"][0]["command"]
    for extra in ("--help", "--version", "-h", ""):
        rc, out = run_capture(job, f"{base} {extra}".strip(), t["path"], timeout)
        ok = rc == 0 or bool(re.search(r"usage|kullanım|options|--help|version|\bv?\d+\.\d+", out, re.I)) and rc not in (126, 127)
        if ok:
            update_tool(slug, test={"ok": True, "at": now(), "cmd": f"{base} {extra}".strip(), "out": out[-1500:]})
            save_user_recipe(tools()[slug], tested=True)
            return True, f"`{base} {extra}` çalıştı (kod {rc}):\n{out[-1200:]}"
    update_tool(slug, test={"ok": False, "at": now(), "out": out[-1500:]})
    return False, f"Deneme başarısız (kod {rc}):\n{out[-1500:]}"

def resolve_tool(ref):
    """Ajanın verdiği araç adını (slug, ad, repo) kurulu araçla eşleştirir."""
    tl = tools()
    if ref in tl:
        return ref
    r = slugify(ref or "")
    for s, t in tl.items():
        if r and (slugify(s) == r or slugify(t.get("name", "")) == r or slugify(t.get("full_name", "").split("/")[-1]) == r):
            return s
    return None

def safe_path(p, roots):
    ap = os.path.realpath(os.path.expanduser(p))
    return ap if any(ap == os.path.realpath(r) or ap.startswith(os.path.realpath(r) + os.sep) for r in roots) else None

AGENT_SYS = """Sen Cypher Tool'un GÖREV AJANISIN. Kullanıcının Linux bilgisayarında, verdiği görevi baştan sona kendin yaparsın:
1) Önce kurulu araçlara bak (list_tools). Uygun araç varsa onu kullan.
2) Yoksa GitHub'da ara (search_github — İNGİLİZCE anahtar kelimelerle), adayları yıldız, güncellik, lisans ve Linux desteğine göre değerlendir; gerekirse repo_info ile README'sini oku.
3) En iyisini kur (install). Kurulum planını kullanıcı onaylar.
4) Kurduğun aracı DENE (smoke_test ve/veya run ile --help, örnek kullanım). Hata olursa düzelt (README'ye göre komutları değiştir, eksik paketi kur, gerekirse başka aday dene).
5) Görev bir iş yapmaksa (dosya dönüştürme, indirme, analiz vb.) aracı run ile KULLANARAK işi bitir ve sonucu doğrula (ör. çıktı dosyası var mı, ls ile bak).
6) Uygun araç yoksa ya da çok basit bir işse KENDİ ARACINI GELİŞTİR (create_tool): temiz, çalışan, hata kontrollü kod yaz (tercihen Python stdlib veya küçük bağımlılıklar), README + Türkçe rehber ekle, sonra mutlaka dene.
7) Bir işi bitirince finish ile Türkçe rapor ver: ne yaptın, hangi araç, nasıl kullanılır, test sonucu, oluşan dosyalar. finish'ten sonra kullanıcı yeni istek verebilir; sohbet devam eder.

SOHBET KURALLARI (çok önemli):
- Kullanıcıyla Türkçe, samimi ve net konuş. Görev belirsizse ya da birden fazla yol varsa önce say ile ne istediğini sor (seçenekler sun).
- Bir aracı kurup tanıdığında (README'sini okuyup denedikten sonra) say ile kullanıcıya o araçla NELER YAPABİLECEĞİNİ somut maddelerle anlat ("Bu araçla şunları yapabilirim: …") ve options içinde 3-5 tıklanabilir öneri ver; sonra kullanıcının talimatını bekle.
- Kullanıcının talimatını uygula, sonucu göster, sonra yine "başka ne yapayım?" diye seçenek sun.
- Kullanıcı açıkça "kendin karar ver / hepsini yap" demedikçe, büyük ya da geri alınamaz işlerden önce say ile onayını al.
- Kullanıcı "hatırla", "unutma", "bundan sonra hep …", "bir daha … yapma" gibi bir şey derse HEMEN remember (kind: tercih) ile kaydet ve kaydettiğini söyle.
- Kullanıcı yaptığın bir şeyi düzeltirse ("yanlış oldu, şöyle olmalıydı") bunu remember (kind: ders) ile kaydet.

HER YANITIN SADECE TEK BİR JSON NESNESİ olmalı:
{"thought": "kısa Türkçe düşünce", "action": "<eylem>", "args": {...}}

EYLEMLER:
- list_tools {}  → kurulu araçlar
- search_github {"query": "pdf merge cli"}  → GitHub adayları (GitHub arama sözdizimi kullanabilirsin: language:python, stars:>100)
- repo_info {"repo": "sahip/ad"}  → açıklama + README
- install {"url": "https://github.com/sahip/ad"}  → kurar (eksik bağımlılıkları da), dönüşte araç adı (slug) ve eylemleri gelir
- read_tool {"slug": "..."}  → kurulu aracın README'si ve eylemleri
- smoke_test {"slug": "..."}  → aracı --help/--version ile otomatik dener
- run {"command": "...", "where": "work" | "<slug>" | "/mutlak/klasör", "timeout": 180}  → bash komutu çalıştırır (kullanıcı onaylar). "where": slug ise o aracın klasöründe çalışır (.venv/bin/..., ./bin/... yolları oradan geçerli). Etkileşimli (girdi bekleyen) komut çalıştırma; her zaman etkileşimsiz bayrakları kullan.
- write_file {"path": "çalışma klasörüne göre yol veya mutlak yol", "content": "..."}  → dosya yazar
- create_tool {"name": "...", "description_tr": "...", "files": {"main.py": "..."}, "steps": ["python3 -m venv .venv", ".venv/bin/pip install ..."], "actions": [{"label": "Başlat", "command": ".venv/bin/python main.py", "terminal": true}], "guide_tr": "## Ne işe yarar?\\n..."}  → yeni araç geliştirip Cypher Tool'a ekler
- say {"message_tr": "kullanıcıya söyleyeceğin (Markdown olabilir)", "options": ["öneri 1", "öneri 2", "..."]}  → kullanıcıya konuşur/sorar ve CEVABINI BEKLER (cevap GÖZLEM olarak gelir)
- finish {"report_tr": "Markdown Türkçe rapor", "next_options": ["sonraki öneri 1", "..."]}  → işi bitirir, kullanıcıya rapor verir ve yeni isteğini bekler
- remember {"note": "kısa, genel geçer not", "kind": "ders" | "tercih" | "araç"}  → KALICI HAFIZAYA yazar. Kullan: kullanıcının bir tercihini öğrendiğinde (tercih), işe yarayan bir komut/çözüm bulduğunda ya da bir hatadan ders çıkardığında (ders), bir aracın neyi nasıl yaptığını öğrendiğinde (araç; slug ve örnek komutla). Gereksiz/tek seferlik şeyleri yazma.

HAFIZA: Aşağıda geçmiş oturumlardan öğrendiklerin var. Bunlara uy (özellikle kullanıcı tercihlerine) ve aynı hataları tekrarlama.

KURALLAR: Global kurulum yapma (proje içi .venv / yerel npm). Kullanıcının dosyalarını silme veya üzerine yazma; çıktıları yeni dosyalara yaz. Aynı başarısız şeyi tekrar etme, farklı yol dene. Gizli bilgi (şifre, anahtar) isteme. Gözlemleri dikkatle oku."""

def agent_flow(job, task, opts):
    opts = opts or {}
    workdir = os.path.expanduser(opts.get("workdir") or WORK_DIR)
    os.makedirs(workdir, exist_ok=True)
    auto = bool(opts.get("auto")); max_steps = int(opts.get("max_steps", 30))
    job.auto = auto  # kullanıcı "sormadan çalıştır" dediyse planlar otomatik onaylanır (şifre ve sorular yine sorulur)
    job.title = "🎯 " + task[:70]; job.ctx["task"] = task; job.ctx["steps"] = []
    title = job.title
    if not llm_available():
        return hunt_fallback(job, task, workdir)
    oi = os_info()
    sysmsg = AGENT_SYS + (f"\n\nSİSTEM: {oi.get('PRETTY_NAME', 'Linux')} | paket yöneticisi: {detect_pm()} | {platform.machine()} | "
                          f"RAM {mem_gb()} GB | Python {platform.python_version()} | node: {'var' if which('node') else 'yok'} | "
                          f"ollama: {'var' if which('ollama') else 'yok'}\nÇALIŞMA KLASÖRÜ (work): {workdir}\nEv dizini: {os.path.expanduser('~')}")
    rules = (cfg().get("agent_rules") or "").strip()
    if rules:
        sysmsg += "\n\nKULLANICININ KALICI TALİMATLARI (EN YÜKSEK ÖNCELİK — her zaman uy):\n" + rules
        job.log("📜 Kalıcı talimatlar yüklendi")
    mc = mem_context(task)
    sysmsg += "\n\nHAFIZAN (geçmiş oturumlardan):\n" + (mc or "(henüz boş)")
    persona = next((a for a in cfg()["agents"] if a.get("id") == opts.get("persona")), None)
    if persona:
        sysmsg += f"\n\nEK KİŞİLİK ({persona['name']}): {persona['system']}"
        job.log(f"🎭 Kişilik: {persona['name']}")
    if mc:
        job.log(f"🧠 Hafızadan {mc.count(chr(10)) + 1} not yüklendi")
    msgs = [{"role": "user", "content": f"GÖREV: {task}" if task.strip() else "GÖREV: (kullanıcı henüz bir görev yazmadı — kendini kısaca tanıt ve say ile ne yapmak istediğini sor, örnek seçenekler sun)"}]
    job.ctx["chat"] = [{"role": "user", "text": task}] if task.strip() else []
    job.log(f"🎯 Görev: {task}\n📁 Çalışma klasörü: {workdir}\n🤖 Onay modu: {'otomatik (komutlar sorulmadan)' if auto else 'her komutta onay'}")
    roots = [workdir, TOOLS_DIR]
    step = 0; budget = max_steps
    while True:
        step += 1
        if step > budget:
            r = job.ask("question", {"question": f"⏳ {max_steps} adımlık sınıra geldim. Devam edeyim mi, yoksa başka bir şey mi yapayım?", "options": ["Devam et", "Bitir"]})
            ans = (((r or {}).get("data") or {}).get("answer") or "") if r and r.get("ok") else ""
            if not ans or ans.strip().lower() in ("bitir", "dur", "çık", "kapat"):
                break
            job.ctx["chat"].append({"role": "user", "text": ans}); budget = step + max_steps
            msgs.append({"role": "user", "content": "KULLANICI: " + ans}); continue
        if job.cancelled:
            job.status = "iptal"; return
        job.status = f"düşünüyor (adım {step})"
        try:
            txt, prov = llm_ask(msgs[:1] + msgs[-24:], sysmsg, opts.get("provider", ""), opts.get("model", ""), log=job.log)
        except Exception as e:
            job.log(f"✖ Yapay zekâya ulaşılamadı: {e}"); job.status = "hata"; return
        try:
            d = extract_json(txt); act = d.get("action", ""); args = d.get("args") or {}
        except Exception:
            msgs += [{"role": "assistant", "content": txt[:2000]}, {"role": "user", "content": "GÖZLEM: Yanıtın geçerli JSON değildi. SADECE tek bir JSON nesnesi döndür."}]
            continue
        job.log(f"\n💭 {d.get('thought', '')}\n▶ {act} {json.dumps(args, ensure_ascii=False)[:300]}")
        stp = {"role": "step", "n": step, "thought": d.get("thought", ""), "action": act, "args": {k: (v if len(str(v)) < 300 else str(v)[:300] + "…") for k, v in args.items()}}
        job.ctx["steps"].append(stp)
        if act not in ("finish", "say", "ask_user"):
            job.ctx["chat"].append(stp)
        job.status = f"{act} (adım {step})"
        obs = ""
        try:
            if act in ("finish", "say", "ask_user"):
                if act == "finish":
                    msg = args.get("report_tr") or d.get("thought", ""); opts_ = args.get("next_options") or []
                    job.ctx["report"] = msg; job.log("\n✅ İŞ TAMAMLANDI\n" + msg)
                    notify(APP, "🎯 Görev Ajanı işi bitirdi — sonraki isteğini bekliyor")
                else:
                    msg = args.get("message_tr") or args.get("question") or d.get("thought", ""); opts_ = args.get("options") or []
                    job.log("\n💬 " + msg)
                job.ctx["chat"].append({"role": "agent", "text": msg, "options": opts_, "final": act == "finish"})
                job.title = title
                r = job.ask("question", {"question": msg, "options": opts_, "final": act == "finish"})
                ans = (((r or {}).get("data") or {}).get("answer") or "").strip() if r and r.get("ok") else ""
                if not ans or ans.lower() in ("bitir", "dur", "çık", "kapat", "teşekkürler", "tesekkurler", "yeter"):
                    agent_reflect(job, msgs, sysmsg, opts)
                    job.status = "tamamlandı"; job.log("👋 Oturum bitti."); return
                job.ctx["chat"].append({"role": "user", "text": ans}); job.log("🧑 " + ans)
                budget = step + max_steps
                msgs += [{"role": "assistant", "content": json.dumps(d, ensure_ascii=False)}, {"role": "user", "content": "KULLANICI: " + ans}]
                continue
            elif act == "remember":
                mem_add(args.get("note", ""), args.get("kind", "ders")); obs = "Hafızaya yazıldı."
                job.log("🧠 Hafızaya eklendi: " + args.get("note", "")[:200])
            elif act == "list_tools":
                obs = json.dumps([{"slug": s, "name": t["name"], "repo": t.get("full_name"), "ne_yapar": (t.get("summary") or "")[:200],
                                   "eylemler": [a["command"] for a in t.get("actions", [])], "durum": t.get("status")} for s, t in tools().items()], ensure_ascii=False) or "[] (hiç araç yok)"
            elif act == "search_github":
                obs = json.dumps(gh_search(args.get("query", task)), ensure_ascii=False)
            elif act == "repo_info":
                repo = args.get("repo", "").replace("https://github.com/", "").strip("/")
                m = gh_meta(*repo.split("/", 1)) if "/" in repo else {}
                obs = json.dumps({k: m.get(k) for k in ("full_name", "description", "stars", "language", "license", "topics")}, ensure_ascii=False) + "\nREADME:\n" + gh_readme(repo)
            elif act == "install":
                url = args.get("url", "")
                before = set(tools())
                install_flow(job, url, {"shortcut": opts.get("shortcut", True), "provider": opts.get("provider", "")})
                job.title = title
                new = [s for s in tools() if s not in before]
                if new:
                    t = tools()[new[0]]
                    obs = json.dumps({"slug": new[0], "durum": t["status"], "eylemler": t.get("actions", []), "klasör": t["path"]}, ensure_ascii=False)
                    job.ctx.setdefault("installed", []).append(new[0])
                else:
                    obs = "Kurulum yapılmadı (kullanıcı iptal etti ya da hata oluştu). Son kayıtlar:\n" + "\n".join(job.lines[-25:])
            elif act == "read_tool":
                t = tools()[resolve_tool(args.get("slug", "")) or args.get("slug", "")]
                obs = json.dumps({"eylemler": t.get("actions"), "klasör": t["path"], "kurulum": t.get("steps")}, ensure_ascii=False) + "\nREADME:\n" + read_readme(t["path"], 7000)
            elif act == "smoke_test":
                ok, out = smoke_test(job, resolve_tool(args.get("slug", "")) or args.get("slug", ""))
                obs = ("BAŞARILI: " if ok else "BAŞARISIZ: ") + out
            elif act == "run":
                cmd = args.get("command", "").strip(); where = str(args.get("where", "work") or "work")
                ts = resolve_tool(where)
                if ts:
                    where = ts; cwd = tools()[ts]["path"]
                elif where in ("work", "") :
                    cwd = workdir
                elif os.path.isdir(os.path.expanduser(where)):
                    cwd = os.path.expanduser(where)
                else:
                    raise KeyError(f"'{where}' adında araç ya da klasör yok")
                if not auto:
                    plan = finalize_plan(cwd, {"name": "Ajanın komutu", "summary": f"💭 {d.get('thought', '')}\n📁 {cwd}", "steps": [cmd], "actions": [], "warnings": []})
                    r = job.ask("plan", plan)
                    if not r or not r.get("ok"):
                        obs = "Kullanıcı bu komutu ONAYLAMADI. Başka bir yol düşün ya da ask_user ile sor."
                        msgs += [{"role": "assistant", "content": json.dumps(d, ensure_ascii=False)}, {"role": "user", "content": "GÖZLEM: " + obs}]
                        continue
                    data = r.get("data") or {}
                    for c in data.get("deps", []) or []:
                        run_capture(job, c, cwd)
                    cmd = " && ".join(data.get("steps") or [cmd])
                rc, out = run_capture(job, cmd, cwd, int(args.get("timeout", 180)))
                fixes = quick_fixes(out, tools().get(where))
                obs = f"çıkış kodu: {rc}\nÇIKTI (son kısım):\n{out[-3500:]}" + (f"\nOTOMATİK TESPİT: {json.dumps(fixes, ensure_ascii=False)}" if fixes else "")
            elif act == "write_file":
                p = args.get("path", "")
                ap = safe_path(p if os.path.isabs(os.path.expanduser(p)) else os.path.join(workdir, p), roots)
                if not ap:
                    obs = f"Bu yola yazma izni yok. Sadece çalışma klasörü ({workdir}) veya araç klasörleri."
                else:
                    content = args.get("content", "")
                    if not auto:
                        r = job.ask("confirm", {"message": f"Ajan bir dosya yazmak istiyor:\n{ap}\n({len(content.splitlines())} satır)\n\n{content[:1500]}"})
                        if not r or not r.get("ok"):
                            obs = "Kullanıcı dosya yazmayı onaylamadı."
                    if not obs:
                        os.makedirs(os.path.dirname(ap), exist_ok=True)
                        if os.path.exists(ap) and not ap.startswith(os.path.realpath(TOOLS_DIR)) and not ap.startswith(os.path.realpath(WORK_DIR)):
                            obs = "Dosya zaten var; kullanıcının dosyasının üzerine yazılmaz. Başka bir ad kullan."
                        else:
                            open(ap, "w", encoding="utf-8").write(content); obs = f"Yazıldı: {ap}"; job.log(f"📝 {ap}")
            elif act == "create_tool":
                obs = agent_create_tool(job, args, opts)
                job.title = title
            else:
                obs = f"Bilinmeyen eylem: {act}. Geçerli eylemlerden birini kullan."
        except KeyError as e:
            obs = f"Bulunamadı: {e}. list_tools ile doğru slug'ı kontrol et."
        except Exception as e:
            obs = f"HATA: {str(e)[:800]}"
        job.log("👁 " + obs[:600].replace("\n", "\n   "))
        stp["obs"] = obs[:700]
        msgs += [{"role": "assistant", "content": json.dumps(d, ensure_ascii=False)}, {"role": "user", "content": "GÖZLEM: " + obs[:5000]}]
    job.status = "tamamlandı"

def agent_reflect(job, msgs, sysmsg, opts):
    """Oturumdan kalıcı dersler çıkarır (kendini geliştirme)."""
    if len(msgs) < 4:
        return
    try:
        txt, _ = llm_ask(msgs[:1] + msgs[-30:] + [{"role": "user", "content":
            "OTURUM BİTTİ. Bu oturumdan gelecekte işine yarayacak en fazla 5 kalıcı ders/tercih/araç bilgisi çıkar "
            "(ör. 'X işi için Y aracı iyi çalışıyor: komut …', 'Kullanıcı çıktıları masaüstüne istiyor', 'Z kurulumunda şu hata şöyle çözüldü'). "
            "Zaten hafızada olanları tekrar etme. SADECE JSON: {\"notes\":[{\"note\":\"...\",\"kind\":\"ders|tercih|araç\"}]}"}],
            sysmsg, opts.get("provider", ""), opts.get("model", ""))
        notes = extract_json(txt).get("notes", [])
        for n in notes[:5]:
            mem_add(n.get("note", ""), n.get("kind", "ders"))
        if notes:
            job.log("🧠 Bu oturumdan öğrenilenler hafızaya yazıldı:\n   • " + "\n   • ".join(n.get("note", "") for n in notes[:5]))
    except Exception as e:
        job.log(f"(ders çıkarma atlandı: {str(e)[:100]})")

def agent_create_tool(job, a, opts):
    name = a.get("name") or "ajan-araci"
    dest = unique_dir(TOOLS_DIR, slugify(name)); os.makedirs(dest)
    slug = os.path.basename(dest)
    files = a.get("files") or {}
    for rel, content in files.items():
        ap = safe_path(os.path.join(dest, rel), [dest])
        if not ap:
            continue
        os.makedirs(os.path.dirname(ap), exist_ok=True)
        open(ap, "w", encoding="utf-8").write(content)
        if content.startswith("#!"):
            os.chmod(ap, 0o755)
    if "README.md" not in files:
        open(os.path.join(dest, "README.md"), "w", encoding="utf-8").write(f"# {name}\n\n{a.get('description_tr', '')}\n\nCypher Tool Görev Ajanı tarafından geliştirildi.\n")
    job.log(f"🛠 Yeni araç geliştirildi: {dest} ({len(files)} dosya)")
    plan = finalize_plan(dest, {"name": name, "summary": a.get("description_tr", "") + "\n\nDosyalar: " + ", ".join(files),
                                "steps": a.get("steps", []), "actions": a.get("actions", []), "warnings": ["Bu aracı yapay zekâ ajanı yazdı; kodu Rehber → Orijinal README / klasörden inceleyebilirsin."]})
    plan["full_name"] = "yerel/" + slug
    r = {"ok": True, "data": None} if opts.get("auto") else job.ask("plan", plan)
    if not r or not r.get("ok"):
        shutil.rmtree(dest, ignore_errors=True); return "Kullanıcı aracı onaylamadı; dosyalar silindi."
    plan.update(r.get("data") or {})
    icon = ""
    try:
        src = os.path.join(WEB_DIR, "logo.svg"); icon = slug + ".svg"; shutil.copy(src, os.path.join(ICON_DIR, icon))
    except Exception:
        pass
    tool = {"slug": slug, "name": plan.get("name") or name, "path": dest, "source": "yerel (Görev Ajanı geliştirdi)", "full_name": "yerel/" + slug,
            "meta": {"description": a.get("description_tr", "")}, "summary": a.get("description_tr", ""), "category": "Ajanın geliştirdiği araç",
            "steps": plan.get("steps", []), "actions": plan.get("actions", []), "runtimes": plan.get("runtimes", []), "system_packages": [],
            "optional": [], "icon": icon, "installed_at": now(), "status": "kuruluyor", "guide_tr": a.get("guide_tr", ""),
            "update_mode": "kapali", "inject_keys": True, "catalog_id": "", "agent_made": True}
    with _lock:
        t = tools(); t[slug] = tool; save_tools(t)
    ok = execute_plan(job, tool, plan) if (plan.get("steps") or plan.get("deps") or plan.get("runtimes")) else True
    update_tool(slug, status="kuruldu" if ok else "hata")
    if ok and tool["actions"]:
        make_shortcuts(tools()[slug], desktop=opts.get("shortcut", True))
    job.ctx.setdefault("installed", []).append(slug)
    return json.dumps({"slug": slug, "klasör": dest, "kurulum": "başarılı" if ok else "HATALI", "eylemler": tool["actions"],
                       "son_kayıtlar": job.lines[-15:] if not ok else []}, ensure_ascii=False)

def hunt_fallback(job, task, workdir):
    """API yokken: GitHub'da ara → en çok yıldızlıyı kur → dene."""
    job.log("ℹ Yapay zekâ API'si yok → basit mod: GitHub'da ara, en popüler adayı kur ve dene.\n"
            "   (Görevi kendisinin yapması ve araç geliştirmesi için Ücretsiz AI sekmesinden bir model ekle.)")
    try:
        cands = gh_search(task, 5)
    except Exception as e:
        job.log(f"✖ GitHub araması başarısız: {e}"); job.status = "hata"; return
    if not cands:
        job.log("✖ Aday bulunamadı. İngilizce anahtar kelimelerle dene (ör. 'pdf merge')."); job.status = "hata"; return
    job.ctx["candidates"] = cands
    r = job.ask("choose", {"candidates": cands, "task": task})
    if not r or not r.get("ok"):
        job.status = "iptal"; return
    repo = ((r.get("data") or {}).get("repo")) or cands[0]["repo"]
    before = set(tools()); title = job.title
    install_flow(job, "https://github.com/" + repo, {})
    job.title = title
    new = [s for s in tools() if s not in before]
    if not new:
        job.status = "hata"; return
    ok, out = smoke_test(job, new[0])
    t = tools()[new[0]]
    job.ctx["report"] = (f"## Sonuç\n**{repo}** kuruldu ({t['status']}).\n\n**Deneme:** {'✅ çalışıyor' if ok else '❌ başarısız'}\n\n```\n{out[-800:]}\n```\n\n"
                         f"Kullanım için **Rehberler** sekmesine bak.")
    job.status = "tamamlandı" if ok else "hata"

# ───────────────────────────── HTTP sunucu ─────────────────────────────
TOKEN = secrets.token_urlsafe(24)
LAST_SEEN = [time.time()]

def public_state():
    c = cfg()
    provs = [{**{k: v for k, v in p.items() if k != "api_key"}, "has_key": bool(p.get("api_key"))} for p in c["providers"]]
    tl = []
    for slug, t in sorted(tools().items(), key=lambda x: x[1].get("installed_at", ""), reverse=True):
        tl.append({k: v for k, v in t.items() if k not in ("guide_tr",)} | {"has_guide": bool(t.get("guide_tr"))})
    installed_src = {t.get("source", "").lower().rstrip("/") for t in tools().values()}
    cat = [{**{k: v for k, v in x.items() if k not in ("guide_tr", "install")}, "summary": guide_summary(x.get("guide_tr")),
            "owner": x["full_name"].split("/")[0], "installed": x["source"].lower() in installed_src} for x in catalog()]
    return {"app": APP, "version": VERSION, "tools": tl, "providers": provs, "default_provider": c.get("default_provider", ""),
            "agents": c["agents"], "catalog": cat, "presets": PROVIDER_PRESETS,
            "agent_rules": c.get("agent_rules", ""), "agent_defaults": c.get("agent_defaults", {}), "workdir_default": WORK_DIR,
            "settings": {k: c[k] for k in ("failover", "use_ai", "auto_shortcut", "release_assets", "update_check", "update_default_mode")} | {"github_token_set": bool(c.get("github_token"))},
            "jobs": [j.summary() for j in sorted(JOBS.values(), key=lambda j: -j.created)][:60],
            "procs": [p.summary() for p in sorted(PROCS.values(), key=lambda p: -p.started)][:40],
            "system": {"os": os_info().get("PRETTY_NAME", "Linux"), "pm": detect_pm(), "arch": platform.machine(),
                       "ram_gb": mem_gb(), "gpu": gpu_info(), "desktop": desktop_dir() or "", "terminal": (find_terminal() or [""])[0]}}

def system_checks():
    items = []
    for k, label, why in (("git", "git", "Depoları indirmek ve güncellemek için"), ("venv", "Python venv", "Python araçlarını izole kurmak için"),
                          ("7z", "7-Zip", "rar/7z arşivlerini açmak için"), ("unrar", "unrar", "rar arşivleri için (alternatif)"),
                          ("gcc", "Derleyici (gcc/make)", "Kaynaktan derlenen araçlar için"), ("curl", "curl", "Bazı resmi kurulum betikleri için"),
                          ("git-lfs", "git-lfs", "Büyük dosyalı depolar için"), ("notify-send", "Bildirimler", "Güncelleme/kurulum bildirimleri için"),
                          ("xdg-utils", "xdg-utils", "Masaüstü kısayolları ve dosya açma için")):
        items.append({"key": k, "label": label, "why": why, "ok": check_key(k), "kind": "sys"})
    for r, label, why in (("node22", "Node.js 22+", "Node tabanlı araçlar (sudo'suz yerel kurulum)"), ("uv", "uv (Python yöneticisi)", "Modern Python araçları, istenen Python sürümü")):
        items.append({"key": r, "label": label, "why": why, "ok": runtime_ok(r), "kind": "runtime"})
    items.append({"key": "ollama", "label": "Ollama", "why": "API anahtarsız yerel yapay zekâ modelleri", "ok": bool(which("ollama")), "kind": "ollama"})
    items.append({"key": "pkexec", "label": "pkexec (polkit)", "why": "Grafik parola penceresiyle güvenli yönetici izni", "ok": bool(shutil.which("pkexec")), "kind": "info"})
    return items

def system_fix_flow(job, keys):
    job.title = "Sistem bağımlılıkları"
    rts = [k for k in keys if k in ("node22", "uv")]
    sysk = [k for k in keys if k in PKG]
    cmds, missing = dep_commands(sysk)
    plan = {"name": "Sistem bağımlılıkları", "summary": "Seçilen eksikler kurulacak: " + ", ".join(keys), "steps": cmds, "actions": [],
            "runtimes": rts, "runtimes_missing": rts, "deps": [], "warnings": []}
    r = job.ask("plan", plan)
    if not r or not r.get("ok"):
        job.status = "iptal"; return
    plan.update(r.get("data") or {})
    for rt in rts:
        ensure_runtime(rt, job.log)
    ok, _, _ = run_steps(job, plan["steps"], DATA)
    job.status = "tamamlandı" if ok else "hata"

class Handler(BaseHTTPRequestHandler):
    server_version = "CypherTool"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8", extra=None):
        data = body if isinstance(body, bytes) else (json.dumps(body, ensure_ascii=False).encode() if not isinstance(body, str) else body.encode())
        self.send_response(code)
        self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store"); self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers(); self.wfile.write(data)

    def _host_ok(self):
        h = (self.headers.get("Host") or "").split(":")[0]
        return h in ("127.0.0.1", "localhost")

    def _auth(self):
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        tok = self.headers.get("X-Token") or (qs.get("t") or [""])[0]
        return secrets.compare_digest(tok, TOKEN)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}") if n else {}

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, {"error": "host"})
        LAST_SEEN[0] = time.time()
        u = urllib.parse.urlparse(self.path); p = u.path
        if p in ("/", "/index.html"):
            return self._send(200, open(os.path.join(WEB_DIR, "index.html"), "rb").read(), "text/html; charset=utf-8")
        if p.startswith("/vendor/"):
            f = os.path.join(WEB_DIR, "vendor", os.path.basename(p))
            if os.path.isfile(f):
                ct = "text/css" if f.endswith(".css") else "application/javascript"
                return self._send(200, open(f, "rb").read(), ct + "; charset=utf-8")
        if p in ("/logo.svg",):
            return self._send(200, open(os.path.join(WEB_DIR, "logo.svg"), "rb").read(), "image/svg+xml")
        if p.startswith("/icons/"):
            f = os.path.join(ICON_DIR, os.path.basename(p))
            if os.path.isfile(f):
                ct = "image/svg+xml" if f.endswith(".svg") else "image/png"
                return self._send(200, open(f, "rb").read(), ct, {"Content-Security-Policy": "script-src 'none'"})
            return self._send(404, {"error": "yok"})
        if not self._auth():
            return self._send(401, {"error": "yetkisiz"})
        try:
            if p == "/api/state":
                return self._send(200, public_state())
            if p == "/api/memory":
                return self._send(200, {"memory": mem_all(), "recipes": [{k: v for k, v in r.items() if k not in ("guide_tr",)} for r in jload(USER_CATALOG, [])]})
            if p == "/api/system":
                return self._send(200, {"items": system_checks(), "ollama_models": OLLAMA_MODELS, "keyless": KEYLESS_CANDIDATES})
            m = re.match(r"^/api/jobs/(\w+)$", p)
            if m:
                j = JOBS.get(m.group(1))
                if not j:
                    return self._send(404, {"error": "görev yok"})
                since = int((urllib.parse.parse_qs(u.query).get("since") or ["0"])[0])
                return self._send(200, {**j.summary(), "lines": j.lines[since:], "next": len(j.lines), "ctx": {k: v for k, v in j.ctx.items() if k in ("found", "github", "chat", "steps", "report", "task", "installed", "candidates")}})
            m = re.match(r"^/api/procs/(\w+)$", p)
            if m:
                pr = PROCS.get(m.group(1))
                if not pr:
                    return self._send(404, {"error": "süreç yok"})
                since = int((urllib.parse.parse_qs(u.query).get("since") or ["0"])[0])
                return self._send(200, {**pr.summary(), "text": "".join(pr.chunks[since:]), "next": len(pr.chunks)})
            m = re.match(r"^/api/tools/([\w.-]+)/guide$", p)
            if m:
                t = tools().get(m.group(1))
                if not t:
                    return self._send(404, {"error": "araç yok"})
                rec = next((c for c in catalog() if c.get("id") == t.get("catalog_id")), None)
                g = t.get("guide_tr") or (rec or {}).get("guide_tr", "")
                return self._send(200, {"guide": g, "readme": read_readme(t["path"], 60000), "can_ai": llm_available()})
            if p == "/api/export/download":
                f = os.path.join(EXPORT_DIR, os.path.basename((urllib.parse.parse_qs(u.query).get("file") or [""])[0]))
                if os.path.isfile(f):
                    return self._send(200, open(f, "rb").read(), "application/octet-stream",
                                      {"Content-Disposition": f'attachment; filename="{os.path.basename(f)}"'})
                return self._send(404, {"error": "dosya yok"})
        except Exception as e:
            return self._send(500, {"error": str(e)})
        self._send(404, {"error": "bulunamadı"})

    def do_POST(self):
        if not self._host_ok() or not self._auth():
            return self._send(401, {"error": "yetkisiz"})
        LAST_SEEN[0] = time.time()
        p = urllib.parse.urlparse(self.path).path
        try:
            if p == "/api/import":
                n = int(self.headers.get("Content-Length") or 0)
                fn = os.path.basename(self.headers.get("X-Filename") or "import.json")
                dst = os.path.join(EXPORT_DIR, "gelen-" + fn)
                with open(dst, "wb") as f:
                    while n > 0:
                        b = self.rfile.read(min(n, 1 << 20)); f.write(b); n -= len(b)
                j = start_job("İçe aktarma", "import", import_flow, dst)
                return self._send(200, {"job": j.id})
            b = self._body()
            return self._send(200, self.route(p, b) or {"ok": True})
        except KeyError as e:
            return self._send(404, {"error": f"bulunamadı: {e}"})
        except Exception as e:
            return self._send(500, {"error": str(e)})

    def route(self, p, b):
        if p == "/api/install":
            urls = [u.strip() for u in re.split(r"[\s,]+", b.get("urls", "")) if u.strip()] if isinstance(b.get("urls"), str) else b.get("urls", [])
            ids = []
            for u in urls:
                ids.append(start_job(f"Kurulum: {u}", "install", install_flow, u, b.get("opts", {})).id)
            return {"jobs": ids}
        m = re.match(r"^/api/jobs/(\w+)/(respond|cancel)$", p)
        if m:
            j = JOBS[m.group(1)]
            if m.group(2) == "cancel":
                j.cancelled = True; j.respond(False); j.status = "iptal"
            else:
                j.respond(bool(b.get("ok")), b.get("data"))
            return
        if p == "/api/jobs/approve_all":
            n = 0
            for j in JOBS.values():
                if j.pending and j.pending["kind"] in ("plan", "fix"):
                    j.respond(True, j.pending["payload"]); n += 1
            return {"approved": n}
        if p == "/api/jobs/clear":
            for k in [k for k, j in JOBS.items() if j.status in ("tamamlandı", "hata", "iptal")]:
                del JOBS[k]
            for k in [k for k, pr in PROCS.items() if pr.rc is not None]:
                del PROCS[k]
            return
        m = re.match(r"^/api/tools/([\w.-]+)/(\w+)$", p)
        if m:
            slug, act = m.groups(); t = tools()[slug]
            if act == "run":
                pr = run_tool(slug, int(b.get("action", 0)), b.get("args", ""), b.get("mode", "app"))
                return {"proc": pr.id if pr else None}
            if act == "doctor":
                return {"job": start_job(f"Doktor: {t['name']}", "doctor", doctor_flow, slug).id}
            if act == "update":
                return {"job": start_job(f"Güncelleme: {t['name']}", "update", update_flow, slug).id}
            if act == "check_update":
                has, why = check_update(t); update_tool(slug, update_available=has, update_info=why, last_check=now())
                return {"update": has, "info": why}
            if act == "optional":
                return {"job": start_job("İsteğe bağlı kurulum", "optional", optional_flow, slug, int(b.get("index", 0))).id}
            if act == "commands":
                return {"job": start_job(b.get("title", "Komutlar"), "commands", commands_flow, slug, b.get("commands", []), b.get("title", "Komutları çalıştır")).id}
            if act == "shortcut":
                return {"made": make_shortcuts(t, desktop=b.get("desktop", True))}
            if act == "guide":
                return {"guide": make_guide(slug)}
            if act == "edit":
                allowed = {k: b[k] for k in ("name", "actions", "update_mode", "inject_keys", "summary", "category") if k in b}
                update_tool(slug, **allowed); return
            if act == "open_folder":
                subprocess.Popen(["xdg-open", t["path"]], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return
            if act == "delete":
                remove_shortcuts(slug)
                if b.get("files", True):
                    shutil.rmtree(t["path"], ignore_errors=True)
                    for f in os.listdir(ICON_DIR):
                        if f.startswith(slug + "."):
                            os.remove(os.path.join(ICON_DIR, f))
                with _lock:
                    tt = tools(); tt.pop(slug, None); save_tools(tt)
                return
        m = re.match(r"^/api/procs/(\w+)/(input|stop|resize)$", p)
        if m:
            pr = PROCS[m.group(1)]
            if m.group(2) == "stop":
                pr.stop()
            elif m.group(2) == "resize":
                pr.resize(b.get("cols", 120), b.get("rows", 36))
            else:
                pr.write(b.get("text", "") + ("\n" if b.get("enter", True) else ""))
            return
        if p == "/api/run_command":
            slug = b.get("slug", "")
            return {"job": start_job("Ajan komutu", "commands", commands_flow, slug, [x for x in b.get("command", "").splitlines() if x.strip()], "Ajanın önerdiği komut").id}
        if p == "/api/providers/save":
            c = cfg(); old = {x.get("id"): x for x in c["providers"]}; new = []
            for x in b.get("providers", []):
                x = dict(x); x["id"] = x.get("id") or uuid.uuid4().hex[:8]
                if not x.get("api_key") and x["id"] in old:
                    x["api_key"] = old[x["id"]].get("api_key", "")
                if x.get("clear_key"):
                    x["api_key"] = ""
                x.pop("has_key", None); x.pop("clear_key", None)
                new.append(x)
            c["providers"] = new
            if b.get("default_provider") is not None:
                c["default_provider"] = b["default_provider"]
            if not any(x["id"] == c.get("default_provider") for x in new):
                c["default_provider"] = new[0]["id"] if new else ""
            save_cfg(c); return
        if p == "/api/providers/test":
            c = cfg(); pv = next((x for x in c["providers"] if x["id"] == b.get("id")), None)
            if not pv:
                raise KeyError("sağlayıcı")
            t0 = time.time()
            out = llm_call(pv, [{"role": "user", "content": "Tek kelimeyle 'çalışıyor' yaz."}], timeout=60)
            return {"ok": True, "reply": out.strip()[:200], "ms": int((time.time() - t0) * 1000)}
        if p == "/api/providers/models":
            c = cfg(); pv = next((x for x in c["providers"] if x["id"] == b.get("id")), None) or b
            base = pv.get("base_url", "").rstrip("/"); key = pv.get("api_key", "")
            if pv.get("type") == "anthropic":
                r = http_json(base + "/models", headers={"x-api-key": key, "anthropic-version": "2023-06-01"})
                return {"models": [x["id"] for x in r.get("data", [])]}
            if pv.get("type") == "gemini":
                r = http_json(f"{base}/models?key={urllib.parse.quote(key)}")
                return {"models": [x["name"].split("/")[-1] for x in r.get("models", [])]}
            r = http_json(base + "/models", headers={"Authorization": f"Bearer {key}"} if key else {})
            ms = [x["id"] for x in r.get("data", [])]
            if "openrouter.ai" in base and b.get("free_only"):
                ms = [x["id"] for x in r.get("data", []) if str((x.get("pricing") or {}).get("prompt")) in ("0", "0.0")]
            return {"models": sorted(ms)}
        if p == "/api/agents/save":
            c = cfg(); c["agents"] = [dict(a, id=a.get("id") or uuid.uuid4().hex[:8]) for a in b.get("agents", [])]; save_cfg(c); return
        if p == "/api/chat":
            return chat(b.get("agent"), b.get("messages", []), b.get("slug", ""))
        if p == "/api/chat_all":
            res = []; c = cfg()
            def one(a):
                try:
                    r = chat(a["id"], [{"role": "user", "content": b.get("message", "")}], b.get("slug", ""))
                except Exception as e:
                    r = {"reply": f"⚠ {e}", "agent": a["name"], "provider": "-"}
                res.append(r)
            th = [threading.Thread(target=one, args=(a,)) for a in c["agents"] if a["id"] in (b.get("agents") or [x["id"] for x in c["agents"]])]
            [x.start() for x in th]; [x.join(240) for x in th]
            return {"replies": res}
        if p == "/api/settings":
            c = cfg()
            for k in ("failover", "use_ai", "auto_shortcut", "release_assets", "update_check", "update_default_mode"):
                if k in b:
                    c[k] = b[k]
            if b.get("github_token") is not None:
                c["github_token"] = b["github_token"].strip()
            save_cfg(c); return
        if p == "/api/updates/check":
            return {"updates": check_all_updates()}
        if p == "/api/system/fix":
            return {"job": start_job("Sistem bağımlılıkları", "system", system_fix_flow, b.get("keys", [])).id}
        if p == "/api/agent/settings":
            c = cfg()
            if "rules" in b:
                c["agent_rules"] = b["rules"][:8000]
            if "defaults" in b:
                c["agent_defaults"] = {k: b["defaults"].get(k) for k in ("workdir", "provider", "persona", "auto")}
            save_cfg(c); return
        if p == "/api/memory/save":
            with _lock:
                jsave(MEMORY_FILE, b.get("entries", []))
            return
        if p == "/api/memory/add":
            mem_add(b.get("text", ""), b.get("kind", "tercih")); return
        if p == "/api/recipes/delete":
            jsave(USER_CATALOG, [x for x in jload(USER_CATALOG, []) if x["id"] != b.get("id")]); return
        if p == "/api/agent/start":
            return {"job": start_job("Görev Ajanı", "agent", agent_flow, b.get("task", ""), b.get("opts", {})).id}
        if p == "/api/freeai/scan":
            return {"job": start_job("Ücretsiz AI taraması", "freeai", free_ai_scan, bool(b.get("add", True))).id}
        if p == "/api/freeai/ollama":
            return {"job": start_job("Yerel AI kurulumu", "ollama", ollama_setup_flow, b.get("model", "qwen2.5-coder:7b")).id}
        if p == "/api/export":
            f = export_all(bool(b.get("full")), bool(b.get("include_keys")))
            return {"file": os.path.basename(f), "path": f, "size": os.path.getsize(f)}
        if p == "/api/shutdown":
            threading.Timer(0.5, lambda: os._exit(0)).start(); return
        raise KeyError(p)

def open_window(url):
    for b in ("chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "brave-browser", "microsoft-edge", "vivaldi"):
        if shutil.which(b):
            subprocess.Popen([b, f"--app={url}", "--class=CypherTool", "--window-size=1400,900",
                              f"--user-data-dir={os.path.join(CONF_DIR, 'pencere')}", "--no-first-run", "--no-default-browser-check"],
                             start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
    if shutil.which("firefox"):
        subprocess.Popen(["firefox", "--new-window", url], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return
    subprocess.Popen(["xdg-open", url], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def existing_session():
    s = jload(SESSION_FILE, {})
    if not s.get("port"):
        return None
    try:
        r = http_json(f"http://127.0.0.1:{s['port']}/api/state", headers={"X-Token": s["token"]}, timeout=3)
        return s if r.get("app") == APP else None
    except Exception:
        return None

def serve(open_ui=True, port=8765):
    global TOKEN
    s = existing_session()
    if s:
        url = f"http://127.0.0.1:{s['port']}/#{s['token']}"
        print(f"{APP} zaten çalışıyor: {url}")
        if open_ui:
            open_window(url)
        return
    srv = None
    for pt in [port] + list(range(port + 1, port + 30)):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", pt), Handler); break
        except OSError:
            continue
    pt = srv.server_address[1]
    jsave(SESSION_FILE, {"port": pt, "token": TOKEN, "pid": os.getpid()}, private=True)
    write_env_file(cfg())
    url = f"http://127.0.0.1:{pt}/#{TOKEN}"
    print(f"{APP} {VERSION} çalışıyor → {url}")
    threading.Thread(target=update_scheduler, daemon=True).start()
    def idle_watch():  # pencere kapanınca ve iş yokken 10 dk sonra kapan
        while True:
            time.sleep(60)
            busy = any(j.status not in ("tamamlandı", "hata", "iptal") for j in JOBS.values()) or any(p.rc is None for p in PROCS.values())
            if not busy and time.time() - LAST_SEEN[0] > 600 and os.environ.get("CT_KEEPALIVE") != "1":
                os._exit(0)
    threading.Thread(target=idle_watch, daemon=True).start()
    if open_ui:
        threading.Timer(0.6, open_window, args=(url,)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass

# ───────────────────────────── CLI ─────────────────────────────
def cli_ask(kind, payload):
    B, P, R = "\033[1m", "\033[95m", "\033[0m"
    if kind in ("plan", "fix"):
        print(f"\n{P}{B}━━━ {'KURULUM PLANI' if kind == 'plan' else 'DÜZELTME ÖNERİSİ'}: {payload.get('name', '')} ━━━{R}")
        if payload.get("summary"): print("  " + payload["summary"])
        for w in payload.get("why", []): print(f"  • {w}")
        if payload.get("runtimes_missing"): print(f"{B}  Yerel çalışma ortamı indirilecek:{R} " + ", ".join(payload["runtimes_missing"]))
        if payload.get("deps"): print(f"{B}  Eksik sistem paketleri:{R}\n    " + "\n    ".join(payload["deps"]))
        print(f"{B}  Adımlar:{R}")
        for s in payload.get("steps", []): print("    $ " + s)
        for a in payload.get("actions", []): print(f"{B}  Çalıştırma:{R} [{a['label']}] {a['command']}")
        for w in payload.get("warnings", []): print(f"\033[93m  ⚠ {w}{R}")
        a = input(f"{P}Onaylıyor musun? [E/h]: {R}").strip().lower()
        return {"ok": a in ("", "e", "evet", "y", "yes"), "data": None}
    if kind == "confirm":
        return {"ok": input(payload.get("message", "") + " [e/H]: ").strip().lower() in ("e", "evet", "y")}
    if kind == "question":
        print(f"\n{P}{B}🤖 Ajan:{R} {payload.get('question', '')}")
        for i, o in enumerate(payload.get("options", []), 1):
            print(f"   {P}{i}){R} {o}")
        a = input(f"{P}Sen (numara ya da yaz, boş = bitir): {R}").strip()
        if a.isdigit() and 1 <= int(a) <= len(payload.get("options", [])):
            a = payload["options"][int(a) - 1]
        return {"ok": bool(a), "data": {"answer": a}}
    if kind == "choose":
        for i, c in enumerate(payload["candidates"], 1):
            print(f"  {i}) {c['repo']} ⭐{c['stars']} — {c['description'][:90]}")
        a = input("Hangisi kurulsun? [1]: ").strip() or "1"
        return {"ok": True, "data": {"repo": payload["candidates"][int(a) - 1]["repo"]}} if a.isdigit() else {"ok": False}
    if kind == "manual":
        print(f"Şu komutu başka bir terminalde çalıştır:\n  cd {payload['cwd']} && {payload['command']}")
        return {"ok": input("Tamamlandı mı? [E/h]: ").strip().lower() in ("", "e", "evet")}
    return {"ok": False}

def main():
    args = sys.argv[1:]
    if not args:
        return serve(True)
    cmd = args[0]
    if cmd.startswith(("http://", "https://", "git@")) or re.match(r"^[\w.-]+/[\w.-]+$", cmd):
        args = ["kur"] + args; cmd = "kur"
    if cmd in ("kur", "install"):
        if len(args) < 2:
            print("Kullanım: cyphertool kur <github-link> [<link> ...]"); return
        for u in args[1:]:
            start_job(f"Kurulum: {u}", "install", install_flow, u, {}, cli=True)
    elif cmd in ("gorev", "görev", "ajan", "task"):
        start_job("Görev Ajanı", "agent", agent_flow, " ".join(args[1:]), {"workdir": os.getcwd()}, cli=True)
    elif cmd in ("liste", "list"):
        for slug, t in tools().items():
            print(f"{slug:28} {t.get('status', ''):10} {t.get('full_name', '')}  {'⬆ ' + t.get('update_info', '') if t.get('update_available') else ''}")
    elif cmd in ("calistir", "run"):
        t = tools().get(args[1]) if len(args) > 1 else None
        if not t:
            print("Araç bulunamadı. 'cyphertool liste' ile bak."); return
        os.execv(make_launcher(t, int(args[2]) if len(args) > 2 and args[2].isdigit() else 0), ["x"] + args[3:])
    elif cmd in ("kontrol", "check"):
        res = check_all_updates(cli=True)
        print("\n".join(f"⬆ {s}: {w}" for s, w in res) or "Tüm araçlar güncel.")
    elif cmd in ("guncelle", "update"):
        for s in (args[1:] or [s for s, t in tools().items() if t.get("update_available")]):
            start_job("Güncelleme", "update", update_flow, s, cli=True)
    elif cmd in ("disa-aktar", "export"):
        print("Dışa aktarıldı:", export_all("--tam" in args or "--full" in args, "--anahtarlar" in args))
    elif cmd in ("ice-aktar", "import"):
        start_job("İçe aktarma", "import", import_flow, os.path.abspath(args[1]), cli=True)
    elif cmd in ("sunucu", "server"):
        serve(False)
    elif cmd in ("-h", "--help", "yardim"):
        print(__doc__)
    else:
        print(__doc__)

if __name__ == "__main__":
    main()
