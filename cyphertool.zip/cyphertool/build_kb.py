"""Hata bilgi bankasını (hata_bankasi.json) üretir. Çalıştır: python3 build_kb.py"""
import json, re

# paket anahtarı → (apt, dnf, pacman, zypper, apk)
P = {
 "build": ("build-essential", "gcc gcc-c++ make", "base-devel", "gcc gcc-c++ make", "build-base"),
 "pydev": ("python3-dev", "python3-devel", "python", "python3-devel", "python3-dev"),
 "venv": ("python3-venv", "python3", "python", "python3", "py3-virtualenv"),
 "pip": ("python3-pip", "python3-pip", "python-pip", "python3-pip", "py3-pip"),
 "tk": ("python3-tk", "python3-tkinter", "tk", "python3-tk", "py3-tkinter"),
 "pkgconf": ("pkg-config", "pkgconf-pkg-config", "pkgconf", "pkg-config", "pkgconf"),
 "ssl": ("libssl-dev", "openssl-devel", "openssl", "libopenssl-devel", "openssl-dev"),
 "ffi": ("libffi-dev", "libffi-devel", "libffi", "libffi-devel", "libffi-dev"),
 "zlib": ("zlib1g-dev", "zlib-devel", "zlib", "zlib-devel", "zlib-dev"),
 "cmake": ("cmake", "cmake", "cmake", "cmake", "cmake"),
 "git": ("git", "git", "git", "git", "git"),
 "gitlfs": ("git-lfs", "git-lfs", "git-lfs", "git-lfs", "git-lfs"),
 "curl": ("curl", "curl", "curl", "curl", "curl"),
 "ca": ("ca-certificates", "ca-certificates", "ca-certificates", "ca-certificates", "ca-certificates"),
 "unzip": ("unzip", "unzip", "unzip", "unzip", "unzip"),
 "7z": ("p7zip-full", "p7zip p7zip-plugins", "p7zip", "p7zip-full", "p7zip"),
 "ffmpeg": ("ffmpeg", "ffmpeg-free", "ffmpeg", "ffmpeg", "ffmpeg"),
 "xcb": ("libxcb-cursor0 libxkbcommon-x11-0 libxcb-xinerama0 libxcb-icccm4 libxcb-image0 libxcb-keysyms1 libxcb-render-util0",
         "xcb-util-cursor libxkbcommon-x11 xcb-util-wm xcb-util-image xcb-util-keysyms xcb-util-renderutil",
         "xcb-util-cursor libxkbcommon-x11 xcb-util-wm xcb-util-image xcb-util-keysyms xcb-util-renderutil",
         "libxcb-cursor0 libxkbcommon-x11-0", "xcb-util-cursor libxkbcommon"),
 "gl": ("libgl1 libglib2.0-0", "mesa-libGL glib2", "mesa glib2", "Mesa-libGL1 glib2", "mesa-gl glib"),
 "portaudio": ("portaudio19-dev", "portaudio-devel", "portaudio", "portaudio-devel", "portaudio-dev"),
 "alsa": ("libasound2-dev", "alsa-lib-devel", "alsa-lib", "alsa-devel", "alsa-lib-dev"),
 "pq": ("libpq-dev", "libpq-devel", "postgresql-libs", "postgresql-devel", "libpq-dev"),
 "mysql": ("default-libmysqlclient-dev", "mysql-devel", "mariadb-libs", "libmysqlclient-devel", "mariadb-dev"),
 "xml": ("libxml2-dev libxslt1-dev", "libxml2-devel libxslt-devel", "libxml2 libxslt", "libxml2-devel libxslt-devel", "libxml2-dev libxslt-dev"),
 "jpeg": ("libjpeg-dev libpng-dev", "libjpeg-turbo-devel libpng-devel", "libjpeg-turbo libpng", "libjpeg8-devel libpng16-devel", "jpeg-dev libpng-dev"),
 "sqlite": ("libsqlite3-dev", "sqlite-devel", "sqlite", "sqlite3-devel", "sqlite-dev"),
 "bz2": ("libbz2-dev", "bzip2-devel", "bzip2", "libbz2-devel", "bzip2-dev"),
 "lzma": ("liblzma-dev", "xz-devel", "xz", "xz-devel", "xz-dev"),
 "readline": ("libreadline-dev", "readline-devel", "readline", "readline-devel", "readline-dev"),
 "curldev": ("libcurl4-openssl-dev", "libcurl-devel", "curl", "libcurl-devel", "curl-dev"),
 "dbus": ("libdbus-1-dev", "dbus-devel", "dbus", "dbus-1-devel", "dbus-dev"),
 "gtk3": ("libgtk-3-dev", "gtk3-devel", "gtk3", "gtk3-devel", "gtk+3.0-dev"),
 "webkit": ("libwebkit2gtk-4.1-dev", "webkit2gtk4.1-devel", "webkit2gtk-4.1", "webkit2gtk3-soup2-devel", "webkit2gtk-4.1-dev"),
 "x11": ("libx11-dev libxtst-dev libxrandr-dev", "libX11-devel libXtst-devel libXrandr-devel", "libx11 libxtst libxrandr", "libX11-devel libXtst-devel", "libx11-dev libxtst-dev"),
 "fuse": ("libfuse2t64", "fuse-libs", "fuse2", "libfuse2", "fuse"),
 "docker": ("docker.io", "docker", "docker", "docker", "docker"),
 "xdg": ("xdg-utils", "xdg-utils", "xdg-utils", "xdg-utils", "xdg-utils"),
 "notify": ("libnotify-bin", "libnotify", "libnotify", "libnotify-tools", "libnotify"),
 "emoji": ("fonts-noto-color-emoji", "google-noto-emoji-color-fonts", "noto-fonts-emoji", "noto-coloremoji-fonts", "font-noto-emoji"),
 "java": ("default-jdk", "java-latest-openjdk-devel", "jdk-openjdk", "java-21-openjdk-devel", "openjdk21"),
 "pyisp": ("python-is-python3", "python-unversioned-command", "python", "python3", "python3"),
 "rustc": ("rustc cargo", "rust cargo", "rust", "rust cargo", "rust cargo"),
 "golang": ("golang-go", "golang", "go", "go", "go"),
 "dos2unix": ("dos2unix", "dos2unix", "dos2unix", "dos2unix", "dos2unix"),
 "nettools": ("lsof psmisc", "lsof psmisc", "lsof psmisc", "lsof psmisc", "lsof psmisc"),
 "gmp": ("libgmp-dev", "gmp-devel", "gmp", "gmp-devel", "gmp-dev"),
 "yaml": ("libyaml-dev", "libyaml-devel", "libyaml", "libyaml-devel", "yaml-dev"),
 "magic": ("libmagic1", "file-libs", "file", "libmagic1", "libmagic"),
 "tesseract": ("tesseract-ocr", "tesseract", "tesseract", "tesseract-ocr", "tesseract-ocr"),
 "poppler": ("poppler-utils", "poppler-utils", "poppler", "poppler-tools", "poppler-utils"),
 "chromium_deps": ("libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxrandr2 libgbm1 libasound2t64 libpango-1.0-0",
                   "nss atk at-spi2-atk cups-libs libdrm libxkbcommon libXcomposite libXdamage libXrandr mesa-libgbm alsa-lib pango",
                   "nss atk at-spi2-atk libcups libdrm libxkbcommon libxcomposite libxdamage libxrandr mesa alsa-lib pango",
                   "mozilla-nss libatk-1_0-0 libcups2 libgbm1 libasound2", "nss atk cups-libs libdrm libxkbcommon mesa-gbm alsa-lib pango"),
}

# C başlık dosyası → paket anahtarı
HEADERS = {"Python.h": "pydev", "openssl/ssl.h": "ssl", "openssl/opensslv.h": "ssl", "ffi.h": "ffi", "zlib.h": "zlib",
           "portaudio.h": "portaudio", "alsa/asoundlib.h": "alsa", "libpq-fe.h": "pq", "pg_config.h": "pq", "mysql.h": "mysql",
           "mysql/mysql.h": "mysql", "libxml/xmlversion.h": "xml", "libxml/parser.h": "xml", "jpeglib.h": "jpeg", "png.h": "jpeg",
           "sqlite3.h": "sqlite", "bzlib.h": "bz2", "lzma.h": "lzma", "readline/readline.h": "readline", "curl/curl.h": "curldev",
           "dbus/dbus.h": "dbus", "gtk/gtk.h": "gtk3", "X11/Xlib.h": "x11", "X11/extensions/XTest.h": "x11", "gmp.h": "gmp", "yaml.h": "yaml"}
# paylaşımlı kütüphane → paket anahtarı
LIBS = {"libGL": "gl", "libgthread-2.0": "gl", "libglib-2.0": "gl", "libxcb-cursor": "xcb", "libxkbcommon-x11": "xcb", "libportaudio": "portaudio",
        "libasound": "chromium_deps", "libnss3": "chromium_deps", "libatk-1.0": "chromium_deps", "libgbm": "chromium_deps", "libfuse": "fuse",
        "libssl": "ssl", "libcrypto": "ssl", "libffi": "ffi", "libmagic": "magic", "libpq": "pq", "libsqlite3": "sqlite", "libz": "zlib",
        "libcups": "chromium_deps", "libdrm": "chromium_deps", "libXcomposite": "chromium_deps", "libXdamage": "chromium_deps",
        "libpango-1.0": "chromium_deps", "libX11": "x11", "libXtst": "x11", "libgtk-3": "gtk3"}

# her kayıt: kimlik, kategori, desen (regex), başlık, neden, çözüm komutları, otomatik uygulanabilir mi
E = []
def add(i, cat, rx, title, cause, fix, auto=True):
    re.compile(rx)
    E.append({"id": i, "cat": cat, "re": rx, "title": title, "cause": cause, "fix": fix, "auto": auto})

# ── Python / pip ──
add("py-nomodule", "Python", r"(?:ModuleNotFoundError|ImportError): No module named '([\w.]+)'", "Eksik Python kütüphanesi: {g1}",
    "Program bu kütüphaneyi kullanıyor ama kurulu değil.", ["{PIPMOD}"])
add("py-pep668", "Python", r"externally-managed-environment|This environment is externally managed",
    "Sistem Python'una pip ile kurulum engellendi (PEP 668)", "Yeni dağıtımlar (Ubuntu 23.04+, Debian 12+) sistem Python'unu korur. Araç için ayrı sanal ortam (.venv) kullanılmalı.",
    ["python3 -m venv .venv", ".venv/bin/python -m pip install --upgrade pip", "# Sonra kurulum komutlarında 'pip' yerine '.venv/bin/pip' kullanılır"])
add("py-venv-missing", "Python", r"ensurepip is not available|No module named venv|The virtual environment was not created successfully",
    "Python venv modülü eksik", "Debian/Ubuntu'da venv ayrı paket olarak gelir.", ["{INSTALL:venv}"])
add("py-pip-missing", "Python", r"No module named pip\b|pip3?: (?:command )?not found|pip3?: komut bulunamadı", "pip bulunamadı",
    "pip kurulu değil.", ["{INSTALL:pip}"])
add("py-python-cmd", "Python", r"(?:/usr/bin/env: )?['‘]?python['’]?: No such file or directory|(?:^|\s)python: (?:command )?not found",
    "'python' komutu yok (sadece python3 var)", "Bazı betikler 'python' adını bekler; yeni dağıtımlarda sadece 'python3' vardır.", ["{INSTALL:pyisp}"])
add("py-header", "Derleme", r"fatal error: (Python\.h): No such file", "Python geliştirme başlıkları eksik (Python.h)",
    "C uzantılı bir Python paketi derleniyor; python3-dev gerekli.", ["{INSTALL:pydev build}"])
add("py-wheel-fail", "Python", r"Failed building wheel for ([\w.-]+)|error: subprocess-exited-with-error|Building wheel for ([\w.-]+) .*error",
    "Python paketi derlenemedi ({g1})", "Paket kaynaktan derlenmeye çalışıldı; derleyici veya başlık dosyaları eksik ya da Python sürümü çok yeni.",
    ["{INSTALL:build pydev pkgconf ssl ffi}", "{PIP} --upgrade pip setuptools wheel"])
add("py-distutils", "Python", r"No module named 'distutils'", "distutils kaldırılmış (Python 3.12+)",
    "Python 3.12'de distutils kaldırıldı; setuptools onun yerini alıyor.", ["{PIP} setuptools"])
add("py-version-req", "Python", r"requires a different Python|Requires-Python|python_requires|Package '[\w-]+' requires a different Python",
    "Paket farklı bir Python sürümü istiyor", "Sistemdeki Python sürümü uygun değil. uv ile istenen sürüm araç klasörüne kurulabilir.",
    ["@runtime uv", "rm -rf .venv && uv venv --python 3.11 .venv", "uv pip install --python .venv/bin/python -r requirements.txt"], auto=False)
add("py-no-matching", "Python", r"No matching distribution found for ([\w.\[\]-]+)|Could not find a version that satisfies the requirement ([\w.\[\]-]+)",
    "Uygun paket sürümü bulunamadı ({g1})", "Paket bu Python sürümü/mimari için yayınlanmamış, adı yanlış ya da internet erişimi yok.",
    ["{PIP} --upgrade pip", "# Python sürümü çok yeniyse: uv venv --python 3.11 .venv"], auto=False)
add("py-resolver", "Python", r"ResolutionImpossible|pip's dependency resolver does not currently take into account|conflicting dependencies",
    "Python bağımlılık çakışması", "İki paket aynı kütüphanenin farklı sürümlerini istiyor.", ["{PIP} --upgrade pip", "# requirements.txt'deki katı sürüm (==) kısıtlarını gevşetmek gerekebilir"], auto=False)
add("py-tk", "Python", r"No module named '?_?tkinter'?|ImportError: libtk", "tkinter (Python GUI) eksik", "Python'un grafik arayüz modülü ayrı pakettir.", ["{INSTALL:tk}"])
add("py-numpy-abi", "Python", r"numpy\.core\.multiarray failed to import|compiled using NumPy 1\.x cannot be run in\s+NumPy 2|_ARRAY_API not found",
    "NumPy 1/2 uyumsuzluğu", "Bir paket NumPy 1 ile derlenmiş, sistemde NumPy 2 var.", ["{PIP} \"numpy<2\""])
add("py-ssl", "Python", r"ssl module in Python is not available|Can't connect to HTTPS URL because the SSL module is not available",
    "Python SSL modülü yok", "Python OpenSSL olmadan derlenmiş (genelde elle derlenmiş Python).", ["{INSTALL:ssl}", "# uv ile hazır Python kullan: uv venv --python 3.12 .venv"], auto=False)
add("py-cert", "Ağ", r"CERTIFICATE_VERIFY_FAILED|SSL: CERTIFICATE_VERIFY_FAILED|certificate verify failed",
    "SSL sertifika doğrulama hatası", "Sertifika paketleri eski/eksik ya da sistem saati yanlış.", ["{INSTALL:ca}", "{SUDO}update-ca-certificates || true", "# Sistem saatini kontrol et: timedatectl"])
add("py-torch-cuda", "GPU", r"Torch not compiled with CUDA enabled|CUDA driver version is insufficient|no CUDA-capable device is detected|Found no NVIDIA driver",
    "PyTorch GPU (CUDA) kullanamıyor", "NVIDIA sürücüsü yok/eski ya da PyTorch'un CPU sürümü kurulu. GPU yoksa CPU modu kullanılmalı.",
    ["# NVIDIA kartın varsa: sürücüyü kur (Ubuntu: sudo ubuntu-drivers install), sonra yeniden başlat", "# GPU yoksa araç ayarlarından 'cpu' seçeneğini kullan"], auto=False)
add("py-cuda-oom", "GPU", r"CUDA out of memory|torch\.OutOfMemoryError", "GPU belleği yetersiz", "Model ekran kartının belleğine sığmıyor.",
    ["# Daha küçük model/düşük batch boyutu seç ya da CPU moduna geç"], auto=False)
add("py-perm-site", "Python", r"Permission denied: '/usr/(?:local/)?lib/python", "Sistem Python klasörüne yazma izni yok",
    "pip global kurulum yapmaya çalışıyor.", ["python3 -m venv .venv", "# Komutlarda '.venv/bin/pip' kullan"])
add("py-crlf", "Betik", r"/usr/bin/env: ['‘]?\w+\r['’]?|bad interpreter: .*\^M|\$'\\r': command not found",
    "Windows satır sonu (CRLF) sorunu", "Betik Windows'ta düzenlenmiş; Linux '\\r' karakterini anlamaz.", ["find . -name '*.sh' -o -name '*.py' | xargs sed -i 's/\\r$//'"])

# ── Node / npm ──
add("node-missing", "Node", r"(?:^|\s)(node|npm|npx|yarn|pnpm): (?:command )?not found|(node|npm|npx): komut bulunamadı",
    "Node.js/npm bulunamadı", "Node.js kurulu değil.", ["@runtime node22"])
add("node-old", "Node", r"Unsupported engine|engine \"node\" is incompatible|requires (?:at least )?Node(?:\.js)? (?:v)?(\d+)|SyntaxError: Unexpected token '\?\?=?'|ERR_UNKNOWN_BUILTIN_MODULE|node:\w+ is not supported",
    "Node.js sürümü çok eski", "Araç daha yeni bir Node.js istiyor.", ["@runtime node22"])
add("node-module", "Node", r"Cannot find module '([^']+)'|ERR_MODULE_NOT_FOUND", "Eksik Node modülü: {g1}",
    "Bağımlılıklar kurulmamış (node_modules yok/eksik).", ["npm install"])
add("node-eacces", "Node", r"npm ERR! code EACCES|EACCES: permission denied, (?:mkdir|open|access) '([^']+)'",
    "npm izin hatası", "npm global klasöre yazmaya çalışıyor ya da node_modules root'a ait.", ["# Global (-g) kurulum yerine proje içi 'npm install' kullan", "{SUDO}chown -R \"$(id -u):$(id -g)\" . ~/.npm 2>/dev/null || true"], auto=False)
add("node-peer", "Node", r"ERESOLVE unable to resolve dependency tree|ERESOLVE could not resolve|peer dep(?:endency)? conflict",
    "npm bağımlılık çakışması (peer dependency)", "Paketlerin istediği sürümler uyuşmuyor.", ["npm install --legacy-peer-deps"])
add("node-gyp", "Node", r"gyp ERR!|node-gyp|prebuild-install warn|make: g\+\+: No such file",
    "Yerel Node modülü derlenemedi (node-gyp)", "C++ derleyici ve Python gerekli.", ["{INSTALL:build pkgconf}", "npm rebuild"])
add("node-enospc", "Node", r"ENOSPC: System limit for number of file watchers reached",
    "Dosya izleme sınırı doldu", "Linux'un inotify sınırı düşük.", ["{SUDO}sh -c 'echo fs.inotify.max_user_watches=524288 >> /etc/sysctl.conf && sysctl -p'"])
add("node-heap", "Node", r"JavaScript heap out of memory|Reached heap limit", "Node bellek sınırı aşıldı", "Derleme çok bellek istiyor.",
    ["export NODE_OPTIONS=--max-old-space-size=4096", "# Sonra komutu tekrar çalıştır"], auto=False)
add("node-script", "Node", r"npm ERR! Missing script: \"?(\w+)\"?|npm error Missing script: \"?(\w+)", "npm betiği yok: {g1}",
    "package.json'da bu isimde bir komut yok.", ["# package.json'daki 'scripts' bölümüne bak: npm run"], auto=False)
add("npm-lock", "Node", r"npm ci can only install packages when your package\.json and package-lock\.json|`npm ci` can only install",
    "package-lock.json uyumsuz", "Kilit dosyası güncel değil.", ["npm install"])
add("node-fetch-fail", "Ağ", r"npm ERR! code (?:ETIMEDOUT|ECONNRESET|ENOTFOUND|EAI_AGAIN)|npm error code (?:ETIMEDOUT|ECONNRESET|ENOTFOUND)",
    "npm ağ hatası", "İnternet bağlantısı/DNS sorunu ya da kayıt sunucusuna ulaşılamıyor.", ["npm config set fetch-retries 5", "npm install"], auto=False)

# ── Rust / Go / Java ──
add("rust-missing", "Rust", r"(?:^|\s)(cargo|rustc): (?:command )?not found", "Rust (cargo) yok", "Proje Rust ile derleniyor.",
    ["curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y", "# ya da dağıtım paketi: {INSTALL:rustc}"], auto=False)
add("rust-old", "Rust", r"requires rustc (\d+\.\d+)|package `[^`]+` cannot be built because it requires rustc|feature `[\w-]+` is required|edition2024",
    "Rust sürümü çok eski", "Dağıtımın Rust paketi eski; rustup ile güncel Rust gerekli.",
    ["curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y", ". \"$HOME/.cargo/env\" && rustup update stable"], auto=False)
add("rust-linker", "Rust", r"linker `cc` not found|error: linker `cc`", "C bağlayıcı (linker) yok", "Rust derlemesi için gcc gerekli.", ["{INSTALL:build}"])
add("rust-openssl", "Rust", r"Could not find directory of OpenSSL installation|openssl-sys|failed to run custom build command for `openssl-sys",
    "OpenSSL geliştirme dosyaları eksik", "Rust openssl-sys paketi libssl-dev ve pkg-config ister.", ["{INSTALL:ssl pkgconf}"])
add("rust-webkit", "Rust", r"webkit2gtk-4\.\d|javascriptcoregtk|The system library `(gtk\+-3\.0|gdk-3\.0|webkit2gtk[\w.-]*)` required by crate",
    "Tauri/GTK geliştirme kütüphaneleri eksik", "Masaüstü (Tauri/GTK) uygulaması derleniyor.", ["{INSTALL:gtk3 webkit pkgconf ssl}"])
add("pkgconfig-lib", "Derleme", r"The system library `([\w+.-]+)` required by crate|Package ([\w+.-]+) was not found in the pkg-config search path|No package '([\w+.-]+)' found",
    "Sistem kütüphanesi bulunamadı: {g1}", "pkg-config bu kütüphaneyi bulamadı; geliştirme (-dev/-devel) paketi gerekli.",
    ["{INSTALL:pkgconf}", "# Paket adı genelde: lib{g1}-dev (Debian/Ubuntu) veya {g1}-devel (Fedora)"], auto=False)
add("go-missing", "Go", r"(?:^|\s)go: (?:command )?not found", "Go derleyicisi yok", "Proje Go ile derleniyor.", ["{INSTALL:golang}"])
add("go-old", "Go", r"go: go\.mod requires go >= ([\d.]+)|go: errors parsing go\.mod|invalid go version '([\d.]+)'|requires go ([\d.]+)",
    "Go sürümü çok eski (gereken: {g1})", "Dağıtımın Go paketi eski. Go 1.21+ kendi araç zincirini (toolchain) otomatik indirebilir.",
    ["export GOTOOLCHAIN=auto && go build ./...", "# Olmazsa go.dev/dl adresinden güncel Go kur"], auto=False)
add("java-missing", "Java", r"(?:^|\s)(java|javac|mvn): (?:command )?not found|JAVA_HOME is not (?:set|defined)", "Java bulunamadı", "Java/JDK gerekli.", ["{INSTALL:java}"])
add("java-version", "Java", r"UnsupportedClassVersionError|has been compiled by a more recent version of the Java Runtime",
    "Java sürümü eski", "Program daha yeni bir Java ile derlenmiş.", ["{INSTALL:java}"])

# ── C / C++ derleme ──
add("c-header", "Derleme", r"fatal error: ([\w/.+-]+\.h): No such file or directory", "Eksik başlık dosyası: {g1}",
    "Derleme için bir geliştirme paketi eksik.", ["{HDR}"])
add("c-compiler", "Derleme", r"(?:^|\s)(gcc|g\+\+|cc|c\+\+|make): (?:command )?not found|No CMAKE_C(?:XX)?_COMPILER could be found|error: command '(?:x86_64-linux-gnu-)?gcc' failed",
    "C/C++ derleyici yok", "Kaynaktan derleme için gcc/make gerekli.", ["{INSTALL:build}"])
add("cmake-missing", "Derleme", r"(?:^|\s)cmake: (?:command )?not found|CMake must be installed|Could not find cmake", "CMake yok", "Proje CMake ile derleniyor.", ["{INSTALL:cmake build}"])
add("cmake-old", "Derleme", r"CMake (\d+\.\d+) or higher is required", "CMake sürümü eski (gereken {g1})", "Dağıtımın CMake'i eski.", ["{PIP} cmake", "# ya da: uv tool install cmake"], auto=False)
add("cmake-pkg", "Derleme", r"Could NOT find (\w+)|Could not find a package configuration file provided by \"(\w+)\"",
    "CMake bağımlılığı bulunamadı: {g1}", "Bir geliştirme kütüphanesi eksik.", ["{CMAKEPKG}"], auto=False)
add("make-target", "Derleme", r"make: \*\*\* No targets specified and no makefile found|No rule to make target", "Makefile yok / hedef bulunamadı",
    "Bu klasörde make ile derleme yapılmıyor ya da önce ./configure veya cmake gerekiyor.", ["# README'deki derleme adımlarına bak (./configure && make ya da cmake)"], auto=False)
add("ld-lib", "Derleme", r"/usr/bin/ld: cannot find -l([\w+-]+)", "Bağlayıcı kütüphaneyi bulamadı: lib{g1}", "lib{g1} geliştirme paketi eksik.", ["{LIBDEV}"], auto=False)

# ── Paylaşımlı kütüphaneler / ikili dosyalar ──
add("so-missing", "Kütüphane", r"error while loading shared libraries: (lib[\w+.-]+?)\.so", "Eksik sistem kütüphanesi: {g1}",
    "Program bu paylaşımlı kütüphaneye ihtiyaç duyuyor.", ["{LIB}"])
add("glibc", "Kütüphane", r"GLIBC_(\d+\.\d+)' not found|GLIBCXX_([\d.]+)' not found", "Sistem çok eski (GLIBC {g1} gerekli)",
    "Hazır ikili dosya daha yeni bir Linux için derlenmiş.", ["# Seçenekler: daha eski sürüm/‘musl’ ikilisini indir, kaynaktan derle ya da Docker ile çalıştır", "# Kalıcı çözüm: dağıtımı güncellemek (ör. Ubuntu 24.04)"], auto=False)
add("exec-format", "İkili", r"Exec format error|cannot execute binary file", "Yanlış mimari (ARM/x86) ya da bozuk dosya",
    "İndirilen program bu işlemci mimarisi için değil.", ["# Doğru mimari için release dosyasını yeniden seç (x86_64/amd64 ya da aarch64/arm64)"], auto=False)
add("perm-exec", "İzin", r"(?:^|: )(\.?/[\w./-]+): Permission denied|bash: \./[\w.-]+: Permission denied|Permission denied \(publickey\)",
    "Çalıştırma izni yok", "Dosya çalıştırılabilir olarak işaretlenmemiş.", ["chmod +x {g1}"])
add("appimage-fuse", "İkili", r"AppImages require FUSE|dlopen\(\): error loading libfuse\.so\.2|fuse: failed to exec fusermount",
    "AppImage için FUSE eksik", "AppImage'lar FUSE 2 kütüphanesi ister.", ["{INSTALL:fuse}", "# Alternatif: ./Uygulama.AppImage --appimage-extract-and-run"])
add("illegal-instr", "İkili", r"Illegal instruction(?: \(core dumped\))?", "İşlemci bu komut setini desteklemiyor (ör. AVX)",
    "Program yeni işlemci özellikleri için derlenmiş.", ["# 'noavx' / 'compat' sürümünü kullan ya da kaynaktan derle"], auto=False)
add("segfault", "İkili", r"Segmentation fault(?: \(core dumped\))?", "Program çöktü (segmentation fault)",
    "Uyumsuz kütüphane, bozuk kurulum ya da program hatası.", ["# 🩺 Doktor ve 🛠 Ajanla onar ile yeniden kurulum dene"], auto=False)
add("text-busy", "İkili", r"Text file busy", "Dosya kullanımda", "Değiştirilmeye çalışılan program şu an çalışıyor.", ["# Aracı durdur (■) ve tekrar dene"], auto=False)

# ── Grafik / ekran ──
add("qt-xcb", "Ekran", r"Could not load the Qt platform plugin \"xcb\"|qt\.qpa\.plugin: Could not|xcb-cursor0 or libxcb-cursor0 is needed",
    "Qt arayüz eklentisi yüklenemedi", "Qt 6 uygulamaları için xcb kütüphaneleri eksik.", ["{INSTALL:xcb}"])
add("no-display", "Ekran", r"cannot open display|Can't open display|no display name and no \$DISPLAY|TclError: no display|Gtk-WARNING \*\*: .*cannot open display",
    "Ekran (DISPLAY) bulunamadı", "Grafik program, grafik oturum olmadan (SSH/sunucu) çalıştırılmış.", ["# Masaüstü oturumunda çalıştır ya da aracın '--headless'/CLI modunu kullan", "# SSH için: ssh -X ile bağlan"], auto=False)
add("libgl", "Ekran", r"libGL\.so\.1: cannot open shared object file|ImportError: libGL\.so|libgthread-2\.0\.so\.0", "OpenGL kütüphanesi eksik (OpenCV vb.)",
    "Görüntü işleme kütüphaneleri OpenGL ister.", ["{INSTALL:gl}", "# Sunucuda: {PIP} opencv-python-headless"])
add("chrome-deps", "Ekran", r"libnss3\.so|Host system is missing dependencies to run browsers|playwright install-deps|Failed to launch the browser process",
    "Tarayıcı (Chromium/Playwright) bağımlılıkları eksik", "Otomasyon tarayıcısı sistem kütüphanelerine ihtiyaç duyar.", ["{INSTALL:chromium_deps}", "# Playwright için: .venv/bin/playwright install chromium"])
add("chrome-root", "Ekran", r"Running as root without --no-sandbox is not supported", "Chrome root ile çalışmıyor",
    "Chrome güvenlik nedeniyle root'ta --no-sandbox ister.", ["# Komutu '--no-sandbox' ile çalıştır ya da normal kullanıcı hesabı kullan"], auto=False)
add("emoji-font", "Ekran", r"emoji font|Noto Color Emoji", "Emoji yazı tipi eksik", "Simgeler kutu olarak görünür.", ["{INSTALL:emoji}"])
add("audio", "Ses", r"ALSA lib .*(?:cannot find card|Unknown PCM)|PortAudio|OSError: PortAudio library not found|No Default Input Device Available",
    "Ses aygıtı/kütüphanesi sorunu", "Ses kütüphanesi eksik ya da mikrofon/hoparlör bulunamadı.", ["{INSTALL:portaudio alsa}"], auto=False)
add("ffmpeg", "Medya", r"(?:^|\s)ffmpeg: (?:command )?not found|ffmpeg (?:is )?not (?:installed|found)|FileNotFoundError: .*'ffmpeg'|Couldn't find ffmpeg|ffprobe (?:not found|is not)",
    "ffmpeg yok", "Video/ses işleme için ffmpeg gerekli.", ["{INSTALL:ffmpeg}"])
add("tesseract", "Medya", r"tesseract is not installed|TesseractNotFoundError", "Tesseract (OCR) yok", "Metin tanıma için gerekli.", ["{INSTALL:tesseract}"])
add("poppler", "Medya", r"Unable to get page count\. Is poppler installed|pdftoppm: (?:command )?not found|PDFInfoNotInstalledError", "Poppler (PDF araçları) yok", "PDF işleme için gerekli.", ["{INSTALL:poppler}"])
add("libmagic", "Kütüphane", r"failed to find libmagic|ImportError: failed to find libmagic", "libmagic eksik", "python-magic sistem kütüphanesi ister.", ["{INSTALL:magic}"])

# ── Paket yöneticisi ──
add("apt-lock", "Paket", r"Could not get lock /var/lib/dpkg/lock|Unable to acquire the dpkg frontend lock|Waiting for cache lock",
    "apt kilitli (başka bir kurulum çalışıyor)", "Arka planda otomatik güncelleme ya da başka bir kurulum var.",
    ["# Birkaç dakika bekle ve tekrar dene", "# Takılı kaldıysa: {SUDO}killall apt apt-get 2>/dev/null; {SUDO}dpkg --configure -a"], auto=False)
add("dpkg-interrupt", "Paket", r"dpkg was interrupted, you must manually run|E: Sub-process /usr/bin/dpkg returned an error code",
    "dpkg yarım kalmış", "Önceki bir kurulum yarıda kesilmiş.", ["{SUDO}dpkg --configure -a", "{SUDO}apt-get install -f -y"])
add("apt-notfound", "Paket", r"E: Unable to locate package ([\w.+-]+)|E: Package '([\w.+-]+)' has no installation candidate|No match for argument: ([\w.+-]+)|error: target not found: ([\w.+-]+)",
    "Paket bulunamadı: {g1}", "Paket listesi eski, paket adı bu dağıtımda farklı ya da 'universe' deposu kapalı.",
    ["{SUDO}apt-get update || true", "{SUDO}add-apt-repository -y universe 2>/dev/null || true"], auto=False)
add("apt-gpg", "Paket", r"NO_PUBKEY ([0-9A-F]+)|The following signatures couldn't be verified|is not signed",
    "Depo imza (GPG) hatası", "Eklenmiş bir üçüncü parti deponun anahtarı eksik/süresi dolmuş.", ["# /etc/apt/sources.list.d/ içindeki sorunlu depoyu kaldır ya da anahtarını yeniden ekle", "{SUDO}apt-get update"], auto=False)
add("apt-broken", "Paket", r"You have held broken packages|unmet dependencies|Depends: .* but it is not going to be installed",
    "Kırık paket bağımlılıkları", "Paketler arasında çakışma var.", ["{SUDO}apt-get update", "{SUDO}apt-get install -f -y", "{SUDO}apt --fix-broken install -y"])
add("dnf-lock", "Paket", r"Waiting for process with pid \d+ to finish|Another app is currently holding the yum lock", "dnf/yum kilitli", "Başka bir kurulum çalışıyor.", ["# Bekle ve tekrar dene"], auto=False)
add("pacman-lock", "Paket", r"unable to lock database|/var/lib/pacman/db\.lck", "pacman kilitli", "Başka bir pacman çalışıyor ya da önceki yarıda kalmış.", ["# pacman çalışmıyorsa: {SUDO}rm -f /var/lib/pacman/db.lck"], auto=False)
add("snap-wsl", "Paket", r"snap .*(?:cannot communicate with server|system does not fully support snapd)|error: cannot communicate with server",
    "snap çalışmıyor (WSL/konteyner)", "snapd bu ortamda (WSL, Docker) desteklenmiyor.", ["# Snap yerine apt/AppImage/Flatpak sürümünü kullan"], auto=False)

# ── İzin / sudo ──
add("not-sudoers", "İzin", r"is not in the sudoers file|is not allowed to run sudo", "Kullanıcının sudo yetkisi yok",
    "Bu hesap yönetici değil.", ["# Root olarak: usermod -aG sudo KULLANICI (Fedora/Arch'ta: wheel), sonra oturumu kapatıp aç"], auto=False)
add("sudo-tty", "İzin", r"sudo: a terminal is required|sudo: no tty present|a password is required", "sudo şifre istiyor",
    "Yönetici izni gereken adım şifresiz çalıştırıldı.", ["# Cypher Tool şifre penceresiyle tekrar çalıştırır"], auto=False)
add("perm-denied", "İzin", r"PermissionError: \[Errno 13\] Permission denied: '([^']+)'|EACCES: permission denied|mkdir: cannot create directory '([^']+)': Permission denied",
    "Erişim izni yok: {g1}", "Dosya/klasör başka kullanıcıya ait ya da korumalı bir yer.", ["{SUDO}chown -R \"$(id -u):$(id -g)\" \"{g1}\" 2>/dev/null || true"], auto=False)
add("readonly-fs", "İzin", r"Read-only file system", "Salt okunur dosya sistemi", "Disk salt okunur bağlanmış (hata/arıza ya da korumalı alan).", ["# Farklı bir klasörde dene; disk hatası olabilir: dmesg | tail"], auto=False)

# ── Docker ──
add("docker-missing", "Docker", r"(?:^|\s)docker: (?:command )?not found|docker compose.*not found|'compose' is not a docker command|docker-compose: (?:command )?not found",
    "Docker / Docker Compose yok", "Bu araç Docker ile çalışıyor.", ["{INSTALL:docker}", "{SUDO}systemctl enable --now docker 2>/dev/null || {SUDO}service docker start", "{SUDO}usermod -aG docker \"$USER\" 2>/dev/null || true"])
add("docker-perm", "Docker", r"permission denied while trying to connect to the Docker daemon socket|Got permission denied .*docker\.sock",
    "Docker izni yok", "Kullanıcı 'docker' grubunda değil.", ["{SUDO}usermod -aG docker \"$USER\"", "# Oturumu kapatıp aç (ya da: newgrp docker)"])
add("docker-daemon", "Docker", r"Cannot connect to the Docker daemon|Is the docker daemon running\?", "Docker servisi çalışmıyor", "Docker arka plan servisi kapalı.",
    ["{SUDO}systemctl start docker 2>/dev/null || {SUDO}service docker start"])
add("docker-port", "Docker", r"Bind for 0\.0\.0\.0:(\d+) failed: port is already allocated", "Port {g1} dolu", "Başka bir program/konteyner aynı portu kullanıyor.",
    ["docker ps --filter publish={g1}", "# Diğer konteyneri durdur ya da port numarasını değiştir"], auto=False)
add("docker-space", "Docker", r"no space left on device.*docker|failed to register layer", "Docker için disk dolu", "Eski imajlar yer kaplıyor.", ["docker system prune -f"], auto=False)

# ── Git ──
add("git-missing", "Git", r"(?:^|\s)git: (?:command )?not found", "git yok", "Depoları indirmek için gerekli.", ["{INSTALL:git}"])
add("git-auth", "Git", r"could not read Username for 'https://github\.com'|Repository not found|Authentication failed for|terminal prompts disabled",
    "Depo bulunamadı ya da gizli", "Link yanlış, depo silinmiş veya gizli (private).", ["# Linki tarayıcıda kontrol et; gizliyse Ayarlar'a GitHub token ekle"], auto=False)
add("git-lfs", "Git", r"git-lfs filter-process|git: 'lfs' is not a git command|This repository is configured for Git LFS", "Git LFS eksik", "Depo büyük dosyalar için Git LFS kullanıyor.",
    ["{INSTALL:gitlfs}", "git lfs install && git lfs pull"])
add("git-dubious", "Git", r"detected dubious ownership in repository", "Git klasör sahipliği uyarısı", "Klasör başka kullanıcıya ait.", ["git config --global --add safe.directory '*'"])
add("git-local-changes", "Git", r"Your local changes to the following files would be overwritten|Not possible to fast-forward", "Güncelleme yerel değişikliklerle çakışıyor",
    "Araç klasöründeki dosyalar değiştirilmiş.", ["git stash", "git pull --ff-only"], auto=False)
add("git-ssl", "Ağ", r"server certificate verification failed|SSL certificate problem", "Git SSL sertifika hatası", "Sertifikalar eksik/eski ya da saat yanlış.", ["{INSTALL:ca}", "{SUDO}update-ca-certificates || true"])

# ── Ağ / port ──
add("port-used", "Ağ", r"Address already in use|EADDRINUSE.*:(\d+)|address already in use.*:(\d+)|OSError: \[Errno 98\]", "Port zaten kullanımda{g1:  ({g1})}",
    "Aracın kullanmak istediği port başka bir program tarafından kullanılıyor (genelde aracın eski bir kopyası).",
    ["{INSTALL:nettools}", "# Portu kullananı bul: lsof -i :PORT  → durdur: fuser -k PORT/tcp", "# ya da aracı farklı portla başlat (--port)"], auto=False)
add("dns", "Ağ", r"Temporary failure in name resolution|Could not resolve host|getaddrinfo (?:ENOTFOUND|EAI_AGAIN)|Name or service not known",
    "İnternet/DNS sorunu", "Adres çözülemiyor; internet bağlantısı veya DNS ayarı sorunlu.", ["# Bağlantıyı kontrol et: ping -c2 1.1.1.1", "# DNS: /etc/resolv.conf içine 'nameserver 1.1.1.1' ekle"], auto=False)
add("conn-refused", "Ağ", r"Connection refused|ECONNREFUSED|Failed to establish a new connection", "Bağlantı reddedildi",
    "Bağlanılmaya çalışılan servis (ör. Ollama, veritabanı) çalışmıyor.", ["# Ollama için: ollama serve &", "# Servisin portunu ve adresini kontrol et"], auto=False)
add("timeout", "Ağ", r"Read timed out|ReadTimeoutError|ETIMEDOUT|Operation timed out|timed out after", "Zaman aşımı", "Ağ yavaş ya da sunucu yanıt vermiyor.", ["# Tekrar dene; proxy/VPN varsa kontrol et"], auto=False)
add("proxy", "Ağ", r"ProxyError|407 Proxy Authentication Required", "Proxy hatası", "Ağ bir proxy üzerinden çıkıyor.", ["# HTTPS_PROXY / HTTP_PROXY ortam değişkenlerini ayarla"], auto=False)

# ── Kaynaklar ──
add("disk-full", "Sistem", r"No space left on device|ENOSPC(?!: System limit)|Disk quota exceeded", "Disk dolu", "Kurulum için yeterli boş alan yok.",
    ["df -h ~ /tmp", "{PIP} cache purge 2>/dev/null || true", "npm cache clean --force 2>/dev/null || true", "{SUDO}apt-get clean 2>/dev/null || true"], auto=False)
add("oom", "Sistem", r"(?:^|\s)Killed(?:\s|$)|Out of memory|MemoryError|signal 9|SIGKILL|exit code 137", "Bellek (RAM) yetersiz — süreç öldürüldü",
    "İşlem RAM'i aştı ve sistem tarafından sonlandırıldı (genelde derleme veya büyük model).",
    ["# Takas alanı (swap) ekle: {SUDO}fallocate -l 4G /swapfile && {SUDO}chmod 600 /swapfile && {SUDO}mkswap /swapfile && {SUDO}swapon /swapfile",
     "# Daha küçük model kullan ya da derlemede paralelliği azalt (make -j2, cargo build -j 2)"], auto=False)
add("too-many-files", "Sistem", r"Too many open files|EMFILE", "Açık dosya sınırı doldu", "Sistem sınırı düşük.", ["ulimit -n 65535"], auto=False)

# ── Yapay zekâ / API ──
add("api-401", "API", r"\b401\b.*(?:Unauthorized|invalid[_ ]api[_ ]key|Incorrect API key)|Invalid API key|invalid x-api-key|authentication_error|API key not valid",
    "API anahtarı geçersiz", "Anahtar yanlış, süresi dolmuş ya da yanlış servise ait.", ["# API'ler sekmesinden anahtarı kontrol et/yenile ve ⚡ Test et"], auto=False)
add("api-key-missing", "API", r"(OPENAI_API_KEY|ANTHROPIC_API_KEY|GEMINI_API_KEY|GOOGLE_API_KEY|OPENROUTER_API_KEY|GROQ_API_KEY|MISTRAL_API_KEY|DEEPSEEK_API_KEY)[^\n]{0,40}(?:not set|is not set|missing|must be set|environment variable)|api_key (?:client option )?must be set|No API key (?:provided|found)",
    "API anahtarı tanımlı değil: {g1}", "Araç bu ortam değişkenini bekliyor.", ["# API'ler sekmesinde ilgili servisi ekle; 'ortam değişkeni' alanına {g1} yaz. Araç kartında ⚙️ → 'API anahtarlarımı aktar' açık olmalı."], auto=False)
add("api-429", "API", r"\b429\b|rate[ _-]?limit|Too Many Requests|quota exceeded|RESOURCE_EXHAUSTED|insufficient_quota", "API kotası/limit doldu",
    "Ücretsiz kota bitti ya da çok hızlı istek atıldı.", ["# Biraz bekle, başka bir API'ye geç (failover açık) ya da başka ücretsiz servis ekle"], auto=False)
add("api-model", "API", r"model[_ ]not[_ ]found|The model `?([\w./:-]+)`? does not exist|Unknown model|model .* is not supported|404 .*model",
    "Model bulunamadı{g1:: {g1}}", "Model adı yanlış ya da bu serviste yok.", ["# API'ler sekmesinde ✏️ → 'Listele' ile mevcut modelleri gör ve seç"], auto=False)
add("ollama-down", "API", r"(?:11434).*(?:refused|Connection)|ollama.*(?:could not connect|not running)|Error: could not connect to ollama", "Ollama çalışmıyor",
    "Yerel model sunucusu kapalı.", ["ollama serve > /dev/null 2>&1 &"], auto=False)
add("ollama-model", "API", r"model ['\"]?([\w.:/-]+)['\"]? not found, try pulling it first|pull model manifest: file does not exist", "Ollama modeli inmemiş: {g1}",
    "Model indirilmemiş.", ["ollama pull {g1}"])
add("context-length", "API", r"context[_ ]length[_ ]exceeded|maximum context length|prompt is too long|too many tokens", "Metin modele sığmıyor",
    "Gönderilen metin modelin bağlam sınırını aşıyor.", ["# Daha kısa girdi ver ya da daha büyük bağlamlı model seç"], auto=False)

# ── Diğer sık hatalar ──
add("env-file", "Yapılandırma", r"\.env (?:file )?not found|Could not find \.env|No \.env file|copy \.env\.example", ".env dosyası yok",
    "Araç ayarlarını .env dosyasından okuyor.", ["[ -f .env ] || cp .env.example .env 2>/dev/null || cp .env.sample .env 2>/dev/null || touch .env", "# .env içine gerekli anahtarları yaz"])
add("config-missing", "Yapılandırma", r"(?:config|configuration) file (?:not found|does not exist)|No such file or directory: '([\w./-]*config[\w./-]*)'",
    "Yapılandırma dosyası eksik{g1: ({g1})}", "Araç ilk çalıştırmadan önce bir ayar dosyası bekliyor.", ["# README'deki 'config' adımına bak; örnek dosya varsa kopyala (config.example → config)"], auto=False)
add("locale", "Sistem", r"locale\.Error: unsupported locale setting|Cannot set LC_ALL|UnicodeEncodeError: 'ascii' codec", "Dil/kodlama (locale) ayarı sorunu",
    "Sistem dili UTF-8 olarak ayarlı değil.", ["export LANG=C.UTF-8 LC_ALL=C.UTF-8", "# Kalıcı: {SUDO}locale-gen tr_TR.UTF-8 en_US.UTF-8"], auto=False)
add("node-npx-cache", "Node", r"npm ERR! code ENOTEMPTY|npm error code ENOTEMPTY", "npm önbelleği bozuk", "Yarım kalan kurulum.", ["rm -rf node_modules", "npm cache clean --force", "npm install"])
add("python-cmd-missing", "Python", r"(?:^|\s)python3: (?:command )?not found", "Python 3 yok", "Python kurulu değil.", ["{INSTALL:venv pip}", "@runtime uv"])
add("uv-missing", "Python", r"(?:^|\s)uvx?: (?:command )?not found", "uv yok", "Modern Python araç yöneticisi gerekli.", ["@runtime uv"])
add("cmd-generic", "Sistem", r"(?:^|\s|: )([\w.+-]+): (?:command )?not found|([\w.+-]+): komut bulunamadı", "Eksik program: {g1}",
    "Gerekli bir program kurulu değil.", ["{CMDPKG}"])
add("selinux", "İzin", r"avc:  denied|SELinux is preventing", "SELinux engelledi", "Fedora/RHEL güvenlik politikası erişimi engelledi.", ["# Geçici test: {SUDO}setenforce 0 (önerilmez); kalıcı çözüm için uygun bağlam/izin ekle"], auto=False)
add("wsl-systemd", "WSL", r"System has not been booted with systemd|Failed to connect to bus: Host is down", "systemd çalışmıyor (WSL/konteyner)",
    "WSL'de systemd kapalı olabilir.", ["{SUDO}sh -c 'printf \"[boot]\\nsystemd=true\\n\" >> /etc/wsl.conf'", "# PowerShell'de: wsl --shutdown ve Ubuntu'yu yeniden aç"], auto=False)
add("hf-token", "API", r"huggingface.*(?:401|gated|Access to model .* is restricted)|You are trying to access a gated repo", "Hugging Face erişimi gerekiyor",
    "Model indirilmesi için HF hesabı/izin gerekiyor.", ["# huggingface.co'da modelin sayfasında erişim iste, token oluştur ve HF_TOKEN olarak API'ler sekmesine ekle"], auto=False)
add("playwright-browsers", "Ekran", r"Executable doesn't exist at .*ms-playwright|playwright install", "Playwright tarayıcısı inmemiş", "Tarayıcı otomasyonu için indirilmesi gerekiyor.",
    [".venv/bin/playwright install chromium 2>/dev/null || npx playwright install chromium", "{INSTALL:chromium_deps}"])

CMDS = {"python3": "venv", "python": "pyisp", "pip": "pip", "pip3": "pip", "git": "git", "curl": "curl", "make": "build", "gcc": "build", "g++": "build",
        "cc": "build", "cmake": "cmake", "pkg-config": "pkgconf", "ffmpeg": "ffmpeg", "ffprobe": "ffmpeg", "unzip": "unzip", "7z": "7z", "xdg-open": "xdg",
        "notify-send": "notify", "java": "java", "javac": "java", "go": "golang", "cargo": "rustc", "rustc": "rustc", "dos2unix": "dos2unix", "lsof": "nettools",
        "fuser": "nettools", "tesseract": "tesseract", "pdftoppm": "poppler", "docker": "docker", "git-lfs": "gitlfs"}
CMAKE_PKGS = {"OpenSSL": "ssl", "ZLIB": "zlib", "CURL": "curldev", "PkgConfig": "pkgconf", "Python3": "pydev", "PythonLibs": "pydev",
              "X11": "x11", "ALSA": "alsa", "PostgreSQL": "pq", "SQLite3": "sqlite", "LibXml2": "xml", "JPEG": "jpeg", "PNG": "jpeg", "GTK3": "gtk3", "Threads": "build"}

out = {"version": 1, "packages": P, "headers": HEADERS, "libs": LIBS, "commands": CMDS, "cmake": CMAKE_PKGS, "errors": E}
json.dump(out, open("hata_bankasi.json", "w"), ensure_ascii=False, indent=1)
print(len(E), "hata kaydı yazıldı")
