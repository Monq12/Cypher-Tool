# Cypher Tool

GitHub araçlarını **tek linkle** kuran, eksiklerini tamamlayan ve hepsini tek bir uygulamadan çalıştıran Linux uygulaması. İçinde çoklu API destekli yapay zekâ ajanları da var.

## Kurulum

```bash
unzip cyphertool.zip && cd cyphertool
bash kur.sh
```

Kurulum betiği şunları yapar:
- Eksikse `python3` ve `git` paketlerini kurar.
- Uygulamayı `~/.local/share/cyphertool` klasörüne kopyalar.
- Menüye ve masaüstüne **Cypher Tool** kısayolunu ekler.
- `cyphertool` ve `ct` komutlarını oluşturur.
- Günlük güncelleme kontrolünü açar (systemd --user).

**Tek satırla kurulum (isteğe bağlı):** Bu klasörü kendi GitHub hesabına `cyphertool` adıyla yükle. Ardından `kur.sh` içindeki `REPO_URL` satırını kendi deponla değiştir. Bundan sonra herhangi bir Linux'ta şu komut yeterli:
```bash
curl -fsSL https://raw.githubusercontent.com/KULLANICI/cyphertool/main/kur.sh | bash
```

## Kullanım

| Ne | Nasıl |
|---|---|
| Uygulamayı aç | Menü veya masaüstündeki **Cypher Tool**, ya da `cyphertool` |
| Terminalden kur | `ct https://github.com/sahip/proje` |
| Toplu kur | `ct link1 link2 link3` (uygulamada: Kur → her satıra bir link) |
| Listele / çalıştır | `cyphertool liste` · `cyphertool calistir <ad>` |
| Güncellemeler | `cyphertool kontrol` · `cyphertool guncelle` |
| Taşı | `cyphertool disa-aktar --tam` → diğer bilgisayarda `cyphertool ice-aktar dosya.tar.gz` |

## Özellikler

- **Link at, kurulsun.** GitHub reposu, kısa yazım (`sahip/proje`), rar/zip/7z/tar arşivi, AppImage veya yerel dosya kabul edilir.
  - README dosyaları okunur. Arşivlerin içindekiler de dahildir.
  - Kurulum planı çıkarılır ve **önce sana gösterilir**. İstersen düzenleyebilirsin.
- **Eksikleri kendisi tamamlar.**
  - Sistem paketleri dağıtıma göre kurulur (apt, dnf, pacman, zypper, apk).
  - Node.js 22 ve uv/Python **sudo'suz** olarak kendi klasörüne indirilir.
  - Koddaki `import` satırlarından eksik Python kütüphaneleri bulunur.
  - Kurulum hatasında "command not found" veya "No module named" mesajları yakalanır ve düzeltme önerilir.
  - Yapay zekâ bağlıysa hata çıktısı ona sorulur.
- **🩺 Doktor:** Kurulu bir aracı tarar (eksik kütüphane, bozuk .venv, eksik node_modules, kayıp çalıştırılabilir dosya) ve onarır.
- **Uygulama içinden çalıştırma.** Gerçek bir terminal (xterm) kullanılır, bu yüzden TUI araçlar da çalışır. İstersen ayrı terminal penceresinde de açabilirsin. Masaüstü kısayolları **repo logosuyla** oluşturulur.
- **📘 Türkçe rehber.** Her araç için ne işe yaradığı ve nasıl kullanıldığı yazılır. İngilizce veya başka dildeki README'ler Türkçeye çevrilir.
- **📚 Kütüphane:** GitHub tam adı, açıklama, yıldız, dil, lisans ve sürüm bilgileri.
- **🔑 Çoklu API.** OpenAI, Anthropic, Gemini, OpenRouter, Groq, Mistral, Cerebras, GitHub Models, DeepSeek, xAI, Ollama, LM Studio ve özel OpenAI uyumlu servisler desteklenir.
  - Bir API hata verirse sıradakine otomatik geçilir.
  - Anahtarlar kurulan araçlara ortam değişkeni olarak aktarılır.
- **🤖 Ajanlar.**
  - Her ajana ayrı API, model ve kişilik verilebilir.
  - Bir aracı bağlam olarak seçersen ajan o aracın README'sini bilir.
  - Ajanın önerdiği komutlar onayınla tek tıkla çalışır.
  - "Tüm ajanlara sor" seçeneği soruyu hepsine birden gönderir.
- **🆓 Ücretsiz AI.**
  - Ollama ile anahtarsız yerel modeller kurulabilir; donanımına göre öneri yapılır.
  - Anahtarsız uç noktalar canlı test edilir ve çalışanlar otomatik eklenir.
  - Ücretsiz anahtar veren servislerin listesi ve GitHub'daki ücretsiz API listeleri gösterilir.
- **🔄 Güncellemeler.** Her gün kontrol edilir. Her araç için mod ayrı seçilir: Sor, Otomatik veya Kapalı.
- **📦 Dışa/İçe aktar:** İki seçenek var: hafif `.json` (kaynaktan yeniden kurar) ya da tam `.tar.gz` (dosyalar dahil).
- **🔐 Yönetici şifresi.** sudo gerektiğinde uygulamada "şifreni gir" penceresi açılır.
  - Şifre yalnızca o adım için kullanılır, hiçbir yere kaydedilmez.
  - İstersen sistemin kendi parola penceresi (pkexec) de kullanılabilir.

## 🎯 Görev Ajanı

Ne istediğini düz Türkçe yaz: *"İndirilenler'deki videoları mp3'e çevir"*, *"PDF birleştiren bir araç bul, kur ve dene"*, *"Terminalde hava durumunu gösteren bir araç yaz"*.

Ajan şu sırayla çalışır:
1. Önce kurulu araçlarına bakar.
2. Uygun araç yoksa GitHub'da arar, adayları karşılaştırır, en iyisini **kurar**, **dener** ve görevi o araçla **yapar**.
3. Uygun araç hiç yoksa kendi kodunu yazıp yeni bir araç **geliştirir**, test eder ve Cypher Tool'a ekler.

Ajan seninle konuşarak çalışır:
- Belirsiz bir yerde soru sorar.
- Bir aracı tanıyınca "Bu araçla şunları yapabilirim…" diye seçenekler sunar.
- Senin talimatına göre devam eder.

Beyni senin eklediğin API'lerden biridir; hangisini kullanacağını sen seçersin. İstersen Ajanlar sekmesindeki bir ajanın kişiliğini de ona giydirebilirsin.

**Ona öğretmek için:**
- **📜 Talimatlar:** Her görevde en yüksek öncelikle uyacağı kalıcı kurallar.
- **Sohbette öğretmek:** "bunu hatırla: …" ya da "bundan sonra hep …" dersen kalıcı tercih olarak kaydeder.
- **🧠 Hafıza:** Öğrendiği notları gör, ekle veya sil. Her oturum sonunda kendisi de ders çıkarıp buraya yazar.
- **Öğrenilmiş tarifler:** Başarıyla kurduğu araçların tarifleri saklanır; aynı araç bir dahaki sefere analiz edilmeden kurulur.

Varsayılan olarak her komut ve kurulum planı senin onayınla çalışır. "Komutları sormadan çalıştır" seçeneği açıksa planlar otomatik onaylanır; şifre ve sorular yine sorulur.
Terminalden de kullanabilirsin: `ct gorev "istediğin iş"`

## Hazır katalog (test edilmiş tarifler)

deep-research (drsh), Flint Agent, clai (pentoshi007), clai (baalimago), gptme, OpenSquilla, ARIA, Aider, Local Deep Research, Open WebUI.

## Güvenlik

- Hiçbir komut onayın olmadan çalışmaz. Riskli komutlar (`curl | sh`, `rm -rf /` vb.) ayrıca işaretlenir.
- Arayüz sadece `127.0.0.1` adresinde çalışır ve her istek oturuma özel rastgele bir anahtarla korunur.
- Release dosyalarının SHA256 sağlaması mümkün olduğunda doğrulanır.
- API anahtarları `~/.config/cyphertool/` altında yalnızca senin okuyabileceğin dosyalarda (izin 600) tutulur.

## Klasörler

- `~/CypherTool/tools/`: kurulan araçlar
- `~/CypherTool/runtimes/`: sudo'suz Node.js, uv ve Python
- `~/CypherTool/exports/`: dışa aktarımlar
- `~/.config/cyphertool/`: ayarlar, API'ler, araç kayıtları

Gereksinimler: Linux, Python 3.9+, git. Arayüz için Chromium, Chrome, Brave veya Firefox önerilir; uygulama penceresi gibi açılır.
Windows'ta WSL2 (Ubuntu) içinde çalışır.
